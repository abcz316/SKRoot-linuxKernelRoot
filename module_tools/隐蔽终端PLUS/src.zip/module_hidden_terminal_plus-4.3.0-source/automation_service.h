#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace automation {

struct Error {
    std::string code;
    std::string message;
    int sys_errno = 0;
};

struct InputAction {
    std::string id;
    uint64_t after_ms = 0;
    std::string text;
    bool append_enter = true;
};

struct Step {
    std::string id;
    std::string type;
    std::string path;
    std::vector<std::string> args;
    std::string command;
    uint64_t wait_ms = 0;
    std::vector<InputAction> inputs;
};

struct Scheme {
    std::string id;
    std::string name;
    bool favorite = false;
    std::string failure_policy = "stop";
    int64_t created_at_ms = 0;
    int64_t updated_at_ms = 0;
    std::vector<Step> steps;
};

struct Draft {
    std::string scheme_id;
    std::string name;
    std::string failure_policy = "stop";
    std::vector<Step> steps;
};

struct Config {
    uint64_t revision = 0;
    Draft draft;
    std::vector<Scheme> schemes;
};

struct StepResult {
    std::string id;
    std::string type;
    std::string state = "pending";
    int exit_code = 0;
    std::string message;
    int64_t started_at_ms = 0;
    int64_t ended_at_ms = 0;
    size_t sent_inputs = 0;
    size_t skipped_inputs = 0;
};

struct RunSnapshot {
    std::string id;
    std::string state = "idle";
    std::string scheme_id;
    std::string name;
    std::string failure_policy = "stop";
    size_t current_step = 0;
    size_t total_steps = 0;
    size_t success_count = 0;
    size_t failure_count = 0;
    int64_t started_at_ms = 0;
    int64_t ended_at_ms = 0;
    std::vector<StepResult> steps;
    std::vector<Error> errors;
};

struct ApiReply {
    int status = 200;
    std::string body;
};

class TerminalTransport {
public:
    using ControlFrameHandler = std::function<bool(const std::string&)>;
    virtual ~TerminalTransport() = default;
    virtual bool sendText(const std::string& text, bool append_enter) = 0;
    virtual bool sendAutomationCommand(const std::string& command) = 0;
    virtual void finishAutomationCommand() = 0;
    // Idle is used only by terminal lifecycle cleanup. Automation deliberately
    // does not consult it: a saved scheme is a force-run byte sequence.
    virtual bool isShellIdle() const = 0;
    virtual bool hasShellIdleState() const { return true; }
    virtual bool isAlive() const = 0;
    virtual void setControlFrameHandler(ControlFrameHandler handler) = 0;
};

class ConfigStore {
public:
    bool load(Config& config, Error& error, bool migrate_legacy = true);
    bool save(uint64_t expected_revision, const Config& desired, Config& saved, Error& error);
    bool replaceDraftFromLegacy(const std::string& legacy_json, Config& saved, Error& error);
    std::string legacyDraftJson(Error& error);

    static bool validate(const Config& config, Error& error);
    static std::string toJson(const Config& config);
    static bool fromJson(const std::string& json, Config& config, Error& error);
};

class AutomationManager {
public:
    AutomationManager();
    ~AutomationManager();

    void configure(TerminalTransport* terminal, std::string hidden_work_dir);
    bool start(const Scheme& scheme, RunSnapshot& snapshot, Error& error);
    RunSnapshot snapshot() const;
    bool cancel(const std::string& run_id, RunSnapshot& snapshot, Error& error);
    bool isActive() const;
    void shutdown();

private:
    bool preflight(const Scheme& scheme, Error& error) const;
    bool handleControlFrame(const std::string& frame);
    void workerMain(Scheme scheme, std::string run_id, std::string token);
    bool runWaitStep(const Step& step, size_t index);
    bool runCommandStep(const Step& step, size_t index, const std::string& token);
    void finishRun(const std::string& state);

    mutable std::mutex m_mu;
    std::condition_variable m_cv;
    TerminalTransport* m_terminal = nullptr;
    std::string m_hidden_work_dir;
    std::thread m_worker;
    RunSnapshot m_snapshot;
    bool m_shutdown_requested = false;
    bool m_frame_ready = false;
    size_t m_frame_step = 0;
    int m_frame_exit_code = 0;
    std::string m_frame_token;
};

class AutomationApi {
public:
    AutomationApi();
    ~AutomationApi();

    void configure(TerminalTransport* terminal, const std::string& hidden_work_dir);
    ApiReply handle(const std::string& path, const std::string& body);
    std::string legacyGetTasks();
    bool legacySaveTasks(const std::string& body, Error& error);
    bool isRunActive() const;
    void shutdown();

private:
    ApiReply handleConfigGet();
    ApiReply handleConfigSet(const std::string& body);
    ApiReply handleRunStart(const std::string& body);
    ApiReply handleRunStatus(const std::string& body);
    ApiReply handleRunCancel(const std::string& body);

    mutable std::mutex m_mu;
    ConfigStore m_store;
    AutomationManager m_manager;
};

} // namespace automation
