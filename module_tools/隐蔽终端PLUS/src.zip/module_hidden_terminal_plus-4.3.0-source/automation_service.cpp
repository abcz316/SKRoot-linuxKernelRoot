#include "automation_service.h"

#include "cJSON.h"
#include "module_base_disk_storage.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <fstream>
#include <memory>
#include <random>
#include <set>
#include <signal.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>

namespace automation {
namespace {

namespace fs = std::filesystem;
using JsonPtr = std::unique_ptr<cJSON, decltype(&cJSON_Delete)>;

constexpr const char* kConfigStorageKey = "automation_config_v1";
constexpr const char* kLegacyStorageKey = "auto_tasks";
constexpr size_t kMaxSchemes = 50;
constexpr size_t kMaxFavoriteSchemes = 6;
constexpr size_t kMaxSteps = 100;
constexpr size_t kMaxInputs = 32;
constexpr size_t kMaxTextBytes = 8 * 1024;
constexpr size_t kMaxArgs = 64;
constexpr uint64_t kMaxDurationMs = 24ULL * 60ULL * 60ULL * 1000ULL;

JsonPtr makeJson(cJSON* value) { return JsonPtr(value, cJSON_Delete); }

std::string printJson(const cJSON* value) {
    char* text = cJSON_PrintUnformatted(value);
    if (!text) return "{}";
    std::string result(text);
    cJSON_free(text);
    return result;
}

int64_t nowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

std::string randomHex(size_t bytes) {
    std::vector<unsigned char> data(bytes);
    int fd = ::open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    size_t offset = 0;
    if (fd >= 0) {
        while (offset < data.size()) {
            const ssize_t count = ::read(fd, data.data() + offset, data.size() - offset);
            if (count > 0) offset += static_cast<size_t>(count);
            else if (count < 0 && errno == EINTR) continue;
            else break;
        }
        ::close(fd);
    }
    if (offset != data.size()) {
        std::random_device device;
        for (size_t index = offset; index < data.size(); ++index) data[index] = static_cast<unsigned char>(device());
    }
    static constexpr char digits[] = "0123456789abcdef";
    std::string result;
    result.reserve(bytes * 2);
    for (unsigned char value : data) {
        result.push_back(digits[value >> 4]);
        result.push_back(digits[value & 0x0f]);
    }
    return result;
}

bool activeState(const std::string& state) {
    return state == "preparing" || state == "running";
}

std::string shellQuote(const std::string& value) {
    std::string result = "'";
    for (char ch : value) {
        if (ch == '\'') result += "'\\''";
        else result.push_back(ch);
    }
    result.push_back('\'');
    return result;
}

std::string dirname(const std::string& path) {
    const size_t slash = path.rfind('/');
    if (slash == std::string::npos) return ".";
    if (slash == 0) return "/";
    return path.substr(0, slash);
}

bool validId(const std::string& value, bool allow_empty = false) {
    if (value.empty()) return allow_empty;
    if (value.size() > 96) return false;
    return std::all_of(value.begin(), value.end(), [](unsigned char ch) {
        return std::isalnum(ch) || ch == '_' || ch == '-';
    });
}

bool validPolicy(const std::string& value) { return value == "stop" || value == "continue"; }

bool getString(cJSON* root, const char* key, std::string& output, bool required, Error& error) {
    cJSON* item = cJSON_GetObjectItemCaseSensitive(root, key);
    if (!item && !required) {
        output.clear();
        return true;
    }
    if (!cJSON_IsString(item) || !item->valuestring) {
        error = {"INVALID_ARGUMENT", std::string("Field '") + key + "' must be a string", EINVAL};
        return false;
    }
    output = item->valuestring;
    return true;
}

bool getBool(cJSON* root, const char* key, bool& output, bool default_value, Error& error) {
    cJSON* item = cJSON_GetObjectItemCaseSensitive(root, key);
    if (!item) {
        output = default_value;
        return true;
    }
    if (!cJSON_IsBool(item)) {
        error = {"INVALID_ARGUMENT", std::string("Field '") + key + "' must be a boolean", EINVAL};
        return false;
    }
    output = cJSON_IsTrue(item);
    return true;
}

bool getNumber(cJSON* root, const char* key, double& output, double default_value, Error& error) {
    cJSON* item = cJSON_GetObjectItemCaseSensitive(root, key);
    if (!item) {
        output = default_value;
        return true;
    }
    if (!cJSON_IsNumber(item) || !std::isfinite(item->valuedouble)) {
        error = {"INVALID_ARGUMENT", std::string("Field '") + key + "' must be a number", EINVAL};
        return false;
    }
    output = item->valuedouble;
    return true;
}

bool getUint(cJSON* root, const char* key, uint64_t& output, uint64_t default_value, Error& error) {
    double value = 0;
    if (!getNumber(root, key, value, static_cast<double>(default_value), error)) return false;
    if (value < 0 || std::floor(value) != value || value > 9007199254740991.0) {
        error = {"INVALID_ARGUMENT", std::string("Field '") + key + "' must be a non-negative integer", EINVAL};
        return false;
    }
    output = static_cast<uint64_t>(value);
    return true;
}

bool getInt64(cJSON* root, const char* key, int64_t& output, int64_t default_value, Error& error) {
    double value = 0;
    if (!getNumber(root, key, value, static_cast<double>(default_value), error)) return false;
    if (std::floor(value) != value || value < -9007199254740991.0 || value > 9007199254740991.0) {
        error = {"INVALID_ARGUMENT", std::string("Field '") + key + "' must be an integer", EINVAL};
        return false;
    }
    output = static_cast<int64_t>(value);
    return true;
}

cJSON* inputJson(const InputAction& input) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "id", input.id.c_str());
    cJSON_AddNumberToObject(root, "afterSec", static_cast<double>(input.after_ms) / 1000.0);
    cJSON_AddStringToObject(root, "text", input.text.c_str());
    cJSON_AddBoolToObject(root, "appendEnter", input.append_enter);
    return root;
}

cJSON* stepJson(const Step& step) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "id", step.id.c_str());
    cJSON_AddStringToObject(root, "type", step.type.c_str());
    if (step.type == "script") {
        cJSON_AddStringToObject(root, "path", step.path.c_str());
        cJSON* args = cJSON_CreateArray();
        for (const auto& arg : step.args) cJSON_AddItemToArray(args, cJSON_CreateString(arg.c_str()));
        cJSON_AddItemToObject(root, "args", args);
    } else if (step.type == "command") {
        cJSON_AddStringToObject(root, "command", step.command.c_str());
    } else if (step.type == "wait") {
        cJSON_AddNumberToObject(root, "seconds", static_cast<double>(step.wait_ms) / 1000.0);
    }
    if (step.type == "script" || step.type == "command") {
        cJSON* inputs = cJSON_CreateArray();
        for (const auto& input : step.inputs) cJSON_AddItemToArray(inputs, inputJson(input));
        cJSON_AddItemToObject(root, "inputs", inputs);
    }
    return root;
}

cJSON* draftJson(const Draft& draft) {
    cJSON* root = cJSON_CreateObject();
    if (draft.scheme_id.empty()) cJSON_AddNullToObject(root, "schemeId");
    else cJSON_AddStringToObject(root, "schemeId", draft.scheme_id.c_str());
    cJSON_AddStringToObject(root, "name", draft.name.c_str());
    cJSON_AddStringToObject(root, "failurePolicy", draft.failure_policy.c_str());
    cJSON* steps = cJSON_CreateArray();
    for (const auto& step : draft.steps) cJSON_AddItemToArray(steps, stepJson(step));
    cJSON_AddItemToObject(root, "steps", steps);
    return root;
}

cJSON* schemeJson(const Scheme& scheme) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "id", scheme.id.c_str());
    cJSON_AddStringToObject(root, "name", scheme.name.c_str());
    cJSON_AddBoolToObject(root, "favorite", scheme.favorite);
    cJSON_AddStringToObject(root, "failurePolicy", scheme.failure_policy.c_str());
    cJSON_AddNumberToObject(root, "createdAtMs", static_cast<double>(scheme.created_at_ms));
    cJSON_AddNumberToObject(root, "updatedAtMs", static_cast<double>(scheme.updated_at_ms));
    cJSON* steps = cJSON_CreateArray();
    for (const auto& step : scheme.steps) cJSON_AddItemToArray(steps, stepJson(step));
    cJSON_AddItemToObject(root, "steps", steps);
    return root;
}

cJSON* configJson(const Config& config) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddNumberToObject(root, "revision", static_cast<double>(config.revision));
    cJSON_AddItemToObject(root, "draft", draftJson(config.draft));
    cJSON* schemes = cJSON_CreateArray();
    for (const auto& scheme : config.schemes) cJSON_AddItemToArray(schemes, schemeJson(scheme));
    cJSON_AddItemToObject(root, "schemes", schemes);
    return root;
}

bool parseInput(cJSON* root, InputAction& input, Error& error) {
    if (!cJSON_IsObject(root)
        || !getString(root, "id", input.id, true, error)
        || !getString(root, "text", input.text, true, error)
        || !getBool(root, "appendEnter", input.append_enter, true, error)) return false;
    double seconds = 0;
    if (!getNumber(root, "afterSec", seconds, 0, error) || seconds < 0 || seconds * 1000.0 > kMaxDurationMs) {
        error = {"INVALID_ARGUMENT", "Automatic input delay must be between 0 and 86400 seconds", EINVAL};
        return false;
    }
    input.after_ms = static_cast<uint64_t>(std::llround(seconds * 1000.0));
    return true;
}

bool parseStep(cJSON* root, Step& step, Error& error) {
    if (!cJSON_IsObject(root)
        || !getString(root, "id", step.id, true, error)
        || !getString(root, "type", step.type, true, error)) return false;
    if (step.type == "script") {
        if (!getString(root, "path", step.path, true, error)) return false;
        cJSON* args = cJSON_GetObjectItemCaseSensitive(root, "args");
        if (!cJSON_IsArray(args) || cJSON_GetArraySize(args) > static_cast<int>(kMaxArgs)) {
            error = {"INVALID_ARGUMENT", "Script args must be an array with at most 64 items", EINVAL};
            return false;
        }
        cJSON* arg = nullptr;
        cJSON_ArrayForEach(arg, args) {
            if (!cJSON_IsString(arg) || !arg->valuestring) {
                error = {"INVALID_ARGUMENT", "Script arguments must be strings", EINVAL};
                return false;
            }
            step.args.emplace_back(arg->valuestring);
        }
    } else if (step.type == "command") {
        if (!getString(root, "command", step.command, true, error)) return false;
    } else if (step.type == "wait") {
        double seconds = 0;
        if (!getNumber(root, "seconds", seconds, 0, error) || seconds < 0 || seconds * 1000.0 > kMaxDurationMs) {
            error = {"INVALID_ARGUMENT", "Wait duration must be between 0 and 86400 seconds", EINVAL};
            return false;
        }
        step.wait_ms = static_cast<uint64_t>(std::llround(seconds * 1000.0));
        return true;
    } else {
        error = {"INVALID_ARGUMENT", "Unknown automation step type", EINVAL};
        return false;
    }

    // timeoutSec was accepted by 4.2.2. Read it as a legacy field but do not
    // preserve or execute it; the 4.2.6 serializer deliberately drops it.
    cJSON* inputs = cJSON_GetObjectItemCaseSensitive(root, "inputs");
    if (!inputs) return true;
    if (!cJSON_IsArray(inputs) || cJSON_GetArraySize(inputs) > static_cast<int>(kMaxInputs)) {
        error = {"INVALID_ARGUMENT", "Automatic inputs must be an array with at most 32 items", EINVAL};
        return false;
    }
    cJSON* input_item = nullptr;
    cJSON_ArrayForEach(input_item, inputs) {
        InputAction input;
        if (!parseInput(input_item, input, error)) return false;
        step.inputs.push_back(std::move(input));
    }
    std::stable_sort(step.inputs.begin(), step.inputs.end(), [](const InputAction& left, const InputAction& right) {
        return left.after_ms < right.after_ms;
    });
    return true;
}

bool parseSteps(cJSON* root, std::vector<Step>& steps, Error& error) {
    if (!cJSON_IsArray(root) || cJSON_GetArraySize(root) > static_cast<int>(kMaxSteps)) {
        error = {"INVALID_ARGUMENT", "Steps must be an array with at most 100 items", EINVAL};
        return false;
    }
    cJSON* item = nullptr;
    cJSON_ArrayForEach(item, root) {
        Step step;
        if (!parseStep(item, step, error)) return false;
        steps.push_back(std::move(step));
    }
    return true;
}

bool parseDraft(cJSON* root, Draft& draft, Error& error) {
    if (!cJSON_IsObject(root)) {
        error = {"INVALID_ARGUMENT", "Field 'draft' must be an object", EINVAL};
        return false;
    }
    cJSON* scheme_id = cJSON_GetObjectItemCaseSensitive(root, "schemeId");
    if (cJSON_IsString(scheme_id) && scheme_id->valuestring) draft.scheme_id = scheme_id->valuestring;
    else if (!cJSON_IsNull(scheme_id) && scheme_id) {
        error = {"INVALID_ARGUMENT", "Draft schemeId must be a string or null", EINVAL};
        return false;
    }
    return getString(root, "name", draft.name, true, error)
        && getString(root, "failurePolicy", draft.failure_policy, true, error)
        && parseSteps(cJSON_GetObjectItemCaseSensitive(root, "steps"), draft.steps, error);
}

bool parseScheme(cJSON* root, Scheme& scheme, Error& error) {
    if (!cJSON_IsObject(root)
        || !getString(root, "id", scheme.id, true, error)
        || !getString(root, "name", scheme.name, true, error)
        || !getBool(root, "favorite", scheme.favorite, false, error)
        || !getString(root, "failurePolicy", scheme.failure_policy, true, error)
        || !getInt64(root, "createdAtMs", scheme.created_at_ms, 0, error)
        || !getInt64(root, "updatedAtMs", scheme.updated_at_ms, 0, error)) return false;
    return parseSteps(cJSON_GetObjectItemCaseSensitive(root, "steps"), scheme.steps, error);
}

bool validateSteps(const std::vector<Step>& steps, Error& error, bool require_runnable = true) {
    if (steps.size() > kMaxSteps) {
        error = {"INVALID_ARGUMENT", "A scheme may contain at most 100 steps", E2BIG};
        return false;
    }
    if (require_runnable && steps.empty()) {
        error = {"INVALID_ARGUMENT", "An automation scheme must contain at least one step", EINVAL};
        return false;
    }
    std::set<std::string> ids;
    for (const auto& step : steps) {
        if (!validId(step.id) || !ids.insert(step.id).second) {
            error = {"INVALID_ARGUMENT", "Step IDs must be unique alphanumeric identifiers", EINVAL};
            return false;
        }
        if (step.type == "script") {
            if ((require_runnable && step.path.empty())
                || (!step.path.empty() && step.path.front() != '/') || step.path.size() > 4096) {
                error = {"INVALID_ARGUMENT", "Script path must be an absolute path", EINVAL};
                return false;
            }
            size_t arg_bytes = 0;
            if (step.args.size() > kMaxArgs) {
                error = {"INVALID_ARGUMENT", "A script may contain at most 64 arguments", E2BIG};
                return false;
            }
            for (const auto& arg : step.args) arg_bytes += arg.size();
            if (arg_bytes > kMaxTextBytes) {
                error = {"INVALID_ARGUMENT", "Script arguments are too large", E2BIG};
                return false;
            }
        } else if (step.type == "command") {
            if ((require_runnable && step.command.empty()) || step.command.size() > kMaxTextBytes) {
                error = {"INVALID_ARGUMENT", "Command must contain 1 to 8192 bytes", EINVAL};
                return false;
            }
        } else if (step.type == "wait") {
            if ((require_runnable && step.wait_ms == 0) || step.wait_ms > kMaxDurationMs) {
                error = {"INVALID_ARGUMENT", "Wait duration is outside the supported range", EINVAL};
                return false;
            }
            continue;
        } else {
            error = {"INVALID_ARGUMENT", "Unknown automation step type", EINVAL};
            return false;
        }
        if (step.inputs.size() > kMaxInputs) {
            error = {"INVALID_ARGUMENT", "A step may contain at most 32 automatic inputs", E2BIG};
            return false;
        }
        std::set<std::string> input_ids;
        for (const auto& input : step.inputs) {
            if (!validId(input.id) || !input_ids.insert(input.id).second
                || input.after_ms > kMaxDurationMs || input.text.size() > kMaxTextBytes) {
                error = {"INVALID_ARGUMENT", "Automatic input is invalid or too large", EINVAL};
                return false;
            }
        }
    }
    return true;
}

void convertLegacy(const std::string& json, Draft& draft) {
    draft = {};
    draft.failure_policy = "stop";
    auto root = makeJson(cJSON_Parse(json.c_str()));
    if (!root || !cJSON_IsArray(root.get())) return;
    int index = 0;
    cJSON* item = nullptr;
    cJSON_ArrayForEach(item, root.get()) {
        if (!cJSON_IsObject(item)) continue;
        cJSON* command = cJSON_GetObjectItemCaseSensitive(item, "cmd");
        cJSON* delay = cJSON_GetObjectItemCaseSensitive(item, "delay");
        if (!cJSON_IsString(command) || !command->valuestring || !*command->valuestring) {
            ++index;
            continue;
        }
        const double seconds = cJSON_IsNumber(delay) ? delay->valuedouble
            : (cJSON_IsString(delay) && delay->valuestring ? std::strtod(delay->valuestring, nullptr) : 0);
        if (std::isfinite(seconds) && seconds > 0 && seconds * 1000.0 <= kMaxDurationMs
            && draft.steps.size() < kMaxSteps) {
            Step wait;
            wait.id = "legacy_wait_" + std::to_string(index);
            wait.type = "wait";
            wait.wait_ms = static_cast<uint64_t>(std::llround(seconds * 1000.0));
            draft.steps.push_back(std::move(wait));
        }
        if (draft.steps.size() >= kMaxSteps) break;
        Step step;
        step.id = "legacy_command_" + std::to_string(index);
        step.type = "command";
        step.command = command->valuestring;
        if (step.command.size() <= kMaxTextBytes) draft.steps.push_back(std::move(step));
        ++index;
    }
}

std::string legacyProjection(const Draft& draft) {
    auto result = makeJson(cJSON_CreateArray());
    double pending_delay = 0;
    for (const auto& step : draft.steps) {
        if (step.type == "wait") {
            pending_delay += static_cast<double>(step.wait_ms) / 1000.0;
            continue;
        }
        std::string command;
        if (step.type == "command") command = step.command;
        else if (step.type == "script") {
            command = "(cd " + shellQuote(dirname(step.path)) + " && sh " + shellQuote(step.path);
            for (const auto& arg : step.args) command += " " + shellQuote(arg);
            command += ")";
        } else continue;
        cJSON* item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "cmd", command.c_str());
        cJSON_AddNumberToObject(item, "delay", pending_delay);
        cJSON_AddItemToArray(result.get(), item);
        pending_delay = 0;
    }
    return printJson(result.get());
}

ApiReply envelope(int status, bool ok, const std::string& code, const std::string& message,
                  int sys_errno, cJSON* data = nullptr) {
    auto root = makeJson(cJSON_CreateObject());
    cJSON_AddBoolToObject(root.get(), "ok", ok);
    cJSON_AddStringToObject(root.get(), "code", code.c_str());
    cJSON_AddStringToObject(root.get(), "message", message.c_str());
    cJSON_AddNumberToObject(root.get(), "errno", sys_errno);
    cJSON_AddStringToObject(root.get(), "requestId", randomHex(8).c_str());
    if (data) cJSON_AddItemToObject(root.get(), "data", data);
    else cJSON_AddNullToObject(root.get(), "data");
    return {status, printJson(root.get())};
}

int statusForError(const Error& error) {
    if (error.code == "CONFIG_CHANGED" || error.code == "AUTOMATION_BUSY"
        || error.code == "AUTOMATION_CANCEL_DISABLED") return 409;
    if (error.code == "RUN_NOT_FOUND" || error.code == "SCHEME_NOT_FOUND" || error.code == "NOT_FOUND") return 404;
    if (error.code == "SCRIPT_UNSUPPORTED" || error.code == "SCRIPT_NOT_FOUND") return 422;
    if (error.code.rfind("INVALID_", 0) == 0) return 400;
    return 500;
}

ApiReply apiError(const Error& error) {
    return envelope(statusForError(error), false, error.code.empty() ? "INTERNAL_ERROR" : error.code,
                    error.message.empty() ? "Automation request failed" : error.message, error.sys_errno);
}

cJSON* errorJson(const Error& error) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "code", error.code.c_str());
    cJSON_AddStringToObject(root, "message", error.message.c_str());
    cJSON_AddNumberToObject(root, "errno", error.sys_errno);
    return root;
}

cJSON* runJson(const RunSnapshot& run) {
    cJSON* root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "id", run.id.c_str());
    cJSON_AddStringToObject(root, "state", run.state.c_str());
    cJSON_AddStringToObject(root, "schemeId", run.scheme_id.c_str());
    cJSON_AddStringToObject(root, "name", run.name.c_str());
    cJSON_AddStringToObject(root, "failurePolicy", run.failure_policy.c_str());
    cJSON_AddNumberToObject(root, "currentStep", static_cast<double>(run.current_step));
    cJSON_AddNumberToObject(root, "totalSteps", static_cast<double>(run.total_steps));
    cJSON_AddNumberToObject(root, "successCount", static_cast<double>(run.success_count));
    cJSON_AddNumberToObject(root, "failureCount", static_cast<double>(run.failure_count));
    cJSON_AddNumberToObject(root, "startedAtMs", static_cast<double>(run.started_at_ms));
    cJSON_AddNumberToObject(root, "endedAtMs", static_cast<double>(run.ended_at_ms));
    cJSON* steps = cJSON_CreateArray();
    for (const auto& step : run.steps) {
        cJSON* item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "id", step.id.c_str());
        cJSON_AddStringToObject(item, "type", step.type.c_str());
        cJSON_AddStringToObject(item, "state", step.state.c_str());
        cJSON_AddNumberToObject(item, "exitCode", step.exit_code);
        cJSON_AddStringToObject(item, "message", step.message.c_str());
        cJSON_AddNumberToObject(item, "startedAtMs", static_cast<double>(step.started_at_ms));
        cJSON_AddNumberToObject(item, "endedAtMs", static_cast<double>(step.ended_at_ms));
        cJSON_AddNumberToObject(item, "sentInputs", static_cast<double>(step.sent_inputs));
        cJSON_AddNumberToObject(item, "skippedInputs", static_cast<double>(step.skipped_inputs));
        cJSON_AddItemToArray(steps, item);
    }
    cJSON_AddItemToObject(root, "steps", steps);
    cJSON* errors = cJSON_CreateArray();
    for (const auto& error : run.errors) cJSON_AddItemToArray(errors, errorJson(error));
    cJSON_AddItemToObject(root, "errors", errors);
    return root;
}

bool scriptKind(const std::string& path, std::string& kind) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) return false;
    std::array<unsigned char, 32> bytes{};
    stream.read(reinterpret_cast<char*>(bytes.data()), bytes.size());
    const std::streamsize count = stream.gcount();
    if (count >= 4 && bytes[0] == 0x7f && bytes[1] == 'E' && bytes[2] == 'L' && bytes[3] == 'F') {
        kind = "elf";
        return true;
    }
    if ((count >= 2 && bytes[0] == '#' && bytes[1] == '!')
        || (path.size() >= 3 && path.substr(path.size() - 3) == ".sh")) {
        kind = "shell";
        return true;
    }
    return false;
}

std::string buildInnerCommand(const Step& step, const std::string& hidden_dir,
                              const std::string& run_id, size_t index,
                              std::string& temporary_path) {
    temporary_path.clear();
    if (step.type == "command") return step.command;
    std::string kind;
    (void)scriptKind(step.path, kind);
    std::string args;
    for (const auto& arg : step.args) args += " " + shellQuote(arg);
    if (kind == "shell") {
        return "cd " + shellQuote(dirname(step.path)) + " && sh " + shellQuote(step.path) + args;
    }
    struct statvfs fs_info {};
    const bool noexec = ::statvfs(step.path.c_str(), &fs_info) == 0 && (fs_info.f_flag & ST_NOEXEC) != 0;
    if (!noexec) {
        return "cd " + shellQuote(dirname(step.path)) + " && chmod 700 " + shellQuote(step.path)
            + " && " + shellQuote(step.path) + args;
    }
    const std::string temp = (fs::path(hidden_dir) /
        (".automation-" + run_id + "-" + std::to_string(index))).string();
    temporary_path = temp;
    return "__ska_tmp=" + shellQuote(temp) + "; cp " + shellQuote(step.path)
        + " \"$__ska_tmp\" && chmod 700 \"$__ska_tmp\" && \"$__ska_tmp\"" + args
        + "; __ska_exec_rc=$?; rm -f \"$__ska_tmp\"; exit $__ska_exec_rc";
}

} // namespace

bool ConfigStore::validate(const Config& config, Error& error) {
    if (!validPolicy(config.draft.failure_policy) || !validId(config.draft.scheme_id, true)
        || config.draft.name.size() > 256 || !validateSteps(config.draft.steps, error, false)) {
        if (error.code.empty()) error = {"INVALID_ARGUMENT", "Draft is invalid", EINVAL};
        return false;
    }
    if (config.schemes.size() > kMaxSchemes) {
        error = {"INVALID_ARGUMENT", "At most 50 schemes may be saved", E2BIG};
        return false;
    }
    std::set<std::string> ids;
    std::set<std::string> names;
    size_t favorites = 0;
    for (const auto& scheme : config.schemes) {
        if (!validId(scheme.id) || !ids.insert(scheme.id).second || scheme.name.empty()
            || scheme.name.size() > 256 || !names.insert(scheme.name).second
            || !validPolicy(scheme.failure_policy) || !validateSteps(scheme.steps, error)) {
            if (error.code.empty()) error = {"INVALID_ARGUMENT", "Scheme names and IDs must be unique and valid", EINVAL};
            return false;
        }
        if (scheme.favorite) ++favorites;
    }
    if (favorites > kMaxFavoriteSchemes) {
        error = {"INVALID_ARGUMENT", "At most 6 schemes may be favorites", E2BIG};
        return false;
    }
    return true;
}

std::string ConfigStore::toJson(const Config& config) {
    auto root = makeJson(configJson(config));
    return printJson(root.get());
}

bool ConfigStore::fromJson(const std::string& json, Config& config, Error& error) {
    auto root = makeJson(cJSON_ParseWithLength(json.data(), json.size()));
    if (!root || !cJSON_IsObject(root.get())) {
        error = {"INVALID_JSON", "Automation config must be a JSON object", EINVAL};
        return false;
    }
    Config parsed;
    if (!getUint(root.get(), "revision", parsed.revision, 0, error)
        || !parseDraft(cJSON_GetObjectItemCaseSensitive(root.get(), "draft"), parsed.draft, error)) return false;
    cJSON* schemes = cJSON_GetObjectItemCaseSensitive(root.get(), "schemes");
    if (!cJSON_IsArray(schemes) || cJSON_GetArraySize(schemes) > static_cast<int>(kMaxSchemes)) {
        error = {"INVALID_ARGUMENT", "Field 'schemes' must be an array with at most 50 items", EINVAL};
        return false;
    }
    cJSON* item = nullptr;
    cJSON_ArrayForEach(item, schemes) {
        Scheme scheme;
        if (!parseScheme(item, scheme, error)) return false;
        parsed.schemes.push_back(std::move(scheme));
    }
    if (!validate(parsed, error)) return false;
    config = std::move(parsed);
    return true;
}

bool ConfigStore::load(Config& config, Error& error, bool migrate_legacy) {
    std::string stored;
    const KModErr read_result = kernel_module::read_string_disk_storage(kConfigStorageKey, stored);
    if (is_ok(read_result) && !stored.empty()) return fromJson(stored, config, error);

    Config initial;
    initial.revision = 1;
    initial.draft.failure_policy = "stop";
    if (migrate_legacy) {
        std::string legacy;
        if (is_ok(kernel_module::read_string_disk_storage(kLegacyStorageKey, legacy)) && !legacy.empty()) {
            convertLegacy(legacy, initial.draft);
        }
    }
    if (!validate(initial, error)) return false;
    const std::string json = toJson(initial);
    const KModErr write_result = kernel_module::write_string_disk_storage(kConfigStorageKey, json.c_str());
    if (!is_ok(write_result)) {
        error = {"STORAGE_FAILED", "Unable to initialize automation config: " + to_string(write_result), EIO};
        return false;
    }
    config = std::move(initial);
    return true;
}

bool ConfigStore::save(uint64_t expected_revision, const Config& desired, Config& saved, Error& error) {
    Config current;
    if (!load(current, error)) return false;
    if (current.revision != expected_revision) {
        error = {"CONFIG_CHANGED", "Automation config was changed by another page", EAGAIN};
        return false;
    }
    Config next = desired;
    next.revision = current.revision + 1;
    if (!validate(next, error)) return false;
    const std::string json = toJson(next);
    const KModErr result = kernel_module::write_string_disk_storage(kConfigStorageKey, json.c_str());
    if (!is_ok(result)) {
        error = {"STORAGE_FAILED", "Unable to save automation config: " + to_string(result), EIO};
        return false;
    }
    saved = std::move(next);
    return true;
}

bool ConfigStore::replaceDraftFromLegacy(const std::string& legacy_json, Config& saved, Error& error) {
    Config current;
    if (!load(current, error)) return false;
    convertLegacy(legacy_json, current.draft);
    return save(current.revision, current, saved, error);
}

std::string ConfigStore::legacyDraftJson(Error& error) {
    Config current;
    if (!load(current, error)) return "[]";
    return legacyProjection(current.draft);
}

AutomationManager::AutomationManager() = default;
AutomationManager::~AutomationManager() { shutdown(); }

void AutomationManager::configure(TerminalTransport* terminal, std::string hidden_work_dir) {
    shutdown();
    std::lock_guard<std::mutex> lock(m_mu);
    m_terminal = terminal;
    m_hidden_work_dir = std::move(hidden_work_dir);
    if (m_terminal) {
        m_terminal->setControlFrameHandler([this](const std::string& frame) {
            return handleControlFrame(frame);
        });
    }
}

bool AutomationManager::preflight(const Scheme& scheme, Error& error) const {
    if (!validateSteps(scheme.steps, error, true)) return false;
    for (const auto& step : scheme.steps) {
        if (step.type != "script") continue;
        struct stat info {};
        if (::lstat(step.path.c_str(), &info) != 0 || !S_ISREG(info.st_mode)) {
            const int value = errno ? errno : ENOENT;
            error = {"SCRIPT_NOT_FOUND", "Script is missing or not a regular file: " + step.path, value};
            return false;
        }
        std::string kind;
        if (!scriptKind(step.path, kind)) {
            error = {"SCRIPT_UNSUPPORTED", "Unsupported script or executable: " + step.path, ENOEXEC};
            return false;
        }
    }
    return true;
}

bool AutomationManager::start(const Scheme& scheme, RunSnapshot& output, Error& error) {
    std::thread previous;
    {
        std::lock_guard<std::mutex> lock(m_mu);
        if (activeState(m_snapshot.state)) {
            error = {"AUTOMATION_BUSY", "Another automation scheme is running", EBUSY};
            return false;
        }
        if (m_worker.joinable()) previous = std::move(m_worker);
    }
    if (previous.joinable()) previous.join();

    TerminalTransport* terminal = nullptr;
    {
        std::lock_guard<std::mutex> lock(m_mu);
        terminal = m_terminal;
    }
    if (!terminal || !terminal->isAlive()) {
        error = {"SHELL_UNAVAILABLE", "Terminal shell is not available", EPIPE};
        return false;
    }
    // Automation is intentionally a mechanical, force-run operation.  Do not
    // probe the foreground process group (PTY) or infer readiness from an
    // anonymous pipe.  A user-created scheme may deliberately target a shell
    // that is currently waiting on a foreground program; in that case the
    // bytes remain queued in the shell transport and are consumed according
    // to normal shell/child stdin semantics.  Avoiding a readiness probe also
    // keeps pipe mode free of extra commands and /proc inspection.
    if (!preflight(scheme, error)) return false;

    const std::string run_id = randomHex(12);
    const std::string token = randomHex(16);
    {
        std::lock_guard<std::mutex> lock(m_mu);
        m_snapshot = {};
        m_snapshot.id = run_id;
        m_snapshot.state = "preparing";
        m_snapshot.scheme_id = scheme.id;
        m_snapshot.name = scheme.name.empty() ? "未保存草稿" : scheme.name;
        m_snapshot.failure_policy = scheme.failure_policy;
        m_snapshot.total_steps = scheme.steps.size();
        m_snapshot.started_at_ms = nowMs();
        for (const auto& step : scheme.steps) {
            StepResult result;
            result.id = step.id;
            result.type = step.type;
            m_snapshot.steps.push_back(std::move(result));
        }
        m_shutdown_requested = false;
        m_frame_ready = false;
        m_frame_token = token;
        output = m_snapshot;
        m_worker = std::thread([this, scheme, run_id, token] { workerMain(scheme, run_id, token); });
    }
    return true;
}

RunSnapshot AutomationManager::snapshot() const {
    std::lock_guard<std::mutex> lock(m_mu);
    return m_snapshot;
}

bool AutomationManager::cancel(const std::string& run_id, RunSnapshot& output, Error& error) {
    {
        std::lock_guard<std::mutex> lock(m_mu);
        if (m_snapshot.id.empty() || (!run_id.empty() && run_id != m_snapshot.id)) {
            error = {"RUN_NOT_FOUND", "Automation run was not found", ENOENT};
            return false;
        }
        output = m_snapshot;
    }
    error = {"AUTOMATION_CANCEL_DISABLED", "Step cancellation is disabled in this transport profile", EOPNOTSUPP};
    return false;
}

bool AutomationManager::isActive() const {
    std::lock_guard<std::mutex> lock(m_mu);
    return activeState(m_snapshot.state);
}

void AutomationManager::shutdown() {
    std::thread worker;
    {
        std::lock_guard<std::mutex> lock(m_mu);
        m_shutdown_requested = true;
        if (m_worker.joinable()) worker = std::move(m_worker);
    }
    m_cv.notify_all();
    if (worker.joinable()) worker.join();
    if (m_terminal) m_terminal->setControlFrameHandler({});
}

bool AutomationManager::handleControlFrame(const std::string& frame) {
    // SKA:<token>:<step-index>:<exit-code>
    if (frame.rfind("SKA:", 0) != 0) return false;
    const size_t token_end = frame.find(':', 4);
    const size_t step_end = token_end == std::string::npos ? std::string::npos : frame.find(':', token_end + 1);
    if (token_end == std::string::npos || step_end == std::string::npos) return true;
    const std::string token = frame.substr(4, token_end - 4);
    char* end = nullptr;
    errno = 0;
    const unsigned long step = std::strtoul(frame.c_str() + token_end + 1, &end, 10);
    if (errno != 0 || !end || end != frame.c_str() + step_end) return true;
    errno = 0;
    const long exit_code = std::strtol(frame.c_str() + step_end + 1, &end, 10);
    if (errno != 0 || !end || *end != '\0') return true;

    TerminalTransport* terminal = nullptr;
    {
        std::lock_guard<std::mutex> lock(m_mu);
        // SKA is an internal protocol namespace. Stale or malformed frames are
        // consumed as well, so they never leak into visible terminal output.
        if (!activeState(m_snapshot.state) || token != m_frame_token || step != m_frame_step) return true;
        m_frame_ready = true;
        m_frame_exit_code = static_cast<int>(exit_code);
        terminal = m_terminal;
        m_cv.notify_all();
    }
    if (terminal) terminal->finishAutomationCommand();
    return true;
}

void AutomationManager::finishRun(const std::string& state) {
    std::lock_guard<std::mutex> lock(m_mu);
    m_snapshot.state = state;
    m_snapshot.ended_at_ms = nowMs();
    for (auto& step : m_snapshot.steps) {
        if (step.state == "pending") step.state = "skipped";
    }
}

bool AutomationManager::runWaitStep(const Step& step, size_t index) {
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(step.wait_ms);
    {
        std::lock_guard<std::mutex> lock(m_mu);
        m_snapshot.current_step = index;
        m_snapshot.steps[index].state = "running";
        m_snapshot.steps[index].started_at_ms = nowMs();
    }
    std::unique_lock<std::mutex> lock(m_mu);
    if (m_cv.wait_until(lock, deadline, [this] { return m_shutdown_requested; })) {
        m_snapshot.steps[index].state = "failed";
        m_snapshot.steps[index].message = "Terminal session ended";
        m_snapshot.steps[index].ended_at_ms = nowMs();
        return false;
    }
    m_snapshot.steps[index].state = "completed";
    m_snapshot.steps[index].ended_at_ms = nowMs();
    ++m_snapshot.success_count;
    return true;
}

bool AutomationManager::runCommandStep(const Step& step, size_t index, const std::string& token) {
    TerminalTransport* terminal = nullptr;
    std::string hidden_dir;
    std::string run_id;
    {
        std::lock_guard<std::mutex> lock(m_mu);
        terminal = m_terminal;
        hidden_dir = m_hidden_work_dir;
        run_id = m_snapshot.id;
        m_snapshot.current_step = index;
        m_snapshot.steps[index].state = "running";
        m_snapshot.steps[index].started_at_ms = nowMs();
        m_frame_step = index;
        m_frame_ready = false;
    }
    std::string temporary_path;
    const std::string inner = buildInnerCommand(step, hidden_dir, run_id, index, temporary_path);
    struct TemporaryPathCleanup {
        const std::string& path;
        ~TemporaryPathCleanup() {
            if (!path.empty()) (void)::unlink(path.c_str());
        }
    } cleanup{temporary_path};
    const std::string wrapper = "__skroot_rc=0; sh -c " + shellQuote(inner)
        + " || __skroot_rc=$?; printf '\\036SKA:" + token + ":" + std::to_string(index)
        + ":%d\\037\\n' \"$__skroot_rc\"";
    if (!terminal || !terminal->sendAutomationCommand(wrapper)) {
        std::lock_guard<std::mutex> lock(m_mu);
        auto& result = m_snapshot.steps[index];
        result.state = "failed";
        result.exit_code = 127;
        result.message = "Unable to send step to terminal";
        result.ended_at_ms = nowMs();
        ++m_snapshot.failure_count;
        m_snapshot.errors.push_back({"TERMINAL_WRITE_FAILED", result.message, EPIPE});
        return false;
    }
    struct AutomationCommandFinish {
        TerminalTransport* terminal;
        ~AutomationCommandFinish() {
            if (terminal) terminal->finishAutomationCommand();
        }
    } command_finish{terminal};

    const auto started = std::chrono::steady_clock::now();
    size_t next_input = 0;
    for (;;) {
        bool frame_already_ready = false;
        {
            std::lock_guard<std::mutex> lock(m_mu);
            frame_already_ready = m_frame_ready;
        }
        if (!frame_already_ready && (!terminal || !terminal->isAlive())) {
            std::lock_guard<std::mutex> lock(m_mu);
            auto& result = m_snapshot.steps[index];
            result.state = "failed";
            result.exit_code = 125;
            result.message = "Terminal shell exited before the step completed";
            result.skipped_inputs = step.inputs.size() - next_input;
            result.ended_at_ms = nowMs();
            ++m_snapshot.failure_count;
            m_snapshot.errors.push_back({"SHELL_UNAVAILABLE", result.message, EPIPE});
            return false;
        }
        bool frame = false;
        bool shutting_down = false;
        int exit_code = 0;
        InputAction input;
        bool send_input = false;
        {
            std::unique_lock<std::mutex> lock(m_mu);
            const auto now = std::chrono::steady_clock::now();
            shutting_down = m_shutdown_requested;
            frame = m_frame_ready;
            if (frame) exit_code = m_frame_exit_code;
            if (!frame && !shutting_down && next_input < step.inputs.size()
                && now >= started + std::chrono::milliseconds(step.inputs[next_input].after_ms)) {
                input = step.inputs[next_input++];
                send_input = true;
            }
            if (!frame && !shutting_down && !send_input) {
                auto wake = std::chrono::steady_clock::time_point::max();
                if (next_input < step.inputs.size()) {
                    wake = std::min(wake, started + std::chrono::milliseconds(step.inputs[next_input].after_ms));
                }
                if (wake == std::chrono::steady_clock::time_point::max()) {
                    m_cv.wait_for(lock, std::chrono::milliseconds(250));
                } else {
                    m_cv.wait_until(lock, std::min(wake, now + std::chrono::milliseconds(250)));
                }
                continue;
            }
        }

        if (shutting_down) {
            std::lock_guard<std::mutex> lock(m_mu);
            auto& result = m_snapshot.steps[index];
            result.state = "failed";
            result.exit_code = 125;
            result.message = "Terminal session ended";
            result.skipped_inputs = step.inputs.size() - next_input;
            result.ended_at_ms = nowMs();
            ++m_snapshot.failure_count;
            m_snapshot.errors.push_back({"SHELL_UNAVAILABLE", result.message, EPIPE});
            return false;
        }
        if (send_input) {
            if (!terminal->sendText(input.text, input.append_enter)) {
                std::lock_guard<std::mutex> lock(m_mu);
                auto& result = m_snapshot.steps[index];
                result.state = "failed";
                result.exit_code = 125;
                result.message = "Unable to send automatic input";
                result.skipped_inputs = step.inputs.size() - next_input;
                result.ended_at_ms = nowMs();
                ++m_snapshot.failure_count;
                m_snapshot.errors.push_back({"INPUT_SEND_FAILED", result.message, EPIPE});
                return false;
            }
            std::lock_guard<std::mutex> lock(m_mu);
            ++m_snapshot.steps[index].sent_inputs;
            continue;
        }
        if (frame) {
            std::lock_guard<std::mutex> lock(m_mu);
            auto& result = m_snapshot.steps[index];
            result.exit_code = exit_code;
            result.skipped_inputs = step.inputs.size() - next_input;
            result.ended_at_ms = nowMs();
            if (exit_code == 0) {
                result.state = "completed";
                ++m_snapshot.success_count;
            } else {
                result.state = "failed";
                result.message = "Step exited with code " + std::to_string(exit_code);
                ++m_snapshot.failure_count;
                m_snapshot.errors.push_back({"STEP_FAILED", result.message, 0});
            }
            return true;
        }
    }
}

void AutomationManager::workerMain(Scheme scheme, std::string run_id, std::string token) {
    (void)run_id;
    {
        std::lock_guard<std::mutex> lock(m_mu);
        m_snapshot.state = "running";
    }
    for (size_t index = 0; index < scheme.steps.size(); ++index) {
        bool shutting_down = false;
        {
            std::lock_guard<std::mutex> lock(m_mu);
            shutting_down = m_shutdown_requested;
            if (shutting_down) {
                m_snapshot.steps[index].state = "failed";
                m_snapshot.steps[index].message = "Terminal session ended";
                m_snapshot.steps[index].ended_at_ms = nowMs();
            }
        }
        if (shutting_down) {
            finishRun("failed");
            return;
        }
        const Step& step = scheme.steps[index];
        const bool proceed = step.type == "wait" ? runWaitStep(step, index) : runCommandStep(step, index, token);
        if (!proceed) {
            finishRun("failed");
            return;
        }
        bool failed = false;
        {
            std::lock_guard<std::mutex> lock(m_mu);
            failed = m_snapshot.steps[index].state == "failed";
        }
        if (failed && scheme.failure_policy == "stop") {
            finishRun("failed");
            return;
        }
    }
    finishRun(snapshot().failure_count > 0 ? "failed" : "completed");
}

AutomationApi::AutomationApi() = default;
AutomationApi::~AutomationApi() { shutdown(); }

void AutomationApi::configure(TerminalTransport* terminal, const std::string& hidden_work_dir) {
    m_manager.configure(terminal, hidden_work_dir);
}

ApiReply AutomationApi::handle(const std::string& path, const std::string& body) {
    std::lock_guard<std::mutex> lock(m_mu);
    if (path == "/api/automation/config/get") return handleConfigGet();
    if (path == "/api/automation/config/set") return handleConfigSet(body);
    if (path == "/api/automation/run/start") return handleRunStart(body);
    if (path == "/api/automation/run/status") return handleRunStatus(body);
    if (path == "/api/automation/run/cancel") return handleRunCancel(body);
    return apiError({"NOT_FOUND", "Unknown automation API route", ENOENT});
}

ApiReply AutomationApi::handleConfigGet() {
    Config config;
    Error error;
    if (!m_store.load(config, error)) return apiError(error);
    return envelope(200, true, "OK", "", 0, configJson(config));
}

ApiReply AutomationApi::handleConfigSet(const std::string& body) {
    Config desired;
    Error error;
    if (!ConfigStore::fromJson(body, desired, error)) return apiError(error);
    Config saved;
    if (!m_store.save(desired.revision, desired, saved, error)) return apiError(error);
    return envelope(200, true, "OK", "", 0, configJson(saved));
}

ApiReply AutomationApi::handleRunStart(const std::string& body) {
    auto root = makeJson(cJSON_ParseWithLength(body.data(), body.size()));
    if (!root || !cJSON_IsObject(root.get())) return apiError({"INVALID_JSON", "Run request must be an object", EINVAL});
    Config config;
    Error error;
    if (!m_store.load(config, error)) return apiError(error);
    Scheme scheme;
    cJSON* scheme_id = cJSON_GetObjectItemCaseSensitive(root.get(), "schemeId");
    cJSON* source = cJSON_GetObjectItemCaseSensitive(root.get(), "source");
    if (cJSON_IsString(scheme_id) && scheme_id->valuestring) {
        auto found = std::find_if(config.schemes.begin(), config.schemes.end(), [&](const Scheme& item) {
            return item.id == scheme_id->valuestring;
        });
        if (found == config.schemes.end()) return apiError({"SCHEME_NOT_FOUND", "Saved scheme was not found", ENOENT});
        scheme = *found;
    } else if (cJSON_IsString(source) && source->valuestring && std::string(source->valuestring) == "draft") {
        scheme.id = config.draft.scheme_id;
        scheme.name = config.draft.name.empty() ? "未保存草稿" : config.draft.name;
        scheme.failure_policy = config.draft.failure_policy;
        scheme.steps = config.draft.steps;
    } else {
        return apiError({"INVALID_ARGUMENT", "Run request requires schemeId or source='draft'", EINVAL});
    }
    RunSnapshot snapshot;
    if (!m_manager.start(scheme, snapshot, error)) return apiError(error);
    return envelope(202, true, "OK", "", 0, runJson(snapshot));
}

ApiReply AutomationApi::handleRunStatus(const std::string& body) {
    RunSnapshot snapshot = m_manager.snapshot();
    if (!body.empty() && body != "{}") {
        auto root = makeJson(cJSON_ParseWithLength(body.data(), body.size()));
        if (!root || !cJSON_IsObject(root.get())) return apiError({"INVALID_JSON", "Status request must be an object", EINVAL});
        cJSON* id = cJSON_GetObjectItemCaseSensitive(root.get(), "id");
        if (cJSON_IsString(id) && id->valuestring && snapshot.id != id->valuestring) {
            return apiError({"RUN_NOT_FOUND", "Automation run was not found", ENOENT});
        }
    }
    return envelope(200, true, "OK", "", 0, runJson(snapshot));
}

ApiReply AutomationApi::handleRunCancel(const std::string& body) {
    auto root = makeJson(cJSON_ParseWithLength(body.data(), body.size()));
    if (!root || !cJSON_IsObject(root.get())) return apiError({"INVALID_JSON", "Cancel request must be an object", EINVAL});
    std::string id;
    Error error;
    if (!getString(root.get(), "id", id, true, error)) return apiError(error);
    RunSnapshot snapshot;
    if (!m_manager.cancel(id, snapshot, error)) return apiError(error);
    return envelope(200, true, "OK", "", 0, runJson(snapshot));
}

std::string AutomationApi::legacyGetTasks() {
    std::lock_guard<std::mutex> lock(m_mu);
    Error error;
    return m_store.legacyDraftJson(error);
}

bool AutomationApi::legacySaveTasks(const std::string& body, Error& error) {
    std::lock_guard<std::mutex> lock(m_mu);
    Config saved;
    return m_store.replaceDraftFromLegacy(body, saved, error);
}

bool AutomationApi::isRunActive() const { return m_manager.isActive(); }
void AutomationApi::shutdown() { m_manager.shutdown(); }

} // namespace automation
