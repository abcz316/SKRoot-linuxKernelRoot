import { build } from 'esbuild';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const output = path.resolve(root, '../../webroot/vendor');
await mkdir(output, { recursive: true });
const result = await build({
  absWorkingDir: root,
  entryPoints: ['vendor-entry.js'],
  outfile: path.join(output, 'codemirror.bundle.js'),
  bundle: true,
  format: 'iife',
  globalName: 'SKCodeMirror',
  target: 'es2020',
  minify: true,
  legalComments: 'none',
  metafile: true,
  banner: { js: '/* CodeMirror 6 offline bundle. Licenses: codemirror.LICENSE.txt. Rebuild: tools/text-editor */' },
});
const packageDirs = new Set();
for (const input of Object.keys(result.metafile.inputs)) {
  const relative = input.replaceAll('\\', '/');
  const match = relative.match(/^(node_modules\/(?:@[^/]+\/)?[^/]+)\//);
  if (match) packageDirs.add(match[1]);
}
const notices = ['CodeMirror 6 and bundled dependencies\nGenerated from the exact installed package-lock.json versions.\n'];
for (const directory of [...packageDirs].sort()) {
  const packagePath = path.join(root, directory);
  const metadata = JSON.parse(await readFile(path.join(packagePath, 'package.json'), 'utf8'));
  let license;
  for (const name of ['LICENSE', 'LICENSE.md', 'LICENSE.txt']) {
    try { license = await readFile(path.join(packagePath, name), 'utf8'); break; } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
  if (!license) throw new Error(`Missing license for ${metadata.name}`);
  notices.push(`\n--- ${metadata.name}@${metadata.version} (${metadata.license}) ---\n\n${license.trim()}\n`);
}
await writeFile(path.join(output, 'codemirror.LICENSE.txt'), notices.join(''), 'utf8');
console.log(`Built codemirror.bundle.js (${result.metafile.outputs[Object.keys(result.metafile.outputs)[0]].bytes} bytes), ${packageDirs.size} dependency licenses.`);
