# 离线 UTF-8 编辑器依赖

在本目录运行 `npm ci`，再运行 `npm run build`，生成 `webroot/vendor/codemirror.bundle.js` 与 `codemirror.LICENSE.txt`。直接和传递依赖均由 `package-lock.json` 锁定；构建需要 Node.js 18+，运行时只加载安装包内的 JavaScript，不访问 CDN。

组件按 `codemirror.bundle.js`、`text-editor.js` 的顺序加载，样式加载 `text-editor.css`。`SKTextEditor.create({root, api, onSaved, canSave})` 提供 `open({path, pane})`、`close(force)` 和 `isOpen()`；组件自行管理读取、保存、关闭确认与显示设置。

CodeMirror 官方参考：[基本编辑器](https://codemirror.net/examples/basic/)、[可撤销状态效果](https://codemirror.net/examples/inverted-effect/)。组件额外记录每个原始换行，保留混合 LF/CRLF；新插入换行采用文件的首个换行风格。保存的 BOM 与编辑文本开头的 U+FEFF 分开处理。语法、字号与自动换行设置只改变显示。

测试：在模块根目录运行 `node --test tests/text-editor.test.js` 与 `node tests/text-editor-visual.cjs`。浏览器测试使用现有 Playwright 安装，`PLAYWRIGHT_CHROMIUM_EXECUTABLE` 可指定本机 Chromium/Edge。
