#pragma once

#include <sys/types.h>
#include <termios.h>

#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>

#include "automation_service.h"

enum class TerminalTransportMode {
    Pty,
    Pipe,
};

const char* terminalTransportModeName(TerminalTransportMode mode);
TerminalTransportMode terminalTransportModeFromString(std::string_view value);

class SuInteractive : public automation::TerminalTransport {
public:
    SuInteractive();
    ~SuInteractive();

    SuInteractive(const SuInteractive&) = delete;
    SuInteractive& operator=(const SuInteractive&) = delete;
    SuInteractive(SuInteractive&&) = delete;
    SuInteractive& operator=(SuInteractive&&) = delete;

    // Start the long-lived su shell using either a controlling PTY or two
    // anonymous pipes. The mode is selected before WebUI creation and cannot
    // be changed while this Shell session is alive.
    bool start(std::string_view shell_rc_dir = {},
               TerminalTransportMode mode = TerminalTransportMode::Pty);

    bool send(const std::string& value);
    bool sendLine(const std::string& line);
    bool sendText(const std::string& text, bool append_enter) override;
    bool sendAutomationCommand(const std::string& command) override;
    void finishAutomationCommand() override;

    void closeInput();
    int wait();
    void stop(bool force = true);

    std::string output() const;
    std::string takeOutput();
    pid_t get_shell_pid() const;
    pid_t get_shell_pgid() const;
    TerminalTransportMode transportMode() const { return m_mode; }

    // PTY uses the controlling terminal foreground group. Pipe uses the
    // upstream 3.1.1 PS1 marker; until one is observed its state is unknown.
    bool isShellIdle() const override;
    bool hasShellIdleState() const override;
    bool isAlive() const override;
    void setControlFrameHandler(ControlFrameHandler handler) override;

    // Called only in the post-fork watchdog child. It closes inherited
    // transport descriptors without touching mutexes or joining threads.
    void closeTransportFdsAfterFork();

private:
    static void setCloExec(int fd);
    static bool makePipe(int fds[2]);
    void stopPipe_(bool force);
    void stopPty_(bool force);
    static void safeClose(int& fd);
    static void safeClose(std::atomic<int>& fd);
    static void setupShellPromptEnv_(std::string_view rc_dir, TerminalTransportMode mode);
    static void cleanupLegacyFiles_(std::string_view rc_dir);

    bool startPty_(std::string_view shell_rc_dir);
    bool startPipe_(std::string_view shell_rc_dir);
    void readerLoop_();
    std::string filterAutomationEcho_(std::string visible);

private:
    std::atomic<pid_t> m_pid{-1};
    std::atomic<pid_t> m_pgid{-1};
    std::atomic<bool> m_pipe_prompt_seen{false};
    std::atomic<bool> m_pipe_shell_ready{false};
    TerminalTransportMode m_mode{TerminalTransportMode::Pty};

    std::atomic<int> m_in_w{-1};
    std::atomic<int> m_out_r{-1};

    mutable std::mutex m_mu;
    std::string m_out;
    ControlFrameHandler m_control_frame_handler;
    std::mutex m_echo_mu;
    struct termios m_saved_automation_termios {};
    bool m_automation_echo_suppressed{false};
    bool m_suppress_automation_input_echo{false};
    std::string m_automation_echo_command;
    std::string m_automation_echo_buffer;
    std::thread m_reader;
};
