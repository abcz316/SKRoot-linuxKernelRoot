# Shell 调度属性修复（4.0.2 及以后）

SKRoot WebUI 线程可能运行在性能核心并带有非零 nice 值。Shell 子进程在 `execvp("su")` 前调用 `shell_scheduler::restoreForExec()`，恢复可用 CPU affinity 和 nice 0；父 WebUI、CivetWeb worker、PTY reader、匿名管道 reader 和 watchdog 的调度属性不变。

恢复请求只会被内核与现有 cpuset/cgroup 约束相交，不扩大设备允许的 CPU 集合，也不改变 UID/GID、能力、SELinux、namespace、comm、argv、环境或文件描述符。失败不会输出发布日志。

传输层按启动设置选择 PTY 或匿名管道，两种模式都在 Shell `exec` 前执行相同的调度恢复。
