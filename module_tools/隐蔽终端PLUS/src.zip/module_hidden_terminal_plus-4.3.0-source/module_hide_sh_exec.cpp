
#include <algorithm>
#include <fstream>
#include <filesystem>
#include <system_error>
#include <chrono>
#include <ctime>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/xattr.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <cerrno>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <vector>

#include "kernel_module_kit_umbrella.h"

#include "su_interactive.h"
#include "idle_killer.h"
#include "json_helper.h"
#include "url_encode_utils.h"
#include "list_dir_helper.h"
#include "simple_hash_util.h"
#include "file_manager_api.h"
#include "webui_access_policy.h"
#include "automation_service.h"

#define WORK_DIR_NAME "work"
#define MAX_QUICK_ACTIONS 10
#define RECORD_CMD_LEN 100

namespace fs = std::filesystem;

int skroot_module_main(const char* root_key, const char* module_private_dir) { return 0; }

static void append_or_move_to_back(std::vector<std::string>& vec, const std::string& target) {
    auto it = std::find(vec.begin(), vec.end(), target);
    if (it != vec.end()) {
        if (it + 1 != vec.end()) std::rotate(it, it + 1, vec.end());
    } else {
        vec.push_back(target);
    }
}

static void add_quick_actions(const std::vector<std::string>& cmd) {
    if (!cmd.size()) return;
    std::string json;
    kernel_module::read_string_disk_storage("quick_actions", json);
    std::vector<std::string> cmd_arr = parse_json(json);
    for(auto & c : cmd) {
        std::vector<char> encoded_buf(c.size() * 3 + 1, '\0');
        url_encode(c.c_str(), encoded_buf.data());
        std::string encoded_str(encoded_buf.data(), std::strlen(encoded_buf.data()));
        append_or_move_to_back(cmd_arr, encoded_str);
    }
    while (cmd_arr.size() > MAX_QUICK_ACTIONS) {
        cmd_arr.erase(cmd_arr.begin());
    }
    json = json_array_from_set(cmd_arr);
    kernel_module::write_string_disk_storage("quick_actions", json.c_str());
}

static std::string read_quick_actions_json() {
    std::string json;
    kernel_module::read_string_disk_storage("quick_actions", json);
    if(json.empty()) json = "[]";
    return json;
}

static void write_terminal_keep_mode(bool enabled) {
    kernel_module::write_bool_disk_storage("terminal_keep_mode", enabled);
}

static bool read_terminal_keep_mode() {
    bool enabled = false;
    kernel_module::read_bool_disk_storage("terminal_keep_mode", enabled);
    return enabled;
}

static void write_terminal_transport_mode(TerminalTransportMode mode) {
    kernel_module::write_string_disk_storage("terminal_transport_mode", terminalTransportModeName(mode));
}

static TerminalTransportMode read_terminal_transport_mode() {
    std::string value;
    kernel_module::read_string_disk_storage("terminal_transport_mode", value);
    // The 4.2.6 default deliberately preserves the current PTY behavior for
    // existing installations. Users who prefer the pipe profile can opt in.
    return terminalTransportModeFromString(value.empty() ? "pty" : value);
}

static void create_work_dir(const char* module_private_dir, const char* work_dir_name) {
    fs::path work_dir = fs::path(module_private_dir) / work_dir_name;
    std::error_code ec;
    fs::create_directories(work_dir, ec);
    ::chmod(work_dir.c_str(), 0777);
    const char* selinux_flag = "u:object_r:system_file:s0";
    ::setxattr(work_dir.c_str(), XATTR_NAME_SELINUX, selinux_flag, std::strlen(selinux_flag) + 1, 0);
}

std::string module_on_install(const char* root_key, const char* module_private_dir) {
    add_quick_actions({"getenforce", "ls /", "id"});
    create_work_dir(module_private_dir, WORK_DIR_NAME);
    return "";
}

static bool pid_alive(pid_t pid) {
    if (pid <= 1) return false;
    if (::kill(pid, 0) == 0) return true;
    return errno == EPERM;
}

static void wait_parent_exit(const std::string& root_key, pid_t ppid) {
    timespec ts{0, 500 * 1000 * 1000}; // 500ms
    while (getppid() != 1 && pid_alive(ppid)) {
        skroot_env::get_root(root_key.c_str());
        nanosleep(&ts, nullptr);
    }
}


// WebUI HTTP服务器回调函数
class MyWebHttpHandler : public kernel_module::WebUIHttpHandler {
public:
    void onPrepareCreate(const char* root_key, const char* module_private_dir, uint32_t port) override {
        m_root_key = root_key;
        m_session_token = file_manager::randomHex(32);

        m_hide_dir = (fs::path(module_private_dir) / WORK_DIR_NAME).string();
        m_file_api.configure(SimpleHashUtil::to_random_string(m_root_key).data());
        m_keep_terminal = read_terminal_keep_mode();
        m_transport_mode = read_terminal_transport_mode();
        m_su_interactive.start(module_private_dir, m_transport_mode);
        m_automation_api.configure(&m_su_interactive, m_hide_dir);
        if (!m_keep_terminal) {
            fork_sh_process_daemon();
        }
        m_idle_killer.start(std::chrono::seconds(20), [this]() -> bool {
            if (m_automation_api.isRunActive()) return false;
            if (m_keep_terminal) {
                if (!m_su_interactive.isShellIdle()) {
                    // PTY 尚未回到 Shell 前台，或 pipe 尚未返回提示符；保留会话。
                    // 后台子进程数量与空闲判断无关。
                    return false;
                }
                printf("[module_hide_sh_exec] shell foreground, idle kill!\n");
            } else {
                printf("[module_hide_sh_exec] idle kill!\n");
            }
            if (m_file_api.isJobActive()) return false;
            // Release the transport before joining unrelated file-manager
            // workers. In normal mode this makes a PTY page close observable
            // immediately and wakes automation waiting on a completion frame.
            m_su_interactive.stop(true);
            m_file_api.shutdown();
            m_automation_api.shutdown();
            if (m_server) m_server->close();
            _exit(0);
            return true;
        });
    }

    void onServerCreated(CivetServer* server) override {
        m_server = server;
    }

    bool handleGet(CivetServer* server, struct mg_connection* conn, const std::string& path, const std::string& query) override {
        if (!is_loopback_request(conn)) {
            kernel_module::webui::send_json(conn, 403, error_json("REMOTE_ACCESS_DENIED", "WebUI is restricted to this device"));
            return true;
        }
        return false;
    }

    bool handlePost(CivetServer* server, struct mg_connection* conn, const std::string& path, const std::string& body) override {
        //printf("[module_hide_sh_exec] POST request\nPath: %s\nBody: %s\n", path.c_str(), body.c_str());
        m_idle_killer.touch();
        if (!is_loopback_request(conn)) {
            kernel_module::webui::send_json(conn, 403, error_json("REMOTE_ACCESS_DENIED", "WebUI is restricted to this device"));
            return true;
        }
        if (!is_allowed_origin(conn)) {
            kernel_module::webui::send_json(conn, 403, error_json("ORIGIN_DENIED", "Request origin does not match this WebUI"));
            return true;
        }
        if (path == "/api/session") {
            const std::string response = "{\"ok\":true,\"code\":\"OK\",\"message\":\"\",\"errno\":0,\"requestId\":\""
                + file_manager::randomHex(8) + "\",\"data\":{\"token\":\"" + m_session_token + "\"}}";
            kernel_module::webui::send_json(conn, 200, response);
            return true;
        }
        const char* token = mg_get_header(conn, "X-SKRoot-Session");
        if (!token || m_session_token != token) {
            kernel_module::webui::send_json(conn, 401, error_json("INVALID_SESSION", "Missing or invalid WebUI session token"));
            return true;
        }
        if (path.rfind("/api/files/", 0) == 0) {
            file_manager::ApiReply reply = m_file_api.handle(path, body);
            kernel_module::webui::send_json(conn, reply.status, reply.body);
            return true;
        }
        if (path.rfind("/api/automation/", 0) == 0) {
            automation::ApiReply reply = m_automation_api.handle(path, body);
            kernel_module::webui::send_json(conn, reply.status, reply.body);
            return true;
        }

        if (path == "/sendCommand" && m_automation_api.isRunActive()) {
            kernel_module::webui::send_json(conn, 409, error_json("AUTOMATION_BUSY", "Terminal input is locked while automation is running"));
            return true;
        }

        std::string resp;
        if(path == "/sendCommand") resp = handle_send_command(body);
        else if(path == "/getNewOutput") resp = handle_get_new_output(body);
        else if(path == "/getQuickActions") resp = handle_get_quick_actions(body);
        else if(path == "/listDir") resp = handle_list_dir(body);
        else if(path == "/getAutoTasks") resp = handle_get_auto_tasks();
        else if(path == "/saveAutoTasks") resp = handle_save_auto_tasks(body);
        else if(path == "/getHideDir") resp = handle_get_hide_dir();
        else if(path == "/checkFileType") resp = handle_check_file_type(body);
        else if(path == "/checkExecMount") resp = handle_check_exec_mount(body);
        else if(path == "/getTerminalKeepMode") resp = handle_get_terminal_keep_mode();
        else if(path == "/saveTerminalKeepMode") resp = handle_save_terminal_keep_mode(body);
        else if(path == "/getTerminalTransportMode") resp = handle_get_terminal_transport_mode();
        else if(path == "/saveTerminalTransportMode") {
            if (body != "pty" && body != "pipe") {
                kernel_module::webui::send_json(conn, 400, error_json("INVALID_TRANSPORT_MODE", "Transport mode must be pty or pipe"));
                return true;
            }
            resp = handle_save_terminal_transport_mode(body);
        }
        else if(path == "/exitWebui") resp = handle_exit_webui();
        else {
            kernel_module::webui::send_json(conn, 404, error_json("NOT_FOUND", "Unknown WebUI route"));
            return true;
        }

        kernel_module::webui::send_text(conn, 200, resp);
        return true;
    }

    ServerExitAction onBeforeServerExit() override { return ServerExitAction::KeepRunning; }

private:
    static std::string error_json(const std::string& code, const std::string& message) {
        return "{\"ok\":false,\"code\":\"" + json_escape(code) + "\",\"message\":\""
            + json_escape(message) + "\",\"errno\":0,\"requestId\":\""
            + file_manager::randomHex(8) + "\",\"data\":null}";
    }

    static bool is_loopback_request(struct mg_connection* conn) {
        const mg_request_info* info = mg_get_request_info(conn);
        if (!info) return false;
        return webui_access::isLoopbackAddress(info->remote_addr)
            || webui_access::isLoopbackDestination(info->server_port, info->remote_port, info->remote_addr);
    }

    static bool is_loopback_host(const std::string& value) {
        if (value.empty()) return false;
        std::string hostname;
        std::string port;
        bool has_port = false;
        if (value.front() == '[') {
            const size_t close = value.find(']');
            if (close == std::string::npos) return false;
            hostname = value.substr(1, close - 1);
            if (close + 1 < value.size()) {
                if (value[close + 1] != ':') return false;
                has_port = true;
                port = value.substr(close + 2);
            }
        } else {
            const size_t first_colon = value.find(':');
            const size_t last_colon = value.rfind(':');
            if (first_colon != std::string::npos && first_colon == last_colon) {
                hostname = value.substr(0, first_colon);
                has_port = true;
                port = value.substr(first_colon + 1);
            } else {
                hostname = value;
            }
        }
        if (has_port && (port.empty() || !std::all_of(port.begin(), port.end(), [](unsigned char ch) {
                return std::isdigit(ch) != 0;
            }))) return false;
        if (has_port) {
            char* end = nullptr;
            errno = 0;
            const unsigned long parsed_port = std::strtoul(port.c_str(), &end, 10);
            if (errno != 0 || !end || *end != '\0' || parsed_port > 65535) return false;
        }
        std::transform(hostname.begin(), hostname.end(), hostname.begin(), [](unsigned char ch) {
            return static_cast<char>(std::tolower(ch));
        });
        return hostname == "localhost" || hostname == "127.0.0.1" || hostname == "::1"
            || hostname == "0:0:0:0:0:0:0:1";
    }

    static bool is_allowed_origin(struct mg_connection* conn) {
        const char* host_header = mg_get_header(conn, "Host");
        if (!host_header || !*host_header) return false;
        const std::string host = host_header;
        if (!is_loopback_host(host)) return false;
        const char* origin = mg_get_header(conn, "Origin");
        if (!origin || !*origin) return true;
        const std::string value = origin;
        return value == std::string("http://") + host || value == std::string("https://") + host;
    }

    void fork_sh_process_daemon() {
        pid_t shell_pid = m_su_interactive.get_shell_pid();
        if (shell_pid <= 1) return;

        pid_t ppid = getpid();
        pid_t child = fork();
        if(child == 0) {
            // Do this before waiting: the watchdog must not keep a PTY slave
            // alive while the WebUI process is still running.
            m_su_interactive.closeTransportFdsAfterFork();
            wait_parent_exit(m_root_key, ppid);
            printf("[module_hide_sh_exec] kill sh: %d\n", shell_pid);
            // The watchdog mirrors the original lifecycle contract: close
            // only the long-lived Shell, leaving its orphanable children
            // untouched. Drop inherited transport fds first so a PTY is not
            // kept alive by this post-fork helper.
            (void)::kill(shell_pid, SIGKILL);
            _exit(0);
        }
    }

    std::string handle_send_command(const std::string& body) {
        m_idle_killer.touch();
        if(body == "su") return "OK";
        m_su_interactive.sendLine(body);
        if (!body.empty() && body.length() < RECORD_CMD_LEN) {
            add_quick_actions({body});
        }
        return "OK";
    }

    std::string handle_get_new_output(const std::string& body) {
        m_idle_killer.touch();
        return m_su_interactive.takeOutput();
    }

    std::string handle_get_quick_actions(const std::string& body) {
        m_idle_killer.touch();
        return read_quick_actions_json();
    }

    std::string handle_list_dir(const std::string& body) {
        m_idle_killer.touch();
        std::string dir = body.empty() ? "/" : body;
        const std::string special_comm = SimpleHashUtil::to_random_string(m_root_key).data();
        return list_dir_helper::build_list_dir_result_json(dir, special_comm);
    }

    std::string handle_get_auto_tasks() {
        return m_automation_api.legacyGetTasks();
    }

    std::string handle_save_auto_tasks(const std::string& body) {
        automation::Error error;
        return m_automation_api.legacySaveTasks(body, error) ? "OK" : (error.message.empty() ? "Save failed" : error.message);
    }
	
    std::string handle_get_hide_dir() { return m_hide_dir; }
	
	std::string handle_check_file_type(const std::string& filepath) {
        m_idle_killer.touch();
        if (filepath.empty()) return "unknown";
        std::error_code ec;
        if (!fs::is_regular_file(filepath, ec)) return "not a file";
        std::ifstream file(filepath, std::ios::binary);
        if (!file) return "error reading";
        char buffer[32] = {0};
        file.read(buffer, sizeof(buffer));
        std::streamsize bytesRead = file.gcount();
        if (bytesRead >= 4 && buffer[0] == 0x7f && buffer[1] == 'E' && buffer[2] == 'L' && buffer[3] == 'F') {
            if (bytesRead >= 20) {
                uint16_t machine = *reinterpret_cast<uint16_t*>(&buffer[18]);
                if (machine == 183) return "executable_arm64";
                else if (machine == 40) return "executable_arm32";
                else return "executable_other_elf";
            }
            return "executable_unknown_elf";
        }
        if (bytesRead >= 2 && buffer[0] == '#' && buffer[1] == '!') return "shell_script";
        if (filepath.size() >= 3 && filepath.substr(filepath.size() - 3) == ".sh") return "shell_script";
        return "unknown";
    }
	
	std::string handle_check_exec_mount(const std::string& path) {
        m_idle_killer.touch();
        if (path.empty()) return "Empty path";
        std::error_code ec;
        if (!fs::exists(path, ec)) return "Path does not exist";
        struct statvfs st;
        if (::statvfs(path.c_str(), &st) != 0) return "Failed to get filesystem status";
		bool is_noexec = (st.f_flag & ST_NOEXEC) != 0;
		return is_noexec ? "can not exec" : "can exec";
    }
	
    std::string handle_get_terminal_keep_mode() {
        return read_terminal_keep_mode() ? "1" : "0";
    }

    std::string handle_save_terminal_keep_mode(const std::string& body) {
        write_terminal_keep_mode(body == "1");
        return "OK";
    }

    std::string handle_get_terminal_transport_mode() const {
        const TerminalTransportMode saved = read_terminal_transport_mode();
        return std::string("{\"effective\":\"") + terminalTransportModeName(m_transport_mode)
            + "\",\"saved\":\"" + terminalTransportModeName(saved) + "\"}";
    }

    std::string handle_save_terminal_transport_mode(const std::string& body) {
        if (body != "pty" && body != "pipe") return "INVALID_TRANSPORT_MODE";
        write_terminal_transport_mode(terminalTransportModeFromString(body));
        return "OK";
    }

	std::string handle_exit_webui() {
        // This handler runs on a CivetWeb worker. CivetServer::close() calls
        // mg_stop(), which waits for every worker (including this one) and can
        // deadlock the old WebUI process. _exit() below releases the listening
        // socket and all CivetWeb threads after module-owned state is cleaned.
		// Close the Shell transport first. File jobs and the automation worker
		// are independent of the WebUI request thread and may take longer to
		// join; PTY/pipe cleanup must not wait behind them.
		m_su_interactive.stop(true);
		m_file_api.shutdown();
        m_automation_api.shutdown();
        _exit(0);
        return "OK";
    }
private:
    std::string m_root_key;
    std::string m_session_token;
    CivetServer* m_server = nullptr;
    std::string m_hide_dir;
    bool m_keep_terminal = false;
    TerminalTransportMode m_transport_mode{TerminalTransportMode::Pty};
    SuInteractive m_su_interactive;
    file_manager::FileManagerApi m_file_api;
    automation::AutomationApi m_automation_api;
    IdleKiller m_idle_killer;
};

// SKRoot 模块名片
// 字段说明见 module_descriptor.h
SKROOT_MODULE_NAME("隐蔽终端PLUS")
SKROOT_MODULE_VERSION("4.3.0")
SKROOT_MODULE_DESC("提供隐蔽的sh执行通道、自动化，以及功能完善的双栏文件管理(类MT风格)功能。避免类似App带来的特征暴露风险。")
SKROOT_MODULE_AUTHOR("SKRoot、斓梦语")
SKROOT_MODULE_ID32("2fbe469d90f04ef89c6763c8d2885b47")
SKROOT_MODULE_ON_INSTALL(module_on_install)
SKROOT_MODULE_WEB_UI(MyWebHttpHandler)
// Independent module: do not consume the original module's update feed.
