[CmdletBinding()]
param(
    [string] $NdkBuild = "$env:LOCALAPPDATA/Android/Sdk/ndk/26.3.11579264/ndk-build.cmd",
    [string] $SdkRoot = (Join-Path $PSScriptRoot '../SKRoot-linuxKernelRoot/Pro(众测开放中)/src/testModule/kernel_module_kit'),
    [string] $OutputDirectory = (Join-Path $PSScriptRoot '../build/hidden-terminal-plus'),
    [string] $PackagePath = (Join-Path $PSScriptRoot '../release/隐蔽终端PLUS-4.3.0-arm64.zip')
)
$ErrorActionPreference = 'Stop'
$SdkRoot = [IO.Path]::GetFullPath($SdkRoot)
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
$PackagePath = [IO.Path]::GetFullPath($PackagePath)
foreach ($required in @($NdkBuild, "$SdkRoot/lib/libkernel_module_kit_static.a", "$SdkRoot/include/kernel_module_kit_umbrella.h")) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) { throw "Missing dependency: $required" }
}
if (Test-Path -LiteralPath $PackagePath) { throw "Package already exists: $PackagePath" }
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
& $NdkBuild -C "$PSScriptRoot/jni" "KERNEL_MODULE_KIT=$($SdkRoot.Replace('\', '/'))" "NDK_OUT=$OutputDirectory/obj" "NDK_LIBS_OUT=$OutputDirectory/libs" -j4
if ($LASTEXITCODE -ne 0) { throw "NDK build failed: $LASTEXITCODE" }
$library = "$OutputDirectory/libs/arm64-v8a/libmodule_hidden_terminal_plus.so"
$bytes = [IO.File]::ReadAllBytes($library)
if ($bytes.Length -lt 20 -or $bytes[0] -ne 127 -or $bytes[1] -ne 69 -or $bytes[2] -ne 76 -or $bytes[3] -ne 70 -or $bytes[4] -ne 2 -or $bytes[5] -ne 1 -or $bytes[18] -ne 183 -or $bytes[19] -ne 0) {
    throw 'Expected ELF64 little-endian AArch64 library.'
}
$binaryText = [Text.Encoding]::UTF8.GetString($bytes)
$version = [regex]::Match((Get-Content -Raw -LiteralPath "$PSScriptRoot/module_hide_sh_exec.cpp"), 'SKROOT_MODULE_VERSION\("([^"]+)"\)').Groups[1].Value
if (-not $version -or -not $binaryText.Contains($version)) { throw 'Module version validation failed.' }
if (-not $binaryText.Contains('2fbe469d90f04ef89c6763c8d2885b47') -or -not $binaryText.Contains('隐蔽终端PLUS') -or $binaryText.Contains('zse9vkTjLjWXbafvx8Mlh1MTf8SMTUEL') -or $binaryText.Contains('https://abcz316.github.io/SKRoot-linuxKernelRoot/module_hide_sh_exec/update.json')) {
    throw 'Module identity validation failed.'
}
$webroot = Join-Path $PSScriptRoot 'webroot'
foreach ($asset in @('vendor/codemirror.bundle.js', 'vendor/codemirror.LICENSE.txt', 'text-editor.js', 'text-editor.css', 'image-viewer.js', 'image-viewer.css', 'archive-browser.js')) {
    if (-not (Test-Path -LiteralPath (Join-Path $webroot $asset) -PathType Leaf)) { throw "Missing WebUI dependency: $asset" }
}
$items = @(@{ Path = 'libmodule_hidden_terminal_plus.so'; Source = $library })
foreach ($file in (Get-ChildItem -LiteralPath $webroot -File -Recurse | Sort-Object FullName)) {
    $relative = $file.FullName.Substring($webroot.Length + 1).Replace('\', '/')
    $items += @{ Path = "webroot/$relative"; Source = $file.FullName }
}
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $PackagePath) | Out-Null
$archive = [IO.Compression.ZipFile]::Open($PackagePath, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($item in $items) {
        $entry = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $item.Source, $item.Path, [IO.Compression.CompressionLevel]::Optimal)
        $entry.ExternalAttributes = 33188 -shl 16
    }
} finally { $archive.Dispose() }
$archive = [IO.Compression.ZipFile]::OpenRead($PackagePath)
try {
    if ($archive.Entries.Count -ne $items.Count) { throw 'Package entry count mismatch.' }
    foreach ($item in $items) {
        $entry = $archive.GetEntry($item.Path)
        if ($null -eq $entry) { throw "Missing package entry: $($item.Path)" }
        $stream = $entry.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)) }
        finally { $stream.Dispose() }
        if ($hash -ne (Get-FileHash -LiteralPath $item.Source -Algorithm SHA256).Hash) { throw "Package content mismatch: $($item.Path)" }
    }
} finally { $archive.Dispose() }
Write-Output "PACKAGE=$PackagePath"
Write-Output "SHA256=$((Get-FileHash -LiteralPath $PackagePath -Algorithm SHA256).Hash)"
