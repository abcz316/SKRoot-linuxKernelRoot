# 隐蔽终端PLUS 4.2.14：合并官方 3.1.1 终端修复

> 本文记录 4.2.14。当时复用通用帧解析器的提示符扫描存在边界差异；4.2.15 已改用专用扫描并移除额外 PTY slave，见 [TERMINAL_4.2.15.md](TERMINAL_4.2.15.md)。

## 来源和版本

工作区基线是用户提供的 4.2.13 源码，不是 4.1.13；用户已确认这一点。PLUS 初始修改提交为 `e77c013`，首次原始导入为 `12c9faa`。未取得独立的 4.2.12 源码快照，不能仅依据版本号断言那次尝试具体改了什么。

2026-10-10 联网核对 GitHub master 为 `7ad782c8bce0410381e9dae803206c4b76d6f56d`，与本地 SDK 仓库一致，其模块元数据为 3.1.1。模块最后一次修改提交为 `ccd92af467366cd2102eebf9b87d7b67533200af`；前次模块提交 `dcfd6fa7c6eb0662be5240aebe847be0e73c61ef` 的版本为 3.1.0。

- [官方 3.1.1 模块源码](https://github.com/abcz316/SKRoot-linuxKernelRoot/tree/7ad782c8bce0410381e9dae803206c4b76d6f56d/Pro%28%E4%BC%97%E6%B5%8B%E5%BC%80%E6%94%BE%E4%B8%AD%29/src/testModule/module_hide_sh_exec)
- [Pipe 实现](https://github.com/abcz316/SKRoot-linuxKernelRoot/blob/7ad782c8bce0410381e9dae803206c4b76d6f56d/Pro%28%E4%BC%97%E6%B5%8B%E5%BC%80%E6%94%BE%E4%B8%AD%29/src/testModule/module_hide_sh_exec/su_interactive/pipe_su_interactive.cpp)
- [PTY 实现](https://github.com/abcz316/SKRoot-linuxKernelRoot/blob/7ad782c8bce0410381e9dae803206c4b76d6f56d/Pro%28%E4%BC%97%E6%B5%8B%E5%BC%80%E6%94%BE%E4%B8%AD%29/src/testModule/module_hide_sh_exec/su_interactive/pty_su_interactive.cpp)

## 差异与最终取舍

| 项目 | 4.2.13 基线 | 官方 3.1.1 | PLUS 4.2.14 |
| --- | --- | --- | --- |
| Pipe 提示符 | 不设置提示符 rc | 设置 PS1 就绪标记，跨 read 分块解析 | 合入官方协议；兼容 PLUS 自动化控制帧 |
| Pipe 空闲 | 始终 false | 提示符置就绪，含换行输入先清除 | 采用官方判定；未见标记前仍未知 |
| PTY 前台 | TIOCGPGRP 与 Shell pgid 比较 | 同一判定方式 | 保留这套官方判定 |
| Pipe 手动回显 | WebUI 本地回显 | Native sendLine 回显 | 采用 Native，删除前端重复回显 |
| 标准 IO | 非阻塞、50ms poll、关闭标志 | 阻塞 read/write、EINTR 重试 | 采用官方流程，移除原来的机制 |
| 停止/回收 | 先尝试回收、锁序列化、统一回收策略 | Pipe 与 PTY 各自的停止/wait 流程 | 按模式移植官方流程；不保留并发停止锁 |
| fd 清理 | 主进程关闭所有终端 fd，看护关闭继承 fd | Pipe closeInput 仅关闭输入；看护保留继承 fd | 按用户要求保留 4.2.13 清理方式 |
| 执行 su 前调度 | 恢复 CPU affinity、nice 0 | 未调用此恢复 | 按用户要求保留两条启动路径的恢复 |
| 模块身份 | PLUS 独立名称和 ID | 官方名称和 ID | 继续 PLUS 身份，版本增加到 4.2.14 |

保留现有 `SuInteractive` 接口以衔接 PLUS 自动化；停止实现分为 `stopPipe_` 与 `stopPty_`，分别对应官方实现。原子 fd 的 exchange 关闭属于保留的描述符清理，用于防止重复关闭，不承担读写取消功能。额外 PTY slave fd 仍供既有自动输入回显控制使用。

Pipe 提示符标记与现有自动化帧均为 RS/US 格式，接入现有跨块解析器并优先处理提示符，避免把提示符交给自动化回调。自动输入的原始字节、强制执行方案、ANSI 渲染、文件管理和归档安装功能保持现有实现。只把手动命令回显迁移到 Native，自动化发送不额外插入手动回显。

官方 Pipe 注释称“强制 sh -i”，但两条实际启动路径都是 `argv = {"su", nullptr}` 后 `execvp("su", argv)`，并未传 `-i`。本次以实际源码为准，不凭注释追加参数，也不把主机模拟 Shell 测试当作目标设备 su 的实测。

## 行为边界

遵循官方阻塞 IO 后，继承管道端点的子进程可能延长停止时间；不再承诺 4.2.13 的读写可中断和并发停止能力。官方 PTY 的 SIGKILL 之后最后一次 waitpid 使用 WNOHANG，本次没有替换为阻塞兜底回收。Pipe 的提示符状态是交互协议提示，不是对任意程序、改写 PS1 或批量排队输入的通用任务完成保证。

旧版 4.2.13 安装包保留。当前源码目录名仍包含 4.2.13，以保持 Git 路径和历史连续性；实际模块元数据与新安装包是 4.2.14。

## 验证

测试使用 WSL Linux 的隔离 su 替身（交互式 POSIX Bash，以及无提示符的非交互式分支），不调用主机系统 su。覆盖提示符、read 输入、PS2、多次启动、前后台进程、原 ENV、无效 rc 路径、控制帧分块、看护 fd 清理、阻塞读写及自然退出。旧的并发停止与无条件限时停止用例按上游语义改写；阻塞行为使用有限寿命的子进程验证。

最终执行结果：

- `tests/run-host-tests.sh`：8 组 C++ 测试全部通过，31 项 JavaScript 测试全部通过。
- 调度测试通过；`shell_scheduler.cpp/.h` 本次未修改，两条 su exec 路径仍在执行前调用恢复。
- 看护 fd 清理测试验证子进程关闭继承 fd 后，不影响父进程的终端读写。
- NDK r26d / Android ARM64 编译成功，包内 ELF 名称、ID、版本及 ZIP 每项文件哈希校验通过。
- 主机编译有 SDK 既有 `module_err_def.h` 文件末尾反斜杠换行警告，没有编译错误。
- 未安装到真实设备，目标 SKRoot su 的交互提示符和完整设备行为仍需真机验证。

安装包：`release/隐蔽终端PLUS-4.2.14-arm64.zip`，1,100,009 字节。

SHA-256：`ea44031d0be141d07904cdb9004eaac5e300984ee41d7b08c299d03da46172bb`。
