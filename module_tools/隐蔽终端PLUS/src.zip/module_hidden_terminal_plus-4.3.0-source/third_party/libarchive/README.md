# libarchive Android dependency

The archive extraction service links a small, static arm64 build of
libarchive 3.8.8 and xz/liblzma 5.8.1.  ZIP and the 7z/RAR readers are built
in; Android's system zlib supplies the zlib symbols.

## Source hashes

```text
libarchive-3.8.8.tar.xz  3873a88801da067d0528a989af06877710529d50ee8fe6f3970cbb4302efb918
xz-5.8.1.tar.xz          0b54f79df85912504de0b14aec7971e3f964491af1812d83447005807513cd9e
```

The source archives are cached outside the repository at
`$HOME/.cache/skroot-archive-deps/`.  Rebuild with Android NDK r26d from a
space-free checkout (NDK's make frontend rejects paths containing spaces):

```sh
export NDK=/path/to/android-ndk-r26d
export API=23
export TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/linux-x86_64"

# Build xz/liblzma first, then libarchive against the resulting arm64 prefix.
./configure --host=aarch64-linux-android --enable-static --disable-shared \
  --disable-doc --disable-tests --disable-xzdec --disable-lzmadec \
  CC="$TOOLCHAIN/bin/aarch64-linux-android${API}-clang" \
  AR="$TOOLCHAIN/bin/llvm-ar" RANLIB="$TOOLCHAIN/bin/llvm-ranlib"
make -j2

# Copy libarchive.a, liblzma.a and archive*.h into this module's
# jni/prebuilt/arm64-v8a and third_party/libarchive/include directories.
```

Licenses are kept in `third_party/licenses/` next to the headers and static
archives.  Update the hashes above whenever the dependency versions change.
