# Android ZIP UTF-8 路径兼容修复（4.2.11）

部分 Windows/FAT 压缩工具会同时写入 ZIP UTF-8 标志与 Info-ZIP Unicode Path extra field。Android 原生进程即使启用 `C.UTF-8` locale，libarchive 的字符集桥仍可能返回 `ARCHIVE_WARN` 和空路径，导致此前的安全路径校验终止任务。

4.2.11 在 libarchive 路径为空时只读取 ZIP 中央目录中的名称：优先使用通过严格 UTF-8 校验的 UTF-8 标志名称，或 CRC 匹配的 Unicode Path extra field。恢复后的名称继续经过绝对路径、`..`、长度和目标目录边界校验；压缩数据、CRC、加密状态和格式解析仍由 libarchive 处理。
