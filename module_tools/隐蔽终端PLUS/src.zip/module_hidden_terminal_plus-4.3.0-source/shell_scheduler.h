#pragma once

namespace shell_scheduler {

struct RestoreResult {
    bool nice_restored{false};
    bool affinity_restored{false};
    int nice_error{0};
    int affinity_error{0};
};

// Restore ordinary shell scheduling immediately before exec.
// This only changes the calling task. The parent WebUI process, PTY reader,
// watchdog and CivetWeb workers retain their existing scheduling policy.
RestoreResult restoreForExec() noexcept;

} // namespace shell_scheduler
