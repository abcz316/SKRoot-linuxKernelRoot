# module_hide_sh_exec 4.0.1 scheduler-fix workspace

> 本文件保留上游派生版本历史。当前 PLUS 版本为 4.3.0，以 README.md 和 FILE_FEATURES_4.3.0.md 为准；终端实现继续沿用 TERMINAL_4.2.15.md，下述 4.2.13 的非阻塞读写及 pipe 空闲策略已被后续合并替换。

- Baseline: working-tree snapshot of SKRoot Pro `module_hide_sh_exec` 4.0.1.
- Purpose: isolate the shell child scheduling fix from the original workspace.
- Scope: restore the shell child to normal CPU affinity and nice 0 immediately before `execvp("su")`.
- Current output version: `4.2.13`.
- 4.2.13 restores PID-only Shell shutdown: lifecycle cleanup never broadcasts to
  the Shell process group or recursively kills descendants. PTY idle checks use
  the foreground process group; pipe mode conservatively reports unknown state
  and avoids `/proc` descendant scans. The post-fork watchdog closes inherited
  transport descriptors before waiting for the parent.
- Automation uses a force-run profile: starting a sequence skips Shell
  foreground/idle probes in both PTY and pipe modes and writes the configured
  bytes directly to the long-lived Shell. Any foreground program may consume
  queued input according to normal stdin semantics.
- Previous 4.2.12 force-run arm64 library SHA-256: `24e5a4d9a35a050b9e08ed708fae6f9b7efc739b29ec449988e27a533942c0e5`.
- Previous 4.2.12 force-run package SHA-256: `fd60f80715ffa5f9342c4985cc9b883f509e3c8b0e3028c26a25d2a7918e844c`.
- Original baseline package SHA-256: `145a316e7be099e16ce2335afb15065d9d94bcc07f51205929dae2cccf29a5b1`.
- 4.0.3 arm64 library SHA-256: `0c063adb9f2f06e1d4e69254c8984d373efab14378e6118d36ff72720e1adec7`.
- 4.0.3 package SHA-256: `37555d45bfcff6ff90d635155fc99d5b374c28b83afbac22e9839c9240a0e9b4`.
- 4.0.4 arm64 library SHA-256: `a262bc13780421dfe3d57457b0db636f07ff5970a064bcef24450748dc55fa16`.
- 4.0.4 package SHA-256: `b2a1a8212a3d55aef29a4c59d92729f137c198f177a54ad54038db95ed5b912e`.
- 4.0.5 arm64 library SHA-256: `6ced5bd03c61b0ae326571171a7b95dd555e11d25db1c980df3740ff698ef006`.
- 4.0.5 package SHA-256: `f23e9a972cb19c828c696bc783e44c6e24777b522f55bc283df58ba954a68136`.
- 4.1.0 arm64 library SHA-256: `a4873515fd7e535a1c2529c293c96d9b1e19d366db12757bac7413035a30ed83`.
- 4.1.0 package SHA-256: `bd5f81eb7021015c69a23c37f8bb27008776c7d979226a5e7276468e6c3962f0`.
- 4.2.0 adds completion-aware sequential automation schemes, draft autosave, favorites,
  timed step input, revision-protected automation APIs, and PTY control-frame filtering.
- 4.2.0 arm64 library SHA-256: `e897861a14615e862e58e392b6cf97a7c6a4c0eec3c48a2bc2f7cd5c1c824108`.
- 4.2.0 package SHA-256: `9d8a50f1dd193e0b61233d743d8240ae5f045addeedf9a3ad34b58ebf71c35ff`.
- `隐蔽终端-4.2.0-arm64.zip` is byte-identical to the English-named package.
- 4.2.1 replaces long PTY wrapper injection with a short `__ska` runner command and
  adds true-device verified echo filtering and timeout/cancel terminal restoration.
- 4.2.1 arm64 library SHA-256: `5edf0918286b82ece37b5f2ec04e0fa1a8dcde5f1bea45f98149f23158f3879f`.
- 4.2.1 package SHA-256: `cb166b4b68bd3d37fc5b8f48131e536d39fa1cc6c6763f37e25d5416c079637d`.
- `隐蔽终端-4.2.1-arm64.zip` is byte-identical to the English-named package.
- 4.2.2 updates the WebUI density and input-simulator save interaction without changing
  Native APIs or terminal lifecycle behavior.
- 4.2.2 arm64 library SHA-256: `beff512f160b6d3abbea654f43cfff304f95a22642e2cf56449650dd0eac8b23`.
- 4.2.2 package SHA-256: `69ffde81d88103b10e1dad023b1cd90b683a14625a83b0f21c6654e95b868a50`.
- `隐蔽终端-4.2.2-arm64.zip` is byte-identical to the English-named package.
- 4.2.3 adds selectable PTY/anonymous-pipe terminal transport and explicit PTY
  lifecycle cleanup while preserving compatibility-mode background behavior.
- 4.2.3 arm64 library SHA-256: `88c6db0bfade6b8d97bb1d94e920fcf6940ade335611da938ad8795aeda87c5e`.
- 4.2.3 package SHA-256: `0851067ba75adefb61e1034e0af63516b59d9cc4fa80047075952b7243c461ac`.
- `隐蔽终端-4.2.3-arm64.zip` is byte-identical to the English-named package.
- 4.2.4 makes libarchive operations use a thread-local UTF-8 locale, fixing
  ZIP/7z entries with Chinese or other UTF-8 path names under the native C locale.
- 4.2.4 arm64 library SHA-256: `cc441167a2cd874b6788ddb5899fbc647c883e2cb440a9db88f6f80561f8e259`.
- 4.2.4 package SHA-256: `08773b7b589e17743972a9d368921956618b2387072a7e074bb0d407d7541ac6`.
- `隐蔽终端-4.2.4-arm64.zip` is byte-identical to the English-named package.
- 4.2.5 adds single/batch ZIP compression with UTF-8 paths, atomic auto-renamed output,
  special-file warnings, and progress/cancel support. It also adds confirmed single-APK
  root installation through direct `cmd package`/`pm` execution with process-group cleanup,
  result codes, cancellation and timeout handling.
- 4.2.5 arm64 library SHA-256: `6daab06d29cd646667efcb86ff648188e1128b8e019301a402117fd0ac9f1e50`.
- 4.2.5 package SHA-256: `2df18042c48dede22dd005d818db7ab15d122d0054766287683a62ac01c0d2ed`.
- `隐蔽终端-4.2.5-arm64.zip` is byte-identical to the English-named package.
- 4.2.6 fixes APK installation from FUSE-backed paths such as `/sdcard` by streaming
  the root-opened APK through `cmd package install -S SIZE`/`pm install -S SIZE`, avoiding
  system_server re-opening the path under the `fuse` SELinux label. Error output is reduced
  to actionable summary lines while retaining request IDs.
- 4.2.6 arm64 library SHA-256: `9cb459facb35086f5fcb1babedbe034244d29cfa461861ed06c546075a617ee4`.
- 4.2.6 package SHA-256: `2b0145d5df6a2fe37e28073e12ec3b671ca121b124f04a5970e1ede70fc0536d`.
- `隐蔽终端-4.2.6-arm64.zip` is byte-identical to the English-named package.
- 4.2.7 fixes OEM package-manager sessions that reject FUSE-backed APK file
  descriptors with `fstat failed: EACCES`: it retries through a randomized,
  mode-0644 `/data/local/tmp` staging file and removes that file after install.
- 4.2.7 arm64 library SHA-256: `a00ceaa4eaa3d964fa8f8419cd96fd22e0e734472fe48a1dcce647ffb84efc9d`.
- 4.2.7 English package SHA-256: `a03f8119dc3a05152a4ff1d522e6a901c3724a84da7911faf2388e38a0211549`.
- 4.2.7 Chinese package SHA-256: `a03f8119dc3a05152a4ff1d522e6a901c3724a84da7911faf2388e38a0211549`.
- 4.2.8 uses an anonymous pipe as the only APK transport. The root process
  reads the source APK and forwards bytes to `cmd/pm install -S`; no FUSE fd is
  passed to `system_server` and no `/data/local/tmp` APK fallback is created.
- 4.2.8 arm64 library SHA-256: `0961e41900e840b70adf38116177ebd1c6c5a9abd12bf9b541717cb3b10f5178`.
- 4.2.8 package SHA-256: `00128c1054f03369b1b6693a4ff0484a44da6f2fd2aed3e5c530a17e1205c1b2`.
- 4.2.9 makes the expanded terminal help/settings area shrink within the terminal
  viewport and scroll internally, preserving the bottom action and safe-area inset.
- 4.2.9 arm64 library SHA-256: `cf84578c460ed71259893c6a9726218e7043b1b64d06fff4944517cde6a6926d`.
- 4.2.9 package SHA-256: `704018932723db727051637b984107df1b1734398ebae1afdfe1ab1a72071253`.
- 4.2.10 recognizes regular files ending in `.apk.1` as installable APKs in both
  the WebUI and Native validation, while preserving anonymous-pipe transport.
- 4.2.10 arm64 library SHA-256: `84b81710645596f09f97c8f74c9ad22045c5e91eb4a4aa8ae58cdc16e6ff1ae2`.
- 4.2.10 package SHA-256: `11eb2afde0a7279e329478c11d8d38ffd317e286bc737c21e220935e2dfbb242`.
- 4.2.11 recovers validated UTF-8 ZIP paths from the central directory when
  Android libarchive returns `ARCHIVE_WARN` with a null converted pathname.
- 4.2.11 arm64 library SHA-256: `5b654a4575786ebb2cf80cbb65b36d655a4f4a9f9a892dd74ade89b099b9d475`.
- 4.2.11 package SHA-256: `ad02b174891f32fcc0ae17c1bc64d43b3928a752fd9e17fd908092896e72805c`.
- Previous 4.0.2 package remains in `testModule/module_hide_sh_exec/dist/` for rollback.
