# 隐蔽终端PLUS

从用户提供的 `module_hide_sh_exec-4.2.13-source.zip` 建立的独立模块。
历史文档描述上游版本，当前身份和构建方式以本文件为准。

- 模块名称：隐蔽终端PLUS
- 独立 ID（固定 32 字符）：`2fbe469d90f04ef89c6763c8d2885b47`
- 当前版本：`4.3.0`；独立模块初始源码基线为 `4.2.13`。
- 架构：Android ARM64 / arm64-v8a
- 产物：`libmodule_hidden_terminal_plus.so` + `webroot/`
- 保留原作者信息与第三方许可；不接入原模块的更新源。

新 ID 用于与原模块区分，后续升级本模块应保持此 ID 不变。
不自动迁移原模块数据。终端、自动化及 su 调度沿用 4.2.15。

4.3.0 增加带语法高亮/行号/字号/显示换行的 UTF-8 编辑器、图片预览、压缩包目录浏览和部分解压。使用方法、限制及验证见 [FILE_FEATURES_4.3.0.md](FILE_FEATURES_4.3.0.md)。

## 构建安装包

使用 PowerShell 7、Android NDK r26d 和工作区内的 SKRoot Pro SDK：

```powershell
./module_hide_sh_exec-4.2.13-source/build-package.ps1
```

可传入 `-NdkBuild`、`-SdkRoot`、`-OutputDirectory`、`-PackagePath` 指定路径。
脚本拒绝覆盖已有安装包，验证 ARM64 ELF、模块身份及 ZIP 每项内容的 SHA-256。
默认安装包位于工作区 `release/隐蔽终端PLUS-4.3.0-arm64.zip`。
通过 SKRoot Pro 的模块安装入口选择该 ZIP；不是 APK 或 Magisk 模块包。

离线 CodeMirror bundle 与许可证已纳入源码。修改编辑器依赖时，在 `tools/text-editor` 运行 `npm ci`、`npm run build` 后再打包；日常 NDK 构建无需 Node 或联网。

## Git

源码由工作区根目录 Git 仓库追踪，原始导入与 PLUS 修改分别提交。
构建产物位于工作区忽略的 `build/` 和 `release/`，不纳入源码提交。

## 首次打包验证（2026-10-10）

以下记录仅对应首次 4.2.13 包；4.2.14 的合并取舍与验证见 [UPSTREAM_3.1.1_MERGE.md](UPSTREAM_3.1.1_MERGE.md)。
4.2.15 对齐专用 Pipe 提示符扫描并移除 PTY 额外 slave，见 [TERMINAL_4.2.15.md](TERMINAL_4.2.15.md)。

- NDK r26d ARM64 编译成功，安装包大小 1,099,286 字节。
- ELF 内嵌新名称与新 ID 校验通过，旧 ID 和旧更新 URL 均不存在。
- ZIP 内所有文件与构建产物/WebUI 源文件逐项 SHA-256 一致。
- 现有 JavaScript 回归测试 30/30 通过；尚未进行真机安装测试。
- 安装包 SHA-256：`47931f602377ecf88d0178ca50baf7dd176598d52d8418fa1b6a4c23c87b8e4f`。
