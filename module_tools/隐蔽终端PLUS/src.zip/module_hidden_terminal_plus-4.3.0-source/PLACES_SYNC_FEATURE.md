# Bookmarks, recent paths, and pane synchronization (4.1.0)

The file manager now persists bookmarks and the twenty most recently visited
directories in the module-private `file_manager_places_v1` storage record.
Paths are normalized, deduplicated, and returned through authenticated
`/api/files/places/get` and `/api/files/places/set` endpoints.

The WebUI adds:

- an **Add bookmark** action for the active pane's current directory;
- a half-height bottom drawer with **Recent** and **Bookmarks** tabs;
- upward opening from the bottom handle and pull-down dismissal when the list
  is at its top;
- tap-to-navigate using the pane that was active when the drawer opened;
- long-press actions for deleting recent entries, adding a recent directory to
  bookmarks, deleting bookmarks, and editing bookmark notes;
- a **Synchronize panes** overflow action that copies the active pane's path,
  entries, and scroll position to the opposite pane without changing either
  pane's saved home directory.

Recent paths are recorded only after a directory listing succeeds. Internal
refreshes caused by jobs, renames, file creation, or text saves do not reorder
the recent list.
