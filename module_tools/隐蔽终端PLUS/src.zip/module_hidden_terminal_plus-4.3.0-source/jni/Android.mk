LOCAL_PATH := $(call my-dir)
KERNEL_MODULE_KIT ?= $(LOCAL_PATH)/../../SKRoot-linuxKernelRoot/Pro(众测开放中)/src/testModule/kernel_module_kit

include $(CLEAR_VARS)
LOCAL_MODULE := kernel_module_kit_static_prebuilt
LOCAL_SRC_FILES := $(KERNEL_MODULE_KIT)/lib/libkernel_module_kit_static.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := libarchive_static_prebuilt
LOCAL_SRC_FILES := prebuilt/arm64-v8a/libarchive.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := liblzma_static_prebuilt
LOCAL_SRC_FILES := prebuilt/arm64-v8a/liblzma.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := module_hidden_terminal_plus
LOCAL_CPP_FEATURES += exceptions

LOCAL_SRC_FILES := ../module_hide_sh_exec.cpp ../su_interactive.cpp ../idle_killer.cpp ../cJSON.cpp \
    ../file_manager_service.cpp ../file_manager_api.cpp ../archive_service.cpp ../shell_scheduler.cpp
LOCAL_SRC_FILES += ../automation_service.cpp
LOCAL_SRC_FILES += ../image_preview_service.cpp ../archive_browser_service.cpp

LOCAL_C_INCLUDES  += $(KERNEL_MODULE_KIT)/include
LOCAL_STATIC_LIBRARIES := kernel_module_kit_static_prebuilt libarchive_static_prebuilt liblzma_static_prebuilt
LOCAL_LDLIBS += -lz

include $(LOCAL_PATH)/build_macros.mk

include $(BUILD_SHARED_LIBRARY)
