# WebUI exit deadlock fix (4.0.3)

`/exitWebui` is dispatched on a CivetWeb worker thread. Calling
`CivetServer::close()` there enters `mg_stop()`, while the CivetWeb master
thread joins all workers before completing the stop. The request worker waits
for the master and the master waits for that request worker, leaving a stale
process with a closed listener.

Version 4.0.3 keeps the existing exit behavior but removes the synchronous
server close from the request handler:

1. stop/cancel module-owned file work;
2. terminate and reap the interactive shell;
3. call `_exit(0)`;
4. let the kernel close the HTTP listening socket and all remaining file
   descriptors as part of process exit.

The idle timeout still calls `CivetServer::close()` from the dedicated
`IdleKiller` thread, where it is outside the CivetWeb worker pool.
