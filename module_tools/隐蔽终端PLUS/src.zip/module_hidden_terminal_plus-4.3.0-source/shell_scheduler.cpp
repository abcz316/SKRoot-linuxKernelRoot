#include "shell_scheduler.h"

#include <cerrno>
#include <sched.h>
#include <sys/resource.h>

namespace shell_scheduler {

RestoreResult restoreForExec() noexcept {
    RestoreResult result;

    // The WebUI framework raises the launching thread to nice -10. nice is
    // inherited across fork/exec, so return the shell branch to the ordinary
    // Android/Linux value without changing the parent task.
    errno = 0;
    if (::setpriority(PRIO_PROCESS, 0, 0) == 0) {
        result.nice_restored = true;
    } else {
        result.nice_error = errno;
    }

    // Ask for every CPU representable by the libc ABI. The kernel intersects
    // this mask with online CPUs and the task's cpuset/cgroup allowance, so the
    // call expands an inherited performance-cluster mask without moving the
    // shell to another cgroup.
    cpu_set_t available_mask;
    CPU_ZERO(&available_mask);
    for (int cpu = 0; cpu < CPU_SETSIZE; ++cpu) {
        CPU_SET(cpu, &available_mask);
    }

    errno = 0;
    if (::sched_setaffinity(0, sizeof(available_mask), &available_mask) == 0) {
        result.affinity_restored = true;
    } else {
        result.affinity_error = errno;
    }

    return result;
}

} // namespace shell_scheduler
