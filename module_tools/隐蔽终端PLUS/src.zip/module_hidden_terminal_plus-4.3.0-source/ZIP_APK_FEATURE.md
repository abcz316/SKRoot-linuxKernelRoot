# ZIP 压缩与 APK Root 安装（4.2.10）

文件管理器支持将单个或批量选择的文件、目录压缩为 ZIP，并将结果写入另一栏在确认时的目录。输出名称取排序后第一项名称；同名时自动追加 `(1)`、`(2)`，不覆盖已有归档。实现使用 libarchive、UTF-8 路径、分块读写、原子提交和现有后台任务进度/取消机制；symlink 仅保存链接本身，特殊文件提示后跳过。

单个 `.apk` 或 `.apk.1` 普通文件可通过二次确认启动 root 安装任务，兼容 QQ、微信下载后追加 `.1` 的安装包。原文件无需改名。Native 层以 root 打开 APK，通过匿名 pipe 将内容流入系统 `cmd package install -r -d --user 0 -S SIZE` 的标准输入；缺少 `cmd` 时使用 `pm install`。FUSE 文件描述符不会直接传入 `system_server`，也不创建 `/data/local/tmp` 中转文件；如果设备拒绝匿名 pipe，任务直接返回包管理器错误。任务捕获安装结果，支持取消、10 分钟超时和进程回收，并继续遵循 WebUI session 与单写任务互斥。
