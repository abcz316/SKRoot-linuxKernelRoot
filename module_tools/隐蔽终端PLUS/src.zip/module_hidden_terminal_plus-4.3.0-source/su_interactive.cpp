#include "su_interactive.h"

#include "shell_scheduler.h"
#include "stream_control_filter.h"
#include "pipe_output_filter.h"

#include <unistd.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <termios.h>

#include <cstdlib>
#include <cstring>
#include <chrono>
#include <thread>
#include <utility>
namespace {

bool waitPidBlocking(pid_t pid, int& status) {
    for (;;) {
        pid_t result = ::waitpid(pid, &status, 0);
        if (result == pid) return true;
        if (result < 0 && errno == EINTR) continue;
        return false;
    }
}

} // namespace

const char* terminalTransportModeName(TerminalTransportMode mode) {
    return mode == TerminalTransportMode::Pipe ? "pipe" : "pty";
}

TerminalTransportMode terminalTransportModeFromString(std::string_view value) {
    return value == "pipe" ? TerminalTransportMode::Pipe : TerminalTransportMode::Pty;
}

SuInteractive::SuInteractive() = default;

SuInteractive::~SuInteractive() {
    stop(true);
}

void SuInteractive::setCloExec(int fd) {
    const int flags = ::fcntl(fd, F_GETFD);
    if (flags >= 0) (void)::fcntl(fd, F_SETFD, flags | FD_CLOEXEC);
}

bool SuInteractive::makePipe(int fds[2]) {
    if (::pipe(fds) != 0) return false;
    setCloExec(fds[0]);
    setCloExec(fds[1]);
    return true;
}

void SuInteractive::safeClose(int& fd) {
    if (fd >= 0) {
        ::close(fd);
        fd = -1;
    }
}

void SuInteractive::safeClose(std::atomic<int>& fd) {
    const int value = fd.exchange(-1, std::memory_order_acq_rel);
    if (value >= 0) ::close(value);
}

static void ignore_sighup() {
    struct sigaction action {};
    action.sa_handler = SIG_IGN;
    sigemptyset(&action.sa_mask);
    action.sa_flags = 0;
    (void)::sigaction(SIGHUP, &action, nullptr);
}

void SuInteractive::cleanupLegacyFiles_(std::string_view rc_dir) {
    if (rc_dir.empty()) return;
    std::string dir(rc_dir);
    while (dir.size() > 1 && dir.back() == '/') dir.pop_back();
    (void)::unlink((dir + "/.skroot_mkshrc").c_str());
    (void)::unlink((dir + "/work/.skroot_automation_runner").c_str());
}

void SuInteractive::setupShellPromptEnv_(std::string_view rc_dir, TerminalTransportMode mode) {
    const bool pipe = mode == TerminalTransportMode::Pipe;
    if (!pipe && rc_dir.empty()) return;
    const std::string prompt = pipe ? std::string(PipeOutputFilter::kReadyMarker) + "# " : "# ";
    if (rc_dir.empty()) {
        ::unsetenv("ENV");
        ::unsetenv("SKROOT_ORIG_ENV");
        ::setenv("PS1", prompt.c_str(), 1);
        ::setenv("PS2", "> ", 1);
        ::setenv("PROMPT", prompt.c_str(), 1);
        return;
    }
    std::string dir(rc_dir);
    while (dir.size() > 1 && dir.back() == '/') dir.pop_back();
    const std::string rc_path = dir + "/.skroot_mkshrc";
    const char* old_env = ::getenv("ENV");
    if (old_env && *old_env && rc_path != old_env) ::setenv("SKROOT_ORIG_ENV", old_env, 1);
    else ::unsetenv("SKROOT_ORIG_ENV");

    const int fd = ::open(rc_path.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
    if (fd >= 0) {
        const std::string rc =
            "if [ -n \"$SKROOT_ORIG_ENV\" ] && [ -r \"$SKROOT_ORIG_ENV\" ]; then\n"
            "  . \"$SKROOT_ORIG_ENV\"\n"
            "fi\n"
            "unset SKROOT_ORIG_ENV\n"
            "PS1='" + prompt + "'\n"
            "PS2='> '\n"
            "PROMPT=\"$PS1\"\n";
        size_t left = rc.size();
        const char* cursor = rc.data();
        while (left > 0) {
            const ssize_t written = ::write(fd, cursor, left);
            if (written > 0) {
                cursor += written;
                left -= static_cast<size_t>(written);
            } else if (written < 0 && errno == EINTR) {
                continue;
            } else {
                break;
            }
        }
        ::close(fd);
        (void)::chmod(rc_path.c_str(), 0600);
        if (left == 0) {
            ::setenv("ENV", rc_path.c_str(), 1);
        } else {
            ::unsetenv("ENV");
            ::unsetenv("SKROOT_ORIG_ENV");
        }
    } else if (pipe) {
        // Preserve the marker through the environment if the rc is unwritable.
        ::unsetenv("ENV");
        ::unsetenv("SKROOT_ORIG_ENV");
    }
    ::setenv("PS1", prompt.c_str(), 1);
    ::setenv("PS2", "> ", 1);
    ::setenv("PROMPT", prompt.c_str(), 1);
}

bool SuInteractive::start(std::string_view shell_rc_dir, TerminalTransportMode mode) {
    stop(true);
    m_mode = mode;
    return mode == TerminalTransportMode::Pty
        ? startPty_(shell_rc_dir)
        : startPipe_(shell_rc_dir);
}

bool SuInteractive::startPipe_(std::string_view shell_rc_dir) {
    cleanupLegacyFiles_(shell_rc_dir);
    m_pipe_shell_ready.store(false, std::memory_order_release);
    m_pipe_prompt_seen.store(false, std::memory_order_release);
    {
        std::lock_guard<std::mutex> lock(m_mu);
        m_out.clear();
    }
    int in_pipe[2]{-1, -1};
    int out_pipe[2]{-1, -1};
    if (!makePipe(in_pipe) || !makePipe(out_pipe)) {
        safeClose(in_pipe[0]); safeClose(in_pipe[1]);
        safeClose(out_pipe[0]); safeClose(out_pipe[1]);
        return false;
    }
    const pid_t pid = ::fork();
    if (pid < 0) {
        safeClose(in_pipe[0]); safeClose(in_pipe[1]);
        safeClose(out_pipe[0]); safeClose(out_pipe[1]);
        return false;
    }
    if (pid == 0) {
        if (::dup2(in_pipe[0], STDIN_FILENO) < 0 ||
            ::dup2(out_pipe[1], STDOUT_FILENO) < 0 ||
            ::dup2(STDOUT_FILENO, STDERR_FILENO) < 0) _exit(126);
        ::close(in_pipe[0]); ::close(in_pipe[1]);
        ::close(out_pipe[0]); ::close(out_pipe[1]);
        setupShellPromptEnv_(shell_rc_dir, TerminalTransportMode::Pipe);
        (void)shell_scheduler::restoreForExec();
        const char* argv[] = {"su", nullptr};
        ::execvp("su", const_cast<char* const*>(argv));
        const char* message = "exec su failed\n";
        (void)::write(STDERR_FILENO, message, std::strlen(message));
        _exit(127);
    }
    safeClose(in_pipe[0]);
    safeClose(out_pipe[1]);
    m_pid = pid;
    m_pgid = -1;
    m_in_w.store(in_pipe[1], std::memory_order_release);
    m_out_r.store(out_pipe[0], std::memory_order_release);
    m_reader = std::thread([this] { readerLoop_(); });
    {
        std::lock_guard<std::mutex> lock(m_mu);
        m_out += "# \n";
    }
    return true;
}

bool SuInteractive::startPty_(std::string_view shell_rc_dir) {
    int master = ::posix_openpt(O_RDWR | O_NOCTTY);
    if (master < 0) return false;
    setCloExec(master);
    if (::grantpt(master) != 0 || ::unlockpt(master) != 0) {
        ::close(master);
        return false;
    }
    char slave_name[128] = {};
    if (::ptsname_r(master, slave_name, sizeof(slave_name)) != 0) {
        ::close(master);
        return false;
    }
    const pid_t pid = ::fork();
    if (pid < 0) {
        ::close(master);
        return false;
    }
    if (pid == 0) {
        (void)::setsid();
        const int slave = ::open(slave_name, O_RDWR);
        if (slave < 0) _exit(120);
        (void)::ioctl(slave, TIOCSCTTY, 0);
        ::dup2(slave, STDIN_FILENO);
        ::dup2(slave, STDOUT_FILENO);
        ::dup2(slave, STDERR_FILENO);
        if (slave > STDERR_FILENO) ::close(slave);
        ::close(master);
        ignore_sighup();
        setupShellPromptEnv_(shell_rc_dir, TerminalTransportMode::Pty);
        (void)shell_scheduler::restoreForExec();
        const char* argv[] = {"su", nullptr};
        ::execvp("su", const_cast<char* const*>(argv));
        const char* message = "exec su failed\n";
        (void)::write(STDERR_FILENO, message, std::strlen(message));
        _exit(127);
    }
    const int master_read = ::dup(master);
    if (master_read < 0) {
        ::kill(pid, SIGKILL);
        ::close(master);
        return false;
    }
    setCloExec(master_read);
    m_pid = pid;
    m_pgid = pid;
    m_in_w.store(master, std::memory_order_release);
    m_out_r.store(master_read, std::memory_order_release);
    {
        std::lock_guard<std::mutex> lock(m_mu);
        m_out.clear();
    }
    m_reader = std::thread([this] { readerLoop_(); });
    return true;
}

void SuInteractive::readerLoop_() {
    char buffer[4096];
    StreamControlFrameFilter filter;
    PipeOutputFilter pipe_filter;
    for (;;) {
        const int fd = m_out_r.load(std::memory_order_acquire);
        if (fd < 0) break;
        const ssize_t count = ::read(fd, buffer, sizeof(buffer));
        if (count > 0) {
            ControlFrameHandler handler;
            {
                std::lock_guard<std::mutex> lock(m_mu);
                handler = m_control_frame_handler;
            }
            const std::string_view chunk(buffer, static_cast<size_t>(count));
            std::string visible = m_mode == TerminalTransportMode::Pipe
                ? pipe_filter.consume(chunk, handler, [this] {
                    m_pipe_prompt_seen.store(true, std::memory_order_release);
                    m_pipe_shell_ready.store(true, std::memory_order_release);
                })
                : filter.consume(chunk, handler);
            if (m_mode == TerminalTransportMode::Pty) visible = filterAutomationEcho_(std::move(visible));
            if (!visible.empty()) {
                std::lock_guard<std::mutex> lock(m_mu);
                m_out += visible;
            }
            continue;
        }
        if (count == 0) break;
        if (errno == EINTR) continue;
        if (errno == EIO && m_mode == TerminalTransportMode::Pty) break;
        break;
    }
    const std::string trailing = m_mode == TerminalTransportMode::Pipe
        ? pipe_filter.flush() : filter.flush();
    if (!trailing.empty()) {
        std::lock_guard<std::mutex> lock(m_mu);
        m_out += trailing;
    }
    m_pipe_shell_ready.store(false, std::memory_order_release);
    m_pipe_prompt_seen.store(false, std::memory_order_release);
    safeClose(m_out_r);
}

std::string SuInteractive::filterAutomationEcho_(std::string visible) {
    std::lock_guard<std::mutex> lock(m_echo_mu);
    if (!m_suppress_automation_input_echo) return visible;
    m_automation_echo_buffer += visible;
    const size_t newline = m_automation_echo_buffer.find('\n');
    if (newline == std::string::npos) {
        if (m_automation_echo_buffer.size() <= 4096) return {};
        m_suppress_automation_input_echo = false;
        m_automation_echo_command.clear();
        return std::exchange(m_automation_echo_buffer, {});
    }
    const std::string first_line = m_automation_echo_buffer.substr(0, newline + 1);
    const std::string remainder = m_automation_echo_buffer.substr(newline + 1);
    const bool echoed = !m_automation_echo_command.empty()
        && first_line.find(m_automation_echo_command) != std::string::npos;
    m_suppress_automation_input_echo = false;
    m_automation_echo_command.clear();
    m_automation_echo_buffer.clear();
    return echoed ? remainder : first_line + remainder;
}

bool SuInteractive::send(const std::string& value) {
    if (m_in_w < 0) return false;
    // Upstream: submitting a complete command clears readiness before write.
    if (m_mode == TerminalTransportMode::Pipe && value.find('\n') != std::string::npos) {
        m_pipe_shell_ready.store(false, std::memory_order_release);
    }
    const char* cursor = value.data();
    size_t left = value.size();
    while (left > 0) {
        const ssize_t written = ::write(m_in_w, cursor, left);
        if (written > 0) {
            cursor += written;
            left -= static_cast<size_t>(written);
        } else if (written < 0 && errno == EINTR) {
            continue;
        } else {
            return false;
        }
    }
    return true;
}

bool SuInteractive::sendLine(const std::string& line) {
    if (m_mode == TerminalTransportMode::Pipe && !line.empty()) {
        std::lock_guard<std::mutex> lock(m_mu);
        m_out.append("# ");
        m_out.append(line);
        m_out.push_back('\n');
    }
    if (!send(line)) return false;
    if (!line.empty() && line.back() == '\n') return true;
    return send("\n");
}

bool SuInteractive::sendText(const std::string& text, bool append_enter) {
    // Automation inputs retain their existing raw-byte / no-local-echo behavior.
    if (!send(text)) return false;
    return !append_enter || (!text.empty() && text.back() == '\n') || send("\n");
}

bool SuInteractive::sendAutomationCommand(const std::string& command) {
    if (m_mode == TerminalTransportMode::Pipe) return sendText(command, true);
    std::lock_guard<std::mutex> lock(m_echo_mu);
    // Linux PTY masters operate on their slave's termios. Keeping a separate
    // slave open here would prevent the reader from observing the last close.
    const int fd = m_in_w.load(std::memory_order_acquire);
    if (fd < 0) return false;
    if (m_automation_echo_suppressed) {
        (void)::tcsetattr(fd, TCSANOW, &m_saved_automation_termios);
        m_automation_echo_suppressed = false;
    }
    struct termios original {};
    if (::tcgetattr(fd, &original) == 0) {
        struct termios hidden = original;
        hidden.c_lflag &= static_cast<tcflag_t>(~ECHO);
        if (::tcsetattr(fd, TCSANOW, &hidden) == 0) {
            m_saved_automation_termios = original;
            m_automation_echo_suppressed = true;
        }
    }
    m_suppress_automation_input_echo = true;
    m_automation_echo_command = command;
    m_automation_echo_buffer.clear();
    const bool result = sendLine(command);
    if (!result) {
        const int restore_fd = m_in_w.load(std::memory_order_acquire);
        if (m_automation_echo_suppressed && restore_fd >= 0) {
            (void)::tcsetattr(restore_fd, TCSANOW, &m_saved_automation_termios);
        }
        m_automation_echo_suppressed = false;
        m_suppress_automation_input_echo = false;
        m_automation_echo_command.clear();
        m_automation_echo_buffer.clear();
    }
    return result;
}

void SuInteractive::finishAutomationCommand() {
    if (m_mode != TerminalTransportMode::Pty) return;
    std::lock_guard<std::mutex> lock(m_echo_mu);
    const int restore_fd = m_in_w.load(std::memory_order_acquire);
    if (m_automation_echo_suppressed && restore_fd >= 0) {
        (void)::tcsetattr(restore_fd, TCSANOW, &m_saved_automation_termios);
    }
    m_automation_echo_suppressed = false;
    m_suppress_automation_input_echo = false;
    m_automation_echo_command.clear();
    m_automation_echo_buffer.clear();
}

void SuInteractive::closeInput() {
    m_pipe_shell_ready.store(false, std::memory_order_release);
    m_pipe_prompt_seen.store(false, std::memory_order_release);
    finishAutomationCommand();
    // Close all parent-side transport descriptors first. This is deliberately
    // before waiting or signalling so a page close releases the transport
    // immediately; only the long-lived Shell is terminated afterwards.
    safeClose(m_in_w);
    safeClose(m_out_r);
}

int SuInteractive::wait() {
    if (m_pid <= 0) return -1;
    closeInput();
    if (m_mode == TerminalTransportMode::Pipe) {
        const pid_t pid = m_pid;
        int status = 0;
        const bool ok = waitPidBlocking(pid, status);
        if (m_reader.joinable()) m_reader.join();
        m_pid = -1;
        m_pgid = -1;
        m_pipe_shell_ready.store(false, std::memory_order_release);
        if (!ok) return -1;
        if (WIFEXITED(status)) return WEXITSTATUS(status);
        if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
        return -1;
    }
    int status = 0;
    for (;;) {
        const pid_t result = ::waitpid(m_pid, &status, 0);
        if (result == m_pid) break;
        if (result < 0 && errno == EINTR) continue;
        break;
    }
    if (m_reader.joinable()) m_reader.join();
    const pid_t old = m_pid;
    m_pid = -1;
    m_pgid = -1;
    if (old <= 0) return -1;
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return -1;
}

void SuInteractive::stop(bool force) {
    if (m_mode == TerminalTransportMode::Pipe) stopPipe_(force);
    else stopPty_(force);
}

void SuInteractive::stopPipe_(bool force) {
    closeInput();
    m_pipe_shell_ready.store(false, std::memory_order_release);
    const pid_t pid = m_pid;
    bool reaped = false;
    if (pid > 0 && force) {
        (void)::kill(pid, SIGTERM);
        for (int i = 0; i < 30; ++i) {
            int status = 0;
            pid_t result = ::waitpid(pid, &status, WNOHANG);
            if (result == pid) { reaped = true; break; }
            if (result < 0 && errno == ECHILD) { reaped = true; break; }
            if (result < 0 && errno != EINTR) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        if (!reaped) {
            (void)::kill(pid, SIGKILL);
            int status = 0;
            reaped = waitPidBlocking(pid, status);
        }
    } else if (pid > 0) {
        int status = 0;
        reaped = waitPidBlocking(pid, status);
    }
    if (m_reader.joinable()) m_reader.join();
    safeClose(m_out_r);
    m_pid = -1;
    m_pgid = -1;
    (void)reaped;
}

void SuInteractive::stopPty_(bool force) {
    closeInput();
    if (m_pid > 0 && force) {
        ::kill(m_pid, SIGTERM);
        for (int i = 0; i < 30; ++i) {
            int status = 0;
            pid_t result = ::waitpid(m_pid, &status, WNOHANG);
            if (result == m_pid) { m_pid = -1; break; }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        if (m_pid > 0) ::kill(m_pid, SIGKILL);
    }
    safeClose(m_out_r);
    if (m_reader.joinable()) m_reader.join();
    if (m_pid > 0) {
        int status = 0;
        (void)::waitpid(m_pid, &status, WNOHANG);
        m_pid = -1;
    }
    m_pgid = -1;
}

std::string SuInteractive::output() const {
    std::lock_guard<std::mutex> lock(m_mu);
    return m_out;
}

std::string SuInteractive::takeOutput() {
    std::lock_guard<std::mutex> lock(m_mu);
    std::string result = std::move(m_out);
    m_out.clear();
    return result;
}

pid_t SuInteractive::get_shell_pid() const {
    return m_pid;
}

pid_t SuInteractive::get_shell_pgid() const {
    return m_pgid;
}

bool SuInteractive::isShellIdle() const {
    if (m_pid <= 0) return false;
    if (m_mode == TerminalTransportMode::Pipe) {
        return m_pipe_shell_ready.load(std::memory_order_acquire);
    }
    const int input_fd = m_in_w.load(std::memory_order_acquire);
    const int output_fd = m_out_r.load(std::memory_order_acquire);
    const int fd = input_fd >= 0 ? input_fd : output_fd;
    if (fd < 0) return false;
    pid_t foreground = -1;
    if (::ioctl(fd, TIOCGPGRP, &foreground) != 0) return false;
    const pid_t shell_group = ::getpgid(m_pid);
    return shell_group > 0 && foreground == shell_group;
}

bool SuInteractive::hasShellIdleState() const {
    return m_pid > 0 &&
        (m_mode != TerminalTransportMode::Pipe ||
         m_pipe_prompt_seen.load(std::memory_order_acquire));
}

void SuInteractive::closeTransportFdsAfterFork() {
    static_assert(std::atomic<int>::is_always_lock_free, "post-fork fd exchange must be lock-free");
    safeClose(m_in_w);
    safeClose(m_out_r);
}

bool SuInteractive::isAlive() const {
    if (m_pid <= 1) return false;
    if (::kill(m_pid, 0) == 0) return true;
    return errno == EPERM;
}

void SuInteractive::setControlFrameHandler(ControlFrameHandler handler) {
    std::lock_guard<std::mutex> lock(m_mu);
    m_control_frame_handler = std::move(handler);
}
