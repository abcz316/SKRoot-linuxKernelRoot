#pragma once

#include <functional>
#include <string>
#include <string_view>

class StreamControlFrameFilter {
public:
    using Handler = std::function<bool(const std::string&)>;

    // Empty prefix preserves the original generic RS/US filtering behavior.
    // Pipe transport reserves only SKA: frames; unrelated RS bytes are output.
    explicit StreamControlFrameFilter(std::string_view prefix = {}) : m_prefix(prefix) {}

    std::string consume(std::string_view chunk, const Handler& handler) {
        std::string visible;
        visible.reserve(chunk.size());
        for (unsigned char ch : chunk) {
            if (!m_reading) {
                if (ch == 0x1e) {
                    m_reading = true;
                    m_frame.clear();
                } else {
                    visible.push_back(static_cast<char>(ch));
                }
                continue;
            }
            if (!m_prefix.empty() && ch == 0x1e) {
                visible += flush();
                m_reading = true;
            } else if (ch == 0x1f) {
                const bool handled = (m_prefix.empty() || m_frame.rfind(m_prefix, 0) == 0)
                    && handler && handler(m_frame);
                if (!handled) {
                    visible.push_back(static_cast<char>(0x1e));
                    visible += m_frame;
                    visible.push_back(static_cast<char>(0x1f));
                }
                m_frame.clear();
                m_reading = false;
            } else if (m_frame.size() < kMaxFrameBytes) {
                m_frame.push_back(static_cast<char>(ch));
                if (!m_prefix.empty() && m_frame.size() <= m_prefix.size() &&
                    m_frame != m_prefix.substr(0, m_frame.size())) {
                    visible += flush();
                }
            } else {
                visible.push_back(static_cast<char>(0x1e));
                visible += m_frame;
                visible.push_back(static_cast<char>(ch));
                m_frame.clear();
                m_reading = false;
            }
        }
        return visible;
    }

    std::string flush() {
        if (!m_reading) return {};
        std::string visible(1, static_cast<char>(0x1e));
        visible += m_frame;
        m_frame.clear();
        m_reading = false;
        return visible;
    }

private:
    static constexpr size_t kMaxFrameBytes = 8192;
    bool m_reading = false;
    std::string m_prefix;
    std::string m_frame;
};
