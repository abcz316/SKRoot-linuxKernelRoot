#pragma once

#include <algorithm>
#include <string>
#include <string_view>

#include "stream_control_filter.h"

// Port of official 3.1.1 PipeSuInteractive::consumeOutput_: find the entire
// prompt marker, retaining only a possible marker prefix at the chunk tail.
// PLUS automation filtering runs on the remaining spans, never on the marker.
class PipeOutputFilter {
public:
    static constexpr std::string_view kReadyMarker = "\x1e" "SKROOT_READY" "\x1f";

    template <typename ReadyHandler>
    std::string consume(std::string_view chunk,
                        const StreamControlFrameFilter::Handler& automation_handler,
                        const ReadyHandler& ready_handler) {
        m_pending.append(chunk);
        std::string visible;
        for (;;) {
            const size_t pos = m_pending.find(kReadyMarker);
            if (pos != std::string::npos) {
                visible += m_automation.consume(std::string_view(m_pending).substr(0, pos), automation_handler);
                // A prompt is a boundary: an unfinished automation frame must
                // not buffer the visible prompt or absorb a subsequent frame.
                visible += m_automation.flush();
                m_pending.erase(0, pos + kReadyMarker.size());
                ready_handler();
                continue;
            }
            size_t keep = 0;
            const size_t max_keep = std::min(m_pending.size(), kReadyMarker.size() - 1);
            for (size_t n = max_keep; n > 0; --n) {
                if (std::string_view(m_pending).substr(m_pending.size() - n) == kReadyMarker.substr(0, n)) {
                    keep = n;
                    break;
                }
            }
            const size_t flush_size = m_pending.size() - keep;
            visible += m_automation.consume(std::string_view(m_pending).substr(0, flush_size), automation_handler);
            m_pending.erase(0, flush_size);
            return visible;
        }
    }

    std::string flush() {
        // Pending data is only an incomplete prompt prefix, never a full frame.
        std::string visible = m_automation.consume(m_pending, {});
        m_pending.clear();
        visible += m_automation.flush();
        return visible;
    }

private:
    std::string m_pending;
    StreamControlFrameFilter m_automation{"SKA:"};
};
