# 隐蔽终端PLUS 4.2.15

日期：2026-10-11。基于 PLUS 4.2.14（`aa48de6`）继续对齐官方 3.1.1，仅修改 Pipe 提示符解析和父进程持有的 PTY slave。

## Pipe 提示符

4.2.14 让通用 RS/US 解析器同时识别提示符和自动化帧。遇到 `RS + OTHER + RS + SKROOT_READY + US` 时，解析器把它看成一个未知帧，漏掉提示符，可能导致空闲状态一直为 false；未知 RS 后面的普通输出也可能被缓存。

4.2.15 的 `PipeOutputFilter` 移植官方 `PipeSuInteractive::consumeOutput_` 的完整标记搜索及尾部前缀保留算法，优先识别提示符，再处理剩余输出中的 PLUS 自动化帧。未知 RS 不再阻挡提示符或普通输出。仅对 Pipe 的后续自动化解析启用 `SKA:` 前缀匹配，PTY 的现有通用帧过滤不变。提示符边界会输出之前残缺的自动化帧，不把它与提示符之后的内容拼接。

官方源码固定于 `7ad782c8bce0410381e9dae803206c4b76d6f56d`：[Pipe 扫描实现](https://github.com/abcz316/SKRoot-linuxKernelRoot/blob/7ad782c8bce0410381e9dae803206c4b76d6f56d/Pro%28%E4%BC%97%E6%B5%8B%E5%BC%80%E6%94%BE%E4%B8%AD%29/src/testModule/module_hide_sh_exec/su_interactive/pipe_su_interactive.cpp)。

## PTY 描述符

先用独立 Linux PTY 测试验证 master 的 tcgetattr/tcsetattr 可以控制 slave 的 ECHO，并验证关闭最后一个 slave 后 master 返回 EIO。随后将 PLUS 自动化回显控制与恢复改用现有 master，移除父进程额外打开的 slave 和相应成员。

父进程只持有两个 master 描述符，与官方结构一致。Shell 自然退出且所有 slave 持有者退出后，reader 可以看到 EIO 并结束，不再被父进程自身持有的 slave 阻挡。看护进程仍先关闭全部继承终端 fd，再等待父进程退出。

保留：两条 su 路径的 CPU affinity/nice 0 恢复、上游阻塞读写和停止回收流程、自动化回显抑制与恢复、独立模块名称和 ID、文件管理等功能。旧 rc/runner 清理和 rc 写入失败保护没有在本轮扩大修改。

## 验证范围

- Pipe 测试覆盖每个分块位置、逐字节读取、未知/嵌套/残缺控制符、连续提示符、自动化帧穿插、未知内容立即输出及 EOF 尾部保留。
- 实际 Shell 会话测试覆盖此前会漏掉的提示符输入，以及无 US 的普通输出。
- 独立 PTY 测试检查 master 对 slave 的 ECHO 开关、可见回显、关闭最后一个 slave 后的 EIO。
- Shell 会话测试检查自动化输入不回显、重复恢复 termios、自然退出后 reader 在 wait/stop 之前关闭 fd，以及父进程/看护进程的描述符数量与清理。
- 测试在 WSL Linux 执行，su 使用隔离的 Bash 替身；不等同于 Android 目标设备的 SKRoot su 实测。

最终结果：10 组 C++ 测试、31 项 JavaScript 测试全部通过；最终解析器头文件调整后，重新编译并通过 Shell 生命周期集成测试。NDK r26d ARM64 编译成功；安装包 12 项文件逐项 SHA-256 校验通过，包内 ELF 名称、ID、4.2.15 版本均验证通过。未进行 Android 真机安装测试。

安装包：`release/隐蔽终端PLUS-4.2.15-arm64.zip`，1,100,822 字节。

SHA-256：`6458f0b9d3b25aabd9d329c4b0d43ba9a288a12ad047b035a06e173c89d5a926`。

此前 4.2.13、4.2.14 安装包保持原样，便于回退。源码目录名继续使用最初的 4.2.13 导入路径。
