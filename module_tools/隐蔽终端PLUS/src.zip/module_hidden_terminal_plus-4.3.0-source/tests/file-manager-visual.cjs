const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
let playwright;
try {
  playwright = require('playwright');
} catch (_) {
  const dependencyRoot = path.join(process.env.USERPROFILE || '', '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules');
  process.env.NODE_PATH = [dependencyRoot, path.join(dependencyRoot, '.pnpm/node_modules')].join(path.delimiter);
  require('node:module').Module._initPaths();
  playwright = require(path.join(dependencyRoot, 'playwright'));
}
const { chromium } = playwright;

function chromiumLaunchOptions() {
  const expected = chromium.executablePath();
  if (expected && fs.existsSync(expected)) return { headless: true };
  const cache = process.platform === 'win32' ? path.join(process.env.LOCALAPPDATA, 'ms-playwright') : path.join(require('node:os').homedir(), '.cache/ms-playwright');
  if (!fs.existsSync(cache)) return { headless: true };
  const candidates = fs.readdirSync(cache)
    .filter(name => name.startsWith('chromium_headless_shell-'))
    .sort((left, right) => Number(right.split('-').pop()) - Number(left.split('-').pop()))
    .map(name => path.join(cache, name, process.platform === 'win32' ? 'chrome-headless-shell-win64/chrome-headless-shell.exe' : 'chrome-headless-shell-linux64/chrome-headless-shell'));
  const executablePath = candidates.find(candidate => fs.existsSync(candidate));
  return executablePath ? { headless: true, executablePath } : { headless: true };
}

const webroot = path.resolve(__dirname, '../webroot');
const outputDir = path.join(require('node:os').tmpdir(), 'skroot-file-manager-visual');
fs.mkdirSync(outputDir, { recursive: true });

const textContent = 'SKRoot dual pane editor\nUTF-8: \u6587\u672c\u7f16\u8f91\n';
let jobTicks = 0;
let jobStartCount = 0;
let lastJobOperation = '';
let lastJobOutputPath = '';
let lastCreatePath = '';
let automationConfig = {
  revision: 1,
  draft: { schemeId: null, name: '', failurePolicy: 'stop', steps: [] },
  schemes: [],
};
let automationRun = { id: '', state: 'idle', steps: [], currentStep: 0, totalSteps: 0, successCount: 0, failureCount: 0 };
let automationRunTicks = 0;
let placesState = {
  bookmarks: [{ path: '/sdcard/Download', note: '下载目录' }],
  recent: [{ path: '/sdcard' }, { path: '/data/local/tmp' }, { path: '/storage/emulated/0/Android' }],
};

function envelope(data, ok = true, code = 'OK', message = '') {
  return JSON.stringify({ ok, code, message, errno: 0, requestId: 'mock-request', data });
}

function entriesFor(requestPath) {
  const prefix = requestPath === '/sdcard' || requestPath === '/' ? '' : requestPath.split('/').pop() + '-';
  return [
    { name: `${prefix}Android`, type: 'directory', isDir: true, date: '2026-07-26', time: '10:15', size: 0, mtimeMs: 0, mode: 16877, uid: 0, gid: 0, hideProtected: false },
    { name: `${prefix}Download`, type: 'directory', isDir: true, date: '2026-07-25', time: '21:03', size: 0, mtimeMs: 0, mode: 16877, uid: 0, gid: 0, hideProtected: false },
    { name: `${prefix}hidden-work`, type: 'directory', isDir: true, date: '2026-07-24', time: '18:44', size: 0, mtimeMs: 0, mode: 16895, uid: 0, gid: 0, hideProtected: true },
    { name: 'linked-dir', type: 'symlink', isDir: true, date: '2026-07-24', time: '18:40', size: 0, mtimeMs: 0, mode: 41471, uid: 0, gid: 0, hideProtected: false },
    { name: 'notes.txt', type: 'file', isDir: false, date: '2026-07-26', time: '09:42', size: Buffer.byteLength(textContent), mtimeMs: 0, mode: 33188, uid: 0, gid: 0, hideProtected: false },
    { name: 'backup.zip', type: 'file', isDir: false, date: '2026-07-26', time: '09:40', size: 4096, mtimeMs: 0, mode: 33188, uid: 0, gid: 0, hideProtected: false },
    { name: 'demo app.apk', type: 'file', isDir: false, date: '2026-07-26', time: '09:39', size: 8192, mtimeMs: 0, mode: 33188, uid: 0, gid: 0, hideProtected: false },
    { name: 'QQ received app.apk.1', type: 'file', isDir: false, date: '2026-07-26', time: '09:38', size: 8192, mtimeMs: 0, mode: 33188, uid: 0, gid: 0, hideProtected: false },
    { name: 'run-script.sh', type: 'file', isDir: false, date: '2026-07-23', time: '12:20', size: 2496, mtimeMs: 0, mode: 33261, uid: 0, gid: 0, hideProtected: false },
    { name: 'very-long-configuration-file-name-that-must-ellipsis.json', type: 'file', isDir: false, date: '2026-07-20', time: '08:05', size: 18203, mtimeMs: 0, mode: 33188, uid: 0, gid: 0, hideProtected: false },
    ...Array.from({ length: 10 }, (_, index) => ({
      name: `folder-${String(index + 1).padStart(2, '0')}`,
      type: 'directory', isDir: true, date: '2026-07-18', time: '13:10', size: 0,
      mtimeMs: 0, mode: 16877, uid: 0, gid: 0, hideProtected: false,
    })),
  ];
}

function jsonResponse(res, data, status = 200) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(data);
}

function textResponse(res, data = 'OK', status = 200) {
  res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end(data);
}

const server = http.createServer((req, res) => {
  if (req.method === 'POST') {
    let body = '';
    req.setEncoding('utf8');
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      let parsed = {};
      try { parsed = body ? JSON.parse(body) : {}; } catch (_) {}
      if (req.url === '/api/session') return jsonResponse(res, envelope({ token: 'mock-session' }));
      if (req.url === '/api/files/settings/get') return jsonResponse(res, envelope({ leftHome: '/sdcard', rightHome: '/data/local/tmp' }));
      if (req.url === '/api/files/settings/set-home') return jsonResponse(res, envelope({ leftHome: '/sdcard', rightHome: '/data/local/tmp' }));
      if (req.url === '/api/files/places/get') return jsonResponse(res, envelope(placesState));
      if (req.url === '/api/files/places/set') {
        placesState = {
          bookmarks: Array.isArray(parsed.bookmarks) ? parsed.bookmarks : [],
          recent: Array.isArray(parsed.recent) ? parsed.recent.slice(0, 20) : [],
        };
        return jsonResponse(res, envelope(placesState));
      }
      if (req.url === '/api/files/list') return jsonResponse(res, envelope({ path: parsed.path, items: entriesFor(parsed.path) }));
      if (req.url === '/api/files/create') {
        lastCreatePath = parsed.path || '';
        return jsonResponse(res, envelope({ path: lastCreatePath, modeOctal: '0644' }), 201);
      }
      if (req.url === '/api/files/properties/get') return jsonResponse(res, envelope({
        path: parsed.path, name: path.basename(parsed.path || ''), type: 'file', size: Buffer.byteLength(textContent),
        mtimeMs: 1785030000000, modeOctal: '0644', symbolic: 'rw-r--r--', uid: '0', ownerName: 'root',
        gid: '1023', groupName: 'media_rw', symlinkTarget: '', recursiveEligible: false,
      }));
      if (req.url === '/api/files/principals/list') return jsonResponse(res, envelope({
        users: [{ name: 'root', id: '0' }, { name: 'shell', id: '2000' }],
        groups: [{ name: 'root', id: '0' }, { name: 'media_rw', id: '1023' }],
      }));
      if (req.url === '/api/files/job/start') {
        jobTicks = 0;
        jobStartCount++;
        lastJobOperation = parsed.op;
        lastJobOutputPath = parsed.op === 'compress' ? `${parsed.destination}/notes.txt.zip` : '';
        return jsonResponse(res, envelope({ id: 'mock-job', state: 'scanning', operation: parsed.op, outputPath: lastJobOutputPath, totalBytes: 0, processedBytes: 0, totalItems: 0, processedItems: 0, successCount: 0, skippedCount: 0, failedCount: 0, errors: [] }), 202);
      }
      if (req.url === '/api/files/job/status') {
        if (!parsed.id) return jsonResponse(res, envelope({ id: '', state: 'idle', operation: '', totalBytes: 0, processedBytes: 0, totalItems: 0, processedItems: 0, successCount: 0, skippedCount: 0, failedCount: 0, errors: [] }));
        jobTicks++;
        const complete = jobTicks > 2;
        return jsonResponse(res, envelope({ id: 'mock-job', state: complete ? 'completed' : 'running', operation: lastJobOperation || 'copy', currentPath: '/sdcard/notes.txt', outputPath: lastJobOutputPath, exitCode: 0, resultCode: lastJobOperation === 'install_apk' ? 'APK_INSTALL_COMPLETED' : '', resultMessage: lastJobOperation === 'install_apk' ? 'Success' : '', totalBytes: 100, processedBytes: complete ? 100 : 55, totalItems: 2, processedItems: complete ? 2 : 1, successCount: complete ? 2 : 1, skippedCount: 0, failedCount: 0, errors: [] }));
      }
      if (req.url === '/api/files/job/cancel') return jsonResponse(res, envelope({ id: 'mock-job', state: 'cancelling', operation: 'copy', errors: [] }));
      if (req.url === '/api/files/text/open') return jsonResponse(res, envelope({ sessionId: 'read-1', path: parsed.path, size: Buffer.byteLength(textContent), hasBom: false, version: { device: '1', inode: '2', size: String(Buffer.byteLength(textContent)), mtimeSec: '3', mtimeNsec: '4' } }));
      if (req.url === '/api/files/text/read') return jsonResponse(res, envelope({ base64: Buffer.from(textContent).toString('base64'), offset: 0, nextOffset: Buffer.byteLength(textContent), eof: true }));
      if (req.url === '/api/automation/config/get') return jsonResponse(res, envelope(automationConfig));
      if (req.url === '/api/automation/config/set') {
        if (Number(parsed.revision) !== automationConfig.revision) {
          return jsonResponse(res, envelope(null, false, 'CONFIG_CHANGED', '配置版本冲突'), 409);
        }
        automationConfig = JSON.parse(JSON.stringify({ ...parsed, revision: automationConfig.revision + 1 }));
        return jsonResponse(res, envelope(automationConfig));
      }
      if (req.url === '/api/automation/run/start') {
        const source = parsed.schemeId
          ? automationConfig.schemes.find(item => item.id === parsed.schemeId)
          : automationConfig.draft;
        automationRunTicks = 0;
        automationRun = {
          id: 'automation-run-1', state: 'running', schemeId: parsed.schemeId || '',
          name: source?.name || '未保存草稿', failurePolicy: source?.failurePolicy || 'stop',
          currentStep: 0, totalSteps: source?.steps?.length || 0, successCount: 0, failureCount: 0,
          steps: (source?.steps || []).map(step => ({ id: step.id, type: step.type, state: 'pending', exitCode: 0 })),
          errors: [],
        };
        return jsonResponse(res, envelope(automationRun), 202);
      }
      if (req.url === '/api/automation/run/status') {
        if (automationRun.id && automationRun.state === 'running') {
          automationRunTicks++;
          if (automationRunTicks >= 3) {
            automationRun.state = 'completed';
            automationRun.currentStep = Math.max(0, automationRun.totalSteps - 1);
            automationRun.successCount = automationRun.totalSteps;
            automationRun.steps.forEach(step => { step.state = 'completed'; });
          } else if (automationRun.totalSteps) {
            automationRun.currentStep = Math.min(automationRun.totalSteps - 1, automationRunTicks - 1);
            automationRun.successCount = Math.max(0, automationRunTicks - 1);
            automationRun.steps[automationRun.currentStep].state = 'running';
          }
        }
        return jsonResponse(res, envelope(automationRun));
      }
      if (req.url === '/api/automation/run/cancel') {
        automationRun.state = 'cancelled';
        return jsonResponse(res, envelope(automationRun));
      }
      if (req.url === '/getQuickActions') return textResponse(res, '[]');
      if (req.url === '/getNewOutput') return textResponse(res, '');
      if (req.url === '/getTerminalKeepMode') return textResponse(res, '0');
      if (req.url === '/getTerminalTransportMode') return jsonResponse(res, JSON.stringify({ effective: 'pty', saved: 'pty' }));
      if (req.url === '/saveTerminalTransportMode') return textResponse(res, 'OK');
      if (req.url === '/getAutoTasks') return textResponse(res, '[]');
      if (req.url === '/getHideDir') return textResponse(res, '/data/skroot/work');
      if (req.url === '/checkFileType') return textResponse(res, body.endsWith('.sh') ? 'shell_script' : 'unknown');
      if (req.url === '/checkExecMount') return textResponse(res, 'can exec');
      return textResponse(res, 'OK');
    });
    return;
  }

  const requestPath = req.url === '/' ? '/index.html' : decodeURIComponent(req.url.split('?')[0]);
  const file = path.resolve(webroot, '.' + requestPath);
  if (!file.startsWith(webroot) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404);
    res.end('not found');
    return;
  }
  const ext = path.extname(file);
  const contentTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
  res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});

async function openManager(page, baseUrl) {
  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  await page.click('#fileBtn');
  await page.waitForSelector('#fileWorkspace.show');
  await page.waitForFunction(() => document.querySelectorAll('[data-list="left"] .fm-row').length > 5);
}

async function verifyTerminalDetails(page, baseUrl, viewportName) {
  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  await page.click('.tip-more > summary');
  await page.waitForFunction(() => document.querySelector('.tip-more')?.open === true);
  const initial = await page.evaluate(() => {
    const card = document.querySelector('.card').getBoundingClientRect();
    const terminal = document.querySelector('.terminal').getBoundingClientRect();
    const composer = document.querySelector('.composer');
    const composerRect = composer.getBoundingClientRect();
    const style = getComputedStyle(composer);
    return {
      cardBottom: card.bottom,
      terminalBottom: terminal.bottom,
      composerTop: composerRect.top,
      composerBottom: composerRect.bottom,
      composerClientHeight: composer.clientHeight,
      composerScrollHeight: composer.scrollHeight,
      overflowY: style.overflowY,
      viewportHeight: innerHeight,
    };
  });
  assert.ok(initial.composerBottom <= initial.cardBottom + 1, `${viewportName}: terminal details overflow the card`);
  assert.ok(initial.composerBottom <= initial.terminalBottom + 1, `${viewportName}: terminal details overflow the terminal`);
  assert.ok(initial.composerBottom <= initial.viewportHeight + 1, `${viewportName}: terminal details overflow the viewport`);
  assert.equal(initial.overflowY, 'auto', `${viewportName}: terminal details are not scrollable`);
  assert.ok(initial.composerClientHeight > 0, `${viewportName}: terminal details have no usable height`);

  await page.locator('#terminalEndButton').evaluate(node => node.scrollIntoView({ block: 'nearest' }));
  const button = await page.locator('#terminalEndButton').evaluate(node => {
    const buttonRect = node.getBoundingClientRect();
    const composerRect = node.closest('.composer').getBoundingClientRect();
    return {
      top: buttonRect.top,
      bottom: buttonRect.bottom,
      composerTop: composerRect.top,
      composerBottom: composerRect.bottom,
      viewportHeight: innerHeight,
    };
  });
  assert.ok(button.top >= button.composerTop - 1, `${viewportName}: terminal end button is clipped at the top`);
  assert.ok(button.bottom <= button.composerBottom + 1, `${viewportName}: terminal end button is clipped at the bottom`);
  assert.ok(button.bottom <= button.viewportHeight + 1, `${viewportName}: terminal end button is outside the viewport`);
  await page.screenshot({ path: path.join(outputDir, `${viewportName}-terminal-details.png`), fullPage: true });
}

(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const baseUrl = `http://127.0.0.1:${server.address().port}/`;
  const browser = await chromium.launch(chromiumLaunchOptions());
  const viewports = [
    { name: 'phone-390', width: 390, height: 844, isMobile: true },
    { name: 'phone-412', width: 412, height: 915, isMobile: true },
    { name: 'phone-landscape', width: 844, height: 390, isMobile: true },
    { name: 'tablet', width: 768, height: 1024, isMobile: false },
    { name: 'desktop', width: 1280, height: 800, isMobile: false },
  ];

  for (const viewport of viewports) {
    const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height }, hasTouch: viewport.isMobile, isMobile: viewport.isMobile });
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await verifyTerminalDetails(page, baseUrl, viewport.name);
    await openManager(page, baseUrl);

    const geometry = await page.evaluate(() => {
      const left = document.getElementById('filePaneLeft').getBoundingClientRect();
      const right = document.getElementById('filePaneRight').getBoundingClientRect();
      const header = document.querySelector('.fm-topbar').getBoundingClientRect();
      return { left, right, header, width: innerWidth, height: innerHeight };
    });
    assert.ok(Math.abs(geometry.left.width - geometry.right.width) <= 2, `${viewport.name}: panes are not equal`);
    assert.ok(geometry.left.right <= geometry.right.left + 1, `${viewport.name}: panes overlap`);
    assert.ok(geometry.header.bottom <= geometry.left.top + 1, `${viewport.name}: header overlaps panes`);
    assert.ok(geometry.right.right <= geometry.width + 1, `${viewport.name}: content overflows viewport`);
    const density = await page.evaluate(() => {
      const row = document.querySelector('[data-list="left"] .fm-row');
      const place = document.querySelector('.fm-place-row');
      return {
        rowHeight: row ? row.getBoundingClientRect().height : 0,
        placeHeight: place ? place.getBoundingClientRect().height : 0,
      };
    });
    assert.ok(density.rowHeight >= 44, `${viewport.name}: file row touch target is too small`);
    assert.ok(density.rowHeight <= (viewport.width <= 520 ? 46.5 : 50.5), `${viewport.name}: file rows are not compact`);
    await page.screenshot({ path: path.join(outputDir, `${viewport.name}-dual-pane.png`), fullPage: true });

    if (viewport.name === 'phone-390') {
      const directoryRow = page.locator('[data-list="left"] .fm-row[data-name="Android"]');
      await directoryRow.click();
      await page.waitForFunction(() => document.getElementById('activePathText').textContent === '/sdcard/Android');
      await page.locator('[data-list="left"] .fm-row.parent').click();
      await page.waitForFunction(() => document.getElementById('activePathText').textContent === '/sdcard');

      const linkedDirectoryRow = page.locator('[data-list="left"] .fm-row[data-name="linked-dir"]');
      await linkedDirectoryRow.click();
      await page.waitForFunction(() => document.getElementById('activePathText').textContent === '/sdcard/linked-dir');
      await page.locator('[data-list="left"] .fm-row.parent').click();
      await page.waitForFunction(() => document.getElementById('activePathText').textContent === '/sdcard');

      await page.click('#activePathTrigger');
      await page.fill('#pathInput', '/etc');
      await page.press('#pathInput', 'Enter');
      await page.waitForFunction(() => document.getElementById('activePathText').textContent === '/etc');
      assert.equal(await page.locator('#activePathEditor').isHidden(), true);
      await page.locator('[data-list="left"] .fm-row.parent').click();
      await page.waitForFunction(() => document.getElementById('activePathText').textContent === '/');

      const fileRow = page.locator('[data-list="left"] .fm-row[data-name="notes.txt"]');
      await fileRow.click();
      await page.waitForSelector('#actionModal.show');
      await page.screenshot({ path: path.join(outputDir, 'phone-390-actions.png'), fullPage: true });
      assert.equal(await page.locator('#actProperties').isVisible(), true);
      await page.click('#actProperties');
      await page.waitForSelector('#propertiesContent:not([hidden])');
      await page.screenshot({ path: path.join(outputDir, 'phone-390-properties.png'), fullPage: true });
      await page.click('#propertiesEditMode');
      await page.waitForSelector('#permissionModal.show');
      await page.check('#permissionModal [data-mode-bit="2048"]');
      assert.match(await page.locator('#permissionPreview').textContent(), /4644/);
      await page.click('#permissionCancel');
      await page.click('#propertiesEditOwner');
      await page.waitForSelector('#ownershipModal.show');
      await page.fill('#ownershipUser', 'shell');
      assert.equal(await page.locator('#ownershipConfirm').isEnabled(), true);
      await page.click('#ownershipCancel');
      await page.click('#propertiesClose');

      await page.click('#fileMenuBtn');
      await page.click('#fileNewFile');
      await page.fill('#createFileInput', 'README');
      await page.click('#createFileConfirm');
      await page.waitForFunction(() => !document.getElementById('createFileModal').classList.contains('show'));
      assert.equal(lastCreatePath, '/README');

      await page.click('#fileMenuBtn');
      await page.click('#fileAddBookmark');
      await page.waitForFunction(() => window.SKFileManager.model.bookmarks.some(item => item.path === '/'));

      const edge = await page.locator('#filePlacesEdge').boundingBox();
      const edgeViewport = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }));
      assert.ok(edge.width >= 120 && edge.height >= 40, 'places edge hit target is too small');
      assert.ok(edgeViewport.height - (edge.y + edge.height) >= 27, 'places edge is still inside the bottom gesture zone');
      await page.mouse.move(edge.x + edge.width / 2, edge.y + edge.height / 2);
      await page.mouse.down();
      await page.mouse.move(edge.x + edge.width / 2 + 36, edge.y + edge.height / 2, { steps: 3 });
      await page.mouse.up();
      await page.waitForTimeout(100);
      assert.equal(await page.locator('#filePlacesSheet').evaluate(node => node.classList.contains('show')), false, 'horizontal movement should not open places');
      await page.mouse.move(edge.x + edge.width / 2, edge.y + edge.height / 2);
      await page.mouse.down();
      await page.mouse.move(edge.x + edge.width / 2, edge.y - 52, { steps: 4 });
      await page.mouse.up();
      await page.waitForSelector('#filePlacesSheet.show');
      const placesGeometry = await page.locator('#filePlacesSheet').evaluate(node => {
        const rect = node.getBoundingClientRect();
        return { height: rect.height, viewport: innerHeight };
      });
      assert.ok(Math.abs(placesGeometry.height - placesGeometry.viewport * 0.5) <= 3, 'places sheet is not half height');
      assert.ok(await page.locator('#filePlacesList .fm-place-row').count() >= 3);
      await page.click('#filePlacesBookmarkTab');
      const rootBookmark = page.locator('#filePlacesList .fm-place-row[data-path="/"]');
      await rootBookmark.waitFor();
      const bookmarkBox = await rootBookmark.boundingBox();
      await page.mouse.move(bookmarkBox.x + 50, bookmarkBox.y + bookmarkBox.height / 2);
      await page.mouse.down();
      await page.waitForTimeout(580);
      await page.mouse.up();
      await page.waitForSelector('#placeActionModal.show');
      assert.equal(await page.locator('#placeActionEditNote').isVisible(), true);
      await page.click('#placeActionEditNote');
      await page.fill('#bookmarkNoteInput', '根目录');
      await page.click('#bookmarkNoteConfirm');
      await page.waitForFunction(() => document.querySelector('#filePlacesList .fm-place-row[data-path="/"] .fm-place-name')?.textContent === '根目录');
      await page.screenshot({ path: path.join(outputDir, 'phone-390-places.png'), fullPage: true });
      const placeDensity = await page.evaluate(() => {
        const row = document.querySelector('.fm-place-row');
        return row ? row.getBoundingClientRect().height : 0;
      });
      assert.ok(placeDensity >= 44 && placeDensity <= 48.5, `phone-390: place rows are not compact (${placeDensity})`);

      const handle = await page.locator('#filePlacesHandle').boundingBox();
      await page.mouse.move(handle.x + handle.width / 2, handle.y + 8);
      await page.mouse.down();
      await page.mouse.move(handle.x + handle.width / 2, handle.y + 110, { steps: 5 });
      await page.mouse.up();
      await page.waitForFunction(() => !document.getElementById('filePlacesSheet').classList.contains('show'));

      await page.click('#filePlacesEdge');
      await page.waitForSelector('#filePlacesSheet.show');
      await page.click('#filePlacesClose');
      await page.waitForFunction(() => !document.getElementById('filePlacesSheet').classList.contains('show'));

      await page.click('#fileMenuBtn');
      await page.click('#fileSyncPanes');
      assert.equal(await page.evaluate(() => window.SKFileManager.model.panes.right.path), '/');

      const archiveRow = page.locator('[data-list="left"] .fm-row[data-name="backup.zip"]');
      await archiveRow.click({ button: 'right' });
      await page.waitForSelector('#actionModal.show');
      assert.equal(await page.locator('#actExtract').isVisible(), true);
      assert.equal(await page.locator('#actCompress').isVisible(), true);
      await page.click('#actionCancel');

      const apkRow = page.locator('[data-list="left"] .fm-row[data-name="demo app.apk"]');
      await apkRow.click();
      await page.waitForSelector('#actionModal.show');
      assert.equal(await page.locator('#actInstallApk').isVisible(), true);
      assert.equal(await page.locator('#actCompress').isVisible(), true);
      const startsBeforeCancel = jobStartCount;
      await page.click('#actInstallApk');
      await page.waitForSelector('#apkInstallModal.show');
      assert.match(await page.locator('#apkInstallPath').textContent(), /demo app\.apk$/);
      await page.click('#apkInstallCancel');
      assert.equal(jobStartCount, startsBeforeCancel, 'APK cancellation must not start a job');
      await apkRow.click();
      await page.click('#actInstallApk');
      await page.click('#apkInstallConfirm');
      await page.waitForFunction(() => document.getElementById('fileJobTitle').textContent.includes('任务完成'));
      assert.equal(lastJobOperation, 'install_apk');
      await page.waitForFunction(() => document.getElementById('fileJobBar').hidden, null, { timeout: 5000 });

      const suffixedApkRow = page.locator('[data-list="left"] .fm-row[data-name="QQ received app.apk.1"]');
      await suffixedApkRow.click();
      await page.waitForSelector('#actionModal.show');
      assert.equal(await page.locator('#actInstallApk').isVisible(), true);
      await page.click('#actInstallApk');
      await page.waitForSelector('#apkInstallModal.show');
      assert.match(await page.locator('#apkInstallPath').textContent(), /app\.apk\.1$/);
      await page.click('#apkInstallCancel');

      await fileRow.click();
      await page.waitForSelector('#actionModal.show');
      await page.click('#actCompress');
      await page.waitForSelector('#operationConfirmModal.show');
      assert.match(await page.locator('#operationConfirmTarget').textContent(), /notes\.txt\.zip$/);
      assert.equal(await page.locator('#operationConflictOptions').isHidden(), true);
      await page.click('#operationConfirmCancel');

      const swipeRow = page.locator('[data-list="left"] .fm-row[data-name="Android"]');
      const box = await swipeRow.boundingBox();
      await page.mouse.move(box.x + 12, box.y + box.height / 2);
      await page.mouse.down();
      await page.mouse.move(box.x + 76, box.y + box.height / 2, { steps: 4 });
      await page.mouse.up();
      await page.waitForSelector('#selectionBar:not([hidden])');
      assert.equal(await swipeRow.evaluate(node => node.classList.contains('selected')), true);
      await page.click('#selectionActions');
      await page.waitForSelector('#actionModal.show');
      assert.equal(await page.locator('#actCompress').isVisible(), true);
      assert.equal(await page.locator('#actInstallApk').isHidden(), true);
      await page.click('#actionCancel');
      await page.screenshot({ path: path.join(outputDir, 'phone-390-selection.png'), fullPage: true });
      await page.click('#selectionExit');
      await page.waitForTimeout(700);

      await fileRow.click();
      await page.click('#actEdit');
      await page.waitForSelector('#textEditor.show');
      await page.waitForFunction(() => document.querySelector('#textEditor .cm-content')?.textContent.includes('dual pane editor'));
      await page.screenshot({ path: path.join(outputDir, 'phone-390-editor.png'), fullPage: true });
      await page.click('#textEditorClose');

      for (const args of ['--first', '--name "two words"']) {
        const scriptRow = page.locator('[data-list="left"] .fm-row[data-name="run-script.sh"]');
        await scriptRow.click();
        await page.waitForSelector('#actionModal.show');
        await page.click('#actAuto');
        await page.waitForSelector('#autoModal.show');
        if (!(await page.locator('#autoArgInput').isVisible())) {
          await page.click('#autoModal .adv-params summary');
        }
        await page.fill('#autoArgInput', args);
        await page.click('#autoConfirm');
        await page.waitForSelector('#autoSheet.show');
        if (args === '--first') {
          await page.click('#autoClose');
          await page.click('#fileBtn');
          await page.waitForSelector('#fileWorkspace.show');
        }
      }
      assert.equal(await page.evaluate(() => window.SKInputSimulator.model.draft.steps.filter(step => step.type === 'script').length), 2);
      assert.deepEqual(await page.evaluate(() => window.SKInputSimulator.model.draft.steps.at(-1).args), ['--name', 'two words']);

      await page.click('#autoClose');
      await page.evaluate(() => window.SKFileManager.close());
      await page.click('#autoBtn');
      await page.waitForSelector('#autoSheet.show');
      await page.click('#automationEditorTab');
        const editorGeometry = await page.evaluate(() => {
          const name = document.getElementById('automationDraftName').getBoundingClientRect();
          const policy = document.getElementById('automationFailurePolicy').getBoundingClientRect();
          const scriptCard = document.querySelector('.automation-step-card[data-step-index="0"]');
          const pathInput = scriptCard?.querySelector('[data-step-field="path"]')?.getBoundingClientRect();
          return { name, policy, pathInput, width: innerWidth };
        });
        assert.ok(editorGeometry.pathInput, 'phone-390: script field missing');
      assert.ok(Math.abs(editorGeometry.name.top - editorGeometry.policy.top) <= 2, 'phone-390: editor meta fields are not aligned');
      await page.click('#automationSave');
      await page.waitForSelector('#automationNameModal.show');
      await page.click('#automationNameCancel');
      await page.click('#automationSaveMore');
      await page.waitForSelector('#automationSaveMenu:not([hidden])');
      assert.equal(await page.locator('#automationSaveMenu [data-save-action="rename"]').isDisabled(), true);
      await page.click('#automationSaveMore');
      await page.click('#autoClose');
    }
    if (viewport.name === 'desktop') {
      await page.evaluate(() => window.SKFileManager.close());
      await page.click('#autoBtn');
      await page.waitForSelector('#autoSheet.show');
      await page.click('#automationNewScheme');
      await page.click('[data-add-step="command"]');
      await page.fill('[data-step-field="command"]', 'printf workflow');
      await page.click('[data-add-step="wait"]');
      await page.fill('[data-step-field="seconds"]', '0.2');
      await page.click('[data-add-step="script"]');
      await page.fill('[data-step-field="path"]', '/sdcard/run-script.sh');
      await page.fill('[data-step-field="args"]', '--name "two words"');
      await page.click('[data-step-index="2"] [data-step-action="up"]');
      assert.equal(await page.locator('.automation-step-card').count(), 3);
      assert.equal(await page.locator('.automation-step-card').nth(1).getAttribute('data-step-index'), '1');
      await page.click('#automationSave');
      await page.fill('#automationNameInput', '日常维护');
      await page.click('#automationNameConfirm');
      await page.waitForFunction(() => document.getElementById('automationDraftState').textContent.includes('已保存'));
      await page.click('#automationSave');
      assert.equal(await page.locator('#automationNameModal').isVisible(), false, 'saved draft should overwrite directly');
      await page.click('#automationSaveMore');
      await page.waitForSelector('#automationSaveMenu:not([hidden])');
      assert.equal(await page.locator('#automationSaveMenu [data-save-action="rename"]').isDisabled(), false);
      await page.click('#automationSaveMore');
      const commandGeometry = await page.evaluate(() => {
        const card = document.querySelector('.automation-step-card[data-step-index="0"]');
        const command = card?.querySelector('[data-step-field="command"]')?.getBoundingClientRect();
        return { command };
      });
      assert.ok(commandGeometry.command, 'desktop: command field missing');
      await page.click('#automationLibraryTab');
      await page.click('.automation-scheme-more');
      await page.click('#automationSchemeFavorite');
      await page.waitForFunction(() => !document.getElementById('automationQuickSchemes').hidden);
      await page.screenshot({ path: path.join(outputDir, 'desktop-automation-library.png'), fullPage: true });
      await page.click('#autoClose');
      await page.click('.automation-quick-card');
      await page.waitForSelector('#automationRunBar:not([hidden])');
      assert.equal(await page.locator('#cmd').isDisabled(), true);
      await page.waitForFunction(() => document.getElementById('automationRunState').textContent === '执行完成');
      await page.screenshot({ path: path.join(outputDir, 'desktop-automation-complete.png'), fullPage: true });
      assert.equal(await page.locator('#automationRunCancel').count(), 0, 'step cancellation must stay hidden');
    }
    assert.deepEqual(errors, [], `${viewport.name}: page errors: ${errors.join('; ')}`);
    await page.close();
  }

  await browser.close();
  server.close();
  console.log(`file_manager_visual: OK (${outputDir})`);
})().catch(error => {
  console.error(error);
  server.close();
  process.exitCode = 1;
});
