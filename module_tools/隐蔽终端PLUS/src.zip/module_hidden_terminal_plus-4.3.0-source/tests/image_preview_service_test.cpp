#include "../image_preview_service.h"

#include <cassert>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace fs = std::filesystem;
using namespace file_manager;

namespace {
using Bytes = std::vector<uint8_t>;

void le16(Bytes& bytes, size_t at, uint32_t value) {
    bytes[at] = value & 255;
    bytes[at + 1] = (value >> 8) & 255;
}
void le32(Bytes& bytes, size_t at, uint32_t value) {
    le16(bytes, at, value);
    le16(bytes, at + 2, value >> 16);
}
void be32(Bytes& bytes, size_t at, uint32_t value) {
    bytes[at] = value >> 24;
    bytes[at + 1] = value >> 16;
    bytes[at + 2] = value >> 8;
    bytes[at + 3] = value;
}
void stamp(Bytes& bytes, size_t at, const char* value, size_t count) {
    std::memcpy(bytes.data() + at, value, count);
}
Bytes png(uint32_t width = 5, uint32_t height = 3) {
    Bytes bytes(33);
    stamp(bytes, 0, "\x89PNG\r\n\x1a\n", 8);
    be32(bytes, 8, 13);
    stamp(bytes, 12, "IHDR", 4);
    be32(bytes, 16, width);
    be32(bytes, 20, height);
    bytes[24] = 8;
    bytes[25] = 6;
    return bytes;
}
Bytes gif() {
    Bytes bytes(13);
    stamp(bytes, 0, "GIF89a", 6);
    le16(bytes, 6, 5);
    le16(bytes, 8, 3);
    return bytes;
}
Bytes bmp(bool top_down = false) {
    Bytes bytes(54);
    stamp(bytes, 0, "BM", 2);
    le32(bytes, 2, 54);
    le32(bytes, 10, 54);
    le32(bytes, 14, 40);
    le32(bytes, 18, 5);
    le32(bytes, 22, top_down ? static_cast<uint32_t>(-3) : 3);
    le16(bytes, 26, 1);
    le16(bytes, 28, 24);
    return bytes;
}
Bytes jpeg() {
    return {0xff, 0xd8, 0xff, 0xe0, 0, 4, 0, 0, 0xff, 0xc0, 0, 17, 8,
            0, 3, 0, 5, 3, 1, 0x11, 0, 2, 0x11, 0, 3, 0x11, 0, 0xff, 0xd9};
}
Bytes webp(const char* kind) {
    const bool lossless = std::strcmp(kind, "VP8L") == 0;
    Bytes bytes(lossless ? 26 : 30);
    stamp(bytes, 0, "RIFF", 4);
    le32(bytes, 4, bytes.size() - 8);
    stamp(bytes, 8, "WEBP", 4);
    stamp(bytes, 12, kind, 4);
    le32(bytes, 16, lossless ? 5 : 10);
    if (!std::strcmp(kind, "VP8X")) {
        bytes[24] = 4;
        bytes[27] = 2;
    } else if (lossless) {
        bytes[20] = 0x2f;
        le32(bytes, 21, 4 | (2 << 14));
    } else {
        bytes[23] = 0x9d;
        bytes[24] = 1;
        bytes[25] = 0x2a;
        le16(bytes, 26, 5);
        le16(bytes, 28, 3);
    }
    return bytes;
}
void writeFile(const fs::path& path, const Bytes& bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(reinterpret_cast<const char*>(bytes.data()), bytes.size());
    assert(output.good());
}
} // namespace

int main() {
    char directory[] = "/tmp/skroot-image-test-XXXXXX";
    char* raw = ::mkdtemp(directory);
    assert(raw);
    const fs::path root(raw);
    ImagePreviewService::Clock::time_point now {};
    ImagePreviewService images([&] { return now; });
    ImageOpenResult opened;
    TextReadResult chunk;
    Error error;

    const std::vector<std::pair<Bytes, std::string>> formats {
        {png(), "image/png"}, {jpeg(), "image/jpeg"}, {gif(), "image/gif"},
        {bmp(), "image/bmp"}, {bmp(true), "image/bmp"}, {webp("VP8X"), "image/webp"},
        {webp("VP8 "), "image/webp"}, {webp("VP8L"), "image/webp"},
    };
    const auto path = root / "图片 no extension";
    for (const auto& [bytes, mime] : formats) {
        writeFile(path, bytes);
        assert(images.openImage(path.string(), opened, error));
        assert(opened.mime == mime && opened.width == 5 && opened.height == 3);
        assert(opened.size == bytes.size());
        assert(images.readChunk(opened.session_id, 0, 0, chunk, error));
        assert(chunk.offset == 0 && chunk.next_offset == bytes.size() && chunk.eof);
        Bytes decoded;
        assert(TextTransferService::decodeBase64(chunk.base64_data, decoded));
        assert(decoded == bytes);
        assert(!images.readChunk(opened.session_id, 0, 0, chunk, error));
        assert(error.code == "IMAGE_SESSION_NOT_FOUND");
        images.close(opened.session_id);
        images.close(opened.session_id);
    }

    auto large = png();
    large.resize(kMaxTransferChunkBytes * 2 + 17, 0x7b);
    writeFile(path, large);
    assert(images.openImage(path.string(), opened, error));
    assert(!images.readChunk(opened.session_id, opened.size + 1, 0, chunk, error));
    assert(error.code == "INVALID_OFFSET");
    Bytes reconstructed;
    for (uint64_t offset = 0; offset < opened.size;) {
        assert(images.readChunk(opened.session_id, offset, kMaxTransferChunkBytes + 999, chunk, error));
        Bytes decoded;
        assert(TextTransferService::decodeBase64(chunk.base64_data, decoded));
        assert(decoded.size() <= kMaxTransferChunkBytes);
        reconstructed.insert(reconstructed.end(), decoded.begin(), decoded.end());
        offset = chunk.next_offset;
    }
    assert(reconstructed == large);

    assert(images.openImage(path.string(), opened, error));
    fs::rename(path, root / "previous");
    writeFile(path, large);
    assert(!images.readChunk(opened.session_id, 0, 1, chunk, error));
    assert(error.code == "FILE_CHANGED");
    assert(images.openImage(path.string(), opened, error));
    assert(::truncate(path.c_str(), 0) == 0);
    assert(!images.readChunk(opened.session_id, 0, 1, chunk, error));
    assert(error.code == "FILE_CHANGED");

    assert(!images.openImage(root.string(), opened, error));
    assert(error.code == "NOT_REGULAR_FILE");
    writeFile(path, png());
    assert(::symlink(path.c_str(), (root / "link.png").c_str()) == 0);
    assert(!images.openImage((root / "link.png").string(), opened, error));
    assert(error.code == "NOT_REGULAR_FILE");
    assert(::mkfifo((root / "fifo.png").c_str(), 0600) == 0);
    assert(!images.openImage((root / "fifo.png").string(), opened, error));
    assert(error.code == "NOT_REGULAR_FILE");
    assert(!images.openImage("relative.png", opened, error));

    const auto checkRejected = [&](const Bytes& bytes, const char* code) {
        writeFile(path, bytes);
        assert(!images.openImage(path.string(), opened, error));
        if (error.code != code) std::cerr << "expected " << code << ", got " << error.code << '\n';
        assert(error.code == code);
    };
    checkRejected({}, "IMAGE_UNSUPPORTED_FORMAT");
    checkRejected({'<', 's', 'v', 'g', '>'}, "IMAGE_UNSUPPORTED_FORMAT");
    checkRejected(png(0, 3), "INVALID_IMAGE");
    checkRejected(png(32769, 1), "IMAGE_DIMENSIONS_TOO_LARGE");
    checkRejected(png(8001, 4000), "IMAGE_DIMENSIONS_TOO_LARGE");
    checkRejected(png(0xffffffff, 0xffffffff), "IMAGE_DIMENSIONS_TOO_LARGE");
    auto invalid = png(); invalid.resize(32);
    checkRejected(invalid, "INVALID_IMAGE");
    invalid = jpeg(); invalid[11] = 255;
    checkRejected(invalid, "INVALID_IMAGE");
    invalid = webp("VP8X"); le32(invalid, 16, 0xffffffff);
    checkRejected(invalid, "INVALID_IMAGE");
    invalid = webp("VP8 "); invalid[23] = 0;
    checkRejected(invalid, "INVALID_IMAGE");
    invalid = webp("VP8L"); invalid[20] = 0;
    checkRejected(invalid, "INVALID_IMAGE");
    invalid = bmp(); le32(invalid, 18, 0x80000000);
    checkRejected(invalid, "INVALID_IMAGE");
    invalid = bmp(); le32(invalid, 22, 0x80000000);
    checkRejected(invalid, "IMAGE_DIMENSIONS_TOO_LARGE");
    invalid = bmp(); le32(invalid, 14, 0xffffffff);
    checkRejected(invalid, "INVALID_IMAGE");

    writeFile(path, png(8000, 4000));
    assert(images.openImage(path.string(), opened, error));
    images.close(opened.session_id);
    writeFile(path, png(32768, 1));
    assert(images.openImage(path.string(), opened, error));
    images.close(opened.session_id);
    assert(::truncate(path.c_str(), kMaxImageFileBytes) == 0);
    assert(images.openImage(path.string(), opened, error));
    images.close(opened.session_id);
    assert(::truncate(path.c_str(), kMaxImageFileBytes + 1) == 0);
    assert(!images.openImage(path.string(), opened, error));
    assert(error.code == "IMAGE_TOO_LARGE");

    writeFile(path, png());
    assert(images.openImage(path.string(), opened, error));
    now += std::chrono::minutes(5);
    assert(!images.readChunk(opened.session_id, 0, 1, chunk, error));
    assert(error.code == "IMAGE_SESSION_NOT_FOUND");
    std::vector<std::string> sessions;
    for (int i = 0; i < 9; ++i) {
        now += std::chrono::seconds(1);
        assert(images.openImage(path.string(), opened, error));
        sessions.push_back(opened.session_id);
    }
    assert(!images.readChunk(sessions.front(), 0, 1, chunk, error));
    assert(error.code == "IMAGE_SESSION_NOT_FOUND");
    assert(images.readChunk(sessions.back(), 0, 1, chunk, error));
    now += std::chrono::minutes(4);
    assert(images.readChunk(sessions.back(), 1, 1, chunk, error));
    now += std::chrono::minutes(4);
    assert(images.readChunk(sessions.back(), 2, 1, chunk, error));
    images.shutdown();
    assert(!images.readChunk(sessions.back(), 3, 1, chunk, error));
    assert(!images.openImage(path.string(), opened, error));
    assert(error.code == "IMAGE_SERVICE_CLOSED");
    fs::remove_all(root);
    std::cout << "image preview service checks passed\n";
}
