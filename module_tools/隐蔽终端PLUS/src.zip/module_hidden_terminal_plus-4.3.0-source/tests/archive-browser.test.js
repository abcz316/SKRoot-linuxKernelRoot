const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const { FileManagerModel } = require('../webroot/file-manager-model.js');

function create(api) {
  const context = { window: {}, setTimeout, clearTimeout };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../webroot/archive-browser.js'), 'utf8'), context);
  const model = new FileManagerModel('/left', '/right');
  const browser = context.window.SKArchiveBrowser.create({model, api,
    render() {}, normalizeEntry: x => x, invalidatePane() {}});
  return {model, browser};
}
const deferred = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; };

test('archive views keep real path/home and move with pane swap; virtual source cannot sync', () => {
  const model = new FileManagerModel('/left', '/right');
  const archive = {sessionId:'s',archivePath:'/left/a.zip',innerPath:'dir'};
  model.enterArchive('left', archive);
  assert.equal(model.panes.left.path, '/left');
  assert.equal(model.syncPanesToActive(), false);
  model.swapPanes();
  assert.equal(model.panes.right.archive, archive);
  assert.equal(model.panes.right.home, '/right');
  assert.equal(model.leaveArchive('right'), archive);
  assert.equal(model.panes.right.archive, null);
});

test('duplicate file IDs select accurately and selection survives pagination up to 500 items', () => {
  const model = new FileManagerModel();
  model.enterArchive('left', {sessionId:'s'});
  model.setEntries('left', [{id:'e:1',name:'same'},{id:'e:2',name:'same'}]);
  model.beginSelection('left', 'e:2');
  assert.equal(model.selectedEntries()[0].id, 'e:2');
  model.setEntries('left', [{id:'e:3',name:'next'}]);
  model.toggleSelection('left', 'e:3');
  assert.deepEqual(model.selectedEntries().map(x=>x.id), ['e:2','e:3']);
  model.setEntries('left', Array.from({length:500}, (_,i)=>({id:`e:${i+10}`,name:`n${i}`})));
  assert.equal(model.selectAll(), false);
  assert.equal(model.selectedPaths.size, 2);
  model.clearSelection();
  model.beginSelection('left');
  assert.equal(model.selectAll(), true);
  assert.equal(model.toggleSelection('left','e:900'), false);
  assert.equal(model.selectedPaths.size, 500);
});

test('closing while open is pending closes the late session without reopening the pane', async () => {
  const pending = deferred(), closed = [];
  const {model,browser} = create({openArchive:()=>pending.promise,closeArchive:async id=>closed.push(id)});
  const operation = browser.open('left','/left/a.zip');
  await new Promise(setImmediate);
  await browser.leave('left');
  pending.resolve({sessionId:'late'});
  await operation;
  assert.equal(model.panes.left.archive, null);
  assert.deepEqual(closed, ['late']);
});

test('swapping during index/read delivers result to the archive new pane', async () => {
  const pending = deferred();
  const {model,browser} = create({openArchive:async()=>({sessionId:'s'}),
    getArchiveStatus:async()=>({state:'ready'}),listArchive:()=>pending.promise,closeArchive:async()=>{}});
  const operation = browser.open('left','/left/a.zip');
  await new Promise(setImmediate);
  model.swapPanes();
  pending.resolve({items:[{id:'e:1',name:'one'}],total:1});
  await operation;
  assert.equal(model.panes.right.entries[0].name, 'one');
  assert.equal(model.panes.left.archive,null);
  await browser.close();
});

test('new directory navigation ignores a late previous page', async () => {
  const pending = deferred();
  const {model,browser} = create({openArchive:async()=>({sessionId:'s'}),getArchiveStatus:async()=>({state:'ready'}),
    listArchive:async (_id,inner)=>inner ? {items:[{id:'e:2',name:'new'}],total:1} : pending.promise,
    closeArchive:async()=>{}});
  const first = browser.open('left','/left/a.zip');
  await new Promise(setImmediate);
  await browser.navigate('left','child');
  pending.resolve({items:[{id:'e:1',name:'old'}],total:1});
  await first;
  assert.equal(model.panes.left.entries[0].name,'new');
  await browser.close();
});

test('navigating the other archive pane preserves selection; leaving clears stale entries immediately', async () => {
  const close = deferred();
  const {model,browser} = create({openArchive:async()=>({sessionId:'s'}),getArchiveStatus:async()=>({state:'ready'}),
    listArchive:async()=>({items:[{id:'d:dir',name:'dir',type:'directory'}],total:1}),closeArchive:()=>close.promise});
  await browser.open('right','/right/a.zip');
  model.setEntries('left',[{name:'selected.txt'}]);
  model.beginSelection('left','/left/selected.txt');
  await browser.navigate('right','dir');
  assert.equal(model.selectionPane,'left');
  const leaving = browser.leave('right');
  assert.equal(model.panes.right.entries.length,0);
  await browser.page('right',500);
  close.resolve();
  await leaving;
  assert.equal(model.selectionPane,'left');
});
