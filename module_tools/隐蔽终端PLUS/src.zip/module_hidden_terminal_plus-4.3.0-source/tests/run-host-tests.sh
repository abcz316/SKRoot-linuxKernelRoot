#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
build_dir="${SKROOT_TEST_BUILD_DIR:-$(mktemp -d /tmp/skroot-host-tests-XXXXXX)}"
mkdir -p "$build_dir"
echo "Host tests build dir: $build_dir"
cxx="${CXX:-g++}"
sdk_include="${SKROOT_SDK_INCLUDE:-../SKRoot-linuxKernelRoot/Pro(众测开放中)/src/testModule/kernel_module_kit/include}"
flags=(-std=c++20 -O0 -g -pthread -I. "-I$sdk_include" -Ithird_party/libarchive/include)
# Use development-library names when available, sonames on runtime-only hosts.
libs=(-l:libarchive.so.13 -l:liblzma.so.5 -lz)
for source in cJSON automation_service file_manager_service file_manager_api archive_service archive_browser_service image_preview_service su_interactive shell_scheduler; do
  "$cxx" "${flags[@]}" -c "$source.cpp" -o "$build_dir/$source.o"
done
run_test() {
  local test="$1"; shift
  "$cxx" "${flags[@]}" "tests/$test.cpp" "$@" -o "$build_dir/$test"
  # Match WebUI's lack of a controlling terminal, even from an interactive host.
  setsid --wait timeout 120 "$build_dir/$test"
  echo "PASS $test"
}
run_test automation_service_test "$build_dir/automation_service.o" "$build_dir/cJSON.o"
run_test file_manager_service_test "$build_dir/file_manager_service.o" "$build_dir/archive_service.o" "${libs[@]}"
run_test file_manager_api_test "$build_dir/file_manager_api.o" "$build_dir/file_manager_service.o" "$build_dir/archive_service.o" "$build_dir/archive_browser_service.o" "$build_dir/image_preview_service.o" "$build_dir/cJSON.o" "${libs[@]}"
run_test archive_service_test "$build_dir/file_manager_service.o" "$build_dir/archive_service.o" "${libs[@]}"
run_test archive_browser_service_test "$build_dir/archive_browser_service.o" "$build_dir/file_manager_service.o" "$build_dir/archive_service.o" "${libs[@]}"
run_test image_preview_service_test "$build_dir/image_preview_service.o" "$build_dir/file_manager_service.o" "$build_dir/archive_service.o" "${libs[@]}"
run_test shell_scheduler_test "$build_dir/shell_scheduler.o"
run_test stream_control_filter_test
run_test pipe_output_filter_test
run_test pty_master_termios_test
run_test webui_access_policy_test
run_test su_interactive_lifecycle_test "$build_dir/su_interactive.o" "$build_dir/shell_scheduler.o"
node --test tests/*.test.js
