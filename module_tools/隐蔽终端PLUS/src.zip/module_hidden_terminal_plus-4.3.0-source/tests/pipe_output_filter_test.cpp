#include "../pipe_output_filter.h"

#include <cassert>
#include <iostream>
#include <string>
#include <vector>

static void checkChunks(const std::string& input, const std::string& expected,
                        int expected_prompts, const std::vector<std::string>& expected_frames) {
    // Every possible two-read split, then one-byte reads, must agree.
    for (size_t split = 0; split <= input.size() + 1; ++split) {
        PipeOutputFilter filter;
        std::string output;
        int prompts = 0;
        std::vector<std::string> frames;
        auto receive = [&](const std::string& frame) {
            frames.push_back(frame);
            return frame == "SKA:token:0:0";
        };
        auto ready = [&] { ++prompts; };
        if (split <= input.size()) {
            output += filter.consume(std::string_view(input).substr(0, split), receive, ready);
            output += filter.consume(std::string_view(input).substr(split), receive, ready);
        } else {
            for (char ch : input) output += filter.consume(std::string_view(&ch, 1), receive, ready);
        }
        output += filter.flush();
        assert(output == expected);
        assert(prompts == expected_prompts);
        assert(frames == expected_frames);
    }
}

int main() {
    const std::string marker(PipeOutputFilter::kReadyMarker);
    const std::string automation = "\036SKA:token:0:0\037";
    checkChunks("before" + marker + "# after", "before# after", 1, {});
    checkChunks(std::string("\036OTHER") + marker + "# ", "\036OTHER# ", 1, {});
    checkChunks(std::string("\036SKA:unfinished") + marker + "# " + automation + "done",
                "\036SKA:unfinished# done", 1, {"SKA:token:0:0"});
    checkChunks(automation + marker + "# " + automation + marker + "# ",
                "# # ", 2, {"SKA:token:0:0", "SKA:token:0:0"});
    checkChunks(std::string("\036") + automation + marker, "\036", 1, {"SKA:token:0:0"});
    checkChunks("\036UNKNOWN\037\036SKA:other\037", "\036UNKNOWN\037\036SKA:other\037",
                0, {"SKA:other"});
    checkChunks("\036\037\036S\037\036SK\037", "\036\037\036S\037\036SK\037", 0, {});
    for (size_t n = 1; n < marker.size(); ++n) {
        checkChunks("tail" + marker.substr(0, n), "tail" + marker.substr(0, n), 0, {});
    }

    PipeOutputFilter filter;
    int prompts = 0;
    auto ready = [&] { ++prompts; };
    // Unknown controls cannot delay ordinary output until a future US/prompt.
    const std::string ordinary = std::string("before\036OTHER-") + std::string(9000, 'x');
    assert(filter.consume(ordinary, {}, ready) == ordinary);
    assert(filter.consume(marker, {}, ready).empty() && prompts == 1);
    assert(filter.flush().empty());
    std::cout << "Pipe prompt: malformed controls, all splits, automation and EOF passed\n";
}
