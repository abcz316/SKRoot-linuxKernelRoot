const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { test } = require("node:test");

class FakeNode {
  constructor() {
    this.children = [];
    this.style = {};
    this.className = "";
    this.textContent = "";
    this.scrollTop = 0;
    this.scrollHeight = 0;
  }
  appendChild(node) { this.children.push(node); return node; }
  replaceChildren(...nodes) { this.children = nodes; }
}

function createCore() {
  const context = {
    window: {},
    document: { createElement: () => new FakeNode() },
    requestAnimationFrame: callback => callback(),
  };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, "..", "webroot", "terminal-core.js"), "utf8"), context);
  const out = new FakeNode();
  return { out, core: context.window.SKTerminalCore.createTerminalCore({ out, connDot: new FakeNode(), connText: new FakeNode() }) };
}

for (const mode of ["pty", "pipe"]) {
  test(`ANSI styles render in ${mode} transport`, () => {
    const { out, core } = createCore();
    core.setTransportMode(mode);
    const esc = String.fromCharCode(27);
    core.consumeChunk(`${esc}[31mred${esc}[0m\nprogress 10%\rprogress 20%\n`);
    assert.equal(out.children.length, 2);
    assert.equal(out.children[0].children[0].style.color, "#b91c1c");
    assert.equal(out.children[1].children[0].textContent, "progress 20%");
  });
}
