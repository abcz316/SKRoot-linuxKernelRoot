#include "../su_interactive.h"

#include <cassert>
#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <functional>
#include <thread>
#include <atomic>
#include <vector>
#include <fcntl.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <unistd.h>

namespace fs = std::filesystem;
using namespace std::chrono_literals;

static void eventually(const std::function<bool()>& fn) {
    for (int i = 0; i < 400; ++i) {
        if (fn()) return;
        std::this_thread::sleep_for(10ms);
    }
    assert(false && "condition timed out");
}
static bool alive(pid_t pid) { return pid > 1 && ::kill(pid, 0) == 0; }
static pid_t readPid(const fs::path& path) {
    pid_t pid = -1;
    std::ifstream(path) >> pid;
    return pid;
}
static void ready(SuInteractive& shell) {
    assert(shell.sendLine("printf 'REA''DY\\n'"));
    eventually([&] { return shell.output().find("READY") != std::string::npos; });
    eventually([&] { return shell.isShellIdle(); });
    shell.takeOutput();
}
static void reaped(pid_t pid) {
    int status = 0;
    errno = 0;
    assert(::waitpid(pid, &status, WNOHANG) == -1 && errno == ECHILD);
}
static void cleanupOrphan(pid_t pid) {
    assert(alive(pid));
    ::kill(pid, SIGKILL);
    int status = 0;
    while (::waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
}
static void boundedStop(SuInteractive& shell) {
    auto before = std::chrono::steady_clock::now();
    shell.stop(true);
    assert(std::chrono::steady_clock::now() - before < 1500ms);
}
static void testBackground(const fs::path& root, TerminalTransportMode mode, bool same_group) {
    SuInteractive shell;
    assert(shell.start({}, mode));
    ready(shell);
    const auto pidfile = root / "background.pid";
    fs::remove(pidfile);
    const auto parent = shell.get_shell_pid();
    const std::string command = std::string(same_group ? "set +m; " : "") +
        "(trap '' HUP; exec sleep 60) </dev/null >/dev/null 2>&1 & echo $! > " + pidfile.string() + "; printf 'BACK''GROUND\\n'";
    assert(shell.sendLine(command));
    eventually([&] { return readPid(pidfile) > 1 && shell.output().find("BACKGROUND") != std::string::npos; });
    const pid_t child = readPid(pidfile);
    assert(alive(child));
    if (mode == TerminalTransportMode::Pipe) {
        assert(shell.hasShellIdleState());
    }
    if (same_group) assert(::getpgid(child) == ::getpgid(parent));
    eventually([&] { return shell.isShellIdle(); });
    boundedStop(shell); // detached job no longer holds the terminal descriptors
    reaped(parent);
    cleanupOrphan(child);
}
static void testForeground(const fs::path& root) {
    SuInteractive shell;
    assert(shell.start({}, TerminalTransportMode::Pty));
    ready(shell);
    eventually([&] { return shell.isShellIdle(); });
    const auto pidfile = root / "foreground.pid";
    assert(shell.sendLine("sh -c 'echo $$ > " + pidfile.string() + "; exec sleep 60'"));
    eventually([&] { return readPid(pidfile) > 1 && !shell.isShellIdle(); });
    const pid_t foreground = readPid(pidfile);
    assert(alive(foreground));
    // Normal terminal Ctrl+C for this foreground job, not lifecycle group killing.
    assert(shell.send(std::string(1, '\003')));
    eventually([&] { return shell.isShellIdle(); });
    ready(shell);
    boundedStop(shell);
}
static void testRepeatedStop(TerminalTransportMode mode) {
    SuInteractive shell;
    for (int i = 0; i < 3; ++i) {
        const pid_t old = shell.get_shell_pid();
        assert(shell.start({}, mode));
        if (old > 1) reaped(old);
        ready(shell);
    }
    const pid_t pid = shell.get_shell_pid();
    shell.stop(); // upstream has no concurrent stop serialization
    reaped(pid);
    shell.stop();
}
static void testDestructor(TerminalTransportMode mode) {
    pid_t pid = -1;
    {
        SuInteractive shell;
        assert(shell.start({}, mode));
        ready(shell);
        pid = shell.get_shell_pid();
    }
    reaped(pid);
}
static void testWatchdogFds(TerminalTransportMode mode) {
    std::vector<int> inherited;
    for (int fd = 3; fd < 1024; ++fd) {
        if (::fcntl(fd, F_GETFD) >= 0) inherited.push_back(fd);
    }
    SuInteractive shell;
    assert(shell.start({}, mode));
    ready(shell);
    // Snapshot only this test process's transport descriptors before fork.
    std::vector<int> transport;
    for (int fd = 3; fd < 1024; ++fd) {
        if (::fcntl(fd, F_GETFD) >= 0 &&
            std::find(inherited.begin(), inherited.end(), fd) == inherited.end()) transport.push_back(fd);
    }
    assert(transport.size() == 2u);
    int signal_pipe[2];
    assert(::pipe2(signal_pipe, O_CLOEXEC) == 0);
    pid_t guard = ::fork();
    assert(guard >= 0);
    if (guard == 0) {
        ::close(signal_pipe[0]);
        shell.closeTransportFdsAfterFork();
        for (int fd : transport) if (::fcntl(fd, F_GETFD) != -1 || errno != EBADF) _exit(2);
        (void)::write(signal_pipe[1], "R", 1);
        ::close(signal_pipe[1]);
        ::sleep(2); // remain alive after the parent's stop()
        _exit(0);
    }
    ::close(signal_pipe[1]);
    char ack = 0;
    assert(::read(signal_pipe[0], &ack, 1) == 1 && ack == 'R');
    ::close(signal_pipe[0]);
    ready(shell); // child's close must not close the parent's descriptors
    boundedStop(shell);
    assert(alive(guard));
    int status = 0;
    assert(::waitpid(guard, &status, 0) == guard);
    assert(WIFEXITED(status) && WEXITSTATUS(status) == 0);
}
static void testBlockedWriter(const fs::path& root) {
    SuInteractive shell;
    assert(shell.start({}, TerminalTransportMode::Pipe));
    ready(shell);
    const auto pidfile = root / "blocking.pid";
    assert(shell.sendLine("sh -c 'echo $$ > " + pidfile.string() + "; exec sleep 0.6'"));
    eventually([&] { return readPid(pidfile) > 1; });
    pid_t child = readPid(pidfile);
    std::atomic<bool> returned{false};
    std::thread writer([&] { shell.send(std::string(1024 * 1024, 'x')); returned = true; });
    std::this_thread::sleep_for(100ms);
    assert(!returned);
    // Upstream blocking write can finish only when the child releases stdin.
    shell.stop();
    writer.join();
    assert(returned);
    int status = 0;
    while (::waitpid(child, &status, 0) < 0 && errno == EINTR) {}
}
static void testInheritedPipeWriter(const fs::path& root) {
    // Noninteractive fixture does not print "exit" and wake a pending read.
    ::setenv("SKROOT_TEST_NONINTERACTIVE", "1", 1);
    SuInteractive shell;
    assert(shell.start({}, TerminalTransportMode::Pipe));
    const auto pidfile = root / "inherited-output.pid";
    assert(shell.sendLine("(trap '' HUP; exec sleep 0.6) & echo $! > " + pidfile.string() + "; printf 'INHER''ITED\\n'"));
    eventually([&] { return readPid(pidfile) > 1 && shell.output().find("INHERITED") != std::string::npos; });
    const pid_t child = readPid(pidfile);
    std::this_thread::sleep_for(30ms); // reader is now blocked waiting for output
    std::atomic<bool> stopped{false};
    std::thread stopper([&] { shell.stop(); stopped = true; });
    std::this_thread::sleep_for(100ms);
    assert(!stopped); // closing an fd does not cancel an in-flight Linux read
    stopper.join();   // finishes after the descendant releases its pipe writer
    int status = 0;
    while (::waitpid(child, &status, 0) < 0 && errno == EINTR) {}
    ::unsetenv("SKROOT_TEST_NONINTERACTIVE");
}
static void testNaturalExit() {
    SuInteractive shell;
    assert(shell.start({}, TerminalTransportMode::Pipe));
    ready(shell);
    const pid_t pid = shell.get_shell_pid();
    assert(shell.sendLine("exit 7"));
    // Observe termination without reaping before wait() closes the descriptors;
    // otherwise the fixture's final "exit" output may race the retained close.
    eventually([&] {
        siginfo_t info {};
        return ::waitid(P_PID, pid, &info, WEXITED | WNOHANG | WNOWAIT) == 0 && info.si_pid == pid;
    });
    assert(shell.wait() == 7);
    boundedStop(shell);
    reaped(pid);
}
static void testSplitFrames(TerminalTransportMode mode) {
    SuInteractive shell;
    assert(shell.start({}, mode));
    ready(shell);
    std::atomic<bool> received{false};
    shell.setControlFrameHandler([&](const std::string& frame) {
        if (frame == "SKA:test:0:0") received = true;
        return true;
    });
    assert(shell.sendAutomationCommand("printf '\\036SKA:test'; sleep 0.1; printf ':0:0\\037\\nVISIBLE\\n'"));
    eventually([&] { return received.load() && shell.output().find("VISIBLE") != std::string::npos; });
    assert(shell.output().find(std::string(1, '\036')) == std::string::npos);
    boundedStop(shell);
}

static void testPipePrompt(const fs::path& root) {
    SuInteractive shell;
    // Exercise the rc file as well as the empty-directory environment fallback.
    assert(shell.start(root.string(), TerminalTransportMode::Pipe));
    eventually([&] { return shell.isShellIdle(); });
    assert(shell.hasShellIdleState());
    assert(shell.output().find("SKROOT_READY") == std::string::npos);
    assert(shell.sendLine("sleep 0.2; printf 'FIN''ISHED\\n'"));
    assert(!shell.isShellIdle());
    eventually([&] { return shell.output().find("FINISHED") != std::string::npos && shell.isShellIdle(); });
    assert(shell.sendLine("read -r answer; printf 'ANSWER:%s\\n' \"$answer\""));
    std::this_thread::sleep_for(100ms);
    assert(!shell.isShellIdle());
    assert(shell.sendLine("hello"));
    eventually([&] { return shell.output().find("ANSWER:hello") != std::string::npos && shell.isShellIdle(); });
    assert(shell.send("printf 'PARTIAL\\n'"));
    assert(shell.isShellIdle()); // upstream clears readiness only on newline
    assert(shell.sendLine(""));
    eventually([&] { return shell.output().find("PARTIAL") != std::string::npos && shell.isShellIdle(); });
    shell.takeOutput();
    assert(shell.sendLine("if true; then"));
    eventually([&] { return shell.output().find("> ") != std::string::npos; });
    assert(!shell.isShellIdle()); // PS2 is not a completed command / PS1.
    assert(shell.sendLine("printf 'MULTILINE\\n'; fi"));
    eventually([&] { return shell.output().find("MULTILINE") != std::string::npos && shell.isShellIdle(); });
    boundedStop(shell);
    assert(!shell.isShellIdle() && !shell.hasShellIdleState());
}

static void testPipeEnv(const fs::path& root) {
    const auto original = root / "original.rc";
    std::ofstream(original) << "export PLUS_ENV_LOADED=yes\nPS1='overridden> '\n";
    ::setenv("ENV", original.c_str(), 1);
    SuInteractive shell;
    assert(shell.start(root.string(), TerminalTransportMode::Pipe));
    eventually([&] { return shell.isShellIdle(); });
    assert(shell.sendLine("printf 'ENV:%s\\n' \"$PLUS_ENV_LOADED\""));
    eventually([&] { return shell.output().find("ENV:yes") != std::string::npos && shell.isShellIdle(); });
    boundedStop(shell);
    // Bad rc path must discard the external ENV, leaving the marker in PS1.
    assert(shell.start((root / "missing" / "rc").string(), TerminalTransportMode::Pipe));
    eventually([&] { return shell.isShellIdle(); });
    assert(shell.output().find("overridden>") == std::string::npos);
    boundedStop(shell);
    ::unsetenv("ENV");
}

static void testNoninteractivePipeAndSplitPrompt() {
    ::setenv("SKROOT_TEST_NONINTERACTIVE", "1", 1);
    SuInteractive shell;
    assert(shell.start({}, TerminalTransportMode::Pipe));
    assert(shell.sendLine("printf 'NO''PROMPT\\n'"));
    eventually([&] { return shell.output().find("NOPROMPT") != std::string::npos; });
    assert(!shell.isShellIdle() && !shell.hasShellIdleState());
    int automation_frames = 0;
    shell.setControlFrameHandler([&](const std::string&) { ++automation_frames; return false; });
    assert(shell.sendLine("printf '\\036SKROOT_'; sleep 0.1; printf 'READY\\037# '"));
    eventually([&] { return shell.isShellIdle(); });
    assert(shell.hasShellIdleState());
    assert(shell.output().find("SKROOT_READY") == std::string::npos);
    assert(shell.output().find('\036') == std::string::npos);
    boundedStop(shell);
    assert(automation_frames == 0); // prompt never reaches automation callbacks
    ::unsetenv("SKROOT_TEST_NONINTERACTIVE");
}

static void testMalformedPipePrompt() {
    ::setenv("SKROOT_TEST_NONINTERACTIVE", "1", 1);
    SuInteractive shell;
    assert(shell.start({}, TerminalTransportMode::Pipe));
    // Raw send avoids confusing native command echo with actual child output.
    assert(shell.sendText("printf '\\036OTHER'; sleep 0.1; printf '\\036SKROOT_READY\\037# '", true));
    eventually([&] { return shell.isShellIdle() && shell.output().find("OTHER# ") != std::string::npos; });
    assert(shell.output().find("SKROOT_READY") == std::string::npos);
    shell.takeOutput();
    assert(shell.sendText("printf '\\036UNFINISHED-visible'", true));
    eventually([&] { return shell.output().find("UNFINISHED-visible") != std::string::npos; });
    assert(!shell.isShellIdle());
    boundedStop(shell);
    ::unsetenv("SKROOT_TEST_NONINTERACTIVE");
}

static void testPtyEchoAndNaturalExit() {
    std::vector<int> inherited;
    for (int fd = 3; fd < 1024; ++fd) if (::fcntl(fd, F_GETFD) >= 0) inherited.push_back(fd);
    SuInteractive shell;
    assert(shell.start({}, TerminalTransportMode::Pty));
    ready(shell);
    std::vector<int> masters;
    for (int fd = 3; fd < 1024; ++fd) {
        if (::fcntl(fd, F_GETFD) >= 0 &&
            std::find(inherited.begin(), inherited.end(), fd) == inherited.end()) masters.push_back(fd);
    }
    assert(masters.size() == 2u); // master + its reader dup, no retained slave
    const int master = masters.front();
    for (int round = 0; round < 2; ++round) {
        shell.takeOutput();
        assert(shell.sendLine("sh -c 'stty echo; printf \"ECHO\"\"READY\\n\"; read -r value; printf \"GOT\"\"INPUT\\n\"; sleep 0.5'"));
        eventually([&] { return shell.output().find("ECHOREADY") != std::string::npos; });
        termios original {};
        assert(::tcgetattr(master, &original) == 0 && (original.c_lflag & ECHO));
        shell.takeOutput();
        const std::string hidden = "UNIQUE_AUTOMATION_INPUT_" + std::to_string(round);
        assert(shell.sendAutomationCommand(hidden));
        eventually([&] { return shell.output().find("GOTINPUT") != std::string::npos; });
        termios during {};
        assert(::tcgetattr(master, &during) == 0 && !(during.c_lflag & ECHO));
        assert(shell.output().find(hidden) == std::string::npos);
        // Same restore operation is used on completion and cancel/timeout.
        shell.finishAutomationCommand();
        termios restored {};
        assert(::tcgetattr(master, &restored) == 0);
        assert(restored.c_lflag == original.c_lflag);
        eventually([&] { return shell.isShellIdle(); });
    }
    ready(shell);
    const pid_t pid = shell.get_shell_pid();
    assert(shell.sendLine("exit 9"));
    eventually([&] {
        siginfo_t info {};
        return ::waitid(P_PID, pid, &info, WEXITED | WNOHANG | WNOWAIT) == 0 && info.si_pid == pid;
    });
    // The reader must see EIO and close its master without a stop()/wait().
    // With the old extra slave open both masters stayed alive indefinitely.
    eventually([&] {
        size_t open = 0;
        for (int fd : masters) if (::fcntl(fd, F_GETFD) >= 0) ++open;
        return open == 1;
    });
    assert(shell.wait() == 9);
    reaped(pid);
}

int main() {
    ::alarm(60);
    // Fixture uses ordinary host bash, not the system su or Android root SDK.
    ::signal(SIGPIPE, SIG_IGN);
    assert(::prctl(PR_SET_CHILD_SUBREAPER, 1) == 0);
    char pattern[] = "/tmp/skroot-shell-test-XXXXXX";
    const fs::path root = ::mkdtemp(pattern);
    // The production argv remains exactly {"su", nullptr}, matching upstream.
    // Model a su that launches an interactive POSIX shell even without a TTY.
    std::ofstream(root / "su") << "#!/bin/sh\n"
        "if [ -n \"$SKROOT_TEST_NONINTERACTIVE\" ]; then exec /bin/bash --norc; fi\n"
        "exec /bin/bash --posix --norc -i\n";
    fs::permissions(root / "su", fs::perms::owner_all);
    const std::string path = root.string() + ":/usr/bin:/bin";
    ::setenv("PATH", path.c_str(), 1);
    ::unsetenv("ENV");
    ::unsetenv("BASH_ENV");
    for (auto mode : {TerminalTransportMode::Pipe, TerminalTransportMode::Pty}) {
        testBackground(root, mode, false);
        testBackground(root, mode, true);
        testRepeatedStop(mode);
        testDestructor(mode);
        testWatchdogFds(mode);
        testSplitFrames(mode);
    }
    testForeground(root);
    testBlockedWriter(root);
    testInheritedPipeWriter(root);
    testNaturalExit();
    testPipePrompt(root);
    testPipeEnv(root);
    testNoninteractivePipeAndSplitPrompt();
    testMalformedPipePrompt();
    testPtyEchoAndNaturalExit();
    fs::remove_all(root);
    std::cout << "Shell lifecycle and upstream pipe prompt scenarios passed\n";
}
