#include <cassert>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <poll.h>
#include <termios.h>
#include <unistd.h>

int main() {
    ::alarm(10);
    const int master = ::posix_openpt(O_RDWR | O_NOCTTY | O_CLOEXEC);
    assert(master >= 0);
    assert(::grantpt(master) == 0 && ::unlockpt(master) == 0);
    char name[128] {};
    assert(::ptsname_r(master, name, sizeof(name)) == 0);
    const int slave = ::open(name, O_RDWR | O_NOCTTY | O_CLOEXEC);
    assert(slave >= 0);
    termios original {};
    assert(::tcgetattr(slave, &original) == 0);
    original.c_lflag |= ECHO | ICANON;
    original.c_lflag &= ~ECHONL;
    assert(::tcsetattr(slave, TCSANOW, &original) == 0);

    termios hidden {};
    assert(::tcgetattr(master, &hidden) == 0);
    hidden.c_lflag &= ~ECHO;
    assert(::tcsetattr(master, TCSANOW, &hidden) == 0);
    termios observed {};
    assert(::tcgetattr(slave, &observed) == 0 && !(observed.c_lflag & ECHO));
    assert(::write(master, "hidden\n", 7) == 7);
    char buffer[128] {};
    assert(::read(slave, buffer, sizeof(buffer)) == 7);
    assert(std::memcmp(buffer, "hidden\n", 7) == 0);
    pollfd event{master, POLLIN, 0};
    assert(::poll(&event, 1, 100) == 0); // no echoed input on master

    assert(::tcsetattr(master, TCSANOW, &original) == 0);
    assert(::tcgetattr(slave, &observed) == 0 && (observed.c_lflag & ECHO));
    assert(::write(master, "visible\n", 8) == 8);
    assert(::read(slave, buffer, sizeof(buffer)) == 8);
    assert(::poll(&event, 1, 1000) == 1);
    const ssize_t count = ::read(master, buffer, sizeof(buffer));
    assert(count > 0 && std::string(buffer, count).find("visible") != std::string::npos);

    ::close(slave);
    event.revents = 0;
    assert(::poll(&event, 1, 1000) == 1 && (event.revents & POLLHUP));
    errno = 0;
    assert(::read(master, buffer, sizeof(buffer)) == -1 && errno == EIO);
    ::close(master);
    std::cout << "PTY master: suppress/restore echo and last-slave EIO passed\n";
}
