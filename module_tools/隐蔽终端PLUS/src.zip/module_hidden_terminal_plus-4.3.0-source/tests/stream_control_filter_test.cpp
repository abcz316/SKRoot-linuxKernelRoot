#include "../stream_control_filter.h"

#include <cassert>
#include <string>

int main() {
    StreamControlFrameFilter filter;
    auto internal = [](const std::string& frame) { return frame.rfind("SKA:", 0) == 0; };
    assert(filter.consume("command echo\\036SKA:token:0:%d\\037\n", internal)
        == "command echo\\036SKA:token:0:%d\\037\n");
    assert(filter.consume(std::string("before\x1e") + "SKA:tok", internal) == "before");
    assert(filter.consume(":3:", internal).empty());
    assert(filter.consume(std::string("0\x1f") + "after", internal) == "after");
    const std::string unknown = std::string("x\x1e") + "OTHER:value" + "\x1f" + "y";
    assert(filter.consume(unknown, internal) == unknown);
    assert(filter.consume(std::string("tail\x1e") + "partial", internal) == "tail");
    assert(filter.flush() == std::string("\x1e") + "partial");
    return 0;
}
