const test = require('node:test');
const assert = require('node:assert/strict');
const {
  AutomationModel,
  normalizeConfig,
  normalizeStep,
  MAX_FAVORITES,
  MAX_INPUTS,
  MAX_STEPS,
} = require('../webroot/automation-model.js');

test('normalization preserves migration-shaped command and wait steps', () => {
  const config = normalizeConfig({
    revision: 3,
    draft: {
      schemeId: null,
      name: '',
      failurePolicy: 'stop',
      steps: [
        { id: 'legacy_command_0', type: 'command', command: 'echo one' },
        { id: 'legacy_wait_1', type: 'wait', seconds: 1.5 },
      ],
    },
    schemes: [],
  });
  assert.equal(config.revision, 3);
  assert.equal(config.draft.steps[0].command, 'echo one');
  assert.equal(config.draft.steps[1].seconds, 1.5);
});

test('draft supports add, move, duplicate, delete and automatic inputs', () => {
  const model = new AutomationModel();
  const one = model.addStep('command', { command: 'one' });
  model.addStep('wait', { seconds: 2 });
  model.addStep('script', { path: '/data/local/two.sh', args: ['a b'] });
  assert.equal(model.moveStep(2, 0), true);
  assert.equal(model.draft.steps[0].type, 'script');
  const copy = model.duplicateStep(1);
  assert.notEqual(copy.id, one.id);
  assert.equal(copy.command, 'one');
  assert.ok(model.addInput(1));
  assert.equal(model.draft.steps[1].inputs.length, 1);
  assert.equal(model.removeInput(1, 0), true);
  assert.equal(model.removeStep(3), true);
});

test('model enforces per-scheme step and input limits', () => {
  const model = new AutomationModel({
    draft: { steps: Array.from({ length: MAX_STEPS }, (_, index) => ({ id: `s_${index}`, type: 'wait', seconds: 1 })) },
  });
  assert.throws(() => model.addStep('wait', { seconds: 1 }), /100/);

  const inputs = Array.from({ length: MAX_INPUTS }, (_, index) => ({ id: `i_${index}`, text: '', afterSec: index }));
  const inputModel = new AutomationModel({ draft: { steps: [{ id: 'command', type: 'command', command: 'x', inputs }] } });
  assert.throws(() => inputModel.addInput(0), /32/);
});

test('schemes save, overwrite, copy, rename and delete without aliasing draft steps', () => {
  const model = new AutomationModel();
  model.addStep('command', { command: 'echo original' });
  const saved = model.saveDraft('方案一');
  model.draft.steps[0].command = 'echo changed';
  assert.equal(saved.steps[0].command, 'echo original');
  model.saveDraft('方案一');
  assert.equal(saved.steps[0].command, 'echo changed');
  const copy = model.saveDraft('方案二', true);
  assert.notEqual(copy.id, saved.id);
  assert.equal(model.renameScheme(copy.id, '方案副本'), true);
  assert.equal(model.deleteScheme(saved.id), true);
  assert.equal(model.schemes.length, 1);
});

test('favorite schemes are capped at six', () => {
  const model = new AutomationModel({
    schemes: Array.from({ length: MAX_FAVORITES + 1 }, (_, index) => ({
      id: `scheme_${index}`,
      name: `方案 ${index}`,
      favorite: index < MAX_FAVORITES,
      steps: [{ id: `step_${index}`, type: 'command', command: 'true' }],
    })),
  });
  assert.equal(model.favorites().length, MAX_FAVORITES);
  assert.throws(() => model.toggleFavorite(`scheme_${MAX_FAVORITES}`), /6/);
  model.toggleFavorite('scheme_0');
  assert.equal(model.toggleFavorite(`scheme_${MAX_FAVORITES}`), true);
});

test('file-manager appends scripts instead of replacing the current draft', () => {
  const model = new AutomationModel({
    draft: { steps: [{ id: 'existing', type: 'command', command: 'echo keep' }] },
  });
  model.appendScript('/sdcard/one.sh', ['--first']);
  model.appendScript('/sdcard/two.sh', ['value with spaces']);
  assert.deepEqual(model.draft.steps.map(step => step.type), ['command', 'script', 'script']);
  assert.equal(model.draft.steps[0].command, 'echo keep');
  assert.deepEqual(model.draft.steps[2].args, ['value with spaces']);
});

test('normalization clamps oversized incoming collections defensively', () => {
  const step = normalizeStep({
    type: 'command',
    command: 'true',
    inputs: Array.from({ length: MAX_INPUTS + 5 }, () => ({})),
  });
  assert.equal(step.inputs.length, MAX_INPUTS);
});
