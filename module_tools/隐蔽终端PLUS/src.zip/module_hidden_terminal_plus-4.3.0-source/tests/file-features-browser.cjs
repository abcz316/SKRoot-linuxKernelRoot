const assert = require('node:assert/strict');
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
let playwright;
try { playwright = require('playwright'); }
catch (_) {
  playwright = require(path.join(process.env.USERPROFILE || os.homedir(),
    '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
}

const webroot = path.resolve(__dirname, '../webroot');
const outputDir = process.env.SKROOT_FEATURE_SCREENSHOT_DIR || path.join(os.tmpdir(), 'skroot-file-features-qa');
const jobs = [];
const requests = [];
const sessions = new Map();
const saves = new Map();
const readers = new Map();
let counter = 0;
let imagePayload = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jZ1kAAAAASUVORK5CYII=', 'base64');
let imageWidth = 1, imageHeight = 1;
let textPayload;
const initialText = JSON.stringify({
  name: '隐蔽终端PLUS', enabled: true, version: '4.2.16',
  description: '文件编辑、图片预览和压缩包浏览。'.repeat(12),
  tasks: [{ name: 'backup', timeout: 30 }, { name: 'verify', timeout: 60 }],
  paths: ['/sdcard/Download', '/data/local/tmp'],
}, null, 2) + '\n';
const version = () => ({ device: '1', inode: '2', size: String(textPayload.length), mtimeSec: '1780000000', mtimeNsec: '0' });
const file = (name, type = 'file') => ({ name, type, isDir: type === 'directory',
  size: type === 'directory' ? 0 : 4096, date: '2026-10-11', time: '09:30', mtimeMs: 1791672600000,
  mode: type === 'directory' ? 16877 : 33188, uid: 0, gid: 0, hideProtected: false });
const directoryEntries = requestPath => requestPath === '/destination'
  ? [file('target.zip'), file('output', 'directory')]
  : [file('workspace', 'directory'), file('config.json'), file('photo.png'), file('bundle.zip'), file('plain.txt')];
const entry = (id, entryPath, type = 'file', extra = {}) => ({ id, path: entryPath,
  name: entryPath.split('/').pop(), type, size: type === 'directory' ? 0 : 1024,
  mtimeMs: 1791672600000, duplicateIndex: 1, isImplicit: false, selectable: true, ...extra });
const archiveEntries = inner => inner === '' ? [entry('d:docs', 'docs', 'directory'),
  entry('e:1', 'same.txt'), entry('e:2', 'same.txt', 'file', { duplicateIndex: 2 }),
  ...Array.from({ length: 501 }, (_, i) => entry(`e:${i + 100}`, `item-${String(i).padStart(3, '0')}.txt`))]
  : inner === 'docs' ? [entry('d:docs/deeper', 'docs/deeper', 'directory', { isImplicit: true }),
    entry('e:3', 'docs/config.json'), entry('e:4', 'docs/config.json', 'file', { duplicateIndex: 2 }),
    entry('e:5', 'docs/pipe', 'fifo', { selectable: false })]
    : [entry('e:6', 'docs/deeper/readme.txt')];

function json(res, data, status = 200, ok = true, code = 'OK', message = '') {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ ok, code, message, errno: 0, requestId: 'browser-fixture', data }));
}
function plain(res, data = '') {
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end(data);
}
function idleJob() { return { id: '', state: 'idle', operation: '', errors: [], warnings: [] }; }
const server = http.createServer((req, res) => {
  if (req.method === 'POST') {
    let body = '';
    req.setEncoding('utf8');
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      let data = {};
      try { data = body ? JSON.parse(body) : {}; } catch (_) {}
      requests.push({ route: req.url, data });
      if (req.url === '/api/session') return json(res, { token: 'mock-session' });
      if (req.headers['x-skroot-session'] !== 'mock-session') return json(res, null, 401, false, 'INVALID_SESSION');
      switch (req.url) {
        case '/api/files/settings/get': return json(res, { leftHome: '/sdcard', rightHome: '/destination' });
        case '/api/files/places/get': return json(res, { bookmarks: [], recent: [] });
        case '/api/files/places/set': return json(res, data);
        case '/api/files/list': return json(res, { path: data.path, items: directoryEntries(data.path) });
        case '/api/files/text/open': {
          const id = `text-${++counter}`; readers.set(id, Buffer.from(textPayload));
          return json(res, { sessionId: id, path: data.path, size: textPayload.length, hasBom: false, version: version() });
        }
        case '/api/files/text/read': {
          const value = readers.get(data.sessionId), offset = data.offset || 0;
          const bytes = value.subarray(offset, offset + (data.limit || 131072));
          return json(res, { base64: bytes.toString('base64'), offset, nextOffset: offset + bytes.length, eof: offset + bytes.length === value.length });
        }
        case '/api/files/text/save/start': {
          const id = `save-${++counter}`; saves.set(id, []);
          return json(res, { saveId: id, chunkSize: 131072 });
        }
        case '/api/files/text/save/chunk': saves.get(data.saveId).push(Buffer.from(data.base64, 'base64')); return json(res, {});
        case '/api/files/text/save/commit': textPayload = Buffer.concat(saves.get(data.saveId)); saves.delete(data.saveId); return json(res, { version: version() });
        case '/api/files/text/save/abort': saves.delete(data.saveId); return json(res, {});
        case '/api/files/image/open': return json(res, { sessionId: `image-${++counter}`, path: data.path, size: imagePayload.length, mime: 'image/png', width: imageWidth, height: imageHeight, version: version() });
        case '/api/files/image/read': {
          const offset = data.offset || 0, bytes = imagePayload.subarray(offset, offset + (data.limit || 131072));
          return json(res, { base64: bytes.toString('base64'), offset, nextOffset: offset + bytes.length, eof: offset + bytes.length === imagePayload.length });
        }
        case '/api/files/image/close': return json(res, {});
        case '/api/files/archive/open': {
          const id = `archive-${++counter}`;
          const value = { sessionId: id, path: data.path, state: 'ready', scannedEntries: 508, totalEntries: 508, totalNodes: 509, version: version(), error: {} };
          sessions.set(id, value); return json(res, value, 202);
        }
        case '/api/files/archive/status': return sessions.has(data.sessionId) ? json(res, sessions.get(data.sessionId)) : json(res, null, 404, false, 'ARCHIVE_SESSION_NOT_FOUND');
        case '/api/files/archive/list': {
          if (!sessions.has(data.sessionId)) return json(res, null, 404, false, 'ARCHIVE_SESSION_NOT_FOUND');
          const entries = archiveEntries(data.innerPath || ''), offset = data.offset || 0;
          const items = entries.slice(offset, offset + (data.limit || 500));
          return json(res, { sessionId: data.sessionId, innerPath: data.innerPath || '', offset,
            nextOffset: offset + items.length, total: entries.length, eof: offset + items.length === entries.length, items });
        }
        case '/api/files/archive/close': sessions.delete(data.sessionId); return json(res, {});
        case '/api/files/job/start': {
          jobs.push(data);
          return json(res, { id: `job-${jobs.length}`, state: 'scanning', operation: data.op,
            totalBytes: 1024, processedBytes: 0, totalItems: 1, processedItems: 0,
            successCount: 0, skippedCount: 0, failedCount: 0, errors: [], warnings: [] }, 202);
        }
        case '/api/files/job/status': return json(res, !data.id ? idleJob() : {
          id: data.id, state: 'completed', operation: 'extract', totalBytes: 1024, processedBytes: 1024,
          totalItems: 1, processedItems: 1, successCount: 1, skippedCount: 0, failedCount: 0, errors: [], warnings: [] });
        case '/api/automation/config/get': return json(res, { revision: 1, draft: { schemeId: null, name: '', failurePolicy: 'stop', steps: [] }, schemes: [] });
        case '/api/automation/run/status': return json(res, { id: '', state: 'idle', steps: [], currentStep: 0, totalSteps: 0, successCount: 0, failureCount: 0 });
        case '/getTerminalTransportMode': res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ saved: 'pty', effective: 'pty' })); return;
        case '/getQuickActions': case '/getAutoTasks': return plain(res, '[]');
        case '/getTerminalKeepMode': return plain(res, '0');
        case '/getHideDir': return plain(res, '/data/skroot/work');
        default: return req.url.startsWith('/api/') ? json(res, {}) : plain(res, '');
      }
    });
    return;
  }
  const requested = req.url === '/' ? '/index.html' : decodeURIComponent(req.url.split('?')[0]);
  const filename = path.resolve(webroot, '.' + requested);
  if (!filename.startsWith(webroot + path.sep) || !fs.existsSync(filename) || fs.statSync(filename).isDirectory()) {
    res.writeHead(404); res.end(); return;
  }
  res.writeHead(200, { 'Content-Type': ({ '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' })[path.extname(filename)] || 'application/octet-stream' });
  fs.createReadStream(filename).pipe(res);
});

function launchOptions() {
  const options = { headless: true };
  if (fs.existsSync(playwright.chromium.executablePath())) return options;
  const cache = process.platform === 'win32' ? path.join(process.env.LOCALAPPDATA, 'ms-playwright') : path.join(os.homedir(), '.cache/ms-playwright');
  const suffix = process.platform === 'win32' ? 'chrome-headless-shell-win64/chrome-headless-shell.exe' : 'chrome-headless-shell-linux64/chrome-headless-shell';
  if (fs.existsSync(cache)) options.executablePath = fs.readdirSync(cache).filter(name => name.startsWith('chromium_headless_shell-'))
    .sort((a, b) => Number(b.split('-').pop()) - Number(a.split('-').pop()))
    .map(name => path.join(cache, name, suffix)).find(candidate => fs.existsSync(candidate));
  return options;
}
const row = (page, pane, key) => page.locator(`[data-list="${pane}"] .fm-row[data-path="${key}"]`);
const named = (page, pane, name) => page.locator(`[data-list="${pane}"] .fm-row[data-name="${name}"]`);
const parent = (page, pane) => page.locator(`[data-list="${pane}"] .fm-row.parent`);
async function clickMenu(page, id) { await page.locator('#fileMenuBtn').click(); await page.locator(`#${id}`).click(); }
async function waitArchive(page, pane, inner = '') {
  await page.waitForFunction(({ pane, inner }) => {
    const view = window.SKFileManager.model.panes[pane];
    return view.archive?.innerPath === inner && !view.loading && view.entries.length > 0;
  }, { pane, inner });
}
async function swipeSelect(page, locator) {
  await locator.scrollIntoViewIfNeeded();
  const box = await locator.boundingBox();
  await page.mouse.move(box.x + 18, box.y + box.height / 2);
  await page.mouse.down();
  await page.mouse.move(box.x + 78, box.y + box.height / 2, { steps: 5 });
  await page.mouse.up();
  await page.waitForTimeout(650); // The UI deliberately suppresses clicks after a selection swipe.
}
async function noOverflow(page, selector, label) {
  const bounds = await page.locator(selector).evaluate(element => {
    const rect = element.getBoundingClientRect();
    return { left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom, width: innerWidth, height: innerHeight };
  });
  assert.ok(bounds.left >= -1 && bounds.right <= bounds.width + 1 && bounds.top >= -1 && bounds.bottom <= bounds.height + 1,
    `${label} leaves viewport: ${JSON.stringify(bounds)}`);
}

async function runViewport(browser, baseUrl, viewport) {
  textPayload = Buffer.from(initialText);
  jobs.length = 0;
  const page = await browser.newPage({ viewport: { width: viewport.width, height: viewport.height },
    isMobile: viewport.mobile, hasTouch: viewport.mobile });
  const errors = [], dialogs = [], failedAssets = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('dialog', async dialog => { dialogs.push(dialog.message()); await dialog.accept(); });
  page.on('response', response => { if (response.status() >= 400) failedAssets.push(`${response.status()} ${response.url()}`); });
  try {
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.locator('#fileBtn').click();
    await named(page, 'left', 'config.json').waitFor();
    await named(page, 'left', 'config.json').click();
    await page.locator('#actEdit').click();
    await page.locator('#textEditor .cm-content').waitFor();
    await page.waitForFunction(() => document.querySelectorAll('#textEditor .cm-line span').length > 3);
    assert.ok(await page.locator('#textEditor .cm-lineNumbers .cm-gutterElement').count() > 3);
    assert.match(await page.locator('#textEditorPosition').textContent(), /共 \d+ 行/);
    await page.locator('#textEditorFontPlus').click();
    assert.equal(await page.locator('#textEditorFontReset').textContent(), '15px');
    await page.locator('#textEditorWrap').click();
    assert.equal(await page.locator('#textEditorWrap').getAttribute('aria-pressed'), 'false');
    await page.locator('#textEditorWrap').click();
    assert.equal(await page.locator('#textEditorSave').isDisabled(), true, 'display preferences must not alter source text');
    await noOverflow(page, '#textEditor', `${viewport.name} editor`);
    await noOverflow(page, '.sk-editor-toolbar', `${viewport.name} editor toolbar`);
    await page.screenshot({ path: path.join(outputDir, `${viewport.name}-editor.png`) });
    await page.locator('#textEditor .cm-content').click();
    await page.keyboard.press('Control+End');
    await page.keyboard.insertText(' ');
    await page.locator('#textEditorSave').click();
    await page.waitForFunction(() => document.querySelector('#textEditorSave').disabled && document.querySelector('#textEditorBusy').hidden);
    assert.equal(textPayload.toString(), initialText + ' ');
    await page.locator('#textEditorClose').click();

    const dataUrl = await page.evaluate(() => {
      const canvas = document.createElement('canvas'); canvas.width = 960; canvas.height = 600;
      const context = canvas.getContext('2d'), gradient = context.createLinearGradient(0, 0, 960, 600);
      gradient.addColorStop(0, '#0e7490'); gradient.addColorStop(1, '#7c3aed');
      context.fillStyle = gradient; context.fillRect(0, 0, 960, 600);
      context.fillStyle = '#fff'; context.font = '56px sans-serif'; context.fillText('Image preview', 80, 275);
      context.font = '32px sans-serif'; context.fillText('960 × 600 · PNG', 80, 335);
      return canvas.toDataURL('image/png');
    });
    imagePayload = Buffer.from(dataUrl.split(',')[1], 'base64'); imageWidth = 960; imageHeight = 600;
    await named(page, 'left', 'photo.png').click();
    await page.locator('#actImage').click();
    await page.locator('.image-viewer-image:not([hidden])').waitFor();
    assert.match(await page.locator('.image-viewer-meta').textContent(), /^960 × 600/);
    await noOverflow(page, '.image-viewer', `${viewport.name} image`);
    await page.screenshot({ path: path.join(outputDir, `${viewport.name}-image.png`) });
    await page.locator('[data-image-action="actual"]').click();
    assert.equal(await page.locator('.image-viewer-scale').textContent(), '100%');
    await page.locator('.image-viewer-close').click();

    await named(page, 'left', 'bundle.zip').click();
    await waitArchive(page, 'left');
    assert.equal(await page.evaluate(() => SKFileManager.model.panes.left.path), '/sdcard');
    assert.equal(await page.locator('#activePathText').textContent(), '/sdcard/bundle.zip!/');
    assert.equal(await named(page, 'left', 'same.txt').count(), 2);
    await row(page, 'left', 'd:docs').click();
    await waitArchive(page, 'left', 'docs');
    assert.equal(await named(page, 'left', 'config.json').count(), 2);
    await noOverflow(page, '#fileWorkspace', `${viewport.name} archive`);
    await page.screenshot({ path: path.join(outputDir, `${viewport.name}-archive.png`) });
    await row(page, 'left', 'e:4').click();
    assert.equal(await page.locator('#actEdit').isVisible(), false);
    assert.equal(await page.locator('#actImage').isVisible(), false);
    assert.equal(await page.locator('#actDelete').isVisible(), false);
    await page.locator('#actExtract').click();
    assert.ok((await page.locator('#operationConfirmTarget').textContent()).includes('/destination/config.json'));
    await page.locator('#operationConfirmOk').click();
    await page.waitForFunction(() => document.querySelector('#fileJobTitle').textContent.includes('任务完成'));
    assert.equal(jobs.length, 1);
    assert.deepEqual(jobs[0].sources, ['/sdcard/bundle.zip']);
    assert.equal(jobs[0].destination, '/destination');
    assert.equal(jobs[0].archiveSelection.basePath, 'docs');
    assert.deepEqual(jobs[0].archiveSelection.entryIds, ['e:4']);

    await named(page, 'right', 'target.zip').click();
    await waitArchive(page, 'right');
    await row(page, 'left', 'e:3').click();
    assert.equal(await page.locator('#actExtract').isDisabled(), true, 'archive view must not be an extraction destination');
    await page.locator('#actionCancel').click();
    await parent(page, 'right').click();
    await named(page, 'right', 'target.zip').waitFor();
    assert.equal(await page.evaluate(() => SKFileManager.model.panes.right.archive), null);
    await page.locator('#filePaneLeft .fm-pane-strip').click();
    await page.locator('#fileMenuBtn').click();
    for (const id of ['fileNewFolder', 'fileNewFile', 'fileSetHome', 'fileAddBookmark', 'fileSyncPanes'])
      assert.equal(await page.locator(`#${id}`).isDisabled(), true, `${id} must be disabled inside an archive`);
    await page.locator('#fileSwapPanes').click();
    await waitArchive(page, 'right', 'docs');
    assert.equal(await page.evaluate(() => SKFileManager.model.panes.right.path), '/sdcard');
    assert.equal(await page.evaluate(() => SKFileManager.model.panes.right.home), '/destination');
    await parent(page, 'right').click();
    await waitArchive(page, 'right');
    await parent(page, 'right').click();
    await named(page, 'right', 'bundle.zip').waitFor();
    assert.equal(await page.evaluate(() => SKFileManager.model.panes.right.archive), null);
    assert.equal(await page.evaluate(() => SKFileManager.model.panes.right.path), '/sdcard');

    // Pagination must preserve selections by header identity, including duplicates.
    if (viewport.name === 'phone-360') {
      await named(page, 'right', 'bundle.zip').click();
      await waitArchive(page, 'right');
      await swipeSelect(page, row(page, 'right', 'e:2'));
      assert.deepEqual(await page.evaluate(() => [...SKFileManager.model.selectedPaths]), ['e:2']);
      await page.locator('[data-list="right"] [data-page="500"]').click();
      await page.waitForFunction(() => SKFileManager.model.panes.right.archive.offset === 500 && !SKFileManager.model.panes.right.loading);
      await row(page, 'right', 'e:600').click();
      assert.deepEqual(await page.evaluate(() => [...SKFileManager.model.selectedPaths]), ['e:2', 'e:600']);
      await page.locator('#selectionActions').click();
      await page.locator('#actExtract').click();
      await page.locator('#operationConfirmOk').click();
      await page.waitForFunction(() => document.querySelector('#fileJobTitle').textContent.includes('任务完成'));
      assert.equal(jobs.length, 2);
      assert.deepEqual(jobs[1].archiveSelection.entryIds, ['e:2', 'e:600']);
      assert.equal(jobs[1].archiveSelection.basePath, '');
      assert.equal(jobs[1].destination, '/destination');
      await page.locator('#activePathTrigger').click();
      await page.locator('#pathInput').fill('/sdcard/workspace');
      await page.locator('#pathGo').click();
      await page.waitForFunction(() => SKFileManager.model.panes.right.path === '/sdcard/workspace' && !SKFileManager.model.panes.right.loading);
      assert.equal(await page.evaluate(() => SKFileManager.model.panes.right.archive), null);
    }
    assert.deepEqual(errors, [], `${viewport.name} page errors`);
    assert.deepEqual(dialogs, [], `${viewport.name} unexpected dialogs`);
    assert.deepEqual(failedAssets, [], `${viewport.name} failed requests`);
    console.log(`PASS integrated file features ${viewport.name}`);
  } catch (error) {
    await page.screenshot({ path: path.join(outputDir, `${viewport.name}-failure.png`), fullPage: true });
    console.error({ pageErrors: errors, dialogs, failedAssets });
    throw error;
  } finally { await page.close(); }
}

(async () => {
  fs.mkdirSync(outputDir, { recursive: true });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await playwright.chromium.launch(launchOptions());
  try {
    const baseUrl = `http://127.0.0.1:${server.address().port}/`;
    for (const viewport of [
      { name: 'phone-360', width: 360, height: 720, mobile: true },
      { name: 'landscape-844', width: 844, height: 390, mobile: true },
      { name: 'desktop-1280', width: 1280, height: 800, mobile: false },
    ]) await runViewport(browser, baseUrl, viewport);
    console.log(`Integrated screenshots: ${outputDir}`);
  } finally {
    await browser.close(); server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
