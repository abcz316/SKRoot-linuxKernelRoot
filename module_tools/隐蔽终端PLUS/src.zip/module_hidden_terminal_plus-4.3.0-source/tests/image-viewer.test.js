const test = require("node:test");
const assert = require("node:assert/strict");
const { isImageName, fitScale, clampPosition, validateOpened, decodeChunk } = require("../webroot/image-viewer.js");

test("image candidate extensions are distinct from active documents", () => {
  for (const name of ["photo.PNG", "a.jpg", "a.jpeg", "a.gif", "a.webp", "a.bmp"]) assert.ok(isImageName(name));
  for (const name of ["a.svg", "a.html", "a.png.exe", "a.tiff", "a.heic", "png"]) assert.ok(!isImageName(name));
});

test("fit and pan bounds preserve access to the whole bitmap", () => {
  assert.equal(fitScale(1200, 800, 360, 640), 0.3);
  assert.equal(fitScale(20, 30, 360, 640), 1);
  assert.equal(fitScale(0, 30, 360, 640), 1);
  assert.deepEqual(clampPosition(999, -999, 1, 1200, 800, 360, 640), { x: 420, y: -80 });
  const fitted = clampPosition(50, -20, 0.3, 1200, 800, 360, 640);
  assert.equal(Math.abs(fitted.x), 0);
  assert.equal(Math.abs(fitted.y), 0);
});

test("metadata rejects oversized and unsupported decodes before Blob creation", () => {
  const valid = { sessionId: "session", size: 32 * 1024 * 1024, width: 8000, height: 4000, mime: "image/png" };
  assert.ok(validateOpened(valid));
  assert.ok(!validateOpened({ ...valid, size: valid.size + 1 }));
  assert.ok(!validateOpened({ ...valid, width: 8001 }));
  assert.ok(!validateOpened({ ...valid, width: 32769, height: 1 }));
  assert.ok(!validateOpened({ ...valid, mime: "image/svg+xml" }));
  assert.ok(!validateOpened({ ...valid, size: -1 }));
});

test("image chunk validation rejects stalled, overflowing and inconsistent transfers", () => {
  const chunk = { offset: 0, nextOffset: 3, base64: "AAEC", eof: true };
  assert.deepEqual(Array.from(decodeChunk(chunk, 0, 3)), [0, 1, 2]);
  assert.throws(() => decodeChunk({ ...chunk, offset: 1 }, 0, 3));
  assert.throws(() => decodeChunk({ ...chunk, nextOffset: 2 }, 0, 3));
  assert.throws(() => decodeChunk({ ...chunk, eof: false }, 0, 3));
  assert.throws(() => decodeChunk({ ...chunk, base64: "", nextOffset: 0 }, 0, 3));
  assert.throws(() => decodeChunk(chunk, 0, 2));
});
