const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const native = fs.readFileSync(path.join(root, "module_hide_sh_exec.cpp"), "utf8");
const html = fs.readFileSync(path.join(root, "webroot/index.html"), "utf8");
const main = fs.readFileSync(path.join(root, "webroot/main.js"), "utf8");
const request = fs.readFileSync(path.join(root, "webroot/request.js"), "utf8");

test("transport mode defaults to PTY and is selected at Shell startup", () => {
  assert.match(native, /value\.empty\(\) \? "pty" : value/);
  assert.match(native, /m_su_interactive\.start\(module_private_dir, m_transport_mode\)/);
  assert.match(native, /SKROOT_MODULE_VERSION\("4\.3\.0"\)/);
  assert.doesNotMatch(native, /terminateProcess(Group|Tree)/);
  assert.doesNotMatch(native, /descendantsOf\(m_pid\)\.empty/);
});

test("WebUI exposes PTY and anonymous pipe settings with deferred activation", () => {
  assert.match(html, /id="terminalTransportSelect"/);
  assert.match(html, /option value="pty"/);
  assert.match(html, /option value="pipe"/);
  assert.match(html, /会创建 \/dev\/pts/);
  assert.match(html, /匿名管道/);
  assert.match(main, /下次启动/);
  assert.match(main, /当前生效：\$\{effective\}/);
  assert.match(main, /保留 PTY/);
});

test("request layer accepts only pty or pipe values", () => {
  assert.match(request, /getTerminalTransportMode/);
  assert.match(request, /saveTerminalTransportMode/);
  assert.match(request, /mode !== 'pty' && mode !== 'pipe'/);
});
