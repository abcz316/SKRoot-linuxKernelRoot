#include "../automation_service.h"
#include "module_base_disk_storage.h"

#include <cassert>
#include <atomic>
#include <chrono>
#include <fstream>
#include <iterator>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace kernel_module {
namespace {
std::map<std::string, std::string> automation_storage;
}

KModErr write_string_disk_storage(const char* key, const char* value) {
    automation_storage[key ? key : ""] = value ? value : "";
    return KModErr::OK;
}

KModErr read_string_disk_storage(const char* key, std::string& out) {
    const auto found = automation_storage.find(key ? key : "");
    if (found == automation_storage.end()) {
        out.clear();
        return KModErr::ERR_MODULE_STORAGE_NOT_FOUND;
    }
    out = found->second;
    return KModErr::OK;
}
} // namespace kernel_module

namespace {

class FakeTerminal final : public automation::TerminalTransport {
public:
    ~FakeTerminal() override {
        for (auto& thread : threads) if (thread.joinable()) thread.join();
    }

    bool sendText(const std::string& text, bool append_enter) override {
        std::lock_guard<std::mutex> lock(mu);
        sent.push_back(text + (append_enter ? "<ENTER>" : ""));
        if (text == "answer") {
            saw_answer = true;
            scheduleFrame(pending_frame + "0", 5);
        }
        return true;
    }

    bool sendAutomationCommand(const std::string& command) override {
        std::lock_guard<std::mutex> lock(mu);
        sent.push_back(command + "<ENTER>");
        const size_t marker = command.find("SKA:");
        assert(marker != std::string::npos);
        const size_t token_end = command.find(':', marker + 4);
        const size_t step_end = token_end == std::string::npos ? std::string::npos : command.find(':', token_end + 1);
        assert(token_end != std::string::npos && step_end != std::string::npos);
        pending_frame = command.substr(marker, step_end - marker + 1);
        if (command.find("shell-dies") != std::string::npos) {
            threads.emplace_back([this] {
                std::this_thread::sleep_for(std::chrono::milliseconds(30));
                alive.store(false);
            });
            return true;
        }
        if (command.find("interactive") != std::string::npos || command.find("slow") != std::string::npos) return true;
        const int exit_code = command.find("fail-seven") != std::string::npos ? 7 : 0;
        scheduleFrame(pending_frame + std::to_string(exit_code), 15);
        return true;
    }

    void finishAutomationCommand() override { finish_count.fetch_add(1); }

    bool isShellIdle() const override { return foreground.load(); }
    bool hasShellIdleState() const override { return known.load(); }
    bool isAlive() const override { return alive.load(); }

    void setControlFrameHandler(ControlFrameHandler value) override {
        std::lock_guard<std::mutex> lock(mu);
        handler = std::move(value);
    }

    bool sawAnswer() const {
        std::lock_guard<std::mutex> lock(mu);
        return saw_answer;
    }

    size_t sentCount() const {
        std::lock_guard<std::mutex> lock(mu);
        return sent.size();
    }

    size_t finishCount() const { return finish_count.load(); }

    std::atomic<bool> known{true};
    std::atomic<bool> foreground{true};
    std::atomic<bool> alive{true};
    std::atomic<size_t> finish_count{0};

private:
    void scheduleFrame(std::string frame, int delay_ms) {
        threads.emplace_back([this, frame = std::move(frame), delay_ms] {
            std::this_thread::sleep_for(std::chrono::milliseconds(delay_ms));
            ControlFrameHandler callback;
            {
                std::lock_guard<std::mutex> lock(mu);
                callback = handler;
            }
            if (callback) callback(frame);
        });
    }

    mutable std::mutex mu;
    ControlFrameHandler handler;
    std::string pending_frame;
    std::vector<std::string> sent;
    std::vector<std::thread> threads;
    bool saw_answer = false;
};

automation::Step commandStep(const std::string& id, const std::string& command) {
    automation::Step step;
    step.id = id;
    step.type = "command";
    step.command = command;
    return step;
}

automation::RunSnapshot waitForRun(automation::AutomationManager& manager, int timeout_ms = 4000) {
    for (int elapsed = 0; elapsed < timeout_ms; elapsed += 10) {
        const auto value = manager.snapshot();
        if (value.state == "completed" || value.state == "failed") return value;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    assert(false && "automation timeout");
    return {};
}

void testForceRunIgnoresShellState() {
    FakeTerminal terminal;
    terminal.known = false;
    terminal.foreground = false;
    automation::AutomationManager manager;
    manager.configure(&terminal, "/tmp");
    automation::Scheme scheme;
    scheme.failure_policy = "stop";
    scheme.steps = {commandStep("one", "echo one")};
    automation::RunSnapshot run;
    automation::Error error;
    // A configured sequence is intentionally sent even when the transport
    // cannot report foreground state or reports a busy shell. This is the
    // force-run profile used by anonymous pipes and PTY alike.
    assert(manager.start(scheme, run, error));
    const auto completed = waitForRun(manager);
    assert(completed.state == "completed");
    assert(terminal.sentCount() == 1);
    manager.shutdown();
}

void testConfigMigrationAndConflict() {
    kernel_module::automation_storage.clear();
    kernel_module::automation_storage["auto_tasks"] =
        R"([{"cmd":"echo one","delay":"0.25"},{"cmd":"echo two","delay":"1.5"}])";
    automation::ConfigStore store;
    automation::Config config;
    automation::Error error;
    assert(store.load(config, error));
    assert(config.revision == 1);
    assert(config.draft.steps.size() == 4);
    assert(config.draft.steps[0].type == "wait");
    assert(config.draft.steps[0].wait_ms == 250);
    assert(config.draft.steps[1].type == "command");
    assert(config.draft.steps[2].type == "wait");
    assert(config.draft.steps[2].wait_ms == 1500);

    automation::Config saved;
    config.draft.name = "draft";
    assert(store.save(1, config, saved, error));
    assert(saved.revision == 2);
    automation::Config stale;
    assert(!store.save(1, config, stale, error));
    assert(error.code == "CONFIG_CHANGED");

    kernel_module::automation_storage.clear();
    automation::Config editable;
    assert(store.load(editable, error));
    automation::Step unfinished;
    unfinished.id = "draft_script";
    unfinished.type = "script";
    editable.draft.steps.push_back(unfinished);
    assert(store.save(editable.revision, editable, saved, error));
}

void testContinueAndStopPolicies() {
    FakeTerminal terminal;
    automation::AutomationManager manager;
    manager.configure(&terminal, "/tmp");

    automation::Scheme scheme;
    scheme.id = "continue";
    scheme.name = "continue";
    scheme.failure_policy = "continue";
    scheme.steps = {commandStep("one", "echo one"), commandStep("bad", "fail-seven"), commandStep("two", "echo two")};
    automation::RunSnapshot started;
    automation::Error error;
    assert(manager.start(scheme, started, error));
    auto completed = waitForRun(manager);
    assert(completed.state == "failed");
    assert(completed.success_count == 2);
    assert(completed.failure_count == 1);
    assert(completed.steps[1].exit_code == 7);

    scheme.id = "stop";
    scheme.failure_policy = "stop";
    assert(manager.start(scheme, started, error));
    completed = waitForRun(manager);
    assert(completed.state == "failed");
    assert(completed.steps[2].state == "skipped");
    manager.shutdown();
}

void testAutomaticInputAndShutdown() {
    FakeTerminal terminal;
    automation::AutomationManager manager;
    manager.configure(&terminal, "/tmp");
    automation::Scheme scheme;
    scheme.id = "interactive";
    scheme.name = "interactive";
    scheme.failure_policy = "stop";
    auto step = commandStep("ask", "interactive");
    automation::InputAction input;
    input.id = "input_one";
    input.after_ms = 20;
    input.text = "answer";
    input.append_enter = true;
    step.inputs.push_back(input);
    scheme.steps.push_back(step);
    automation::RunSnapshot started;
    automation::Error error;
    assert(manager.start(scheme, started, error));
    auto completed = waitForRun(manager);
    assert(completed.state == "completed");
    assert(completed.steps[0].sent_inputs == 1);
    assert(terminal.sawAnswer());

    scheme.id = "early-exit";
    auto early = commandStep("early", "echo complete");
    input.after_ms = 1000;
    early.inputs = {input};
    scheme.steps = {early};
    assert(manager.start(scheme, started, error));
    completed = waitForRun(manager);
    assert(completed.state == "completed");
    assert(completed.steps[0].sent_inputs == 0);
    assert(completed.steps[0].skipped_inputs == 1);

    scheme.id = "shutdown";
    scheme.steps = {commandStep("slow", "slow")};
    assert(manager.start(scheme, started, error));
    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    automation::RunSnapshot disabled;
    assert(!manager.cancel(started.id, disabled, error));
    assert(error.code == "AUTOMATION_CANCEL_DISABLED");
    manager.shutdown();
}

void testShutdownShellDeathAndPreflight() {
    FakeTerminal terminal;
    automation::AutomationManager manager;
    manager.configure(&terminal, "/tmp");
    automation::Scheme scheme;
    scheme.id = "shell-death";
    scheme.name = "shell-death";
    scheme.failure_policy = "stop";
    scheme.steps = {commandStep("dead", "shell-dies")};
    automation::RunSnapshot started;
    automation::Error error;
    assert(manager.start(scheme, started, error));
    auto completed = waitForRun(manager);
    assert(completed.state == "failed");
    assert(completed.errors[0].code == "SHELL_UNAVAILABLE");

    terminal.alive.store(true);
    automation::Step missing;
    missing.id = "missing";
    missing.type = "script";
    missing.path = "/definitely/missing/script.sh";
    scheme.id = "preflight";
    scheme.steps = {commandStep("before", "echo should-not-run"), missing};
    const size_t before = terminal.sentCount();
    assert(!manager.start(scheme, started, error));
    assert(error.code == "SCRIPT_NOT_FOUND");
    assert(terminal.sentCount() == before);
    manager.shutdown();
}

void testAutomationApiRevisionRunAndCancelDisabled() {
    kernel_module::automation_storage.clear();
    FakeTerminal terminal;
    automation::AutomationApi api;
    api.configure(&terminal, "/tmp");

    automation::ConfigStore store;
    automation::Config config;
    automation::Error error;
    assert(store.load(config, error));
    config.draft.steps = {commandStep("api_step", "echo api")};
    const std::string update = automation::ConfigStore::toJson(config);
    auto reply = api.handle("/api/automation/config/set", update);
    assert(reply.status == 200);
    assert(reply.body.find("\"revision\":2") != std::string::npos);
    reply = api.handle("/api/automation/config/set", update);
    assert(reply.status == 409);
    assert(reply.body.find("CONFIG_CHANGED") != std::string::npos);

    const size_t sent_before = terminal.sentCount();
    reply = api.handle("/api/automation/run/start", R"({"source":"draft"})");
    assert(reply.status == 202);
    assert(reply.body.find("requestId") != std::string::npos);
    for (int attempt = 0; attempt < 100; ++attempt) {
        reply = api.handle("/api/automation/run/status", "{}");
        if (reply.body.find("\"state\":\"completed\"") != std::string::npos) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    assert(reply.body.find("\"state\":\"completed\"") != std::string::npos);
    assert(terminal.sentCount() == sent_before + 1);

    automation::Config latest;
    assert(store.load(latest, error));
    latest.draft.steps = {commandStep("api_slow", "slow")};
    automation::Config saved;
    assert(store.save(latest.revision, latest, saved, error));
    reply = api.handle("/api/automation/run/start", R"({"source":"draft"})");
    assert(reply.status == 202);
    const auto id_start = reply.body.find("\"id\":\"");
    assert(id_start != std::string::npos);
    const auto value_start = id_start + std::string("\"id\":\"").size();
    const auto value_end = reply.body.find('"', value_start);
    const std::string run_id = reply.body.substr(value_start, value_end - value_start);
    reply = api.handle("/api/automation/run/cancel", "{\"id\":\"" + run_id + "\"}");
    assert(reply.status == 409);
    assert(reply.body.find("AUTOMATION_CANCEL_DISABLED") != std::string::npos);
    api.shutdown();
}

} // namespace

int main() {
    testForceRunIgnoresShellState();
    testConfigMigrationAndConflict();
    testContinueAndStopPolicies();
    testAutomaticInputAndShutdown();
    testShutdownShellDeathAndPreflight();
    testAutomationApiRevisionRunAndCancelDisabled();
    return 0;
}
