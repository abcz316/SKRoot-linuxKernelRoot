const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
let playwright;
try { playwright = require("playwright"); }
catch (_) {
  playwright = require(path.join(process.env.USERPROFILE || os.homedir(),
    ".cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright"));
}

async function main() {
  const options = { headless: true };
  if (!fs.existsSync(playwright.chromium.executablePath())) {
    const cache = process.platform === "win32"
      ? path.join(process.env.LOCALAPPDATA, "ms-playwright") : path.join(os.homedir(), ".cache/ms-playwright");
    const executable = process.platform === "win32" ? "chrome-headless-shell-win64/chrome-headless-shell.exe"
      : "chrome-headless-shell-linux64/chrome-headless-shell";
    if (fs.existsSync(cache)) options.executablePath = fs.readdirSync(cache)
      .filter(name => name.startsWith("chromium_headless_shell-"))
      .sort((a, b) => Number(b.split("-").pop()) - Number(a.split("-").pop()))
      .map(name => path.join(cache, name, executable)).find(candidate => fs.existsSync(candidate));
  }
  const browser = await playwright.chromium.launch(options);
  const context = await browser.newContext({ viewport: { width: 360, height: 720 }, isMobile: true, hasTouch: true });
  const page = await context.newPage();
  const failures = [];
  page.on("pageerror", error => failures.push(error.message));
  await page.setContent('<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><button id="opener">Open</button>');
  await page.addStyleTag({ path: path.join(__dirname, "../webroot/image-viewer.css") });
  await page.addScriptTag({ path: path.join(__dirname, "../webroot/image-viewer.js") });
  await page.evaluate(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 1200;
    canvas.height = 800;
    const context = canvas.getContext("2d");
    const gradient = context.createLinearGradient(0, 0, 1200, 800);
    gradient.addColorStop(0, "#0e7490");
    gradient.addColorStop(1, "#7c3aed");
    context.fillStyle = gradient;
    context.fillRect(0, 0, 1200, 800);
    context.fillStyle = "white";
    context.font = "72px sans-serif";
    context.fillText("Image preview", 100, 380);
    context.font = "40px sans-serif";
    context.fillText("1200 × 800", 100, 460);
    const payload = canvas.toDataURL("image/png").split(",")[1];
    const bytes = Uint8Array.from(atob(payload), char => char.charCodeAt(0));
    window.closedSessions = [];
    window.pendingOpen = new Map();
    window.abortedReads = 0;
    window.urlsCreated = 0;
    window.urlsRevoked = 0;
    const createUrl = URL.createObjectURL.bind(URL);
    const revokeUrl = URL.revokeObjectURL.bind(URL);
    URL.createObjectURL = blob => { ++window.urlsCreated; return createUrl(blob); };
    URL.revokeObjectURL = url => { ++window.urlsRevoked; return revokeUrl(url); };
    window.mockApi = {
      openImage(filePath) {
        const result = { sessionId: filePath, path: filePath, size: bytes.length, width: 1200, height: 800, mime: "image/png" };
        if (filePath.includes("late")) return new Promise(resolve => window.pendingOpen.set(filePath, () => resolve(result)));
        return Promise.resolve(result);
      },
      readImageChunk(sessionId, offset, limit, options = {}) {
        if (sessionId.includes("slow-read")) return new Promise((resolve, reject) => {
          options.signal.addEventListener("abort", () => {
            ++window.abortedReads;
            reject(new DOMException("Aborted", "AbortError"));
          });
        });
        if (sessionId.includes("bad-image")) return Promise.resolve({ offset, nextOffset: bytes.length, base64: "AAAA", eof: true });
        const data = sessionId.includes("bad-decode")
          ? new Uint8Array(Math.min(limit, bytes.length - offset)) : bytes.subarray(offset, offset + limit);
        let raw = "";
        for (const byte of data) raw += String.fromCharCode(byte);
        return Promise.resolve({ offset, nextOffset: offset + data.length,
          base64: btoa(raw), eof: offset + data.length === bytes.length });
      },
      closeImage(sessionId) { window.closedSessions.push(sessionId); return Promise.resolve(); },
    };
    window.viewer = SKImageViewer.create({ api: window.mockApi });
    document.getElementById("opener").focus();
  });

  await page.evaluate(() => viewer.open({ path: "/sdcard/图片.png", name: "图片.png" }));
  assert.equal(await page.locator(".image-viewer-scale").textContent(), "30%");
  assert.match(await page.locator(".image-viewer-meta").textContent(), /^1200 × 800 · [0-9.]+ MiB$/);
  const geometry = await page.evaluate(() => {
    const image = document.querySelector(".image-viewer-image").getBoundingClientRect();
    const view = document.querySelector(".image-viewer-viewport").getBoundingClientRect();
    return { image: { x: image.x, y: image.y, width: image.width, height: image.height },
      view: { x: view.x, y: view.y, width: view.width, height: view.height },
      overflow: document.documentElement.scrollWidth > window.innerWidth };
  });
  assert.equal(geometry.image.width, 360);
  assert.equal(geometry.image.x, 0);
  assert.ok(Math.abs(geometry.image.y + geometry.image.height / 2 - geometry.view.y - geometry.view.height / 2) < 1);
  assert.equal(geometry.overflow, false);
  const out = process.env.SKROOT_IMAGE_SCREENSHOT_DIR || path.join(os.tmpdir(), "skroot-image-viewer-qa");
  fs.mkdirSync(out, { recursive: true });
  await page.screenshot({ path: path.join(out, "image-mobile.png") });

  await page.locator('[data-image-action="actual"]').click();
  assert.equal(await page.locator(".image-viewer-scale").textContent(), "100%");
  const cdpsession = await context.newCDPSession(page);
  const view = await page.locator(".image-viewer-viewport").boundingBox();
  const middle = view.y + view.height / 2;
  await cdpsession.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x: 130, y: middle }, { x: 230, y: middle }] });
  await cdpsession.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ x: 80, y: middle }, { x: 280, y: middle }] });
  await cdpsession.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  assert.equal(await page.locator(".image-viewer-scale").textContent(), "200%");
  await page.locator('[data-image-action="fit"]').click();
  assert.equal(await page.locator(".image-viewer-scale").textContent(), "30%");
  await page.locator(".image-viewer-close").click();
  assert.equal(await page.evaluate(() => viewer.isOpen), false);
  assert.equal(await page.evaluate(() => urlsCreated), await page.evaluate(() => urlsRevoked));

  // Closing while opening must close the returned session and never reopen UI.
  await page.evaluate(() => { window.lateTask = viewer.open({ path: "/late.png" }); viewer.close(); });
  await page.evaluate(() => { pendingOpen.get("/late.png")(); return window.lateTask; });
  assert.equal(await page.evaluate(() => viewer.isOpen), false);
  assert.ok(await page.evaluate(() => closedSessions.includes("/late.png")));

  // A late response from a previous image must not overwrite the new image.
  await page.evaluate(() => { window.oldTask = viewer.open({ path: "/late-old.png" }); });
  await page.evaluate(() => viewer.open({ path: "/current.png" }));
  await page.evaluate(() => { pendingOpen.get("/late-old.png")(); return window.oldTask; });
  assert.equal(await page.locator(".image-viewer-path").textContent(), "/current.png");
  assert.ok(await page.evaluate(() => closedSessions.includes("/late-old.png")));

  await page.evaluate(() => { window.slowTask = viewer.open({ path: "/slow-read.png" }); });
  await page.waitForFunction(() => document.querySelector(".image-viewer-meta").textContent === "正在读取");
  await page.evaluate(async () => { viewer.close(); await window.slowTask; });
  assert.equal(await page.evaluate(() => abortedReads), 1);
  assert.ok(await page.evaluate(() => closedSessions.includes("/slow-read.png")));
  assert.equal(await page.evaluate(() => urlsCreated), await page.evaluate(() => urlsRevoked));

  await page.evaluate(() => viewer.open({ path: "/bad-image.png" }));
  assert.equal(await page.locator(".image-viewer-meta").textContent(), "无法预览");
  assert.ok((await page.locator(".image-viewer-message").textContent()).includes("读取进度无效"));
  await page.keyboard.press("Escape");
  assert.equal(await page.evaluate(() => viewer.isOpen), false);

  await page.evaluate(() => viewer.open({ path: "/bad-decode.png" }));
  assert.equal(await page.locator(".image-viewer-meta").textContent(), "无法预览");
  assert.ok((await page.locator(".image-viewer-message").textContent()).includes("图片已损坏"));
  await page.evaluate(() => viewer.close());
  assert.equal(await page.evaluate(() => urlsCreated), await page.evaluate(() => urlsRevoked));

  await page.setViewportSize({ width: 1280, height: 800 });
  await page.evaluate(() => viewer.open({ path: "/desktop.png" }));
  assert.ok((await page.locator(".image-viewer-image").boundingBox()).width <= 1280);
  await page.screenshot({ path: path.join(out, "image-desktop.png") });
  await page.evaluate(() => viewer.close());
  assert.equal(await page.evaluate(() => urlsCreated), await page.evaluate(() => urlsRevoked));
  assert.deepEqual(failures, []);
  await browser.close();
  console.log(`image viewer browser checks passed; screenshots: ${out}`);
}
main().catch(error => { console.error(error); process.exit(1); });
