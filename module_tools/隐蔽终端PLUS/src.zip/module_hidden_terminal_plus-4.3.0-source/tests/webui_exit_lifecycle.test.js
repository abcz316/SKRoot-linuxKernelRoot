const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const source = fs.readFileSync(path.join(__dirname, "..", "module_hide_sh_exec.cpp"), "utf8");

test("request-thread WebUI exit relies on process exit instead of CivetServer::close", () => {
  const match = source.match(/std::string\s+handle_exit_webui\s*\(\s*\)\s*\{([\s\S]*?)\n\s*\}/);
  assert.ok(match, "handle_exit_webui body should be present");

  const body = match[1];
  assert.doesNotMatch(body, /m_server\s*\)?\s*->\s*close\s*\(/);

  const shellStop = body.indexOf("m_su_interactive.stop(true)");
  const fileShutdown = body.indexOf("m_file_api.shutdown()");
  const processExit = body.indexOf("_exit(0)");
  assert.ok(fileShutdown >= 0);
  assert.ok(shellStop >= 0);
  assert.ok(fileShutdown > shellStop);
  assert.ok(processExit > shellStop);
});

test("transport settings and module version are present", () => {
  assert.match(source, /SKROOT_MODULE_VERSION\("4\.3\.0"\)/);
  assert.doesNotMatch(source, /terminateProcess(Group|Tree)/);
  assert.match(source, /getTerminalTransportMode/);
  assert.match(source, /saveTerminalTransportMode/);
  assert.match(source, /m_su_interactive\.start\(module_private_dir, m_transport_mode\)/);
});

test("idle timeout retains graceful server close outside the request handler", () => {
  const beforeHandler = source.slice(0, source.indexOf("std::string handle_exit_webui"));
  assert.match(beforeHandler, /if\s*\(m_server\)\s*m_server->close\s*\(\s*\)/);
});

const terminal = fs.readFileSync(path.join(__dirname, "..", "su_interactive.cpp"), "utf8");
const header = fs.readFileSync(path.join(__dirname, "..", "su_interactive.h"), "utf8");

test("terminal lifecycle has no process tree enumeration or group signalling", () => {
  for (const code of [source, terminal, header]) {
    assert.doesNotMatch(code, /terminateProcess(Group|Tree)|descendantsOf|allProcesses|readProcInfo/);
    assert.doesNotMatch(code, /(?:kill|killpg)\s*\(\s*-/);
  }
  assert.doesNotMatch(terminal, /opendir|\/proc\//);
  assert.match(terminal, /::kill\(pid, SIGTERM\)/);
  assert.match(terminal, /::kill\(pid, SIGKILL\)/);
});

test("watchdog drops descriptors before waiting, signals only shell PID", () => {
  const body = source.slice(source.indexOf("void fork_sh_process_daemon()"), source.indexOf("std::string handle_send_command"));
  const close = body.indexOf("closeTransportFdsAfterFork()");
  const wait = body.indexOf("wait_parent_exit(");
  assert.ok(close >= 0 && close < wait);
  assert.match(body, /::kill\(shell_pid, SIGKILL\)/);
  const closeBody = terminal.slice(terminal.indexOf("void SuInteractive::closeTransportFdsAfterFork()"), terminal.indexOf("bool SuInteractive::isAlive()"));
  for (const fd of ["m_in_w", "m_out_r"]) assert.ok(closeBody.includes(`safeClose(${fd})`));
  assert.doesNotMatch(header + terminal, /m_termios_fd/);
  assert.match(closeBody, /is_always_lock_free/);
  assert.doesNotMatch(closeBody, /lock_guard|join|finishAutomationCommand/);
});

test("automation keeps force-run while pipe idle uses upstream prompt state", () => {
  const idle = terminal.slice(terminal.indexOf("bool SuInteractive::isShellIdle()"), terminal.indexOf("void SuInteractive::closeTransportFdsAfterFork()"));
  assert.match(idle, /TerminalTransportMode::Pipe\)\s*\{[^}]*m_pipe_shell_ready/);
  assert.match(idle, /TIOCGPGRP/);
  assert.match(idle, /foreground == shell_group/);
  const automation = fs.readFileSync(path.join(__dirname, "..", "automation_service.cpp"), "utf8");
  assert.doesNotMatch(automation.slice(automation.indexOf("bool AutomationManager::start"), automation.indexOf("RunSnapshot AutomationManager::snapshot")), /hasShellIdleState|isShellIdle/);
});

test("transport follows upstream blocking IO with retained descriptor cleanup", () => {
  const reader = terminal.slice(terminal.indexOf("void SuInteractive::readerLoop_()"), terminal.indexOf("std::string SuInteractive::filterAutomationEcho_"));
  assert.match(reader, /::read\(fd, buffer, sizeof\(buffer\)\)/);
  assert.doesNotMatch(terminal + header, /O_NONBLOCK|setNonblocking|::poll|m_transport_closing|m_lifecycle_mu|m_send_mu/);
  assert.match(terminal, /::write\(m_in_w, cursor, left\)/);
  const close = terminal.slice(terminal.indexOf("void SuInteractive::closeInput()"), terminal.indexOf("int SuInteractive::wait()"));
  for (const fd of ["m_in_w", "m_out_r"]) assert.ok(close.includes(`safeClose(${fd})`));
});

test("both su launch paths restore scheduling and pipe echo has one owner", () => {
  assert.equal((terminal.match(/shell_scheduler::restoreForExec\(\)/g) || []).length, 2);
  const launch = /shell_scheduler::restoreForExec\(\);\s*const char\* argv\[\] = \{"su", nullptr\};\s*::execvp/g;
  assert.equal((terminal.match(launch) || []).length, 2);
  const main = fs.readFileSync(path.join(__dirname, "..", "webroot/main.js"), "utf8");
  assert.doesNotMatch(main, /terminalCore\.appendLine\("# " \+ v\)/);
});
