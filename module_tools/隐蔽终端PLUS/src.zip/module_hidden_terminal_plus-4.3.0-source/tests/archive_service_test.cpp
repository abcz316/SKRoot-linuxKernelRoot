#include "../archive_service.h"

#include "../third_party/libarchive/include/archive.h"
#include "../third_party/libarchive/include/archive_entry.h"

#include <cassert>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <locale.h>
#include <string>
#include <thread>
#include <vector>

#include <unistd.h>

namespace fs = std::filesystem;
using namespace file_manager;

namespace {

struct EntrySpec {
    std::string path;
    std::string data;
    bool directory = false;
    bool symlink = false;
    std::string link_target;
};

void writeArchive(const fs::path& path, bool seven_zip, const std::vector<EntrySpec>& entries) {
    archive* writer = archive_write_new();
    assert(writer);
    assert((seven_zip ? archive_write_set_format_7zip(writer)
                      : archive_write_set_format_zip(writer)) == ARCHIVE_OK);
    assert(archive_write_open_filename(writer, path.c_str()) == ARCHIVE_OK);
    for (const auto& spec : entries) {
        archive_entry* entry = archive_entry_new();
        assert(entry);
        archive_entry_set_pathname(entry, spec.path.c_str());
        archive_entry_set_perm(entry, spec.directory ? 0755 : 0644);
        archive_entry_set_mtime(entry, 1700000000, 0);
        if (spec.directory) {
            archive_entry_set_filetype(entry, AE_IFDIR);
            archive_entry_set_size(entry, 0);
        } else if (spec.symlink) {
            archive_entry_set_filetype(entry, AE_IFLNK);
            archive_entry_set_symlink(entry, spec.link_target.c_str());
            archive_entry_set_size(entry, 0);
        } else {
            archive_entry_set_filetype(entry, AE_IFREG);
            archive_entry_set_size(entry, static_cast<la_int64_t>(spec.data.size()));
        }
        assert(archive_write_header(writer, entry) == ARCHIVE_OK);
        if (!spec.directory && !spec.symlink && !spec.data.empty()) {
            assert(archive_write_data(writer, spec.data.data(), spec.data.size())
                   == static_cast<la_ssize_t>(spec.data.size()));
        }
        archive_entry_free(entry);
    }
    assert(archive_write_close(writer) == ARCHIVE_OK);
    assert(archive_write_free(writer) == ARCHIVE_OK);
}

JobSnapshot waitForJob(FileJobManager& jobs, const std::string& id) {
    for (int i = 0; i < 1000; ++i) {
        JobSnapshot value = jobs.snapshot(id);
        if (value.state == "completed" || value.state == "failed" || value.state == "cancelled") return value;
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    assert(false && "archive job timeout");
    return {};
}

std::string readFile(const fs::path& path) {
    std::ifstream stream(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>()};
}

void writeFile(const fs::path& path, const std::string& content) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    assert(stream.good());
    stream.write(content.data(), static_cast<std::streamsize>(content.size()));
    assert(stream.good());
}

JobSnapshot extract(FileJobManager& jobs, const fs::path& archive_path,
                    const fs::path& destination, ConflictPolicy conflict = ConflictPolicy::Overwrite) {
    Error error;
    OperationSpec spec;
    spec.type = OperationType::Extract;
    spec.conflict = conflict;
    spec.sources = {archive_path.string()};
    spec.destination = destination.string();
    std::string id;
    if (!jobs.start(spec, id, error)) {
        std::cerr << "extract start failed: " << error.code << " " << error.message
                  << " errno=" << error.sys_errno << "\n";
        assert(false);
    }
    return waitForJob(jobs, id);
}

JobSnapshot compress(FileJobManager& jobs, const std::vector<fs::path>& sources,
                     const fs::path& destination) {
    Error error;
    OperationSpec spec;
    spec.type = OperationType::Compress;
    for (const auto& source : sources) spec.sources.push_back(source.string());
    spec.destination = destination.string();
    std::string id;
    assert(jobs.start(spec, id, error));
    return waitForJob(jobs, id);
}

} // namespace

int main() {
    assert(::setlocale(LC_CTYPE, "C.UTF-8") != nullptr);
    char temp_template[] = "/tmp/skroot-archive-test-XXXXXX";
    char* raw = ::mkdtemp(temp_template);
    assert(raw);
    fs::path root(raw);
    fs::create_directories(root / "zip-out");
    fs::create_directories(root / "seven-out");
    fs::create_directories(root / "rar-out");

    assert(ArchiveService::isSupportedSingleArchivePath("/tmp/sample.zip"));
    assert(ArchiveService::isSupportedSingleArchivePath("/tmp/sample.rar"));
    assert(ArchiveService::isSupportedSingleArchivePath("/tmp/sample.7z"));
    assert(!ArchiveService::isSupportedSingleArchivePath("/tmp/sample.part1.rar"));
    assert(!ArchiveService::isSupportedSingleArchivePath("/tmp/sample.7z.001"));

    const std::vector<EntrySpec> entries = {
        {"safe", {}, true, false, {}},
        {"safe/hello.txt", "hello archive\n", false, false, {}},
        {"中文目录/配置.txt", "UTF-8 archive\n", false, false, {}},
        {"safe/link", {}, false, true, "hello.txt"},
    };
    writeArchive(root / "sample.zip", false, entries);
    writeArchive(root / "sample.7z", true, entries);

    // Android native processes commonly begin in the plain C locale. The
    // archive itself still contains valid UTF-8 names; extraction must not
    // depend on a process-wide locale having been initialized by the UI.
    assert(::setlocale(LC_CTYPE, "C") != nullptr);

    writeFile(root / "sample.z01", "split zip companion");
    assert(!ArchiveService::isSupportedSingleArchivePath((root / "sample.zip").string()));
    fs::remove(root / "sample.z01");
    writeFile(root / "sample.r00", "split rar companion");
    assert(!ArchiveService::isSupportedSingleArchivePath((root / "sample.rar").string()));
    fs::remove(root / "sample.r00");
    writeFile(root / "sample.7z.001", "split 7z companion");
    assert(!ArchiveService::isSupportedSingleArchivePath((root / "sample.7z").string()));
    fs::remove(root / "sample.7z.001");

    fs::path rar_fixture = fs::absolute("tests/fixtures/test_read_format_rar.rar");
    assert(fs::exists(rar_fixture));

    FileService files;
    FileJobManager jobs(files);

    fs::create_directories(root / "compress-source/中文目录");
    fs::create_directories(root / "compress-out");
    fs::create_directories(root / "compress-check");
    writeFile(root / "compress-source/中文目录/配置.txt", "compressed UTF-8\n");
    writeFile(root / "compress-source/plain.txt", "plain\n");
    assert(::symlink("plain.txt", (root / "compress-source/plain.link").c_str()) == 0);
    assert(::mkfifo((root / "compress-source/special.fifo").c_str(), 0600) == 0);
    JobSnapshot compressed = compress(jobs, {root / "compress-source"}, root / "compress-out");
    assert(compressed.state == "completed");
    assert(compressed.output_path == (root / "compress-out/compress-source.zip").string());
    assert(compressed.warning_count == 1 && compressed.skipped_count == 1);
    assert(fs::exists(compressed.output_path));
    JobSnapshot compressed_extract = extract(jobs, compressed.output_path, root / "compress-check");
    assert(compressed_extract.state == "completed");
    assert(readFile(root / "compress-check/compress-source/中文目录/配置.txt") == "compressed UTF-8\n");
    assert(fs::is_symlink(root / "compress-check/compress-source/plain.link"));

    JobSnapshot renamed_compressed = compress(jobs, {root / "compress-source"}, root / "compress-out");
    assert(renamed_compressed.state == "completed");
    assert(renamed_compressed.output_path == (root / "compress-out/compress-source (1).zip").string());

    fs::create_directories(root / "compress-source/inside");
    OperationSpec unsafe_compress;
    unsafe_compress.type = OperationType::Compress;
    unsafe_compress.sources = {(root / "compress-source").string()};
    unsafe_compress.destination = (root / "compress-source/inside").string();
    Error compress_error;
    std::string unsafe_compress_id;
    assert(!jobs.start(unsafe_compress, unsafe_compress_id, compress_error));
    assert(compress_error.code == "INVALID_DESTINATION");

    fs::path first = root / "a-first.txt";
    fs::path second = root / "b-second.txt";
    writeFile(first, "first");
    writeFile(second, "second");
    JobSnapshot multi_compressed = compress(jobs, {second, first}, root / "compress-out");
    assert(multi_compressed.state == "completed");
    assert(multi_compressed.output_path == (root / "compress-out/a-first.txt.zip").string());

    assert(::setenv("SKROOT_TEST_FORCE_ARCHIVE_PATH_FALLBACK", "1", 1) == 0);
    JobSnapshot zip_result = extract(jobs, root / "sample.zip", root / "zip-out");
    (void)::unsetenv("SKROOT_TEST_FORCE_ARCHIVE_PATH_FALLBACK");
    assert(zip_result.state == "completed");
    assert(readFile(root / "zip-out/safe/hello.txt") == "hello archive\n");
    assert(readFile(root / "zip-out/中文目录/配置.txt") == "UTF-8 archive\n");
    assert(fs::is_symlink(root / "zip-out/safe/link"));

    writeFile(root / "seven-out/safe.txt", "old");
    JobSnapshot seven_result = extract(jobs, root / "sample.7z", root / "seven-out");
    assert(seven_result.state == "completed");
    assert(readFile(root / "seven-out/safe/hello.txt") == "hello archive\n");
    assert(readFile(root / "seven-out/中文目录/配置.txt") == "UTF-8 archive\n");

    JobSnapshot rar_result = extract(jobs, rar_fixture, root / "rar-out");
    assert(rar_result.state == "completed");
    assert(readFile(root / "rar-out/test.txt") == "test text document\r\n");

    writeFile(root / "zip-out/safe/hello.txt", "keep\n");
    JobSnapshot skip_result = extract(jobs, root / "sample.zip", root / "zip-out", ConflictPolicy::Skip);
    assert(skip_result.state == "completed");
    assert(skip_result.skipped_count > 0);
    assert(readFile(root / "zip-out/safe/hello.txt") == "keep\n");

    writeArchive(root / "unsafe.zip", false, {{"../escape.txt", "escape", false, false, {}}});
    Error error;
    OperationSpec unsafe;
    unsafe.type = OperationType::Extract;
    unsafe.conflict = ConflictPolicy::Overwrite;
    unsafe.sources = {(root / "unsafe.zip").string()};
    unsafe.destination = (root / "zip-out").string();
    std::string unsafe_id;
    assert(jobs.start(unsafe, unsafe_id, error));
    JobSnapshot unsafe_result = waitForJob(jobs, unsafe_id);
    assert(unsafe_result.state == "failed");
    assert(!fs::exists(root / "escape.txt"));

    jobs.shutdown();
    fs::remove_all(root);
    std::cout << "archive_service_test: OK\n";
    return 0;
}
