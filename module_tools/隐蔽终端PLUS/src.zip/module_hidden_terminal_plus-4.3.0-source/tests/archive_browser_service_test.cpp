#include "../archive_browser_service.h"
#include "../third_party/libarchive/include/archive.h"
#include "../third_party/libarchive/include/archive_entry.h"

#include <algorithm>
#include <cassert>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <locale.h>
#include <thread>
#include <unistd.h>

namespace fs = std::filesystem;
using namespace file_manager;

namespace {

struct Entry {
    std::string path;
    std::string data;
    std::string link;
    bool directory = false;
};

void makeArchive(const fs::path& path, const std::vector<Entry>& entries, bool seven = false) {
    archive* writer = archive_write_new();
    assert(writer);
    assert((seven ? archive_write_set_format_7zip(writer) : archive_write_set_format_zip(writer)) == ARCHIVE_OK);
    assert(archive_write_open_filename(writer, path.c_str()) == ARCHIVE_OK);
    for (const auto& source : entries) {
        archive_entry* item = archive_entry_new();
        archive_entry_set_pathname_utf8(item, source.path.c_str());
        archive_entry_set_perm(item, source.directory ? 0755 : 0644);
        archive_entry_set_mtime(item, 1700000000, 0);
        archive_entry_set_filetype(item, source.directory ? AE_IFDIR : source.link.empty() ? AE_IFREG : AE_IFLNK);
        archive_entry_set_size(item, source.directory || !source.link.empty() ? 0 : source.data.size());
        if (!source.link.empty()) archive_entry_set_symlink_utf8(item, source.link.c_str());
        assert(archive_write_header(writer, item) == ARCHIVE_OK);
        if (!source.directory && source.link.empty() && !source.data.empty()) {
            assert(archive_write_data(writer, source.data.data(), source.data.size()) == static_cast<la_ssize_t>(source.data.size()));
        }
        archive_entry_free(item);
    }
    assert(archive_write_close(writer) == ARCHIVE_OK);
    assert(archive_write_free(writer) == ARCHIVE_OK);
}

ArchiveBrowserStatus awaitIndex(ArchiveBrowserService& browser, const std::string& id) {
    Error error;
    ArchiveBrowserStatus status;
    for (int i = 0; i < 6000; ++i) {
        assert(browser.status(id, status, error));
        if (status.state == "ready" || status.state == "failed") return status;
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    assert(false && "index timeout");
    return status;
}

ArchiveBrowserStatus openIndex(ArchiveBrowserService& browser, const fs::path& path) {
    Error error;
    ArchiveBrowserStatus opened;
    assert(browser.open(path.string(), opened, error));
    const auto result = awaitIndex(browser, opened.session_id);
    if (result.state != "ready") std::cerr << result.error.code << ": " << result.error.message << '\n';
    assert(result.state == "ready");
    return result;
}

ArchiveBrowserList list(ArchiveBrowserService& browser, const std::string& id, const std::string& path,
                        uint64_t offset = 0, size_t limit = 500) {
    Error error;
    ArchiveBrowserList result;
    assert(browser.list(id, path, offset, limit, result, error));
    return result;
}

ArchiveBrowserEntry named(const ArchiveBrowserList& page, const std::string& name, uint64_t duplicate = 1,
                           const std::string& type = "file") {
    for (const auto& item : page.entries) {
        if (item.name == name && item.duplicate_index == duplicate && item.type == type) return item;
    }
    assert(false && "missing browser entry");
    return {};
}

ArchiveSelection resolve(ArchiveBrowserService& browser, const std::string& id, const std::string& base,
                         const std::vector<std::string>& ids) {
    Error error;
    ArchiveSelection selection;
    assert(browser.resolveSelection(id, base, ids, selection, error));
    return selection;
}

JobSnapshot extract(FileJobManager& jobs, const ArchiveSelection& selection, const fs::path& output,
                    ConflictPolicy conflict = ConflictPolicy::Overwrite) {
    fs::create_directories(output);
    OperationSpec spec;
    spec.type = OperationType::Extract;
    spec.sources = {selection.archive_path};
    spec.destination = output.string();
    spec.conflict = conflict;
    spec.archive_selection = selection;
    Error error;
    std::string id;
    assert(jobs.start(spec, id, error));
    for (int i = 0; i < 6000; ++i) {
        const auto job = jobs.snapshot(id);
        if (job.state == "completed" || job.state == "failed" || job.state == "cancelled") return job;
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    assert(false && "extraction timeout");
    return {};
}

std::string read(const fs::path& path) {
    std::ifstream file(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>()};
}

bool hasError(const JobSnapshot& job, const std::string& code) {
    return std::any_of(job.errors.begin(), job.errors.end(), [&](const auto& error) { return error.code == code; });
}

} // namespace

int main() {
    assert(::setlocale(LC_CTYPE, "C.UTF-8"));
    char pattern[] = "/tmp/skroot-archive-browser-XXXXXX";
    const char* raw = ::mkdtemp(pattern);
    assert(raw);
    const fs::path root(raw);
    const fs::path source = root / "sample.zip";
    makeArchive(source, {
        {"a/b/c.txt", "chosen"}, {"a/b/duplicate.txt", "first"}, {"a/b/duplicate.txt", "second"},
        {"a/b/empty/", {}, {}, true}, {"a/b/nested/deep.txt", "deep"},
        {"a/b/collision", "file sibling"}, {"a/b/collision/", {}, {}, true},
        {"a/b/collision/inside.txt", "directory child"},
        {"a/b/link", {}, "c.txt"}, {"a/b/up", {}, "../../outside.txt"},
        {"a/b/中文.txt", "中文"}, {"unselected.txt", "leave this in the archive"},
    });
    const auto taskCount = [] {
        return std::distance(fs::directory_iterator("/proc/self/task"), fs::directory_iterator{});
    };
    const auto threads_before = taskCount();
    ArchiveBrowserService browser;
    assert(taskCount() == threads_before); // No threads before the WebUI's su fork.
    FileService files;
    FileJobManager jobs(files);
    Error error;
    assert(::setenv("SKROOT_TEST_FORCE_ARCHIVE_PATH_FALLBACK", "1", 1) == 0);
    const auto opened = openIndex(browser, source);
    (void)::unsetenv("SKROOT_TEST_FORCE_ARCHIVE_PATH_FALLBACK");
    const std::string id = opened.session_id;
    assert(opened.total_entries == 12);
    const auto root_page = list(browser, id, "");
    assert(named(root_page, "a", 1, "directory").is_implicit);
    const auto page = list(browser, id, "a/b");
    assert(named(page, "nested", 1, "directory").is_implicit);
    assert(!named(page, "empty", 1, "directory").is_implicit);
    const auto duplicate1 = named(page, "duplicate.txt", 1);
    const auto duplicate2 = named(page, "duplicate.txt", 2);
    assert(duplicate1.id != duplicate2.id && duplicate1.path == duplicate2.path);
    assert(duplicate1.id.rfind("e:", 0) == 0);
    assert(named(page, "中文.txt").size == 6);
    assert(list(browser, id, "a/b", 0, 2).next_offset == 2);
    assert(list(browser, id, "a/b", page.total, 2).eof);
    ArchiveBrowserList invalid_page;
    assert(!browser.list(id, "../a", 0, 1, invalid_page, error));
    assert(!browser.list(id, "a/b", 0, 501, invalid_page, error));
    assert(!browser.list(id, "a/b", 999, 2, invalid_page, error));
    assert(!browser.list(id, "a/b/c.txt", 0, 1, invalid_page, error));
    ArchiveSelection invalid_selection;
    assert(!browser.resolveSelection(id, "", {duplicate2.id}, invalid_selection, error));
    assert(!browser.resolveSelection(id, "a/b", {"e:999999"}, invalid_selection, error));
    assert(!browser.resolveSelection(id, "a/b", {}, invalid_selection, error));
    assert(!browser.resolveSelection(id, "a/b", std::vector<std::string>(501, duplicate2.id), invalid_selection, error));

    const auto one = resolve(browser, id, "a/b", {duplicate2.id, duplicate2.id});
    assert(one.entries.size() == 1);
    auto job = extract(jobs, one, root / "one");
    assert(job.state == "completed" && job.total_items == 1 && job.total_bytes == 6);
    assert(job.processed_items == 1 && job.skipped_count == 0);
    assert(read(root / "one/duplicate.txt") == "second");
    assert(!fs::exists(root / "one/a") && !fs::exists(root / "one/c.txt"));

    const auto both = resolve(browser, id, "a/b", {duplicate1.id, duplicate2.id});
    job = extract(jobs, both, root / "both", ConflictPolicy::Skip);
    assert(job.state == "completed" && job.skipped_count == 1);
    assert(read(root / "both/duplicate.txt") == "first");
    job = extract(jobs, both, root / "overwrite");
    assert(job.state == "completed" && read(root / "overwrite/duplicate.txt") == "second");

    const auto dirs = resolve(browser, id, "a/b", {
        named(page, "empty", 1, "directory").id,
        named(page, "nested", 1, "directory").id,
        named(page, "collision", 1, "directory").id,
    });
    job = extract(jobs, dirs, root / "dirs");
    assert(job.state == "completed");
    assert(fs::is_directory(root / "dirs/empty"));
    assert(read(root / "dirs/nested/deep.txt") == "deep");
    assert(read(root / "dirs/collision/inside.txt") == "directory child");
    assert(job.skipped_count == 0);

    const auto unsafe = resolve(browser, id, "a/b", {
        named(page, "c.txt").id, named(page, "up", 1, "symlink").id,
    });
    job = extract(jobs, unsafe, root / "unsafe");
    assert(job.state == "failed" && hasError(job, "ARCHIVE_UNSAFE_LINK"));
    assert(fs::is_empty(root / "unsafe"));
    const auto safe = resolve(browser, id, "a/b", {named(page, "link", 1, "symlink").id});
    job = extract(jobs, safe, root / "safe");
    assert(job.state == "completed" && fs::is_symlink(root / "safe/link"));
    assert(!fs::exists(root / "safe/c.txt")); // Do not pull unselected link targets.

    // Cached selections own their ordinals and version, not a live session.
    assert(browser.close(id, error));
    assert(browser.close(id, error));
    job = extract(jobs, one, root / "after-close");
    assert(job.state == "completed" && read(root / "after-close/duplicate.txt") == "second");
    ArchiveBrowserStatus missing;
    assert(!browser.status(id, missing, error));

    makeArchive(root / "simple.7z", {{"folder/file.txt", "seven"}}, true);
    const auto seven = openIndex(browser, root / "simple.7z");
    const auto seven_page = list(browser, seven.session_id, "folder");
    job = extract(jobs, resolve(browser, seven.session_id, "folder", {seven_page.entries.front().id}), root / "seven");
    assert(job.state == "completed" && read(root / "seven/file.txt") == "seven");
    const auto rar = openIndex(browser, fs::absolute("tests/fixtures/test_read_format_rar.rar"));
    assert(!list(browser, rar.session_id, "").entries.empty());
    assert(!browser.open(source.string(), missing, error) && error.code == "ARCHIVE_SESSION_LIMIT");
    assert(browser.close(seven.session_id, error) && browser.close(rar.session_id, error));

    const auto stale = openIndex(browser, source);
    const auto stale_page = list(browser, stale.session_id, "a/b");
    const auto stale_selection = resolve(browser, stale.session_id, "a/b", {named(stale_page, "c.txt").id});
    { std::ofstream changed(source, std::ios::binary | std::ios::app); changed << "changed"; }
    assert(!browser.list(stale.session_id, "", 0, 10, invalid_page, error) && error.code == "ARCHIVE_CHANGED");
    OperationSpec stale_spec;
    stale_spec.type = OperationType::Extract;
    stale_spec.sources = {source.string()};
    stale_spec.destination = (root / "one").string();
    stale_spec.archive_selection = stale_selection;
    std::string rejected_id;
    assert(!jobs.start(stale_spec, rejected_id, error) && error.code == "ARCHIVE_CHANGED");
    assert(browser.close(stale.session_id, error));

    makeArchive(root / "self.zip", {{"inner/self.zip", "must not replace the source"}});
    const auto self = openIndex(browser, root / "self.zip");
    const auto self_page = list(browser, self.session_id, "inner");
    job = extract(jobs, resolve(browser, self.session_id, "inner", {self_page.entries.front().id}), root);
    assert(job.state == "failed" && hasError(job, "ARCHIVE_UNSAFE_PATH"));
    assert(fs::file_size(root / "self.zip") == self.version.size);
    assert(browser.close(self.session_id, error));

    fs::create_directories(root / "parent/container/held");
    assert(::symlink("parent", (root / "alias").c_str()) == 0);
    makeArchive(root / "parent/container/held/archive.zip", {{"inner/held", "must not replace source parent"}});
    const auto alias = openIndex(browser, root / "parent/container/held/archive.zip");
    const auto alias_page = list(browser, alias.session_id, "inner");
    job = extract(jobs, resolve(browser, alias.session_id, "inner", {alias_page.entries.front().id}), root / "alias/container");
    assert(job.state == "failed" && hasError(job, "ARCHIVE_UNSAFE_PATH"));
    assert(fs::is_regular_file(root / "parent/container/held/archive.zip"));
    assert(browser.close(alias.session_id, error));

    makeArchive(root / "empty.zip", {});
    const auto empty = openIndex(browser, root / "empty.zip");
    assert(list(browser, empty.session_id, "").total == 0);
    assert(browser.close(empty.session_id, error));
    makeArchive(root / "traversal.zip", {{"../escape.txt", "bad"}});
    assert(browser.open((root / "traversal.zip").string(), missing, error));
    const auto bad = awaitIndex(browser, missing.session_id);
    assert(bad.state == "failed" && bad.error.code == "ARCHIVE_UNSAFE_PATH");
    assert(browser.close(missing.session_id, error));

    { std::ofstream invalid(root / "damaged.zip"); invalid << "not an archive"; }
    assert(browser.open((root / "damaged.zip").string(), missing, error));
    assert(awaitIndex(browser, missing.session_id).state == "failed");
    assert(browser.close(missing.session_id, error));
    { std::ofstream split(root / "sample.z01"); split << "volume"; }
    assert(!browser.open(source.string(), missing, error) && error.code == "ARCHIVE_UNSUPPORTED_FORMAT");

    // A small header count can still create too many virtual directory nodes.
    std::vector<Entry> many;
    for (size_t i = 0; i < 34000; ++i) many.push_back({"n" + std::to_string(i) + "/child/file", ""});
    makeArchive(root / "many-nodes.zip", many);
    assert(browser.open((root / "many-nodes.zip").string(), missing, error));
    const auto too_many = awaitIndex(browser, missing.session_id);
    assert(too_many.state == "failed" && too_many.error.code == "ARCHIVE_INDEX_TOO_LARGE");
    assert(browser.close(missing.session_id, error));

    FileVersion many_version;
    assert(TextTransferService::getVersion((root / "many-nodes.zip").string(), many_version, error));
    std::vector<ArchiveIndexEntry> cancelled_entries;
    std::atomic<bool> cancel{false};
    assert(!ArchiveService::index((root / "many-nodes.zip").string(), many_version, cancel,
        [&](uint64_t count) { if (count >= 64) cancel.store(true); }, cancelled_entries, error));
    assert(error.code == "ARCHIVE_CANCELLED" && cancelled_entries.empty());

    many.clear();
    for (size_t i = 0; i <= kMaxArchiveIndexEntries; ++i) many.push_back({"entry" + std::to_string(i), ""});
    makeArchive(root / "many-headers.zip", many);
    many.clear();
    assert(browser.open((root / "many-headers.zip").string(), missing, error));
    const auto too_many_headers = awaitIndex(browser, missing.session_id);
    assert(too_many_headers.state == "failed" && too_many_headers.error.code == "ARCHIVE_INDEX_TOO_LARGE");
    assert(browser.close(missing.session_id, error));

    std::string prefix;
    for (int i = 0; i < 14; ++i) prefix += std::string(240, 'a') + "/";
    for (size_t i = 0; i < 5100; ++i) many.push_back({prefix + std::to_string(i), ""});
    makeArchive(root / "long-paths.zip", many);
    many.clear();
    assert(browser.open((root / "long-paths.zip").string(), missing, error));
    const auto too_much_text = awaitIndex(browser, missing.session_id);
    assert(too_much_text.state == "failed" && too_much_text.error.code == "ARCHIVE_INDEX_TOO_LARGE");
    assert(browser.close(missing.session_id, error));

    // Cancel queued/scanning work and stop the worker without retaining sessions.
    assert(browser.open((root / "many-nodes.zip").string(), missing, error));
    assert(browser.close(missing.session_id, error));
    browser.shutdown();
    assert(!browser.isActive());
    assert(!browser.open(source.string(), missing, error) && error.code == "ARCHIVE_SERVICE_CLOSED");
    jobs.shutdown();
    fs::remove_all(root);
    std::cout << "archive_browser_service_test: OK\n";
}
