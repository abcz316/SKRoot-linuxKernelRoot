const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
vm.runInThisContext(fs.readFileSync(path.join(__dirname, '../webroot/vendor/codemirror.bundle.js'), 'utf8'));
const cm = globalThis.SKCodeMirror;
const editor = require('../webroot/text-editor.js');

function document(raw) {
  let state = editor.createDocumentState(raw);
  return {
    get state() { return state; },
    dispatch(transaction) { state = transaction.state; },
    edit(changes, grouped = false) {
      state = state.update({ changes, userEvent: 'input.type', annotations: grouped ? [] : cm.isolateHistory.of('full') }).state;
    },
  };
}

test('language detection supports every shipped mode, shebangs and plain fallback', () => {
  for (const [file, language] of [
    ['x.sh', 'shell'], ['.mkshrc', 'shell'], ['x.JSON', 'json'], ['x.jsx', 'javascript'], ['x.tsx', 'typescript'],
    ['x.py', 'python'], ['x.hpp', 'cpp'], ['x.html', 'html'], ['x.xml', 'xml'], ['x.css', 'css'],
    ['x.yml', 'yaml'], ['x.toml', 'toml'], ['x.ini', 'properties'], ['x.properties', 'properties'], ['x.txt', 'plain'],
  ]) assert.equal(editor.inferLanguage(`/root/${file}`, ''), language, file);
  assert.equal(editor.inferLanguage('/bin/script', '#!/system/bin/sh\necho hello'), 'shell');
  assert.equal(editor.inferLanguage('/bin/script', '#!/usr/bin/env -S python3.13 -u\n'), 'python');
  assert.equal(editor.inferLanguage('/bin/script', '#!/usr/bin/node\n'), 'javascript');
  assert.equal(editor.inferLanguage('/bin/script', 'text sh python node'), 'plain');
});

test('large-file mode respects exact byte and logical-line boundaries', () => {
  assert.equal(editor.basicMode('x\n', 1024 * 1024), false);
  assert.equal(editor.basicMode('x\n', 1024 * 1024 + 1), true);
  assert.equal(editor.basicMode('x'.repeat(20000)), false);
  assert.equal(editor.basicMode('x'.repeat(20001)), true);
  assert.equal(editor.basicMode(`${'x'.repeat(20000)}\r\nshort\n`), false);
  assert.equal(editor.basicMode('中文\n'.repeat(150000)), true);
});

test('empty, uniform and mixed line endings survive untouched round trips', () => {
  for (const raw of ['', 'one line', 'a\nb\n', 'a\r\nb\r\n', 'a\r\nb\nc\rd\n', '\r\n\n\r\n']) {
    const state = editor.createDocumentState(raw);
    assert.equal(editor.rawText(state), raw);
    assert.equal(state.doc.lines, raw.split(/\r\n|\r|\n/).length);
  }
});

test('new separators use the first original separator without changing untouched mixed separators', () => {
  const doc = document('first\r\nsecond\nthird\r\n');
  doc.edit({ from: 7, insert: '中\n文\r\n' });
  assert.equal(editor.rawText(doc.state), 'first\r\ns中\r\n文\r\necond\nthird\r\n');
  const noBreak = document('abc');
  noBreak.edit({ from: 1, insert: '\n' });
  assert.equal(editor.rawText(noBreak.state), 'a\nbc');
});

test('multi-range edits preserve separators outside replaced ranges', () => {
  const doc = document('aa\r\nbb\ncc\r\ndd\n');
  doc.edit([{ from: 0, to: 1, insert: 'A\n' }, { from: 6, to: 8, insert: '中文\n' }]);
  assert.equal(editor.rawText(doc.state), 'A\r\na\r\nbb\n中文\r\n\r\ndd\n');
});

test('undo and redo restore deleted mixed separators and exact dirty state', () => {
  const raw = 'a\r\nb\nc\r\nd\n';
  const doc = document(raw);
  const original = doc.state;
  doc.edit({ from: 1, to: 6, insert: 'X\nY\n' });
  const modified = editor.rawText(doc.state);
  assert.equal(editor.sameDocument(original, doc.state), false);
  assert.equal(cm.undo(doc), true);
  assert.equal(editor.rawText(doc.state), raw);
  assert.equal(editor.sameDocument(original, doc.state), true);
  assert.equal(cm.redo(doc), true);
  assert.equal(editor.rawText(doc.state), modified);
});

test('grouped typing history restores the oldest separator snapshot, then redoes all edits', () => {
  const raw = 'a\r\nb\nc\r\n';
  const doc = document(raw);
  doc.edit({ from: 1, to: 3, insert: '\n' }, true);
  doc.edit({ from: 2, to: 4, insert: '\n\n' }, true);
  const modified = editor.rawText(doc.state);
  assert.equal(cm.undoDepth(doc.state), 1);
  cm.undo(doc);
  assert.equal(editor.rawText(doc.state), raw);
  cm.redo(doc);
  assert.equal(editor.rawText(doc.state), modified);
});

test('display configuration and cursor movement never mark the document dirty', () => {
  const doc = document('a\r\nb\n');
  const original = doc.state;
  doc.dispatch(doc.state.update({ selection: { anchor: 2 } }));
  assert.equal(editor.sameDocument(original, doc.state), true);
});

test('UTF-8 BOM is explicit and a content U+FEFF is never discarded', () => {
  assert.deepEqual([...editor.encodedBytes('', true)], [0xef, 0xbb, 0xbf]);
  assert.deepEqual([...editor.encodedBytes('\ufeff', false)], [0xef, 0xbb, 0xbf]);
  assert.deepEqual([...editor.encodedBytes('\ufeff', true)], [0xef, 0xbb, 0xbf, 0xef, 0xbb, 0xbf]);
  assert.equal(new TextDecoder('utf-8', { ignoreBOM: true }).decode(editor.encodedBytes('中文\r\n', false)), '中文\r\n');
});

test('8 MiB boundary counts BOM and UTF-8 bytes rather than code units', () => {
  assert.equal(editor.encodedBytes('a'.repeat(editor.MAX_BYTES), false).length, editor.MAX_BYTES);
  assert.equal(editor.encodedBytes('a'.repeat(editor.MAX_BYTES - 3), true).length, editor.MAX_BYTES);
  assert.equal(editor.encodedBytes('a'.repeat(editor.MAX_BYTES - 2), true).length, editor.MAX_BYTES + 1);
});
