#include "../shell_scheduler.h"

#include <cassert>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <iostream>

#include <fcntl.h>
#include <poll.h>
#include <sched.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

namespace {

bool getAffinity(cpu_set_t& mask) {
    CPU_ZERO(&mask);
    return ::sched_getaffinity(0, sizeof(mask), &mask) == 0;
}

int countCpus(const cpu_set_t& mask) {
    int count = 0;
    for (int cpu = 0; cpu < CPU_SETSIZE; ++cpu) {
        if (CPU_ISSET(cpu, &mask)) ++count;
    }
    return count;
}

int firstCpu(const cpu_set_t& mask) {
    for (int cpu = 0; cpu < CPU_SETSIZE; ++cpu) {
        if (CPU_ISSET(cpu, &mask)) return cpu;
    }
    return -1;
}

bool containsMask(const cpu_set_t& value, const cpu_set_t& expected) {
    for (int cpu = 0; cpu < CPU_SETSIZE; ++cpu) {
        if (CPU_ISSET(cpu, &expected) && !CPU_ISSET(cpu, &value)) return false;
    }
    return true;
}

bool sameMask(const cpu_set_t& left, const cpu_set_t& right) {
    return std::memcmp(&left, &right, sizeof(left)) == 0;
}

bool writeFull(int fd, const void* data, size_t size) {
    const auto* cursor = static_cast<const unsigned char*>(data);
    while (size > 0) {
        const ssize_t written = ::write(fd, cursor, size);
        if (written > 0) {
            cursor += written;
            size -= static_cast<size_t>(written);
            continue;
        }
        if (written < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}

bool readFull(int fd, void* data, size_t size) {
    auto* cursor = static_cast<unsigned char*>(data);
    while (size > 0) {
        const ssize_t received = ::read(fd, cursor, size);
        if (received > 0) {
            cursor += received;
            size -= static_cast<size_t>(received);
            continue;
        }
        if (received < 0 && errno == EINTR) continue;
        return false;
    }
    return true;
}

struct PipeReport {
    shell_scheduler::RestoreResult result;
    cpu_set_t affinity;
    int nice_value;
    int fd_flags_before;
    int fd_flags_after;
    bool started_with_negative_nice;
};

void testAnonymousPipeIsolation() {
    cpu_set_t parent_affinity_before;
    assert(getAffinity(parent_affinity_before));
    assert(countCpus(parent_affinity_before) > 0);

    errno = 0;
    const int parent_nice_before = ::getpriority(PRIO_PROCESS, 0);
    assert(errno == 0);

    int channel[2] = {-1, -1};
    assert(::pipe2(channel, O_CLOEXEC) == 0);

    const pid_t child = ::fork();
    assert(child >= 0);
    if (child == 0) {
        ::close(channel[0]);

        PipeReport report{};
        report.fd_flags_before = ::fcntl(channel[1], F_GETFD);

        cpu_set_t single_cpu;
        CPU_ZERO(&single_cpu);
        CPU_SET(firstCpu(parent_affinity_before), &single_cpu);
        if (::sched_setaffinity(0, sizeof(single_cpu), &single_cpu) != 0) _exit(20);

        // Exercise the real inherited -10 -> 0 transition when the host grants
        // CAP_SYS_NICE. Ordinary test users still cover the 0 -> 0 path.
        report.started_with_negative_nice = (::setpriority(PRIO_PROCESS, 0, -10) == 0);

        report.result = shell_scheduler::restoreForExec();
        report.fd_flags_after = ::fcntl(channel[1], F_GETFD);
        if (!getAffinity(report.affinity)) _exit(21);
        errno = 0;
        report.nice_value = ::getpriority(PRIO_PROCESS, 0);
        if (errno != 0) _exit(22);

        const bool sent = writeFull(channel[1], &report, sizeof(report));
        ::close(channel[1]);
        _exit(sent ? 0 : 23);
    }

    ::close(channel[1]);
    PipeReport report{};
    assert(readFull(channel[0], &report, sizeof(report)));
    ::close(channel[0]);

    int status = 0;
    assert(::waitpid(child, &status, 0) == child);
    assert(WIFEXITED(status) && WEXITSTATUS(status) == 0);

    assert(report.result.nice_restored);
    assert(report.result.affinity_restored);
    assert(report.result.nice_error == 0);
    assert(report.result.affinity_error == 0);
    assert(report.nice_value == 0);
    assert(containsMask(report.affinity, parent_affinity_before));
    assert(report.fd_flags_before >= 0 && report.fd_flags_after == report.fd_flags_before);
    assert((report.fd_flags_after & FD_CLOEXEC) != 0);

    cpu_set_t parent_affinity_after;
    assert(getAffinity(parent_affinity_after));
    assert(sameMask(parent_affinity_before, parent_affinity_after));
    errno = 0;
    assert(::getpriority(PRIO_PROCESS, 0) == parent_nice_before && errno == 0);
}

void testPtyIntegrity() {
    int master = ::posix_openpt(O_RDWR | O_NOCTTY | O_CLOEXEC);
    assert(master >= 0);
    assert(::grantpt(master) == 0);
    assert(::unlockpt(master) == 0);

    char slave_name[128] = {};
    assert(::ptsname_r(master, slave_name, sizeof(slave_name)) == 0);

    const pid_t child = ::fork();
    assert(child >= 0);
    if (child == 0) {
        if (::setsid() < 0) _exit(30);
        const int slave = ::open(slave_name, O_RDWR | O_CLOEXEC);
        if (slave < 0) _exit(31);
        if (::ioctl(slave, TIOCSCTTY, 0) != 0) _exit(32);
        if (::dup2(slave, STDIN_FILENO) < 0 ||
            ::dup2(slave, STDOUT_FILENO) < 0 ||
            ::dup2(slave, STDERR_FILENO) < 0) _exit(33);
        if (slave > STDERR_FILENO) ::close(slave);
        ::close(master);

        const auto result = shell_scheduler::restoreForExec();
        errno = 0;
        const int nice_value = ::getpriority(PRIO_PROCESS, 0);
        if (errno != 0) _exit(34);

        char message[96] = {};
        const int length = std::snprintf(message, sizeof(message),
                                         "SCHED_OK nice=%d affinity=%d nice_ok=%d\n",
                                         nice_value,
                                         result.affinity_restored ? 1 : 0,
                                         result.nice_restored ? 1 : 0);
        if (length <= 0 || !writeFull(STDOUT_FILENO, message, static_cast<size_t>(length))) _exit(35);
        _exit(0);
    }

    pollfd descriptor{master, POLLIN, 0};
    assert(::poll(&descriptor, 1, 3000) > 0);
    char output[256] = {};
    const ssize_t received = ::read(master, output, sizeof(output) - 1);
    assert(received > 0);
    ::close(master);

    int status = 0;
    assert(::waitpid(child, &status, 0) == child);
    assert(WIFEXITED(status) && WEXITSTATUS(status) == 0);
    assert(std::strstr(output, "SCHED_OK nice=0 affinity=1 nice_ok=1") != nullptr);
}

} // namespace

int main() {
    testAnonymousPipeIsolation();
    testPtyIntegrity();
    std::cout << "shell scheduler tests passed\n";
    return 0;
}
