const test = require('node:test');
const assert = require('node:assert/strict');
const { FileManagerModel, normalizePath, joinPath, parentPath, defaultZipName,
  symbolicMode, octalMode } = require('../webroot/file-manager-model.js');

test('path helpers normalize absolute paths', () => {
  assert.equal(normalizePath('/a//b/../c/'), '/a/c');
  assert.equal(joinPath('/a', 'b'), '/a/b');
  assert.equal(parentPath('/a/b'), '/a');
  assert.equal(parentPath('/'), '/');
});

test('ZIP default name uses the sorted first source and removes an existing ZIP suffix', () => {
  assert.equal(defaultZipName(['/source/z-last', '/source/a-first.txt']), 'a-first.txt.zip');
  assert.equal(defaultZipName(['/source/backup.ZIP']), 'backup.zip');
  assert.equal(defaultZipName([]), 'archive.zip');
});

test('permission helpers preserve all twelve Unix permission bits', () => {
  assert.equal(octalMode(0o2770), '2770');
  assert.equal(symbolicMode(0o2770), 'rwxrws---');
  assert.equal(symbolicMode(0o4600), 'rwS------');
  assert.equal(symbolicMode(0o1000), '--------T');
});

test('panes navigate independently and preserve physical homes', () => {
  const model = new FileManagerModel('/left-home', '/right-home');
  model.navigate('left', '/data/local');
  model.navigate('right', '/sdcard/Download');
  assert.equal(model.panes.left.path, '/data/local');
  assert.equal(model.panes.right.path, '/sdcard/Download');
  assert.equal(model.panes.left.home, '/left-home');
  assert.equal(model.panes.right.home, '/right-home');
});

test('swap exchanges view state but not home settings', () => {
  const model = new FileManagerModel('/left-home', '/right-home');
  model.navigate('left', '/left-current');
  model.navigate('right', '/right-current');
  model.panes.left.scrollTop = 12;
  model.panes.right.scrollTop = 34;
  model.swapPanes();
  assert.equal(model.panes.left.path, '/right-current');
  assert.equal(model.panes.right.path, '/left-current');
  assert.equal(model.panes.left.scrollTop, 34);
  assert.equal(model.panes.right.scrollTop, 12);
  assert.equal(model.panes.left.home, '/left-home');
  assert.equal(model.panes.right.home, '/right-home');
});

test('sync copies the active view while preserving homes and active pane', () => {
  const model = new FileManagerModel('/left-home', '/right-home');
  model.navigate('left', '/source');
  model.navigate('right', '/target');
  model.setEntries('left', [{ name: 'one' }]);
  model.panes.left.scrollTop = 42;
  model.activate('left');
  model.syncPanesToActive();
  assert.equal(model.activePane, 'left');
  assert.equal(model.panes.right.path, '/source');
  assert.deepEqual(model.panes.right.entries, [{ name: 'one' }]);
  assert.equal(model.panes.right.scrollTop, 42);
  assert.equal(model.panes.left.home, '/left-home');
  assert.equal(model.panes.right.home, '/right-home');
});

test('recent paths are deduplicated in newest-first order and capped at twenty', () => {
  const model = new FileManagerModel();
  for (let index = 0; index < 24; index += 1) model.touchRecent(`/path/${index}`);
  assert.equal(model.recent.length, 20);
  assert.equal(model.recent[0].path, '/path/23');
  model.touchRecent('/path/10');
  assert.equal(model.recent[0].path, '/path/10');
  assert.equal(model.recent.filter(item => item.path === '/path/10').length, 1);
});

test('bookmarks support deduplication, notes, deletion and serializable snapshots', () => {
  const model = new FileManagerModel();
  assert.equal(model.addBookmark('/sdcard/Download'), true);
  assert.equal(model.addBookmark('/sdcard/Download'), false);
  assert.equal(model.updateBookmarkNote('/sdcard/Download', '下载目录'), true);
  assert.deepEqual(model.placesSnapshot().bookmarks, [{ path: '/sdcard/Download', note: '下载目录' }]);
  assert.equal(model.removeBookmark('/sdcard/Download'), true);
  assert.equal(model.bookmarks.length, 0);
});

test('selection is locked to its source pane', () => {
  const model = new FileManagerModel();
  model.navigate('left', '/source');
  model.navigate('right', '/target');
  model.setEntries('left', [{ name: 'a', isDir: false }, { name: 'b', isDir: true }]);
  model.beginSelection('left', '/source/a');
  assert.equal(model.toggleSelection('right', '/target/x'), false);
  model.toggleSelection('left', '/source/b');
  assert.deepEqual(Array.from(model.selectedPaths).sort(), ['/source/a', '/source/b']);
});

test('operation snapshot fixes the opposite pane destination', () => {
  const model = new FileManagerModel();
  model.navigate('left', '/source');
  model.navigate('right', '/target');
  model.beginSelection('left', '/source/a');
  const snapshot = model.operationSnapshot('copy');
  model.navigate('right', '/changed-later');
  assert.equal(snapshot.destination, '/target');
  assert.equal(snapshot.sourcePane, 'left');
  assert.equal(snapshot.destinationPane, 'right');
});

test('select all and invert operate only on current source entries', () => {
  const model = new FileManagerModel();
  model.navigate('left', '/source');
  model.setEntries('left', [{ name: 'a' }, { name: 'b' }, { name: 'c' }]);
  model.beginSelection('left', '/source/a');
  model.selectAll();
  assert.equal(model.selectedPaths.size, 3);
  model.toggleSelection('left', '/source/c');
  model.invertSelection();
  assert.deepEqual(Array.from(model.selectedPaths), ['/source/c']);
});
