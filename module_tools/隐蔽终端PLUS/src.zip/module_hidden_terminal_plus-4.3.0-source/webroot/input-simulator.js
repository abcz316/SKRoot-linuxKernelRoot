(() => {
  const app = window.SKRootApp;
  const ui = window.SKUiUtils;
  const modelApi = window.SKAutomationModel;
  if (!app || !ui || !modelApi) return;

  const { cmd, sendBtn, autoBtn, fileBtn, sheetOverlay, quickActions } = app.elements;
  const { AutomationModel, normalizeStep } = modelApi;
  const terminalCore = window.SKTerminalCore;
  const composer = document.querySelector(".composer");

  const elements = {
    sheet: document.getElementById("autoSheet"),
    close: document.getElementById("autoClose"),
    draftState: document.getElementById("automationDraftState"),
    libraryTab: document.getElementById("automationLibraryTab"),
    editorTab: document.getElementById("automationEditorTab"),
    libraryView: document.getElementById("automationLibraryView"),
    editorView: document.getElementById("automationEditorView"),
    newScheme: document.getElementById("automationNewScheme"),
    schemeList: document.getElementById("automationSchemeList"),
    draftName: document.getElementById("automationDraftName"),
    failurePolicy: document.getElementById("automationFailurePolicy"),
    stepList: document.getElementById("autoList"),
    addZone: document.querySelector(".automation-add-zone"),
    save: document.getElementById("automationSave"),
    saveMore: document.getElementById("automationSaveMore"),
    saveMenu: document.getElementById("automationSaveMenu"),
    execute: document.getElementById("autoExecBtn"),
    quickSchemes: document.getElementById("automationQuickSchemes"),
    runBar: document.getElementById("automationRunBar"),
    runName: document.getElementById("automationRunName"),
    runState: document.getElementById("automationRunState"),
    runProgress: document.getElementById("automationRunProgress"),
    runDetail: document.getElementById("automationRunDetail"),
  };

  const nameDialog = {
    modal: document.getElementById("automationNameModal"),
    title: document.getElementById("automationNameTitle"),
    input: document.getElementById("automationNameInput"),
    cancel: document.getElementById("automationNameCancel"),
    ok: document.getElementById("automationNameConfirm"),
  };

  const schemeAction = {
    modal: document.getElementById("automationSchemeActionModal"),
    title: document.getElementById("automationSchemeActionTitle"),
    target: document.getElementById("automationSchemeActionTarget"),
    run: document.getElementById("automationSchemeRun"),
    edit: document.getElementById("automationSchemeEdit"),
    favorite: document.getElementById("automationSchemeFavorite"),
    rename: document.getElementById("automationSchemeRename"),
    duplicate: document.getElementById("automationSchemeDuplicate"),
    delete: document.getElementById("automationSchemeDelete"),
    cancel: document.getElementById("automationSchemeActionCancel"),
  };

  const model = new AutomationModel();
  let loaded = false;
  let activeView = "library";
  let saveTimer = null;
  let saveQueue = Promise.resolve();
  let pendingRun = null;
  let runStarting = false;
  let activeRun = null;
  let runPollTimer = null;
  let schemeActionId = "";
  let nameAction = null;
  let dragIndex = -1;
  let pointerDrag = null;

  const runStateNames = {
    idle: "空闲",
    preparing: "准备中",
    running: "执行中",
    completed: "执行完成",
    failed: "执行失败",
  };

  function safeAttr(value) { return ui.safeHtml(String(value ?? "")); }

  function serializeArgs(args) {
    return (Array.isArray(args) ? args : []).map(value => terminalCore.shellQuote(value)).join(" ");
  }

  function setDraftState(text, type = "") {
    elements.draftState.textContent = text;
    elements.draftState.classList.toggle("saving", type === "saving");
    elements.draftState.classList.toggle("error", type === "error");
  }

  function closeSaveMenu() {
    if (!elements.saveMenu || !elements.saveMore) return;
    elements.saveMenu.hidden = true;
    elements.saveMore.setAttribute("aria-expanded", "false");
    elements.saveMore.classList.remove("active");
  }

  function toggleSaveMenu() {
    if (!elements.saveMenu || !elements.saveMore) return;
    const open = elements.saveMenu.hidden;
    elements.saveMenu.hidden = !open;
    elements.saveMore.setAttribute("aria-expanded", String(open));
    elements.saveMore.classList.toggle("active", open);
    const rename = elements.saveMenu.querySelector('[data-save-action="rename"]');
    if (rename) rename.disabled = !model.draft.schemeId;
  }

  function setView(view) {
    activeView = view === "editor" ? "editor" : "library";
    closeSaveMenu();
    const editing = activeView === "editor";
    elements.libraryTab.classList.toggle("active", !editing);
    elements.editorTab.classList.toggle("active", editing);
    elements.libraryView.hidden = editing;
    elements.editorView.hidden = !editing;
    if (editing) renderEditor();
    else renderLibrary();
  }

  function renderQuickSchemes() {
    const favorites = model.favorites();
    elements.quickSchemes.hidden = favorites.length === 0;
    elements.quickSchemes.innerHTML = favorites.map(scheme =>
      `<button class="automation-quick-card" type="button" data-scheme-id="${safeAttr(scheme.id)}" title="${safeAttr(scheme.name)}"><span>${ui.safeHtml(scheme.name)}</span></button>`
    ).join("");
  }

  function renderLibrary() {
    if (!model.schemes.length) {
      elements.schemeList.innerHTML = '<div class="automation-empty"><strong>还没有保存方案</strong><span>新建方案或将当前草稿保存后，可在这里快捷使用。</span></div>';
      renderQuickSchemes();
      return;
    }
    elements.schemeList.innerHTML = model.schemes.map(scheme => {
      const policy = scheme.failurePolicy === "continue" ? "遇错继续" : "遇错停止";
      return `<div class="automation-scheme-card" data-scheme-id="${safeAttr(scheme.id)}" role="button" tabindex="0">
        <div class="automation-scheme-icon">▶</div>
        <div class="automation-scheme-main">
          <div class="automation-scheme-title"><span>${ui.safeHtml(scheme.name)}</span>${scheme.favorite ? '<span class="automation-favorite-mark">★</span>' : ""}</div>
          <div class="automation-scheme-meta">${scheme.steps.length} 个步骤 · ${policy}</div>
        </div>
        <button class="automation-scheme-more" type="button" aria-label="方案操作">⋮</button>
      </div>`;
    }).join("");
    renderQuickSchemes();
  }

  function inputRows(step, stepIndex) {
    if (!step.inputs?.length) return "";
    return step.inputs.map((input, inputIndex) => `<div class="automation-input-row" data-input-index="${inputIndex}">
      <input type="number" min="0" max="86400" step="0.1" value="${safeAttr(input.afterSec)}" data-input-field="afterSec" aria-label="启动后秒数" />
      <input type="text" maxlength="8192" value="${safeAttr(input.text)}" data-input-field="text" placeholder="发送文本" />
      <label><input type="checkbox" data-input-field="appendEnter" ${input.appendEnter ? "checked" : ""} />回车</label>
      <button type="button" data-step-action="remove-input" data-step-index="${stepIndex}" aria-label="删除自动输入">×</button>
    </div>`).join("");
  }

  function stepBody(step, index) {
    if (step.type === "wait") {
      return `<label class="automation-field"><span>等待秒数</span><input type="number" min="0.1" max="86400" step="0.1" value="${safeAttr(step.seconds)}" data-step-field="seconds" /></label>`;
    }
    const common = step.type === "script"
      ? `<label class="automation-field"><span>脚本或可执行文件</span><input type="text" maxlength="4096" value="${safeAttr(step.path)}" data-step-field="path" placeholder="/absolute/path/script.sh" /></label>`
      : `<div class="automation-command-fields">
          <label class="automation-field automation-command-field"><span>命令</span><textarea maxlength="8192" data-step-field="command" placeholder="输入 Shell 命令">${ui.safeHtml(step.command)}</textarea></label>
        </div>`;
    const args = step.type === "script"
      ? `<label class="automation-field"><span>参数</span><input type="text" maxlength="8192" value="${safeAttr(serializeArgs(step.args))}" data-step-field="args" placeholder="多个参数支持引号" /></label>` : "";
    return `${common}${args}<div class="automation-inputs">
      <div class="automation-input-title"><span>自动输入（相对步骤启动时间）</span><button type="button" data-step-action="add-input" data-step-index="${index}">+ 添加输入</button></div>
      ${inputRows(step, index)}
    </div>`;
  }

  function renderEditor() {
    const draft = model.draft;
    elements.draftName.value = draft.name || "";
    elements.failurePolicy.value = draft.failurePolicy;
    if (!draft.steps.length) {
      elements.stepList.innerHTML = '<div class="automation-empty"><strong>当前草稿为空</strong><span>添加脚本、命令或等待步骤。</span></div>';
    } else {
      elements.stepList.innerHTML = draft.steps.map((step, index) => `<article class="automation-step-card" data-step-index="${index}" draggable="true">
        <header class="automation-step-head">
          <span class="automation-drag-handle" title="拖动排序">☰</span>
          <span class="automation-step-number">${index + 1}</span>
          <span class="automation-step-type">${step.type === "script" ? "运行脚本" : step.type === "wait" ? "等待" : "执行命令"}</span>
          <div class="automation-step-tools">
            <button class="automation-step-tool" type="button" data-step-action="up" ${index === 0 ? "disabled" : ""} aria-label="上移" title="上移">↑</button>
            <button class="automation-step-tool" type="button" data-step-action="down" ${index === draft.steps.length - 1 ? "disabled" : ""} aria-label="下移" title="下移">↓</button>
            <button class="automation-step-tool" type="button" data-step-action="duplicate" aria-label="复制步骤" title="复制步骤">⧉</button>
            <button class="automation-step-tool danger" type="button" data-step-action="delete" aria-label="删除步骤" title="删除步骤">×</button>
          </div>
        </header>
        <div class="automation-step-body">${stepBody(step, index)}</div>
      </article>`).join("");
    }
    elements.save.textContent = "保存";
    elements.execute.disabled = !!activeRun && ["preparing", "running"].includes(activeRun.state);
  }

  function renderAll() {
    renderLibrary();
    renderEditor();
    renderRun();
  }

  async function loadConfig(force = false) {
    if (loaded && !force) return model.config;
    const config = await RequestApi.getAutomationConfig();
    model.setConfig(config);
    loaded = true;
    renderAll();
    return model.config;
  }

  function scheduleSave(immediate = false) {
    setDraftState("正在保存…", "saving");
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => persistConfig(), immediate ? 0 : 450);
  }

  function persistConfig() {
    clearTimeout(saveTimer);
    saveTimer = null;
    const request = saveQueue.catch(() => {}).then(async () => {
      const snapshot = model.snapshot();
      const saved = await RequestApi.setAutomationConfig(snapshot);
      model.config.revision = saved.revision;
      setDraftState("草稿已保存");
      renderQuickSchemes();
      return saved;
    }).catch(async error => {
      setDraftState("保存失败", "error");
      if (error?.code === "CONFIG_CHANGED") {
        await loadConfig(true).catch(() => {});
        alert("方案已在另一页面修改，已重新加载最新内容");
      }
      throw error;
    });
    saveQueue = request;
    return request;
  }

  function markChanged() {
    scheduleSave(false);
    renderQuickSchemes();
  }

  async function openAutoSheet(view = activeView) {
    autoBtn.classList.add("active");
    fileBtn.classList.remove("active");
    elements.sheet.classList.add("show");
    elements.sheet.setAttribute("aria-hidden", "false");
    sheetOverlay.classList.add("show");
    try {
      await loadConfig();
      setView(view);
    } catch (error) {
      setDraftState("加载失败", "error");
      alert(error?.message || "方案配置加载失败");
    }
  }

  function closeAutoSheet() {
    closeSaveMenu();
    elements.sheet.classList.remove("show");
    elements.sheet.setAttribute("aria-hidden", "true");
    autoBtn.classList.remove("active");
    if (!document.getElementById("fileWorkspace")?.classList.contains("show")) sheetOverlay.classList.remove("show");
  }

  function validateDraft() {
    if (!model.draft.steps.length) throw new Error("请至少添加一个步骤");
    model.draft.steps.forEach((step, index) => {
      if (step.type === "script" && !String(step.path || "").startsWith("/")) throw new Error(`第 ${index + 1} 步需要绝对脚本路径`);
      if (step.type === "command" && !String(step.command || "").trim()) throw new Error(`第 ${index + 1} 步命令为空`);
      if (step.type === "wait" && !(Number(step.seconds) > 0)) throw new Error(`第 ${index + 1} 步等待时间需要大于 0`);
      if (step.type === "wait" && Number(step.seconds) > 86400) throw new Error(`第 ${index + 1} 步等待时间不能超过 86400 秒`);
      for (const input of step.inputs || []) {
        if (Number(input.afterSec) > 86400) throw new Error(`第 ${index + 1} 步自动输入延时不能超过 86400 秒`);
      }
    });
  }

  function openNameDialog(action, value = "") {
    nameAction = action;
    nameDialog.title.textContent = action.type === "rename" ? "重命名方案" : action.copy ? "另存为方案" : "保存方案";
    nameDialog.input.value = value;
    ui.showModal(nameDialog.modal);
    setTimeout(() => { nameDialog.input.focus(); nameDialog.input.select(); }, 80);
  }

  async function confirmNameAction() {
    const name = nameDialog.input.value.trim();
    if (!nameAction) return;
    try {
      if (nameAction.type === "rename") model.renameScheme(nameAction.schemeId, name);
      else model.saveDraft(name, !!nameAction.copy);
      ui.hideModal(nameDialog.modal);
      nameAction = null;
      renderAll();
      await persistConfig();
      ui.showToast("方案已保存", 1400);
    } catch (error) {
      alert(error?.message || "方案保存失败");
    }
  }

  function schemeById(id) { return model.schemes.find(item => item.id === id); }

  function openSchemeAction(id) {
    const scheme = schemeById(id);
    if (!scheme) return;
    schemeActionId = id;
    schemeAction.title.textContent = "方案操作";
    schemeAction.target.textContent = `${scheme.name}\n${scheme.steps.length} 个步骤`;
    schemeAction.favorite.textContent = scheme.favorite ? "取消收藏" : "收藏到终端";
    ui.showModal(schemeAction.modal);
  }

  function runCandidate(payload) {
    if (payload.schemeId) return schemeById(payload.schemeId);
    return { id: "", name: model.draft.name || "未保存草稿", failurePolicy: model.draft.failurePolicy, steps: model.draft.steps };
  }

  function openRunConfirm(payload) {
    const candidate = runCandidate(payload);
    if (!candidate) return;
    if (runStarting || (activeRun && ["preparing", "running"].includes(activeRun.state))) {
      ui.showToast("已有方案正在执行", 1500);
      return;
    }
    if (!payload.schemeId) {
      try { validateDraft(); }
      catch (error) { alert(error.message); return; }
    }
    // A scheme is a deterministic input sequence. Start it immediately;
    // readiness/foreground checks are intentionally left to the user because
    // queued bytes may be meant for the currently running foreground program.
    pendingRun = payload;
    startPendingRun();
  }

  async function startPendingRun() {
    if (!pendingRun || runStarting) return;
    const runPayload = pendingRun;
    runStarting = true;
    elements.execute.disabled = true;
    try {
      await persistConfig();
      activeRun = await RequestApi.startAutomationRun(runPayload);
      if (pendingRun === runPayload) pendingRun = null;
      closeAutoSheet();
      renderRun();
      pollRun();
    } catch (error) {
      alert(error?.message || "方案启动失败");
    } finally {
      runStarting = false;
      elements.execute.disabled = activeRunState();
    }
  }

  function activeRunState() {
    return !!activeRun && ["preparing", "running"].includes(activeRun.state);
  }

  function renderRun() {
    const active = activeRunState();
    const visible = !!activeRun?.id;
    elements.runBar.hidden = !visible;
    composer?.classList.toggle("automation-locked", active);
    cmd.disabled = active;
    sendBtn.disabled = active;
    if (quickActions) quickActions.setAttribute("aria-disabled", active ? "true" : "false");
    elements.execute.disabled = active;
    if (!visible) return;
    elements.runName.textContent = activeRun.name || "自动化方案";
    elements.runState.textContent = runStateNames[activeRun.state] || activeRun.state;
    const total = Number(activeRun.totalSteps) || 0;
    const done = Math.min(total, (Number(activeRun.successCount) || 0) + (Number(activeRun.failureCount) || 0));
    const percent = total > 0 ? Math.round((active ? Math.max(done, Number(activeRun.currentStep) || 0) : total) / total * 100) : 0;
    elements.runProgress.style.width = `${Math.min(100, percent)}%`;
    const step = activeRun.steps?.[Number(activeRun.currentStep) || 0];
    const stepText = step ? `第 ${(Number(activeRun.currentStep) || 0) + 1}/${total} 步 · ${step.type}` : `${done}/${total} 步`;
    elements.runDetail.textContent = `${stepText} · 成功 ${activeRun.successCount || 0} · 失败 ${activeRun.failureCount || 0}`;
  }

  async function pollRun() {
    clearTimeout(runPollTimer);
    if (!activeRun?.id) return;
    try {
      activeRun = await RequestApi.getAutomationRun(activeRun.id);
      renderRun();
      if (activeRunState()) {
        runPollTimer = setTimeout(pollRun, 500);
      } else {
        renderEditor();
        setTimeout(() => {
          if (!activeRunState()) {
            activeRun = null;
            renderRun();
          }
        }, 4500);
      }
    } catch (error) {
      console.warn("automation status failed", error);
      runPollTimer = setTimeout(pollRun, 1200);
    }
  }

  async function resumeRun() {
    try {
      const status = await RequestApi.getAutomationRun();
      if (status?.id) {
        activeRun = status;
        renderRun();
        if (activeRunState()) pollRun();
      }
    } catch (error) {
      console.warn("automation resume failed", error);
    }
  }

  function updateStepField(target) {
    const card = target.closest(".automation-step-card");
    if (!card) return;
    const index = Number(card.dataset.stepIndex);
    const step = model.draft.steps[index];
    if (!step) return;
    const field = target.dataset.stepField;
    if (field === "path" || field === "command") step[field] = target.value;
    else if (field === "seconds") step[field] = Math.min(86400, Math.max(0, Number(target.value) || 0));
    else if (field === "args") {
      try {
        step.args = terminalCore.splitShellArgs(target.value);
        target.setCustomValidity("");
      } catch (error) {
        target.setCustomValidity(error.message);
        return;
      }
    }
    markChanged();
  }

  function updateInputField(target) {
    const card = target.closest(".automation-step-card");
    const row = target.closest(".automation-input-row");
    if (!card || !row) return;
    const step = model.draft.steps[Number(card.dataset.stepIndex)];
    const input = step?.inputs?.[Number(row.dataset.inputIndex)];
    if (!input) return;
    const field = target.dataset.inputField;
    if (field === "appendEnter") input.appendEnter = target.checked;
    else if (field === "afterSec") input.afterSec = Math.min(86400, Math.max(0, Number(target.value) || 0));
    else if (field === "text") input.text = target.value;
    markChanged();
  }

  function handleStepAction(button) {
    const card = button.closest(".automation-step-card");
    const index = Number(button.dataset.stepIndex ?? card?.dataset.stepIndex);
    const action = button.dataset.stepAction;
    try {
      if (action === "up") model.moveStep(index, index - 1);
      else if (action === "down") model.moveStep(index, index + 1);
      else if (action === "duplicate") model.duplicateStep(index);
      else if (action === "delete") model.removeStep(index);
      else if (action === "add-input") model.addInput(index);
      else if (action === "remove-input") {
        const inputIndex = Number(button.closest(".automation-input-row")?.dataset.inputIndex);
        model.removeInput(index, inputIndex);
      } else return;
      renderEditor();
      markChanged();
    } catch (error) {
      alert(error.message);
    }
  }

  function installDragHandlers() {
    elements.stepList.addEventListener("dragstart", event => {
      const card = event.target.closest(".automation-step-card");
      if (!card) return;
      dragIndex = Number(card.dataset.stepIndex);
      card.classList.add("dragging");
      event.dataTransfer.effectAllowed = "move";
    });
    elements.stepList.addEventListener("dragover", event => {
      const card = event.target.closest(".automation-step-card");
      if (!card || dragIndex < 0) return;
      event.preventDefault();
      elements.stepList.querySelectorAll(".drag-over").forEach(node => node.classList.remove("drag-over"));
      card.classList.add("drag-over");
    });
    elements.stepList.addEventListener("drop", event => {
      const card = event.target.closest(".automation-step-card");
      if (!card || dragIndex < 0) return;
      event.preventDefault();
      const target = Number(card.dataset.stepIndex);
      if (model.moveStep(dragIndex, target)) markChanged();
      dragIndex = -1;
      renderEditor();
    });
    elements.stepList.addEventListener("dragend", () => {
      dragIndex = -1;
      elements.stepList.querySelectorAll(".dragging,.drag-over").forEach(node => node.classList.remove("dragging", "drag-over"));
    });

    elements.stepList.addEventListener("pointerdown", event => {
      const handle = event.target.closest(".automation-drag-handle");
      const card = handle?.closest(".automation-step-card");
      if (!handle || !card || event.button > 0) return;
      pointerDrag = { pointerId: event.pointerId, from: Number(card.dataset.stepIndex), to: Number(card.dataset.stepIndex), moved: false };
      handle.setPointerCapture?.(event.pointerId);
    });
    elements.stepList.addEventListener("pointermove", event => {
      if (!pointerDrag || pointerDrag.pointerId !== event.pointerId) return;
      event.preventDefault();
      pointerDrag.moved = true;
      const node = document.elementFromPoint(event.clientX, event.clientY)?.closest(".automation-step-card");
      if (!node) return;
      pointerDrag.to = Number(node.dataset.stepIndex);
      elements.stepList.querySelectorAll(".drag-over").forEach(item => item.classList.remove("drag-over"));
      node.classList.add("drag-over");
    }, { passive: false });
    const finish = event => {
      if (!pointerDrag || pointerDrag.pointerId !== event.pointerId) return;
      const { from, to, moved } = pointerDrag;
      pointerDrag = null;
      if (moved && model.moveStep(from, to)) markChanged();
      renderEditor();
    };
    elements.stepList.addEventListener("pointerup", finish);
    elements.stepList.addEventListener("pointercancel", finish);
  }

  autoBtn.onclick = () => openAutoSheet();
  elements.close.onclick = closeAutoSheet;
  elements.libraryTab.onclick = () => setView("library");
  elements.editorTab.onclick = () => setView("editor");
  elements.newScheme.onclick = () => {
    model.config.draft = { schemeId: null, name: "", failurePolicy: "stop", steps: [] };
    renderEditor();
    setView("editor");
    markChanged();
  };
  elements.draftName.oninput = () => { model.draft.name = elements.draftName.value; markChanged(); };
  elements.failurePolicy.onchange = () => { model.draft.failurePolicy = elements.failurePolicy.value; markChanged(); };
  elements.addZone.onclick = event => {
    const type = event.target.closest("[data-add-step]")?.dataset.addStep;
    if (!type) return;
    try {
      if (type === "script") model.addStep("script", { path: "", args: [], inputs: [] });
      else if (type === "wait") model.addStep("wait", { seconds: 1 });
      else model.addStep("command", { command: "", inputs: [] });
      renderEditor();
      markChanged();
      elements.stepList.scrollTop = elements.stepList.scrollHeight;
    } catch (error) { alert(error.message); }
  };
  elements.stepList.addEventListener("input", event => {
    if (event.target.dataset.stepField) updateStepField(event.target);
    else if (event.target.dataset.inputField) updateInputField(event.target);
  });
  elements.stepList.addEventListener("change", event => {
    if (event.target.dataset.inputField) updateInputField(event.target);
  });
  elements.stepList.addEventListener("click", event => {
    const button = event.target.closest("[data-step-action]");
    if (button) handleStepAction(button);
  });
  installDragHandlers();

  elements.save.onclick = () => {
    closeSaveMenu();
    try { validateDraft(); }
    catch (error) { alert(error.message); return; }
    if (model.draft.schemeId) {
      try {
        model.saveDraft(model.draft.name, false);
        renderAll();
        persistConfig().then(() => ui.showToast("方案已保存", 1400)).catch(error => alert(error?.message || "方案保存失败"));
      } catch (error) { alert(error.message); }
    } else openNameDialog({ type: "save", copy: false }, model.draft.name);
  };
  elements.saveMore.onclick = event => {
    event.stopPropagation();
    toggleSaveMenu();
  };
  elements.saveMenu.onclick = event => {
    const item = event.target.closest("[data-save-action]");
    if (!item || item.disabled) return;
    const saveAction = item.dataset.saveAction;
    closeSaveMenu();
    if (saveAction === "copy") {
      try { validateDraft(); }
      catch (error) { alert(error.message); return; }
      openNameDialog({ type: "save", copy: true }, model.draft.name ? `${model.draft.name} 副本` : "");
    } else if (saveAction === "rename" && model.draft.schemeId) {
      openNameDialog({ type: "rename", schemeId: model.draft.schemeId }, model.draft.name);
    }
  };
  elements.execute.onclick = () => openRunConfirm({ source: "draft" });

  document.addEventListener("click", event => {
    if (!event.target.closest(".automation-save-wrap")) closeSaveMenu();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") closeSaveMenu();
  });

  elements.schemeList.addEventListener("click", event => {
    const card = event.target.closest(".automation-scheme-card");
    if (!card) return;
    if (event.target.closest(".automation-scheme-more")) openSchemeAction(card.dataset.schemeId);
    else openRunConfirm({ schemeId: card.dataset.schemeId });
  });
  elements.schemeList.addEventListener("keydown", event => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const card = event.target.closest(".automation-scheme-card");
    if (!card) return;
    event.preventDefault();
    openRunConfirm({ schemeId: card.dataset.schemeId });
  });
  elements.quickSchemes.onclick = event => {
    const card = event.target.closest("[data-scheme-id]");
    if (card) openRunConfirm({ schemeId: card.dataset.schemeId });
  };

  schemeAction.cancel.onclick = () => { schemeActionId = ""; ui.hideModal(schemeAction.modal); };
  schemeAction.run.onclick = () => { const id = schemeActionId; ui.hideModal(schemeAction.modal); openRunConfirm({ schemeId: id }); };
  schemeAction.edit.onclick = () => {
    if (model.loadScheme(schemeActionId)) {
      ui.hideModal(schemeAction.modal);
      renderEditor();
      setView("editor");
      markChanged();
    }
  };
  schemeAction.favorite.onclick = async () => {
    try {
      model.toggleFavorite(schemeActionId);
      ui.hideModal(schemeAction.modal);
      renderAll();
      await persistConfig();
    } catch (error) { alert(error.message); }
  };
  schemeAction.rename.onclick = () => {
    const scheme = schemeById(schemeActionId);
    ui.hideModal(schemeAction.modal);
    if (scheme) openNameDialog({ type: "rename", schemeId: scheme.id }, scheme.name);
  };
  schemeAction.duplicate.onclick = async () => {
    try {
      model.duplicateScheme(schemeActionId);
      ui.hideModal(schemeAction.modal);
      renderAll();
      await persistConfig();
    } catch (error) { alert(error.message); }
  };
  schemeAction.delete.onclick = async () => {
    const scheme = schemeById(schemeActionId);
    if (!scheme || !window.confirm(`确定删除方案“${scheme.name}”吗？`)) return;
    model.deleteScheme(scheme.id);
    schemeActionId = "";
    ui.hideModal(schemeAction.modal);
    renderAll();
    try { await persistConfig(); } catch (error) { alert(error?.message || "删除方案失败"); }
  };

  nameDialog.cancel.onclick = () => { nameAction = null; ui.hideModal(nameDialog.modal); };
  nameDialog.ok.onclick = confirmNameAction;
  nameDialog.input.onkeydown = event => { if (event.key === "Enter") { event.preventDefault(); confirmNameAction(); } };
  sheetOverlay.addEventListener("click", () => {
    if (typeof app.closeAllSheets === "function") app.closeAllSheets();
  });

  function legacyTasks() {
    let pendingDelay = 0;
    const result = [];
    for (const step of model.draft.steps) {
      if (step.type === "wait") { pendingDelay += Number(step.seconds) || 0; continue; }
      if (step.type === "command") result.push({ cmd: step.command, delay: String(pendingDelay || 0) });
      else if (step.type === "script") {
        const args = serializeArgs(step.args);
        result.push({ cmd: terminalCore.buildShCommand(step.path, args), delay: String(pendingDelay || 0) });
      }
      pendingDelay = 0;
    }
    return result;
  }

  function replaceLegacyTasks(tasks) {
    const steps = [];
    (Array.isArray(tasks) ? tasks : []).forEach((task, index) => {
      const delay = Number(task?.delay) || 0;
      if (delay > 0) steps.push(normalizeStep({ type: "wait", seconds: delay }));
      if (String(task?.cmd || "").trim()) steps.push(normalizeStep({ type: "command", command: String(task.cmd) }));
    });
    model.config.draft = { schemeId: null, name: "", failurePolicy: "stop", steps };
    renderEditor();
    markChanged();
  }

  async function appendScript(path, args = []) {
    await loadConfig();
    model.appendScript(path, args);
    renderEditor();
    await persistConfig();
    await openAutoSheet("editor");
  }

  window.SKInputSimulator = {
    open: openAutoSheet,
    close: closeAutoSheet,
    getTasks: legacyTasks,
    replaceTasks: replaceLegacyTasks,
    renderTasks: renderEditor,
    appendScript,
    getConfig: () => model.snapshot(),
    model,
  };
  app.openAutoSheet = openAutoSheet;

  const previousCloseAllSheets = app.closeAllSheets;
  app.closeAllSheets = () => {
    if (typeof previousCloseAllSheets === "function") previousCloseAllSheets();
    closeAutoSheet();
  };

  loadConfig().catch(error => console.warn("automation config load failed", error));
  resumeRun();
})();
