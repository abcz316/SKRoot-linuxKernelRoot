(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.SKAutomationModel = api;
})(typeof globalThis !== "undefined" ? globalThis : this, () => {
  const MAX_SCHEMES = 50;
  const MAX_FAVORITES = 6;
  const MAX_STEPS = 100;
  const MAX_INPUTS = 32;

  function makeId(prefix = "id") {
    const bytes = new Uint8Array(10);
    if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes);
    else for (let index = 0; index < bytes.length; index += 1) bytes[index] = Math.floor(Math.random() * 256);
    return `${prefix}_${Array.from(bytes, value => value.toString(16).padStart(2, "0")).join("")}`;
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function normalizeInput(value = {}) {
    return {
      id: String(value.id || makeId("input")),
      afterSec: Math.min(86400, Math.max(0, Number(value.afterSec) || 0)),
      text: String(value.text || ""),
      appendEnter: value.appendEnter !== false,
    };
  }

  function normalizeStep(value = {}) {
    const type = ["script", "command", "wait"].includes(value.type) ? value.type : "command";
    const step = { id: String(value.id || makeId("step")), type };
    if (type === "script") {
      step.path = String(value.path || "");
      step.args = Array.isArray(value.args) ? value.args.map(item => String(item)) : [];
      step.inputs = (Array.isArray(value.inputs) ? value.inputs : []).slice(0, MAX_INPUTS).map(normalizeInput);
    } else if (type === "command") {
      step.command = String(value.command || "");
      step.inputs = (Array.isArray(value.inputs) ? value.inputs : []).slice(0, MAX_INPUTS).map(normalizeInput);
    } else {
      step.seconds = Math.min(86400, Math.max(0, Number(value.seconds) || 0));
    }
    return step;
  }

  function normalizeDraft(value = {}) {
    return {
      schemeId: value.schemeId ? String(value.schemeId) : null,
      name: String(value.name || ""),
      failurePolicy: value.failurePolicy === "continue" ? "continue" : "stop",
      steps: (Array.isArray(value.steps) ? value.steps : []).slice(0, MAX_STEPS).map(normalizeStep),
    };
  }

  function normalizeScheme(value = {}) {
    const draft = normalizeDraft(value);
    return {
      id: String(value.id || makeId("scheme")),
      name: String(value.name || "").trim(),
      favorite: value.favorite === true,
      failurePolicy: draft.failurePolicy,
      createdAtMs: Number(value.createdAtMs) || Date.now(),
      updatedAtMs: Number(value.updatedAtMs) || Date.now(),
      steps: draft.steps,
    };
  }

  function normalizeConfig(value = {}) {
    return {
      revision: Math.max(0, Number(value.revision) || 0),
      draft: normalizeDraft(value.draft),
      schemes: (Array.isArray(value.schemes) ? value.schemes : []).slice(0, MAX_SCHEMES).map(normalizeScheme),
    };
  }

  function stepLabel(step, index = 0) {
    if (step.type === "script") return step.path.split("/").filter(Boolean).pop() || `脚本 ${index + 1}`;
    if (step.type === "wait") return `等待 ${step.seconds || 0} 秒`;
    const firstLine = String(step.command || "").trim().split("\n")[0];
    return firstLine || `命令 ${index + 1}`;
  }

  class AutomationModel {
    constructor(config = {}) {
      this.config = normalizeConfig(config);
    }

    setConfig(config) { this.config = normalizeConfig(config); }
    snapshot() { return clone(this.config); }
    get draft() { return this.config.draft; }
    get schemes() { return this.config.schemes; }
    favorites() { return this.schemes.filter(item => item.favorite).slice(0, MAX_FAVORITES); }

    addStep(type, value = {}) {
      if (this.draft.steps.length >= MAX_STEPS) throw new Error("每个方案最多 100 个步骤");
      const step = normalizeStep({ ...value, id: makeId("step"), type });
      this.draft.steps.push(step);
      return step;
    }

    appendScript(path, args = []) {
      return this.addStep("script", { path, args, inputs: [] });
    }

    removeStep(index) {
      if (index < 0 || index >= this.draft.steps.length) return false;
      this.draft.steps.splice(index, 1);
      return true;
    }

    moveStep(from, to) {
      if (from < 0 || from >= this.draft.steps.length || to < 0 || to >= this.draft.steps.length || from === to) return false;
      const [step] = this.draft.steps.splice(from, 1);
      this.draft.steps.splice(to, 0, step);
      return true;
    }

    duplicateStep(index) {
      if (this.draft.steps.length >= MAX_STEPS) throw new Error("每个方案最多 100 个步骤");
      const source = this.draft.steps[index];
      if (!source) return null;
      const copy = normalizeStep({ ...clone(source), id: makeId("step") });
      copy.inputs = (copy.inputs || []).map(input => ({ ...input, id: makeId("input") }));
      this.draft.steps.splice(index + 1, 0, copy);
      return copy;
    }

    addInput(stepIndex) {
      const step = this.draft.steps[stepIndex];
      if (!step || step.type === "wait") return null;
      if (step.inputs.length >= MAX_INPUTS) throw new Error("每个步骤最多 32 条自动输入");
      const input = normalizeInput({ id: makeId("input") });
      step.inputs.push(input);
      return input;
    }

    removeInput(stepIndex, inputIndex) {
      const inputs = this.draft.steps[stepIndex]?.inputs;
      if (!inputs || inputIndex < 0 || inputIndex >= inputs.length) return false;
      inputs.splice(inputIndex, 1);
      return true;
    }

    loadScheme(id) {
      const scheme = this.schemes.find(item => item.id === id);
      if (!scheme) return false;
      this.config.draft = normalizeDraft({
        schemeId: scheme.id,
        name: scheme.name,
        failurePolicy: scheme.failurePolicy,
        steps: clone(scheme.steps),
      });
      return true;
    }

    saveDraft(name, copyMode = false) {
      const normalizedName = String(name || "").trim();
      if (!normalizedName) throw new Error("方案名称不能为空");
      const existingName = this.schemes.find(item => item.name === normalizedName && item.id !== this.draft.schemeId);
      if (existingName) throw new Error("方案名称已存在");
      const now = Date.now();
      let scheme = !copyMode && this.draft.schemeId ? this.schemes.find(item => item.id === this.draft.schemeId) : null;
      if (!scheme) {
        if (this.schemes.length >= MAX_SCHEMES) throw new Error("最多保存 50 个方案");
        scheme = normalizeScheme({ id: makeId("scheme"), name: normalizedName, createdAtMs: now, updatedAtMs: now });
        this.schemes.unshift(scheme);
      }
      scheme.name = normalizedName;
      scheme.failurePolicy = this.draft.failurePolicy;
      scheme.steps = clone(this.draft.steps).map(normalizeStep);
      scheme.updatedAtMs = now;
      this.draft.schemeId = scheme.id;
      this.draft.name = normalizedName;
      return scheme;
    }

    deleteScheme(id) {
      const index = this.schemes.findIndex(item => item.id === id);
      if (index < 0) return false;
      this.schemes.splice(index, 1);
      if (this.draft.schemeId === id) this.draft.schemeId = null;
      return true;
    }

    duplicateScheme(id) {
      const source = this.schemes.find(item => item.id === id);
      if (!source) return null;
      if (this.schemes.length >= MAX_SCHEMES) throw new Error("最多保存 50 个方案");
      let name = `${source.name} 副本`;
      let suffix = 2;
      while (this.schemes.some(item => item.name === name)) name = `${source.name} 副本 ${suffix++}`;
      const copy = normalizeScheme({ ...clone(source), id: makeId("scheme"), name, favorite: false, createdAtMs: Date.now(), updatedAtMs: Date.now() });
      this.schemes.unshift(copy);
      return copy;
    }

    renameScheme(id, name) {
      const normalizedName = String(name || "").trim();
      if (!normalizedName) throw new Error("方案名称不能为空");
      if (this.schemes.some(item => item.id !== id && item.name === normalizedName)) throw new Error("方案名称已存在");
      const scheme = this.schemes.find(item => item.id === id);
      if (!scheme) return false;
      scheme.name = normalizedName;
      scheme.updatedAtMs = Date.now();
      if (this.draft.schemeId === id) this.draft.name = normalizedName;
      return true;
    }

    toggleFavorite(id) {
      const scheme = this.schemes.find(item => item.id === id);
      if (!scheme) return false;
      if (!scheme.favorite && this.favorites().length >= MAX_FAVORITES) throw new Error("最多收藏 6 个方案");
      scheme.favorite = !scheme.favorite;
      scheme.updatedAtMs = Date.now();
      return scheme.favorite;
    }
  }

  return {
    AutomationModel,
    normalizeConfig,
    normalizeDraft,
    normalizeStep,
    normalizeInput,
    stepLabel,
    makeId,
    MAX_SCHEMES,
    MAX_FAVORITES,
    MAX_STEPS,
    MAX_INPUTS,
  };
});
