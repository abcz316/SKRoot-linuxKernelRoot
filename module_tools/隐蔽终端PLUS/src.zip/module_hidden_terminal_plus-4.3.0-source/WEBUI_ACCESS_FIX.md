# WebUI loopback compatibility fixes (4.0.4–4.0.5)

The WebUI listener was running, but 4.0.3 compared CivetWeb's
`remote_addr` against four literal strings. Android networking components can
format the same loopback endpoint as an equivalent numeric IPv6 value such as
`::ffff:7f00:1`. The first document request was consequently answered with
`REMOTE_ACCESS_DENIED` before `index.html` could load.

Version 4.0.4 parses the numeric address with `inet_pton` and checks the
resulting address bytes. It accepts the complete IPv4 `127.0.0.0/8` loopback
range, IPv6 `::1`, and IPv4-mapped IPv6 loopback addresses. Non-loopback IPv4,
IPv6, and mapped addresses remain rejected. Host, Origin, and per-process
session-token checks are unchanged.

Some Android system browsers route localhost traffic through a browser network
or acceleration process only while Wi-Fi is active. In that case the accepted
connection can have a non-loopback peer address even though its local target
endpoint is still `127.0.0.1`. Version 4.0.5 correlates the request tuple with
the process's connected socket and accepts it only when that socket's local
destination is loopback. A request entering through a WLAN/mobile interface
keeps a non-loopback local destination and remains rejected, even if it spoofs
a loopback Host header.
