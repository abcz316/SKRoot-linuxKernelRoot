﻿#include "idle_killer.h"

static int64_t now_ns() {
    using namespace std::chrono;
    return duration_cast<nanoseconds>(steady_clock::now().time_since_epoch()).count();
}

static int64_t to_ns(std::chrono::seconds s) {
    using namespace std::chrono;
    return duration_cast<nanoseconds>(s).count();
}

IdleKiller::~IdleKiller() {
    stop();
}

void IdleKiller::start(std::chrono::seconds timeout, OnTimeout cb) {
    stop();
    m_timeout_ns = to_ns(timeout);
    m_on_timeout = std::move(cb);
    m_stop_requested.store(false, std::memory_order_release);

    touch();

    bool expected = false;
    if (!m_started.compare_exchange_strong(expected, true, std::memory_order_acq_rel)) {
        return;
    }

    m_thread = std::thread([this] {
        while (!m_stop_requested.load(std::memory_order_acquire)) {
            const auto last = m_last_activity_ns.load(std::memory_order_acquire);
            const auto now  = now_ns();

            if (last != 0 && (now - last) > m_timeout_ns.load(std::memory_order_acquire)) {
                // 先刷新一次，避免 callback 返回 false 后每秒疯狂触发
                touch();
                auto cb = m_on_timeout; // copy
                bool should_stop_thread = true;
                if (cb) {
                    should_stop_thread = cb();
                }
                if (should_stop_thread) {
                    break;
                }
                continue;
            }
            std::unique_lock<std::mutex> lk(m_wait_mu);
            m_wait_cv.wait_for(lk, std::chrono::seconds(1), [this] {
                return m_stop_requested.load(std::memory_order_acquire);
            });
        }
        m_started.store(false, std::memory_order_release);
    });
}

void IdleKiller::touch() {
    m_last_activity_ns.store(now_ns(), std::memory_order_release);
}

void IdleKiller::stop() {
    m_stop_requested.store(true, std::memory_order_release);
    m_wait_cv.notify_all();
    if (m_thread.joinable()) {
        if (m_thread.get_id() == std::this_thread::get_id()) {
            m_thread.detach();
        } else {
            m_thread.join();
        }
    }
    m_started.store(false, std::memory_order_release);
}
