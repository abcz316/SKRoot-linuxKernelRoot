﻿#pragma once
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <functional>
#include <mutex>
#include <thread>
#include <utility>

class IdleKiller {
public:
    // 返回 true：本次超时已经处理完，IdleKiller 线程结束
    // 返回 false：本次不杀，继续监控
    using OnTimeout = std::function<bool()>;

    ~IdleKiller();

    void start(std::chrono::seconds timeout, OnTimeout cb);
    void touch();
    void stop();

private:
    std::atomic<bool>    m_started{false};
    std::atomic<bool>    m_stop_requested{false};
    std::atomic<int64_t> m_last_activity_ns{0};
    std::atomic<int64_t> m_timeout_ns{0};
    std::mutex           m_wait_mu;
    std::condition_variable m_wait_cv;
    std::thread          m_thread;
    OnTimeout           m_on_timeout;
};
