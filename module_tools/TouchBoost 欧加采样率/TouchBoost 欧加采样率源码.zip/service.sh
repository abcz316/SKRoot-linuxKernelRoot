#!/system/bin/sh
# TouchBoost 欧加采样率 - 服务脚本
# 基于OPPO游戏空间数据库修改实现高采样率
# 0循环0耗电，开机执行一次后退出

# 等待系统启动完成
sleep 15

# 获取模块目录（通过脚本自身路径，不硬编码任何路径）
MODDIR="$(dirname "$(readlink -f "$0")")"
if [ ! -d "$MODDIR" ]; then
    MODDIR="${0%/*}"
fi

# 数据库路径
DB_PATH="/data/user/0/com.oplus.cosa/databases/db_game_database"
CONFIG_FILE="$MODDIR/touch.conf"
PACKAGE_CONF="$MODDIR/package.conf"
LOG_FILE="$MODDIR/log/touch_boost.log"

# 排除的包名（系统应用，不修改）
EXCLUDED_PACKAGES="com.ss.android.ugc.aweme com.oplus.ether oplus.cosa.default.model.config com.oplus.cosa"

# 统一字段值
FEATURE_FLAG="16777216"
CREATED_AT="2026-06-14 20:01:30"
MODIFIED_AT="2026-05-07 22:45:37"
OTHER="24831_false&"
FROM_SERVER="1"
COSA_VERSION="16.0.168"

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] TouchBoost: $1" >> "$LOG_FILE"
}

# 初始化日志
mkdir -p "$MODDIR/log"
echo "=== TouchBoost 启动 ===" > "$LOG_FILE"
log "模块目录: $MODDIR"

# 检查必要文件
if [ ! -f "$CONFIG_FILE" ]; then
    log "错误: 配置文件不存在: $CONFIG_FILE"
    exit 1
fi

if [ ! -f "$DB_PATH" ]; then
    log "错误: 游戏空间数据库不存在: $DB_PATH"
    log "请确认已安装OPPO游戏空间(com.oplus.cosa)"
    exit 1
fi

SQLITE3_PATH="$MODDIR/bin/sqlite3"
if [ ! -f "$SQLITE3_PATH" ]; then
    log "错误: sqlite3不存在: $SQLITE3_PATH"
    exit 1
fi
chmod 755 "$SQLITE3_PATH"

# 获取设备型号
DEVICE_MODEL=$(getprop ro.product.model)
log "设备型号: $DEVICE_MODEL"

# 1. 应用包名注入
if [ -f "$PACKAGE_CONF" ]; then
    log "开始注入游戏包名..."
    while IFS= read -r package_name || [ -n "$package_name" ]; do
        # 跳过空行和注释
        if [ -z "$package_name" ] || [[ "$package_name" == \#* ]]; then
            continue
        fi
        package_name=$(echo "$package_name" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        
        if [ -n "$package_name" ]; then
            existing=$("$SQLITE3_PATH" "$DB_PATH" "SELECT COUNT(*) FROM PackageConfigBean WHERE package_name = '$package_name';" 2>/dev/null)
            if [ "$existing" -eq 0 ] 2>/dev/null; then
                log "注入包名: $package_name"
                SQL="INSERT INTO PackageConfigBean (package_name, feature_flag, created_at, modified_at, other, from_server, cosa_version) VALUES ('$package_name', '$FEATURE_FLAG', '$CREATED_AT', '$MODIFIED_AT', '$OTHER', '$FROM_SERVER', '$COSA_VERSION');"
                if ! "$SQLITE3_PATH" "$DB_PATH" "$SQL" 2>/dev/null; then
                    log "注入失败: $package_name"
                fi
            fi
        fi
    done < "$PACKAGE_CONF"
else
    log "警告: package.conf不存在"
fi

# 2. 读取设备对应的采样率配置
NEW_CONFIG=""
while IFS= read -r line || [ -n "$line" ]; do
    if [ -z "$line" ] || [[ "$line" == \#* ]]; then
        continue
    fi
    MODEL=$(echo "$line" | cut -d: -f1)
    CONFIG=$(echo "$line" | cut -d: -f2-)
    if [ "$MODEL" = "$DEVICE_MODEL" ]; then
        NEW_CONFIG="$CONFIG"
        break
    fi
done < "$CONFIG_FILE"

# 如果没有找到精确匹配，尝试使用DEFAULT配置
if [ -z "$NEW_CONFIG" ]; then
    log "警告: 未找到设备 $DEVICE_MODEL 的精确配置，尝试使用DEFAULT通用配置"
    while IFS= read -r line || [ -n "$line" ]; do
        if [ -z "$line" ] || [[ "$line" == \#* ]]; then
            continue
        fi
        MODEL=$(echo "$line" | cut -d: -f1)
        if [ "$MODEL" = "DEFAULT" ]; then
            NEW_CONFIG=$(echo "$line" | cut -d: -f2-)
            break
        fi
    done < "$CONFIG_FILE"
fi

# 如果还是没有找到，使用第一个非注释行的配置
if [ -z "$NEW_CONFIG" ]; then
    log "警告: 未找到DEFAULT配置，使用第一个配置"
    while IFS= read -r line || [ -n "$line" ]; do
        if [ -z "$line" ] || [[ "$line" == \#* ]]; then
            continue
        fi
        NEW_CONFIG=$(echo "$line" | cut -d: -f2-)
        break
    done < "$CONFIG_FILE"
fi

if [ -z "$NEW_CONFIG" ]; then
    log "错误: 无可用的采样率配置"
    exit 1
fi

log "应用采样率配置..."

# 3. 获取所有已配置的包名
PACKAGES=$("$SQLITE3_PATH" "$DB_PATH" "SELECT DISTINCT package_name FROM PackageConfigBean;" 2>/dev/null)

if [ -z "$PACKAGES" ]; then
    log "错误: 数据库中无包名配置"
    exit 1
fi

SUCCESS_COUNT=0
ERROR_COUNT=0

# 4. 更新每个包名的采样率配置
for PACKAGE in $PACKAGES; do
    # 检查是否在排除列表中
    EXCLUDE=false
    for EXCLUDE_PKG in $EXCLUDED_PACKAGES; do
        if [ "$PACKAGE" = "$EXCLUDE_PKG" ]; then
            EXCLUDE=true
            break
        fi
    done
    
    if [ "$EXCLUDE" = true ]; then
        continue
    fi
    
    # 转义配置中的单引号
    ESCAPED_CONFIG=$(echo "$NEW_CONFIG" | sed "s/'/''/g")
    SQL="UPDATE PackageConfigBean SET refresh_rate = '$ESCAPED_CONFIG' WHERE package_name = '$PACKAGE';"
    
    if "$SQLITE3_PATH" "$DB_PATH" "$SQL" 2>/dev/null; then
        SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    else
        log "更新失败: $PACKAGE"
        ERROR_COUNT=$((ERROR_COUNT + 1))
    fi
done

log "完成! 成功: $SUCCESS_COUNT, 失败: $ERROR_COUNT"

# 清理日志（保留最后100行）
if [ -f "$LOG_FILE" ]; then
    tail -n 100 "$LOG_FILE" > "$LOG_FILE.tmp"
    mv "$LOG_FILE.tmp" "$LOG_FILE"
fi

log "=== TouchBoost 执行完成 ==="

# 退出（0循环0耗电）
exit 0
