LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := module_touch_boost

LOCAL_SRC_FILES := $(LOCAL_PATH)/../module_touch_boost.cpp

KERNEL_MODULE_KIT := /tmp/skp_sdk_rebuild/skp_ohmykeymint/kernel_module_kit
LOCAL_C_INCLUDES  += $(KERNEL_MODULE_KIT)/include
LOCAL_LDFLAGS  += $(KERNEL_MODULE_KIT)/lib/libkernel_module_kit_static.a

include $(LOCAL_PATH)/build_macros.mk

include $(BUILD_SHARED_LIBRARY)
