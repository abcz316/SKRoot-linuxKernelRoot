#include <iostream>
#include <unistd.h>
#include <algorithm>
#include <sys/wait.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <sstream>
#include <fstream>
#include "module_touch_boost.h"
#include "webroot_data.h"

#include "kernel_module_kit_umbrella.h"

#define MOD_VER "1.0.0"

using namespace std;

// 全局变量：模块私有目录（resources文件会自动释放到这里）
static std::string g_module_private_dir = "";

static std::string get_package_conf_path() {
    return g_module_private_dir + "package.conf";
}

static std::string get_touch_conf_path() {
    return g_module_private_dir + "touch.conf";
}

static std::string get_service_sh_path() {
    return g_module_private_dir + "service.sh";
}

static std::string get_log_path() {
    return g_module_private_dir + "log/touch_boost.log";
}

static std::string get_status_file_path() {
    return g_module_private_dir + "log/status";
}

static std::string get_package_conf() {
    std::string text;
    std::string path = get_package_conf_path();
    FILE* fp = fopen(path.c_str(), "r");
    if (fp) {
        char buf[4096];
        size_t n;
        while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) {
            text.append(buf, n);
        }
        fclose(fp);
    }
    return text;
}

static bool set_package_conf(const std::string& text) {
    std::string path = get_package_conf_path();
    FILE* fp = fopen(path.c_str(), "w");
    if (!fp) return false;
    fwrite(text.c_str(), 1, text.size(), fp);
    fclose(fp);
    return true;
}

static std::string get_touch_conf() {
    std::string text;
    std::string path = get_touch_conf_path();
    FILE* fp = fopen(path.c_str(), "r");
    if (fp) {
        char buf[4096];
        size_t n;
        while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) {
            text.append(buf, n);
        }
        fclose(fp);
    }
    return text;
}

static bool set_touch_conf(const std::string& text) {
    std::string path = get_touch_conf_path();
    FILE* fp = fopen(path.c_str(), "w");
    if (!fp) return false;
    fwrite(text.c_str(), 1, text.size(), fp);
    fclose(fp);
    return true;
}

static bool file_exists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

static std::string get_file_modify_time(const std::string& path) {
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return "未知";
    time_t t = st.st_mtime;
    struct tm* tm_info = localtime(&t);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", tm_info);
    return std::string(buf);
}

static std::string get_status() {
    // 检查状态文件
    std::string status_file = get_status_file_path();
    if (file_exists(status_file)) {
        FILE* fp = fopen(status_file.c_str(), "r");
        if (fp) {
            char buf[256] = {0};
            fread(buf, 1, sizeof(buf)-1, fp);
            fclose(fp);
            std::string status(buf);
            if (!status.empty()) return status;
        }
    }
    // 检查日志文件是否存在
    std::string log_file = get_log_path();
    if (file_exists(log_file)) {
        return "已执行";
    }
    return "待执行";
}

static std::string get_last_exec_time() {
    std::string log_file = get_log_path();
    if (file_exists(log_file)) {
        return get_file_modify_time(log_file);
    }
    return "从未执行";
}

static std::string get_game_list() {
    std::string conf = get_package_conf();
    std::string result;
    std::istringstream iss(conf);
    std::string line;
    while (std::getline(iss, line)) {
        if (!line.empty() && line[0] != '#' && line.find('.') != std::string::npos) {
            result += line + "\n";
        }
    }
    return result;
}

// 获取设备型号（通过getprop）
static std::string get_device_model() {
    FILE* fp = popen("getprop ro.product.model", "r");
    if (!fp) return "未知";
    char buf[256] = {0};
    fread(buf, 1, sizeof(buf)-1, fp);
    pclose(fp);
    std::string model(buf);
    // 去除换行符
    while (!model.empty() && (model.back() == '\n' || model.back() == '\r')) {
        model.pop_back();
    }
    return model.empty() ? "未知" : model;
}

// 获取包名列表（纯包名，不带注释）
static std::string get_packages() {
    return get_game_list();
}

// 立即执行service.sh
static std::string run_now() {
    bool ok = apply_config();
    return ok ? "OK" : "FAILED";
}

// 清除日志
static std::string clear_log() {
    std::string log_file = get_log_path();
    if (file_exists(log_file)) {
        remove(log_file.c_str());
    }
    // 同时清除状态文件
    std::string status_file = get_status_file_path();
    if (file_exists(status_file)) {
        remove(status_file.c_str());
    }
    return "OK";
}

static bool apply_config() {
    std::string service_sh = get_service_sh_path();
    printf("[TouchBoost] apply_config: %s\n", service_sh.c_str());

    // 先chdir到模块目录
    chdir(g_module_private_dir.c_str());

    // 执行service.sh
    int ret = fork_run_script_and_wait(service_sh.c_str());
    printf("[TouchBoost] service.sh exit code: %d\n", ret);

    // 写入状态文件
    std::string status_file = get_status_file_path();
    FILE* fp = fopen(status_file.c_str(), "w");
    if (fp) {
        if (ret == 0) {
            fprintf(fp, "已执行");
        } else {
            fprintf(fp, "执行失败(%d)", ret);
        }
        fclose(fp);
    }

    return ret == 0;
}

int skroot_module_main(const char* root_key, const char* module_private_dir) {
    printf("Hello! TouchBoost!\n");
    printf("[TouchBoost] module_private_dir: %s\n", module_private_dir);

    // 保存模块私有目录路径
    g_module_private_dir = module_private_dir;
    if (!g_module_private_dir.empty() && g_module_private_dir.back() != '/') {
        g_module_private_dir += "/";
    }

    // 创建log目录
    std::string log_dir = g_module_private_dir + "log";
    mkdir(log_dir.c_str(), 0777);

    // 设置资源文件权限（框架已经设置0777，这里再确保一下）
    std::string chmod_cmd = "chmod 755 " + g_module_private_dir + "*.sh " + g_module_private_dir + "bin/sqlite3 2>/dev/null";
    run_cmd(chmod_cmd);

    // 延迟15秒后执行service.sh（等待系统启动完成和游戏空间数据库就绪）
    std::string service_sh = get_service_sh_path();
    std::string mod_dir = g_module_private_dir;
    printf("[TouchBoost] will exec service.sh after 15s: %s\n", service_sh.c_str());
    fork_delayed_task(15, [service_sh, mod_dir] {
        printf("[TouchBoost] chdir to: %s\n", mod_dir.c_str());
        chdir(mod_dir.c_str());
        printf("[TouchBoost] exec service.sh: %s\n", service_sh.c_str());
        int ret = fork_run_script_and_wait(service_sh.c_str());
        printf("[TouchBoost] service.sh exit code: %d\n", ret);

        // 写入状态文件
        std::string status_file = mod_dir + "log/status";
        FILE* fp = fopen(status_file.c_str(), "w");
        if (fp) {
            if (ret == 0) {
                fprintf(fp, "已执行");
            } else {
                fprintf(fp, "执行失败(%d)", ret);
            }
            fclose(fp);
        }
    });

    return 0;
}

std::string module_on_install(const char* root_key, const char* module_private_dir) {
    printf("[TouchBoost] on install\n");
    printf("[TouchBoost] module_private_dir: %s\n", module_private_dir);
    g_module_private_dir = module_private_dir;
    if (!g_module_private_dir.empty() && g_module_private_dir.back() != '/') {
        g_module_private_dir += "/";
    }
    // 创建log目录
    std::string log_dir = g_module_private_dir + "log";
    mkdir(log_dir.c_str(), 0777);
    return "";
}

void module_on_uninstall(const char* root_key, const char* module_private_dir) {
    printf("[TouchBoost] on uninstall\n");
}

// WebUI HTTP服务器回调函数
class MyWebHttpHandler : public kernel_module::WebUIHttpHandler {
public:
    void onPrepareCreate(const char* root_key, const char* module_private_dir, uint32_t port) override {
        m_module_private_dir = module_private_dir;
        if (!m_module_private_dir.empty() && m_module_private_dir.back() != '/') {
            m_module_private_dir += "/";
        }
        // 同步全局变量
        g_module_private_dir = m_module_private_dir;
        printf("[TouchBoost] WebUI onPrepareCreate, module_private_dir: %s\n", module_private_dir);
    }

    bool handleGet(CivetServer* server, struct mg_connection* conn, const std::string& path, const std::string& query) override {
        printf("[TouchBoost] GET request: path=%s\n", path.c_str());

        if (path == "/" || path == "/index.html") {
            // 返回内嵌的WebUI
            kernel_module::webui::send_bytes(conn, 200, "text/html; charset=utf-8",
                webroot_index_html, webroot_index_html_len);
            return true;
        }

        std::string resp;
        if (path == "/getVersion") resp = MOD_VER;
        else if (path == "/getStatus") resp = get_status();
        else if (path == "/getLastExecTime") resp = get_last_exec_time();
        else if (path == "/getPackageConf") resp = get_package_conf();
        else if (path == "/getTouchConf") resp = get_touch_conf();
        else if (path == "/getGameList") resp = get_game_list();
        else if (path == "/getModuleDir") resp = g_module_private_dir;
        else if (path == "/getDeviceModel") resp = get_device_model();
        else if (path == "/getPackages") resp = get_packages();
        else if (path == "/runNow") resp = run_now();
        else if (path == "/clearLog") resp = clear_log();
        else if (path == "/getLog") {
            std::string log_file = get_log_path();
            if (file_exists(log_file)) {
                FILE* fp = fopen(log_file.c_str(), "r");
                if (fp) {
                    char buf[8192];
                    size_t n;
                    while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) {
                        resp.append(buf, n);
                    }
                    fclose(fp);
                }
            } else {
                resp = "日志文件不存在";
            }
        }

        kernel_module::webui::send_text(conn, 200, resp);
        return true;
    }

    bool handlePost(CivetServer* server, struct mg_connection* conn, const std::string& path, const std::string& body) override {
        printf("[TouchBoost] POST request: path=%s\n", path.c_str());

        std::string resp;
        if (path == "/setPackageConf") resp = set_package_conf(body) ? "OK" : "FAILED";
        else if (path == "/setTouchConf") resp = set_touch_conf(body) ? "OK" : "FAILED";
        else if (path == "/applyConfig") resp = apply_config() ? "OK" : "FAILED";
        else if (path == "/restartService") {
            // 清除旧状态
            std::string status_file = get_status_file_path();
            remove(status_file.c_str());
            sleep(1);
            resp = apply_config() ? "OK" : "FAILED";
        }

        kernel_module::webui::send_text(conn, 200, resp);
        return true;
    }
private:
    std::string m_module_private_dir;
};

// SKRoot 模块名片
SKROOT_MODULE_NAME("TouchBoost 欧加采样率")
SKROOT_MODULE_VERSION(MOD_VER)
SKROOT_MODULE_DESC("基于OPPO游戏空间数据库修改，为一加/OPPO设备添加游戏内最高采样率支持，0循环0耗电，支持自定义游戏包名")
SKROOT_MODULE_AUTHOR("1021")
SKROOT_MODULE_ID32("touch_boost_oplus_1021_000000000")
SKROOT_MODULE_WEB_UI(MyWebHttpHandler)
SKROOT_MODULE_ON_INSTALL(module_on_install)
SKROOT_MODULE_ON_UNINSTALL(module_on_uninstall)
