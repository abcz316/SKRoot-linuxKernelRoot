COMMON_CPPFLAGS := \
    -std=c++20 \
    -fexceptions \
    -fPIC \
    -fvisibility=hidden \
    -ffunction-sections \
    -fdata-sections \
    -Wall \
    -Wextra \
    -Wpedantic \
    -Werror \
    -Wno-unused-parameter

COMMON_LDFLAGS := \
    -Wl,-O2 \
    -Wl,--gc-sections \
    -Wl,-s

LOCAL_CPPFLAGS += $(COMMON_CPPFLAGS)
LOCAL_LDFLAGS += $(COMMON_LDFLAGS)
