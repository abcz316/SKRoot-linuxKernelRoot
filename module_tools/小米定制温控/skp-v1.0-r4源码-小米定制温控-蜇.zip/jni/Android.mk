LOCAL_PATH := $(call my-dir)

ifndef SKROOT_MODULE_KIT
$(error SKROOT_MODULE_KIT is not set; point it to testModule/kernel_module_kit)
endif

include $(CLEAR_VARS)
LOCAL_MODULE := kernel_module_kit_static
LOCAL_SRC_FILES := prebuilt/arm64-v8a/libkernel_module_kit_static.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := custom_thermal_skp
LOCAL_SRC_FILES := \
    ../native/platform.cpp \
    ../native/runtime.cpp \
    ../native/module.cpp
LOCAL_C_INCLUDES += $(LOCAL_PATH)/../native
LOCAL_CPPFLAGS += -isystem $(SKROOT_MODULE_KIT)/include
LOCAL_STATIC_LIBRARIES := kernel_module_kit_static

include $(LOCAL_PATH)/build_macros.mk
include $(BUILD_SHARED_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := custom_thermal_helper
LOCAL_SRC_FILES := ../native/controller_helper.cpp
include $(LOCAL_PATH)/build_macros.mk
include $(BUILD_EXECUTABLE)
