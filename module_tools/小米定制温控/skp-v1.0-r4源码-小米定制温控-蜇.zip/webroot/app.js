const state = { global: {}, limits: {}, apps: {} };
const ui = { appOpen: {} };

let parseBlocked = false;
let messageTimer = null;
let runtimeRefreshPromise = null;
const message = document.getElementById("message");

const $ = id => document.getElementById(id);

function setMessage(text, type = "") {
  if (!message) return;
  if (messageTimer !== null) {
    clearTimeout(messageTimer);
    messageTimer = null;
  }
  message.textContent = text;
  message.className = "message " + type + " visible";
  if (type === "ok") {
    messageTimer = setTimeout(() => {
      message.classList.remove("visible");
      messageTimer = null;
    }, 4500);
  }
}

function enc(s) {
  return encodeURIComponent(String(s));
}

function dec(s) {
  return decodeURIComponent(String(s || ""));
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function request(path, options = {}) {
  const response = await fetch(path, {
    method: options.method || "GET",
    body: options.body,
    credentials: "same-origin",
    headers: { "Cache-Control": "no-store", "Accept": "text/plain, application/json" }
  });
  const text = await response.text();
  if (!response.ok) {
    const detail = text.trim();
    const error = new Error(
      detail ? `HTTP ${response.status}: ${detail}` : `HTTP ${response.status}`
    );
    error.status = response.status;
    throw error;
  }
  return text;
}

async function requestJson(path) {
  const text = await request(path);
  try {
    return JSON.parse(text);
  } catch (_) {
    throw new Error("模块返回了无效状态数据");
  }
}

function setRuntimeBusy(busy) {
  document.querySelectorAll(".mode-option").forEach(button => {
    button.disabled = busy;
  });
  const toggle = $("controllerToggle");
  if (toggle) toggle.disabled = busy;
}

function setHealthItem(id, text, healthState) {
  const value = $(id);
  if (!value) return;

  value.textContent = text;
  const item = value.closest(".health-item");
  if (item) item.dataset.state = healthState;
}

function renderRuntimeStatus(status) {
  const device = status.marketName || status.device || "未知设备";
  if ($("deviceName")) $("deviceName").textContent = device;
  if ($("deviceMeta")) {
    $("deviceMeta").textContent = [status.device, status.kernel].filter(Boolean).join(" · ");
  }
  if ($("controllerToggle")) $("controllerToggle").checked = !!status.controllerEnabled;
  if ($("controllerState")) {
    const labels = {
      running: "控制器运行中",
      waiting: "控制器等待开机",
      restarting: "控制器正在重启"
    };
    const stoppedLabel = status.controllerEnabled ? "控制器异常停止" : "控制器未启用";
    $("controllerState").textContent =
      status.controllerState === "stopped"
        ? stoppedLabel
        : (labels[status.controllerState] || "控制器状态未知");
    $("controllerState").dataset.state = status.controllerState || "stopped";
    $("controllerState").classList.toggle(
      "warning",
      !!status.controllerEnabled && status.controllerState === "stopped"
    );
  }
  if ($("profilesState")) {
    const profileStates = {
      active: ["温控生效", "ok"],
      partial: ["部分属性未生效", "warning"],
      recovering: ["温控恢复中", "warning"],
      mismatch: ["模式不一致", "warning"],
      not_ready: ["配置未就绪", "error"],
      error: ["温控异常", "error"]
    };
    const fallback = status.profilesReady
      ? ["等待运行验证", "warning"]
      : ["配置缺失", "error"];
    const profileState = status.thermalActive
      ? profileStates.active
      : (profileStates[status.thermalState] || fallback);
    $("profilesState").textContent = profileState[0];
    $("profilesState").dataset.state = profileState[1];
    $("profilesState").classList.toggle("warning", profileState[1] === "warning");
  }
  document.querySelectorAll(".mode-option").forEach(button => {
    const active = button.dataset.mode === status.mode;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", active ? "true" : "false");
  });

  const thermalLabels = {
    active: "已生效",
    partial: "部分属性未生效",
    recovering: "正在恢复",
    error: "检测到错误",
    not_ready: "配置未就绪",
    mismatch: "模式不一致"
  };
  const thermalHealth = status.thermalActive || status.thermalState === "active"
    ? "ok"
    : (status.thermalState === "partial" || status.thermalState === "recovering" ||
       status.thermalState === "mismatch" ? "warning" : "error");
  setHealthItem(
    "thermalStateText",
    thermalLabels[status.thermalState] || "状态未知",
    thermalHealth
  );

  const expectedMode = String(status.mode || "").trim().toUpperCase();
  const activeMode = String(status.activeMode || "").trim().toUpperCase();
  const modeMatches = !!expectedMode && activeMode === expectedMode;
  const modeText = modeMatches
    ? `${activeMode} 已一致`
    : `${activeMode || "--"} / 期望 ${expectedMode || "--"}`;
  setHealthItem("activeModeState", modeText, modeMatches ? "ok" : "warning");

  const configFiles = Math.max(0, Number(status.thermalConfigFiles) || 0);
  setHealthItem("configFilesState", `${configFiles} 个文件`, configFiles > 0 ? "ok" : "error");

  const activeProperties = Math.max(0, Number(status.propertyOverridesActive) || 0);
  const totalProperties = Math.max(0, Number(status.propertyOverridesTotal) || 0);
  const propertiesHealth = totalProperties > 0 && activeProperties >= totalProperties
    ? "ok"
    : (activeProperties > 0 ? "warning" : "error");
  setHealthItem(
    "propertiesState",
    `${activeProperties}/${totalProperties} 已生效`,
    propertiesHealth
  );

  const transactionLabels = {
    clean: "正常",
    pending: "待恢复",
    committed: "已提交",
    error: "错误",
    invalid: "无效"
  };
  const transactionHealth = status.transactionState === "clean" ||
    status.transactionState === "committed"
    ? "ok"
    : (status.transactionState === "pending" ? "warning" : "error");
  setHealthItem(
    "transactionState",
    transactionLabels[status.transactionState] || status.transactionState || "未知",
    transactionHealth
  );
}

async function loadStatus() {
  const status = await requestJson("/api/status");
  renderRuntimeStatus(status);
  return status;
}

async function loadRuntimeLog() {
  const log = $("runtimeLog");
  if (!log) return;
  try {
    const text = await request("/api/log");
    log.textContent = text.trim() || "暂无运行记录";
  } catch (error) {
    log.textContent = `日志读取失败：${error.message || "未知错误"}`;
  }
}

async function refreshRuntime(silent = false) {
  if (!runtimeRefreshPromise) {
    runtimeRefreshPromise = (async () => {
      const status = await loadStatus();
      await loadRuntimeLog();
      return status;
    })().finally(() => {
      runtimeRefreshPromise = null;
    });
  }

  try {
    const status = await runtimeRefreshPromise;
    if (!silent) {
      if (status.thermalActive) {
        setMessage("温控正在工作：模式、配置文件、属性覆盖与事务状态均通过", "ok");
      } else if (status.thermalState === "partial") {
        setMessage("温控已加载，但部分属性覆盖未生效，请查看运行日志", "err");
      } else {
        setMessage("温控状态需要处理，请查看下方运行日志", "err");
      }
    }
    return status;
  } catch (error) {
    if (!silent) setMessage(error.message || "运行状态读取失败", "err");
    return null;
  }
}

async function changeMode(mode) {
  try {
    setRuntimeBusy(true);
    setMessage("正在切换温控模式...");
    const result = await request("/api/mode", { method: "POST", body: mode });
    await refreshRuntime(true);
    setMessage(result || "模式已切换", "ok");
  } catch (error) {
    setMessage(error.message || "模式切换失败", "err");
    try { await loadStatus(); } catch (_) { }
  } finally {
    setRuntimeBusy(false);
  }
}

async function changeController(enabled) {
  try {
    setRuntimeBusy(true);
    setMessage(enabled ? "正在启动控制器..." : "正在停止控制器...");
    const result = await request("/api/controller", {
      method: "POST",
      body: enabled ? "true" : "false"
    });
    await refreshRuntime(true);
    setMessage(result || "控制器状态已更新", "ok");
  } catch (error) {
    setMessage(error.message || "控制器状态更新失败", "err");
    try { await loadStatus(); } catch (_) { }
  } finally {
    setRuntimeBusy(false);
  }
}

function resetState() {
  state.global = {};
  state.limits = {};
  state.apps = {};
}

function makeRule(value, disabled = false) {
  return { value: String(value ?? ""), disabled: !!disabled };
}

function ensureApp(pkg) {
  pkg = String(pkg || "").trim();
  if (!pkg) return null;

  if (!state.apps[pkg]) {
    state.apps[pkg] = { config: {}, default: {} };
  }

  return state.apps[pkg];
}

function removeBom(text) {
  return String(text || "").replace(/^\uFEFF/, "");
}

function stripInlineComment(line) {
  let q = false, single = false, e = false;

  for (let i = 0; i < line.length; i++) {
    const c = line[i];

    if (e) {
      e = false;
      continue;
    }

    if (q && c === "\\") {
      e = true;
      continue;
    }

    if (!single && c === '"') {
      q = !q;
      continue;
    }

    if (!q && c === "'") {
      single = !single;
      continue;
    }

    if (!q && !single && c === "#") return line.slice(0, i);
  }

  return line;
}

function unescapeStr(s) {
  let out = "", e = false;

  for (let i = 0; i < s.length; i++) {
    const c = s[i];

    if (e) {
      out += c === "n" ? "\n" :
             c === "r" ? "\r" :
             c === "t" ? "\t" :
             c === "\\" ? "\\" :
             c === '"' ? '"' : c;
      e = false;
      continue;
    }

    if (c === "\\") {
      e = true;
      continue;
    }

    out += c;
  }

  return out;
}

function supportedStringToken(raw) {
  const s = String(raw || "").trim();
  if (s.length < 2) return false;
  if (s.startsWith("'") && s.endsWith("'")) {
    return !s.slice(1, -1).includes("'") && !/[\r\n]/.test(s.slice(1, -1));
  }
  if (!s.startsWith('"') || !s.endsWith('"')) return false;
  let escaped = false;
  for (let i = 1; i < s.length - 1; i++) {
    const c = s[i];
    if (escaped) {
      if (!['n', 'r', 't', '\\', '"'].includes(c)) return false;
      escaped = false;
    } else if (c === "\\") {
      escaped = true;
    } else if (c === '"' || c === "\n" || c === "\r") {
      return false;
    }
  }
  return !escaped;
}

function escapeStr(s) {
  return String(s)
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\r")
    .replace(/\t/g, "\\t");
}

function parseTomlString(raw) {
  const s = String(raw || "").trim();

  if (s.length >= 2 && s.startsWith('"') && s.endsWith('"')) {
    return unescapeStr(s.slice(1, -1));
  }

  if (s.length >= 2 && s.startsWith("'") && s.endsWith("'")) {
    return s.slice(1, -1);
  }

  return s;
}

function parseSection(line) {
  const m = line.match(/^\[\s*(.*?)\s*\]$/);
  if (!m) return null;

  const name = m[1].trim();

  if (name === "config") return { type: "global", pkg: "" };
  if (name === "limits") return { type: "limits", pkg: "" };

  if (name.startsWith("config.")) {
    const token = name.slice(7);
    const quoted = token.startsWith('"') || token.startsWith("'");
    return {
      type: "app-config",
      pkg: parseTomlString(token),
      supported: (quoted ? supportedStringToken(token) : /^[A-Za-z0-9_.-]+$/.test(token))
    };
  }

  if (name.startsWith("default.")) {
    const token = name.slice(8);
    const quoted = token.startsWith('"') || token.startsWith("'");
    return {
      type: "app-default",
      pkg: parseTomlString(token),
      supported: (quoted ? supportedStringToken(token) : /^[A-Za-z0-9_.-]+$/.test(token))
    };
  }

  if (name.startsWith("APP.")) {
    const token = name.slice(4);
    const quoted = token.startsWith('"') || token.startsWith("'");
    return {
      type: "app-config",
      pkg: parseTomlString(token),
      supported: (quoted ? supportedStringToken(token) : /^[A-Za-z0-9_.-]+$/.test(token))
    };
  }

  return null;
}

function findEq(line) {
  let q = false, single = false, e = false;

  for (let i = 0; i < line.length; i++) {
    const c = line[i];

    if (e) {
      e = false;
      continue;
    }

    if (q && c === "\\") {
      e = true;
      continue;
    }

    if (!single && c === '"') {
      q = !q;
      continue;
    }

    if (!q && c === "'") {
      single = !single;
      continue;
    }

    if (!q && !single && c === "=") return i;
  }

  return -1;
}

function parseKV(line) {
  const p = findEq(line);
  if (p < 0) return null;

  const left = line.slice(0, p).trim();
  const right = line.slice(p + 1).trim();

  if (!left) return null;

  let key;

  if (left.startsWith('"') && left.endsWith('"')) {
    key = unescapeStr(left.slice(1, -1));
  } else if (left.startsWith("'") && left.endsWith("'")) {
    key = left.slice(1, -1);
  } else {
    key = left;
  }

  if (!key) return null;

  return {
    key,
    value: parseTomlString(right),
    supported: supportedStringToken(left) && supportedStringToken(right)
  };
}

function parseLine(raw) {
  const t = String(raw || "").trim();

  if (!t) return { type: "empty" };

  if (t.startsWith("#")) {
    const body = t.slice(1).trim();
    const kv = parseKV(body);

    if (kv && kv.supported) {
      return { type: "kv", key: kv.key, value: kv.value, disabled: true,
        supported: true, inlineComment: false };
    }

    return { type: "comment" };
  }

  const withoutComment = stripInlineComment(raw);
  const clean = withoutComment.trim();
  const inlineComment = withoutComment.length !== String(raw || "").length;
  if (!clean) return { type: "comment" };

  const sec = parseSection(clean);
  if (sec) return { type: "section", section: sec, inlineComment };

  const kv = parseKV(clean);
  if (kv) return { type: "kv", key: kv.key, value: kv.value, disabled: false,
    supported: kv.supported, inlineComment };

  return { type: "unknown" };
}

function parseToml(text) {
  resetState();
  text = removeBom(text);

  let section = "", pkg = "";
  let sectionKey = "";
  let sectionRuleCount = 0;
  let blocked = false;
  const seenSections = new Set();
  const seenKeys = new Set();

  for (const raw of String(text || "").split(/\r?\n/)) {
    const item = parseLine(raw);

    if (item.type === "section") {
      if (sectionKey && sectionRuleCount === 0) blocked = true;
      section = item.section.type;
      pkg = item.section.pkg || "";
      sectionKey = `${section}:${pkg}`;
      sectionRuleCount = 0;
      if (item.inlineComment || item.section.supported === false ||
          seenSections.has(sectionKey)) blocked = true;
      seenSections.add(sectionKey);

      if ((section === "app-config" || section === "app-default") && pkg) {
        ensureApp(pkg);
      }

      continue;
    }

    if (item.type === "empty") continue;
    if (item.type !== "kv") {
      blocked = true;
      continue;
    }
    if (!sectionKey || item.supported === false || item.inlineComment) {
      blocked = true;
    }

    const keyIdentity = `${sectionKey}\n${item.key}`;
    if (seenKeys.has(keyIdentity)) blocked = true;
    seenKeys.add(keyIdentity);
    sectionRuleCount++;

    const rule = makeRule(item.value, item.disabled);

    if (section === "global") {
      state.global[item.key] = rule;
    } else if (section === "limits") {
      state.limits[item.key] = rule;
    } else if (section === "app-config" && pkg) {
      const app = ensureApp(pkg);
      if (app) app.config[item.key] = rule;
    } else if (section === "app-default" && pkg) {
      const app = ensureApp(pkg);
      if (app) app.default[item.key] = rule;
    }
  }
  if (sectionKey && sectionRuleCount === 0) blocked = true;
  return { blocked };
}

function countState() {
  let n = Object.keys(state.global).length + Object.keys(state.limits).length;

  for (const app of Object.values(state.apps)) {
    n += Object.keys(app.config).length + Object.keys(app.default).length;
  }

  return n;
}

function fmtPkg(pkg) {
  return /^[A-Za-z0-9_.]+$/.test(pkg) ? pkg : `"${escapeStr(pkg)}"`;
}

function ruleLine(path, rule) {
  const line = `"${escapeStr(path)}" = "${escapeStr(rule.value)}"`;
  return rule.disabled ? `# ${line}` : line;
}

function serializeToml() {
  const out = [];

  if (Object.keys(state.limits).length) {
    out.push("[limits]");
    for (const [p, r] of Object.entries(state.limits)) out.push(ruleLine(p, r));
    out.push("");
  }

  if (Object.keys(state.global).length) {
    out.push("[config]");
    for (const [p, r] of Object.entries(state.global)) out.push(ruleLine(p, r));
    out.push("");
  }

  for (const [pkg, app] of Object.entries(state.apps)) {
    if (Object.keys(app.config).length) {
      out.push(`[config.${fmtPkg(pkg)}]`);
      for (const [p, r] of Object.entries(app.config)) out.push(ruleLine(p, r));
      out.push("");
    }

    if (Object.keys(app.default).length) {
      out.push(`[default.${fmtPkg(pkg)}]`);
      for (const [p, r] of Object.entries(app.default)) out.push(ruleLine(p, r));
      out.push("");
    }
  }

  return out.join("\n").trim() + "\n";
}

async function readConfigText() {
  return request("/api/config");
}

async function loadConfig() {
  try {
    setMessage("正在读取配置...");
    parseBlocked = false;

    const text = await readConfigText();

    const parsed = parseToml(text);
    render();

    const n = countState();

    if (!text.trim()) {
      setMessage("配置为空或不存在");
    } else if (n === 0 || parsed.blocked) {
      parseBlocked = true;
      setMessage("配置包含无法无损保留的注释、重复项或语法，已禁止保存。", "err");
    } else {
      setMessage("配置已读取", "ok");
    }
  } catch (e) {
    resetState();
    render();
    parseBlocked = true;
    setMessage(e.message || "读取失败", "err");
  }
}

async function saveConfig() {
  try {
    if (parseBlocked) {
      setMessage("当前配置未成功解析，已阻止保存，避免覆盖原文件。", "err");
      return;
    }

    setMessage("正在保存...");
    await request("/api/config", { method: "POST", body: serializeToml() });

    render();
    setMessage("保存成功", "ok");
  } catch (e) {
    setMessage(e.message || "保存失败", "err");
  }
}

function getSearch(id) {
  return String($(id)?.value || "").trim().toLowerCase();
}

function shortPath(path) {
  const s = String(path);

  if (s.length <= 42) {
    return s;
  }

  const parts = s.split("/").filter(Boolean);

  if (parts.length >= 5) {
    return "/" + parts[0] + "/.../" + parts.slice(-3).join("/");
  }

  return s.slice(0, 20) + "..." + s.slice(-20);
}

function matchRule(path, rule, key) {
  if (!key) return true;
  return String(path).toLowerCase().includes(key) || String(rule.value).toLowerCase().includes(key);
}

function appRuleCount(app) {
  return Object.keys(app.config).length + Object.keys(app.default).length;
}

function appMatches(pkg, app, key) {
  if (!key) return true;
  if (pkg.toLowerCase().includes(key)) return true;

  for (const [p, r] of Object.entries(app.config)) if (matchRule(p, r, key)) return true;
  for (const [p, r] of Object.entries(app.default)) if (matchRule(p, r, key)) return true;

  return false;
}

function switchTab(name) {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));

  const t = $("view-" + name);
  if (t) t.classList.add("active");
}

function render() {
  renderRules("globalList", state.global, "global", "globalSearch", "暂无全局配置");
  renderRules("limitsList", state.limits, "limits", "limitsSearch", "暂无权限设置");
  renderApps();

  if ($("globalCount")) $("globalCount").textContent = `${Object.keys(state.global).length} 项`;
  if ($("limitsCount")) $("limitsCount").textContent = `${Object.keys(state.limits).length} 项`;
  if ($("appCount")) $("appCount").textContent = `${Object.keys(state.apps).length} 个应用`;
}

function renderRules(id, data, scope, searchId, emptyText) {
  const root = $(id);
  if (!root) return;

  const key = getSearch(searchId);
  const entries = Object.entries(data).filter(([p, r]) => matchRule(p, r, key));

  if (!entries.length) {
    root.innerHTML = `<div class="empty">${emptyText}</div>`;
    return;
  }

  root.innerHTML = entries.map(([p, r]) => `
    <div class="rule ${r.disabled ? "disabled" : ""}">
      <div class="rule-main">
        <div class="path" title="${escapeHtml(p)}">
          ${escapeHtml(shortPath(p))}
          ${r.disabled ? `<span class="badge">已禁用</span>` : ""}
        </div>
        <div class="value">值：<span>${escapeHtml(r.value)}</span></div>
      </div>
      <div class="rule-actions">
        <button class="btn small light js-edit-rule" data-scope="${scope}" data-path="${enc(p)}">编辑</button>
        <button class="btn small warn js-toggle-rule" data-scope="${scope}" data-path="${enc(p)}">${r.disabled ? "启用" : "禁用"}</button>
        <button class="btn small red js-delete-rule" data-scope="${scope}" data-path="${enc(p)}">删除</button>
      </div>
    </div>
  `).join("");
}

function renderApps() {
  const root = $("appList");
  if (!root) return;

  const key = getSearch("appSearch");
  const entries = Object.entries(state.apps).filter(([pkg, app]) => appMatches(pkg, app, key));

  if (!entries.length) {
    root.innerHTML = `<div class="empty">暂无应用配置</div>`;
    return;
  }

  root.innerHTML = entries.map(([pkg, app]) => {
    const open = ui.appOpen[pkg] ? "open" : "";
    const count = appRuleCount(app);

    return `
      <div class="app-card ${open}">
        <div class="app-title">
          <div>
            <h3>${escapeHtml(pkg)}</h3>
            <div class="app-meta">${count} 项配置</div>
          </div>
          <div class="rule-actions">
            <button class="btn small light js-toggle-app" data-pkg="${enc(pkg)}">${open ? "收起" : "展开"}</button>
            <button class="btn small red js-delete-app" data-pkg="${enc(pkg)}">删除</button>
          </div>
        </div>

        <div class="app-body">
          <div class="subsection">
            <div class="subsection-head">
              <div>
                <h4>前台配置</h4>
                <p>[config.${escapeHtml(pkg)}]</p>
              </div>
              <button class="btn small light js-add-app-rule" data-pkg="${enc(pkg)}" data-kind="config">添加</button>
            </div>
            <div class="list">${renderAppRuleHtml(pkg, app.config, "config", "暂无前台配置")}</div>
          </div>

          <div class="subsection">
            <div class="subsection-head">
              <div>
                <h4>退出恢复</h4>
                <p>[default.${escapeHtml(pkg)}]</p>
              </div>
              <button class="btn small light js-add-app-rule" data-pkg="${enc(pkg)}" data-kind="default">添加</button>
            </div>
            <div class="list">${renderAppRuleHtml(pkg, app.default, "default", "暂无恢复配置")}</div>
          </div>
        </div>
      </div>
    `;
  }).join("");
}

function renderAppRuleHtml(pkg, data, kind, emptyText) {
  const key = getSearch("appSearch");
  const entries = Object.entries(data).filter(([p, r]) => matchRule(p, r, key));

  if (!entries.length) return `<div class="empty">${emptyText}</div>`;

  return entries.map(([p, r]) => `
    <div class="rule ${r.disabled ? "disabled" : ""}">
      <div class="rule-main">
        <div class="path" title="${escapeHtml(p)}">
          ${escapeHtml(shortPath(p))}
          ${r.disabled ? `<span class="badge">已禁用</span>` : ""}
        </div>
        <div class="value">值：<span>${escapeHtml(r.value)}</span></div>
      </div>
      <div class="rule-actions">
        <button class="btn small light js-edit-app-rule" data-pkg="${enc(pkg)}" data-kind="${kind}" data-path="${enc(p)}">编辑</button>
        <button class="btn small warn js-toggle-app-rule" data-pkg="${enc(pkg)}" data-kind="${kind}" data-path="${enc(p)}">${r.disabled ? "启用" : "禁用"}</button>
        <button class="btn small red js-delete-app-rule" data-pkg="${enc(pkg)}" data-kind="${kind}" data-path="${enc(p)}">删除</button>
      </div>
    </div>
  `).join("");
}

async function askRule(oldPath = "", oldValue = "") {
  const path = prompt("请输入路径", String(oldPath ?? ""));
  if (path === null) return null;

  const cleanPath = path.trim();
  if (!cleanPath) return null;

  await sleep(120);

  const value = prompt("请输入值", String(oldValue ?? ""));
  if (value === null) return null;

  return [cleanPath, value];
}

async function detectWaltPolicies() {
  const policies = await requestJson("/api/walt-policies");
  if (!Array.isArray(policies)) return [];
  return [...new Set(policies.filter(s => /^policy[0-9]+$/.test(String(s))))]
    .sort((a, b) => Number(a.replace("policy", "")) - Number(b.replace("policy", "")));
}

async function addGlobalPreset() {
  state.global["/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq"] = makeRule("0");

  let policies = [];

  try {
    policies = await detectWaltPolicies();
  } catch (_) {
    policies = [];
  }

  if (policies.length) {
    for (const p of policies) {
      const base = `/sys/devices/system/cpu/cpufreq/${p}/walt`;
      state.global[`${base}/down_rate_limit_us`] = makeRule("1000");
      state.global[`${base}/up_rate_limit_us`] = makeRule("1000");
    }

    setMessage(`已添加全局预设，识别到 ${policies.length} 个 WALT policy`, "ok");
  } else {
    setMessage("未识别到 WALT，仅添加 scaling_min_freq 预设", "ok");
  }

  render();
}

function addLimitsPreset() {
  state.limits["/data/system/mcd/df"] = makeRule("000");
  setMessage("已添加权限预设", "ok");
  render();
}

async function addGlobalRule() {
  const r = await askRule("", "");
  if (!r) return;

  state.global[r[0]] = makeRule(r[1]);
  render();
}

async function addLimitRule() {
  const r = await askRule("", "000");
  if (!r) return;

  state.limits[r[0]] = makeRule(r[1]);
  render();
}

function addApp() {
  const pkg = prompt("请输入应用包名，例如 com.miHoYo.Yuanshen", "");
  if (!pkg) return;

  const clean = pkg.trim();
  if (!clean) return;

  ensureApp(clean);
  ui.appOpen[clean] = true;
  render();
}

document.addEventListener("click", async e => {
  const t = e.target;
  if (!(t instanceof HTMLElement)) return;

  if (t.classList.contains("js-toggle-app")) {
    const pkg = dec(t.dataset.pkg);
    ui.appOpen[pkg] = !ui.appOpen[pkg];
    render();
    return;
  }

  if (t.classList.contains("js-edit-rule")) {
    const scope = t.dataset.scope;
    const path = dec(t.dataset.path);
    const table = scope === "limits" ? state.limits : state.global;
    const old = table[path];

    const r = await askRule(path, old?.value ?? "");
    if (!r) return;

    if (r[0] !== path) delete table[path];
    table[r[0]] = makeRule(r[1], old?.disabled ?? false);
    render();
    return;
  }

  if (t.classList.contains("js-toggle-rule")) {
    const table = t.dataset.scope === "limits" ? state.limits : state.global;
    const path = dec(t.dataset.path);

    if (table[path]) table[path].disabled = !table[path].disabled;
    render();
    return;
  }

  if (t.classList.contains("js-delete-rule")) {
    const table = t.dataset.scope === "limits" ? state.limits : state.global;
    const path = dec(t.dataset.path);

    if (!confirm("确定删除这条配置？")) return;

    delete table[path];
    render();
    return;
  }

  if (t.classList.contains("js-delete-app")) {
    const pkg = dec(t.dataset.pkg);

    if (!confirm(`删除应用配置：${pkg}？`)) return;

    delete state.apps[pkg];
    delete ui.appOpen[pkg];
    render();
    return;
  }

  if (t.classList.contains("js-add-app-rule")) {
    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;

    const r = await askRule("", "");
    if (!r) return;

    const app = ensureApp(pkg);
    if (!app) return;

    const table = kind === "default" ? app.default : app.config;
    table[r[0]] = makeRule(r[1]);
    ui.appOpen[pkg] = true;
    render();
    return;
  }

  if (t.classList.contains("js-edit-app-rule")) {
    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;
    const path = dec(t.dataset.path);
    const app = ensureApp(pkg);

    if (!app) return;

    const table = kind === "default" ? app.default : app.config;
    const old = table[path];

    const r = await askRule(path, old?.value ?? "");
    if (!r) return;

    if (r[0] !== path) delete table[path];
    table[r[0]] = makeRule(r[1], old?.disabled ?? false);
    ui.appOpen[pkg] = true;
    render();
    return;
  }

  if (t.classList.contains("js-toggle-app-rule")) {
    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;
    const path = dec(t.dataset.path);
    const app = ensureApp(pkg);

    if (!app) return;

    const table = kind === "default" ? app.default : app.config;

    if (table[path]) table[path].disabled = !table[path].disabled;

    ui.appOpen[pkg] = true;
    render();
    return;
  }

  if (t.classList.contains("js-delete-app-rule")) {
    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;
    const path = dec(t.dataset.path);
    const app = ensureApp(pkg);

    if (!app) return;
    if (!confirm("确定删除这条配置？")) return;

    const table = kind === "default" ? app.default : app.config;
    delete table[path];
    ui.appOpen[pkg] = true;
    render();
  }
});

async function initialize() {
  try {
    await request("/api/session");
    await refreshRuntime();
  } catch (error) {
    setMessage(error.message || "模块状态读取失败", "err");
  }
  await loadConfig();
  window.setInterval(() => {
    if (!document.hidden) void refreshRuntime(true);
  }, 15000);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) void refreshRuntime(true);
  });
}

initialize();
