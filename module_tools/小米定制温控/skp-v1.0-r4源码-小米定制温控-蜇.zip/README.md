# 定制温控 SKP

这是 `定制温控 v5.7` 的原生 SKRoot(Pro) 模块工程。模块入口、安装与卸载、
开机处理、模式切换、系统属性和 WebUI 通信均已从 Magisk/KernelSU 脚本迁移到
C++/SKP 生命周期。

最终 ZIP 不包含 `module.prop`、`customize.sh`、`service.sh`、`action.sh`、
`thermal.sh`、`system.prop`、`uninstall.sh` 或 `META-INF`。

## 支持范围

- ARM64 小米/红米设备
- Linux 5.10 或更高版本内核
- `/vendor/etc/thermal-normal.conf` 或 `/odm/etc/thermal-normal.conf`
- SKRoot(Pro) 当前模块 SDK

安装前必须先卸载旧版 `Eclipse` Magisk/KernelSU 模块并重启。安装回调会检测
`/data/adb/modules/Eclipse`，检测到旧模块时拒绝继续，避免两套服务同时修改温控。

## 行为

- 安装回调校验设备并调用原始转换器生成 `cool`、`pro`、`extreme`、`danger`
  四套设备专属配置。
- 首次安装使用 `cool`（夏日限定）并默认关闭可选控制器。SKP 没有安装音量键
  交互接口，后续选择统一放在 WebUI。
- 新配置直接在 `/data/vendor/thermal` 同一文件系统内准备完整，并通过
  `renameat2(RENAME_EXCHANGE)` 原子交换。事务身份和阶段写入独立标记；进程或设备
  中断后，下次生命周期回调会识别交换前后目录并完成回滚或提交清理。Android
  文件系统不支持 immutable ioctl 时按 best-effort 处理；旧候选目录会退役清理，
  普通模式退役目录最多保留 4 个，原厂回滚路径不受该上限阻断。
- 首次修改前将 OEM live config 备份到
  `/data/vendor/thermal/.custom_thermal_skp_stock`；备份绑定设备、温控源指纹和逐文件
  清单。卸载只有在备份完整且与当前固件匹配时才原子恢复；备份缺失时保持 live
  config 不变。
- 七项原 `system.prop` 属性在 zygote64 前由捆绑的 `resetprop` 应用，安装时保存
  原值；卸载或任一开机启动步骤失败时逐项恢复或删除原本不存在的属性，并停止
  可能残留的控制器进程。
- `custom_thermal_helper` 是单独编译的 PIE 可执行文件。SKP 多线程宿主 fork 后只做
  预先准备好的 `dup2/close/execve`；双 fork、开机等待、PID 管理和 Asphyxia 启动
  均在 helper 进程中完成，不再继承宿主 C++ 锁或长期持有宿主文件描述符。控制器
  异常退出时由 helper 以 1/2/4/8 秒退避重启，连续 5 次失败后停止；重试期间
  WebUI 显示“控制器正在重启”。
- Asphyxia 的标准输出和错误输出记录在模块私有目录
  `state/controller.log`；helper 同时记录启动 PID、正常退出码或终止信号，用于区分
  配置退出、权限错误和进程崩溃。
- 安装、开机、模式切换、控制器启停和配置保存事件记录到
  `state/runtime.log`，超过 256 KiB 自动轮转为 `state/runtime.log.1`。
- WebUI 的“运行验证”每 15 秒检查设置模式与磁盘 `files.ini`、live 配置文件数、
  七项属性覆盖和温控事务状态，并合并显示 `runtime.log`、`controller.log` 与
  `controller_helper.log` 的尾部。五项状态全部为绿色时，代表模块配置已写入
  live 温控目录且属性值与预期一致。
- 控制器 TOML 位于 SKP 私有目录，权限为 `0600`。首次启用时会只读迁移旧的
  `/sdcard/Android/Eclipse/Asphyxia.toml`（若存在）。打包的 Asphyxia 将硬编码路径
  改为相对的 `state/Asphyxia.toml`，helper 在 SKP 私有目录中启动它，之后不再读取共享存储。
- WebUI 通过 SKP CivetWeb API 管理温控模式、控制器和 TOML，不使用
  `window.ksu.exec` 或任意 shell 命令接口。API 只接受回环连接，并校验 Host、
  已提供的 Origin/Referer、Fetch Metadata 和随机 HttpOnly 会话 cookie。建立会话后，
  兼容 Via 等会省略 POST Origin/Referer 的 Android 浏览器。
- API 对非法模式或非法 TOML 返回 400；合法请求的存储、权限和事务故障返回 500，
  前端错误提示包含 HTTP 状态码和服务端诊断。
- 服务端只接受 Asphyxia 支持的 TOML 表和单行字符串规则；活动目标路径仅允许
  `/sys/`、`/proc/sys/`、`/data/vendor/thermal/` 与精确
  `/data/system/mcd/df`；现有符号链接解析后的目标仍必须位于对应允许根目录。
- WebUI 检测到普通注释、未知表/语法、重复表/键、空表或无法保真的转义时会进入
  只读保护，避免保存时静默丢失原文件内容。

## 闭源载荷

原包没有三个算法程序的源码或跨机型测试样本。为保证配置加解密和规则执行等价，
本工程保留它们作为受管用户态资源：

| 文件 | 用途 | 原始 SHA-256 | 打包 SHA-256 |
| --- | --- | --- | --- |
| `Eclipse` | 安装期四模式生成器 | `3865A89C40DBAC6D71A26F12ABA7EC71D28F4377EE1D0CEE2D88C8A125D68368` | `739B731A301A20DC6911CADEDBBB3B1938F19961E38965BC4E7576CFE6C8DC79` |
| `miui-thermal` | 小米温控配置加解密 | `7100BB501650BBEA18921C06399DFDC633BC043CB8228D301BD5BB0367E67A36` | 同原始文件 |
| `Asphyxia` | 可选规则控制器 | `85FBD7F6143BFF8F042231E0B0FD569BA3C231329677B6F7ED17DDEF2A9C4C4A` | `4229FA219AAFADFF37E379E90C23282698A872A36C05CCE92A550A7B8C482241` |

`Eclipse` 与 `Asphyxia` 原本含有指向 Termux 可写目录的 `DT_RUNPATH`。打包副本将该字符串
清零；Asphyxia 副本还把共享存储中的绝对配置路径改成模块目录下的相对路径。补丁不修改
程序控制流，构建脚本固定校验补丁后的哈希。子进程使用固定 Android 系统环境，不继承
`LD_PRELOAD`。可重复的路径补丁脚本为 `tools/patch_asphyxia_private_config.ps1`。

## 构建

需要 Android NDK r26d 或更高版本，以及 SKRoot 源码中的 `testModule` SDK：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 `
  -NdkRoot "D:\Android\android-ndk-r27d"
```

若 SDK 位于默认下载目录，脚本会自动查找。也可传入
`-SkrootTestModuleRoot`。输出文件：

```text
dist/custom_thermal_skp-v1.0-r4.zip
```

构建会校验四个固定资源哈希、最终 ZIP 原始路径的精确 10 项 allowlist、解压后
逐文件哈希、全部 ELF 的 ARM64 ABI 与 `RPATH/RUNPATH`、生成二进制的共享库依赖、
helper 的 Android PIE 属性，以及 SKP 主入口、安装、卸载和 WebUI 导出。ZIP 条目
使用固定顺序和时间戳，相同输入可逐字节复建。另生成：

```text
dist/verification.txt
dist/porting-diff.txt
```

工作区原包恢复脚本为 `tools/restore_original_archive.ps1`。设备侧回滚由 SKP 卸载
回调执行，使用安装前的 OEM 备份原子恢复配置并恢复七项属性。

## 真机验收

建议先使用 SKRoot 的开发单次运行模式，再做正式 Boot 安装。至少验证：

1. 安装回调能生成四个非空模式目录，默认模式为 `cool`。
2. 四次模式切换后 `/data/vendor/thermal/config/files.ini` 与所选模式一致。
3. WebUI“运行验证”显示“已生效”、磁盘模式一致、配置文件数大于 0、属性覆盖
   `7/7`、事务状态正常；手动切换模式后日志出现 `MODE_OK`。
4. WebUI TOML 保存、控制器启停和重启后启动均正常；启用后状态为“控制器运行中”，
   日志中能看到 `CONTROLLER` 事件与 helper 启动 PID。
5. `logcat`/内核日志中没有 SKP SELinux 拒绝，Asphyxia 能执行 `dumpsys` 并写目标节点。
6. 卸载后 OEM config 和七项属性恢复，控制器进程退出。
7. 模拟强制终止模式切换进程后重启模块，确认事务自动回滚且 live config 始终是
   完整目录。

桌面环境只能完成 ABI、编译、静态资源、ELF 和 ZIP 验证；设备专属配置转换及
SELinux 行为必须在目标手机上完成最终验收。
