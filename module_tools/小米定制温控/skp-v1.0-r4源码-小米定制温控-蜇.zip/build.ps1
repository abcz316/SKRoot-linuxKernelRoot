param(
    [string]$NdkRoot = $env:ANDROID_NDK_ROOT,
    [string]$SkrootTestModuleRoot = $env:SKROOT_TEST_MODULE_ROOT,
    [string]$OriginalArchive = ""
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExpectedOriginalArchiveHash = "047516C68CF211BCCD49208C4C97859A84A4D7311C7B4041AFD301E78FA75636"

if ([string]::IsNullOrWhiteSpace($OriginalArchive)) {
    $OriginalArchive = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE "Downloads") `
        -File -Filter "*.zip" |
        Where-Object {
            (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash -eq `
                $ExpectedOriginalArchiveHash
        } |
        Select-Object -First 1 -ExpandProperty FullName
}

if (-not [string]::IsNullOrWhiteSpace($NdkRoot) -and
    (Test-Path -LiteralPath $NdkRoot -PathType Leaf)) {
    $NdkRoot = Split-Path -Parent $NdkRoot
}

if ([string]::IsNullOrWhiteSpace($NdkRoot)) {
    throw "Set -NdkRoot or ANDROID_NDK_ROOT to an Android NDK directory."
}

if ([string]::IsNullOrWhiteSpace($SkrootTestModuleRoot)) {
    $RepositoryRoot = Join-Path $env:USERPROFILE "Downloads\SKRoot-linuxKernelRoot-master"
    $KitDirectory = Get-ChildItem -LiteralPath $RepositoryRoot -Directory -Recurse -Filter "kernel_module_kit" |
        Where-Object { $_.Parent.Name -eq "testModule" } |
        Select-Object -First 1
    if ($null -eq $KitDirectory) {
        throw "Set -SkrootTestModuleRoot or SKROOT_TEST_MODULE_ROOT to the SDK testModule directory."
    }
    $SkrootTestModuleRoot = $KitDirectory.Parent.FullName
}

$NdkBuild = Join-Path $NdkRoot "ndk-build.cmd"
$KitRoot = Join-Path $SkrootTestModuleRoot "kernel_module_kit"
$KitLibrary = Join-Path $KitRoot "lib\libkernel_module_kit_static.a"
if (-not (Test-Path -LiteralPath $NdkBuild -PathType Leaf)) {
    throw "ndk-build.cmd was not found: $NdkBuild"
}
if (-not (Test-Path -LiteralPath $KitLibrary -PathType Leaf)) {
    throw "SKP SDK static library was not found: $KitLibrary"
}

$LocalKitDirectory = Join-Path $ProjectRoot "jni\prebuilt\arm64-v8a"
$LocalKitLibrary = Join-Path $LocalKitDirectory "libkernel_module_kit_static.a"
New-Item -ItemType Directory -Force -Path $LocalKitDirectory | Out-Null
Copy-Item -LiteralPath $KitLibrary -Destination $LocalKitLibrary -Force

$ExpectedResourceHashes = @{
    "resources\bin\Asphyxia" = "4229FA219AAFADFF37E379E90C23282698A872A36C05CCE92A550A7B8C482241"
    "resources\bin\Eclipse" = "739B731A301A20DC6911CADEDBBB3B1938F19961E38965BC4E7576CFE6C8DC79"
    "resources\bin\miui-thermal" = "7100BB501650BBEA18921C06399DFDC633BC043CB8228D301BD5BB0367E67A36"
    "resources\bin\resetprop" = "70558E6D6199FA5A961B7BAFEB8F96D8157CC63810DB8DF2A3CDED1881763697"
}
foreach ($RelativePath in $ExpectedResourceHashes.Keys) {
    $ResourcePath = Join-Path $ProjectRoot $RelativePath
    if (-not (Test-Path -LiteralPath $ResourcePath -PathType Leaf)) {
        throw "Resource was not found: $RelativePath"
    }
    $ActualHash = (Get-FileHash -LiteralPath $ResourcePath -Algorithm SHA256).Hash
    if ($ActualHash -ne $ExpectedResourceHashes[$RelativePath]) {
        throw "Resource hash mismatch: $RelativePath"
    }
}

$ModuleSourcePath = Join-Path $ProjectRoot "native\module.cpp"
$RuntimeSourcePath = Join-Path $ProjectRoot "native\runtime.cpp"
$RuntimeHeaderPath = Join-Path $ProjectRoot "native\runtime.hpp"
$ControllerHelperSourcePath = Join-Path $ProjectRoot "native\controller_helper.cpp"
$DefaultControllerConfigPath = Join-Path $ProjectRoot "resources\defaults\Asphyxia.toml"
foreach ($SourcePath in @(
    $ModuleSourcePath,
    $RuntimeSourcePath,
    $RuntimeHeaderPath,
    $ControllerHelperSourcePath,
    $DefaultControllerConfigPath
)) {
    if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) {
        throw "Required source file was not found: $SourcePath"
    }
}

$ModuleSource = [IO.File]::ReadAllText($ModuleSourcePath, [Text.Encoding]::UTF8)
$RuntimeSource = [IO.File]::ReadAllText($RuntimeSourcePath, [Text.Encoding]::UTF8)
$RuntimeHeader = [IO.File]::ReadAllText($RuntimeHeaderPath, [Text.Encoding]::UTF8)
$ControllerHelperSource = [IO.File]::ReadAllText(
    $ControllerHelperSourcePath,
    [Text.Encoding]::UTF8
)
$DefaultControllerConfig = [IO.File]::ReadAllText(
    $DefaultControllerConfigPath,
    [Text.Encoding]::UTF8
)

$ExpectedModuleVersion = "1.0"
$ExpectedModuleAuthor = [Text.Encoding]::UTF8.GetString(
    [byte[]](0xE8, 0x8B, 0x8F, 0xE7, 0x96, 0xAB, 0xE6, 0x9D, 0x86,
        0xE8, 0x8F, 0x8C, 0x2F, 0xE8, 0x9C, 0x83)
)
$ExpectedModuleId32 = "be4b666b97e92f1ddcf4b212ba436b40"
foreach ($Metadata in @(
    @{ Label = "version"; Value = "SKROOT_MODULE_VERSION(`"$ExpectedModuleVersion`")" },
    @{ Label = "author"; Value = "SKROOT_MODULE_AUTHOR(`"$ExpectedModuleAuthor`")" },
    @{ Label = "ID32"; Value = "SKROOT_MODULE_ID32(`"$ExpectedModuleId32`")" }
)) {
    if (-not $ModuleSource.Contains($Metadata.Value)) {
        throw "SKP module $($Metadata.Label) metadata differs from the expected value."
    }
}
if ([string]::IsNullOrWhiteSpace($DefaultControllerConfig)) {
    throw "The packaged default controller configuration is empty."
}

$ApiReadAuthorizationPattern =
    'starts_with\s*\(\s*path\s*,\s*"/api/"\s*\)\s*&&\s*!authorize_api\s*\(\s*connection\s*,\s*false\s*\)'
if ($ModuleSource -notmatch $ApiReadAuthorizationPattern -or
    -not $ModuleSource.Contains('if (path == "/api/log")') -or
    -not $ModuleSource.Contains('custom_thermal::runtime_log_text(module_dir_)') -or
    -not $RuntimeHeader.Contains('std::string runtime_log_text(const fs::path& module_dir);')) {
    throw "Authenticated GET /api/log wiring is missing or incomplete."
}

$RuntimeLogPatterns = @(
    @{ Label = "runtime.log path"; Pattern = '"runtime\.log"' },
    @{ Label = "256 KiB rotation threshold"; Pattern = 'st_size\s*>\s*256\s*\*\s*1024' },
    @{ Label = "runtime.log.1 rotation target"; Pattern = 'path\.string\(\)\s*\+\s*"\.1"' },
    @{ Label = "atomic log rotation rename"; Pattern =
            '::rename\s*\(\s*path\.c_str\(\)\s*,\s*previous\.c_str\(\)\s*\)' }
)
foreach ($Check in $RuntimeLogPatterns) {
    if ($RuntimeSource -notmatch $Check.Pattern) {
        throw "Runtime logging check failed: $($Check.Label) is missing."
    }
}

$ThermalStatusFields = @(
    "activeMode",
    "thermalState",
    "thermalActive",
    "thermalConfigFiles",
    "propertyOverridesActive",
    "propertyOverridesTotal",
    "transactionState"
)
foreach ($Field in $ThermalStatusFields) {
    if (-not $RuntimeSource.Contains('\"' + $Field + '\"')) {
        throw "Runtime status JSON field is missing: $Field"
    }
}
if (-not $RuntimeSource.Contains(
        'snapshot.thermal_active = snapshot.thermal_state == "active";'
    ) -or -not $RuntimeSource.Contains(
        'json += snapshot.thermal_active ? "true," : "false,";'
    )) {
    throw "thermalActive is not derived strictly from the active thermal state."
}
if (-not $RuntimeSource.Contains(
        'const RuntimeStatusSnapshot snapshot = runtime_status_snapshot(module_dir);'
    ) -or -not $RuntimeSource.Contains(
        'thermal_state_label(snapshot.thermal_state)'
    ) -or -not $RuntimeSource.Contains(
        'controller_state_label(snapshot.controller_state,'
    )) {
    throw "Runtime log does not include the current live verification snapshot."
}

$LegacyBootGatePath = "/data/data/android"
if ($ControllerHelperSource.Contains($LegacyBootGatePath)) {
    throw "Legacy device data-directory boot gate is still present in controller helper source."
}
if (-not $ControllerHelperSource.Contains('property("sys.boot_completed") != "1"') -or
    -not $ControllerHelperSource.Contains('kPostBootGraceSeconds = 15')) {
    throw "Controller boot scheduling must use sys.boot_completed plus the 15-second grace."
}

$AsphyxiaBytes = [IO.File]::ReadAllBytes(
    (Join-Path $ProjectRoot "resources\bin\Asphyxia")
)
$AsphyxiaText = [Text.Encoding]::ASCII.GetString($AsphyxiaBytes)
if (-not $AsphyxiaText.Contains("state/Asphyxia.toml") -or
    $AsphyxiaText.Contains("/sdcard/Android/Eclipse/Asphyxia.toml")) {
    throw "Asphyxia private-config path patch is missing or inconsistent."
}

$env:SKROOT_MODULE_KIT = $KitRoot.Replace("\", "/")
Push-Location (Join-Path $ProjectRoot "jni")
try {
    & $NdkBuild clean
    if ($LASTEXITCODE -ne 0) { throw "ndk-build clean failed: $LASTEXITCODE" }
    & $NdkBuild "-j$([Environment]::ProcessorCount)"
    if ($LASTEXITCODE -ne 0) { throw "ndk-build failed: $LASTEXITCODE" }
} finally {
    Pop-Location
}

$Library = Join-Path $ProjectRoot "libs\arm64-v8a\libcustom_thermal_skp.so"
$Helper = Join-Path $ProjectRoot "libs\arm64-v8a\custom_thermal_helper"
$Stage = Join-Path $ProjectRoot "dist\stage"
$Package = Join-Path $ProjectRoot "dist\custom_thermal_skp-v1.0-r4.zip"
$SupersededPackage = Join-Path $ProjectRoot "dist\custom_thermal_skp-v5.7.0.zip"
if (-not (Test-Path -LiteralPath $Library -PathType Leaf)) {
    throw "The compiled module library was not found: $Library"
}
if (-not (Test-Path -LiteralPath $Helper -PathType Leaf)) {
    throw "The compiled controller helper was not found: $Helper"
}
$WaiterProcessName = "skp-thrm-wait"
if ([Text.Encoding]::UTF8.GetByteCount($WaiterProcessName) -gt 15) {
    throw "Controller waiter process name exceeds Linux TASK_COMM_LEN."
}
$HelperText = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($Helper))
if (-not $HelperText.Contains($WaiterProcessName) -or
    $HelperText.Contains("skp-thermal-wait")) {
    throw "Controller waiter process name was not embedded consistently."
}
if ($HelperText.Contains($LegacyBootGatePath)) {
    throw "Legacy device data-directory boot gate was found in the compiled helper."
}
if (-not $HelperText.Contains("sys.boot_completed")) {
    throw "Compiled helper does not contain the sys.boot_completed boot gate."
}

$ResolvedProject = [IO.Path]::GetFullPath($ProjectRoot)
$ResolvedStage = [IO.Path]::GetFullPath($Stage)
if (-not $ResolvedStage.StartsWith($ResolvedProject + [IO.Path]::DirectorySeparatorChar,
        [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to clean a staging path outside the project: $ResolvedStage"
}
if (Test-Path -LiteralPath $Stage) {
    Remove-Item -LiteralPath $Stage -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $Stage | Out-Null

Copy-Item -LiteralPath $Library -Destination $Stage
Copy-Item -LiteralPath (Join-Path $ProjectRoot "resources\bin") -Destination $Stage -Recurse
Copy-Item -LiteralPath $Helper -Destination (Join-Path $Stage "bin\custom_thermal_helper")
Copy-Item -LiteralPath (Join-Path $ProjectRoot "resources\defaults") -Destination $Stage -Recurse
Copy-Item -LiteralPath (Join-Path $ProjectRoot "webroot") -Destination $Stage -Recurse

$Required = @(
    "libcustom_thermal_skp.so",
    "bin/Asphyxia",
    "bin/custom_thermal_helper",
    "bin/Eclipse",
    "bin/miui-thermal",
    "bin/resetprop",
    "defaults/Asphyxia.toml",
    "webroot/index.html",
    "webroot/app.js",
    "webroot/style.css"
)

if (Test-Path -LiteralPath $Package) {
    Remove-Item -LiteralPath $Package -Force
}
if ($SupersededPackage -ne $Package -and
    (Test-Path -LiteralPath $SupersededPackage -PathType Leaf)) {
    Remove-Item -LiteralPath $SupersededPackage -Force
}
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$PackageStream = [IO.File]::Open(
    $Package,
    [IO.FileMode]::CreateNew,
    [IO.FileAccess]::ReadWrite,
    [IO.FileShare]::None
)
try {
    $Archive = [IO.Compression.ZipArchive]::new(
        $PackageStream,
        [IO.Compression.ZipArchiveMode]::Create,
        $false
    )
    try {
        $FixedTimestamp = [DateTimeOffset]::new(1980, 1, 1, 0, 0, 0, [TimeSpan]::Zero)
        foreach ($Entry in $Required) {
            $RelativePath = $Entry.Replace("/", [IO.Path]::DirectorySeparatorChar)
            $SourcePath = Join-Path $Stage $RelativePath
            $ZipEntry = $Archive.CreateEntry($Entry, [IO.Compression.CompressionLevel]::Optimal)
            $ZipEntry.LastWriteTime = $FixedTimestamp
            $InputStream = [IO.File]::OpenRead($SourcePath)
            $OutputStream = $ZipEntry.Open()
            try {
                $InputStream.CopyTo($OutputStream)
            } finally {
                $OutputStream.Dispose()
                $InputStream.Dispose()
            }
        }
    } finally {
        $Archive.Dispose()
    }
} finally {
    $PackageStream.Dispose()
}

$PackageArchive = [IO.Compression.ZipFile]::OpenRead($Package)
try {
    $Entries = @($PackageArchive.Entries | ForEach-Object { $_.FullName })
} finally {
    $PackageArchive.Dispose()
}
$EntryDifference = @(Compare-Object -ReferenceObject ($Required | Sort-Object) `
    -DifferenceObject ($Entries | Sort-Object))
if ($EntryDifference.Count -ne 0) {
    throw "Package entry set differs from the native SKP allowlist: $($EntryDifference | Out-String)"
}

$VerifyDirectory = Join-Path $ProjectRoot "dist\verify_extract"
$ResolvedVerify = [IO.Path]::GetFullPath($VerifyDirectory)
if (-not $ResolvedVerify.StartsWith($ResolvedProject + [IO.Path]::DirectorySeparatorChar,
        [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to use a verification path outside the project: $ResolvedVerify"
}
if (Test-Path -LiteralPath $VerifyDirectory) {
    Remove-Item -LiteralPath $VerifyDirectory -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $VerifyDirectory | Out-Null
[IO.Compression.ZipFile]::ExtractToDirectory($Package, $VerifyDirectory)
foreach ($Entry in $Required) {
    $RelativePath = $Entry.Replace("/", [IO.Path]::DirectorySeparatorChar)
    $StagedFile = Join-Path $Stage $RelativePath
    $ExtractedFile = Join-Path $VerifyDirectory $RelativePath
    $StagedHash = (Get-FileHash -LiteralPath $StagedFile -Algorithm SHA256).Hash
    $ExtractedHash = (Get-FileHash -LiteralPath $ExtractedFile -Algorithm SHA256).Hash
    if ($StagedHash -ne $ExtractedHash) {
        throw "Packaged file hash mismatch: $Entry"
    }
}
Remove-Item -LiteralPath $VerifyDirectory -Recurse -Force

$ReadElf = Join-Path $NdkRoot "toolchains\llvm\prebuilt\windows-x86_64\bin\llvm-readelf.exe"
$Nm = Join-Path $NdkRoot "toolchains\llvm\prebuilt\windows-x86_64\bin\llvm-nm.exe"
foreach ($Elf in @(
    $Library,
    $Helper,
    (Join-Path $ProjectRoot "resources\bin\Asphyxia"),
    (Join-Path $ProjectRoot "resources\bin\Eclipse"),
    (Join-Path $ProjectRoot "resources\bin\miui-thermal"),
    (Join-Path $ProjectRoot "resources\bin\resetprop")
)) {
    $Header = (& $ReadElf --file-header $Elf 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { throw "ELF header inspection failed: $Elf" }
    if ($Header -notmatch 'Class:\s+ELF64' -or
        $Header -notmatch 'Machine:\s+AArch64') {
        throw "ELF is not an ARM64 binary: $Elf"
    }
    $Dynamic = (& $ReadElf --dynamic $Elf 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { throw "ELF dynamic-table inspection failed: $Elf" }
    if ($Dynamic -match '\((RUNPATH|RPATH)\).*\[[^\]]+\]') {
        throw "Unsafe runtime search path found in ELF: $Elf"
    }
}

$AllowedGeneratedDependencies = @("libc.so", "libdl.so", "libm.so")
foreach ($Elf in @($Library, $Helper)) {
    $Dynamic = (& $ReadElf --dynamic $Elf 2>&1 | Out-String)
    $Dependencies = @(
        [Regex]::Matches($Dynamic, 'Shared library:\s+\[([^\]]+)\]') |
            ForEach-Object { $_.Groups[1].Value }
    )
    $UnexpectedDependencies = @(
        $Dependencies | Where-Object { $AllowedGeneratedDependencies -notcontains $_ }
    )
    if ($UnexpectedDependencies.Count -ne 0) {
        throw "Unexpected generated ELF dependencies in $Elf`: $($UnexpectedDependencies -join ',')"
    }
}
$HelperDynamic = (& $ReadElf --dynamic $Helper 2>&1 | Out-String)
$HelperProgramHeaders = (& $ReadElf --program-headers $Helper 2>&1 | Out-String)
if ($HelperDynamic -notmatch '\bPIE\b' -or
    $HelperProgramHeaders -notmatch 'Requesting program interpreter:\s*/system/bin/linker64') {
    throw "Controller helper is not an Android ARM64 PIE executable."
}
$Exports = (& $Nm -D --defined-only $Library 2>&1 | Out-String)
if ($LASTEXITCODE -ne 0) { throw "SKP export inspection failed." }
foreach ($ExportPattern in @(
    '__skroot_module_main_',
    '__skroot_module_on_install_',
    '__skroot_module_on_uninstall_',
    '__skroot_module_web_ui_main_',
    'inject_skroot_module_uuid32_'
)) {
    if ($Exports -notmatch [Regex]::Escape($ExportPattern)) {
        throw "Required SKP export is missing: $ExportPattern"
    }
}

$Hash = (Get-FileHash -LiteralPath $Package -Algorithm SHA256).Hash
$OriginalHash = "missing"
$OriginalEntries = @()
if (-not [string]::IsNullOrWhiteSpace($OriginalArchive) -and
    (Test-Path -LiteralPath $OriginalArchive -PathType Leaf)) {
    $OriginalHash = (Get-FileHash -LiteralPath $OriginalArchive -Algorithm SHA256).Hash
    if ($OriginalHash -ne $ExpectedOriginalArchiveHash) {
        throw "Original archive hash mismatch: $OriginalHash"
    }
    $OriginalEntries = @(tar -tf $OriginalArchive)
}
$QuotePowerShellLiteral = {
    param([string]$Value)
    "'" + $Value.Replace("'", "''") + "'"
}
$BaselineCommand = "Get-FileHash -Algorithm SHA256 -LiteralPath $(& $QuotePowerShellLiteral $OriginalArchive)"
$ModifiedCommand = "Get-FileHash -Algorithm SHA256 -LiteralPath $(& $QuotePowerShellLiteral $Package)"
$VerificationPath = Join-Path $ProjectRoot "dist\verification.txt"
$Verification = @(
    "baseline_command=$BaselineCommand",
    "baseline_input=$OriginalArchive",
    "baseline_stdout=$OriginalHash",
    "baseline_exit_status=$(if ($OriginalHash -eq 'missing') { 2 } else { 0 })",
    "modified_command=$ModifiedCommand",
    "modified_input=$Package",
    "modified_stdout=$Hash",
    "modified_exit_status=0",
    "rebuild_command=powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -NdkRoot $(& $QuotePowerShellLiteral $NdkRoot)",
    "rebuild_input=$ProjectRoot",
    "zip_entries=$($Entries -join ',')",
    "module_metadata=version $ExpectedModuleVersion; author $ExpectedModuleAuthor; ID32 $ExpectedModuleId32",
    "default_controller_config=resources/defaults/Asphyxia.toml is non-empty ($([Text.Encoding]::UTF8.GetByteCount($DefaultControllerConfig)) bytes)",
    "runtime_log_api=authenticated GET /api/log; current live verification snapshot; state/runtime.log + controller.log + controller_helper.log tails",
    "runtime_log_rotation=state/runtime.log rotates to runtime.log.1 above 256 KiB",
    "thermal_status_fields=$($ThermalStatusFields -join ',')",
    "controller_config_lookup=state/Asphyxia.toml relative to module private directory",
    "controller_waiter_process=$WaiterProcessName ($([Text.Encoding]::UTF8.GetByteCount($WaiterProcessName)) bytes)",
    "controller_supervision=sys.boot_completed gate with 15-second grace; legacy $LegacyBootGatePath data-directory gate absent from source and compiled helper; supervisor PID and restarting state; 5 consecutive failures with 1/2/4/8-second backoff; reset after 5 stable minutes",
    "mode_api_status=400 only for invalid mode; valid-mode runtime failures use 500",
    "config_api_status=400 only for invalid TOML; valid-config storage failures use 500",
    "transaction_recovery=pending artifacts are cleaned or retired before controller startup; missing marker/candidate/backup artifacts are a valid first-install state; mode retirement cap=4; stock rollback bypass; durable marker-before-backup cleanup",
    "verification=module metadata; non-empty default config; authenticated log API; runtime log rotation; thermal status schema; boot gate; NDK build; raw ZIP path and exact allowlist; extracted hash equality; ARM64 ELF; generated dependency allowlist; helper PIE; helper process name; ELF RUNPATH; SKP exports",
    "verification_exit_status=0"
)
Set-Content -LiteralPath $VerificationPath -Value $Verification -Encoding UTF8

$DiffPath = Join-Path $ProjectRoot "dist\porting-diff.txt"
$RemovedEntries = @($OriginalEntries | Where-Object { $Entries -notcontains $_ } | Sort-Object)
$AddedEntries = @($Entries | Where-Object { $OriginalEntries -notcontains $_ } | Sort-Object)
$Diff = @(
    "original=$OriginalArchive",
    "modified=$Package",
    "behavioral_patch=Via-compatible authenticated loopback POST requests; mode API 400/500 separation",
    "logging_patch=authenticated GET /api/log; current live verification snapshot; 256 KiB runtime.log rotation to runtime.log.1; combined runtime/controller/helper tails",
    "status_patch=active mode, thermal activity, live config count, property override count, and transaction state exposed in status JSON",
    "metadata_patch=module version $ExpectedModuleVersion; author $ExpectedModuleAuthor; ID32 preserved as $ExpectedModuleId32; non-empty default controller config",
    "controller_patch=TASK_COMM_LEN-safe waiter identity; legacy $LegacyBootGatePath boot gate removed; sys.boot_completed plus 15-second grace; enabled-state-first launch with rollback; bounded restart supervision and restarting state",
    "transaction_patch=best-effort immutable handling; pending cleanup; missing optional transaction artifacts treated as ENOENT-clean; stale mode candidate retirement capped at 4; stock rollback bypass; marker fsync",
    "binary_patch=Asphyxia config path /sdcard/Android/Eclipse/Asphyxia.toml -> state/Asphyxia.toml",
    "--- removed legacy entries ---",
    $RemovedEntries,
    "+++ added native SKP entries +++",
    $AddedEntries
)
Set-Content -LiteralPath $DiffPath -Value $Diff -Encoding UTF8

Write-Host "SKP package: $Package"
Write-Host "SHA-256: $Hash"
Write-Host "Verification: $VerificationPath"
Write-Host "Porting diff: $DiffPath"
