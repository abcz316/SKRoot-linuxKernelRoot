param(
    [string]$Path = (Join-Path (Split-Path -Parent $PSScriptRoot) "resources\bin\Asphyxia")
)

$ErrorActionPreference = "Stop"
$ExpectedInputHash = "F941E32AF6BA376A8BE64C6F61CEA39F097D305525EF7685561F933490CA9C8C"
$ExpectedOutputHash = "4229FA219AAFADFF37E379E90C23282698A872A36C05CCE92A550A7B8C482241"
$OldPath = [Text.Encoding]::ASCII.GetBytes("/sdcard/Android/Eclipse/Asphyxia.toml")
$NewPath = [Text.Encoding]::ASCII.GetBytes("state/Asphyxia.toml")

$ResolvedPath = [IO.Path]::GetFullPath($Path)
if (-not (Test-Path -LiteralPath $ResolvedPath -PathType Leaf)) {
    throw "Asphyxia binary was not found: $ResolvedPath"
}

$InputHash = (Get-FileHash -LiteralPath $ResolvedPath -Algorithm SHA256).Hash
if ($InputHash -eq $ExpectedOutputHash) {
    Write-Host "Asphyxia private-config patch already applied: $ResolvedPath"
    exit 0
}
if ($InputHash -ne $ExpectedInputHash) {
    throw "Unexpected Asphyxia input hash: $InputHash"
}

$Bytes = [IO.File]::ReadAllBytes($ResolvedPath)
$Matches = @()
for ($Offset = 0; $Offset -le $Bytes.Length - $OldPath.Length; ++$Offset) {
    $MatchesAtOffset = $true
    for ($Index = 0; $Index -lt $OldPath.Length; ++$Index) {
        if ($Bytes[$Offset + $Index] -ne $OldPath[$Index]) {
            $MatchesAtOffset = $false
            break
        }
    }
    if ($MatchesAtOffset) { $Matches += $Offset }
}
if ($Matches.Count -ne 1) {
    throw "Expected one legacy config path, found $($Matches.Count)"
}

$PatchOffset = $Matches[0]
[Array]::Clear($Bytes, $PatchOffset, $OldPath.Length)
[Array]::Copy($NewPath, 0, $Bytes, $PatchOffset, $NewPath.Length)

$Sha256 = [Security.Cryptography.SHA256]::Create()
try {
    $PatchedHash = -join ($Sha256.ComputeHash($Bytes) | ForEach-Object {
        $_.ToString("X2")
    })
} finally {
    $Sha256.Dispose()
}
if ($PatchedHash -ne $ExpectedOutputHash) {
    throw "Unexpected Asphyxia output hash: $PatchedHash"
}

$TemporaryPath = "$ResolvedPath.tmp.$PID"
try {
    [IO.File]::WriteAllBytes($TemporaryPath, $Bytes)
    Move-Item -LiteralPath $TemporaryPath -Destination $ResolvedPath -Force
} finally {
    if (Test-Path -LiteralPath $TemporaryPath -PathType Leaf) {
        Remove-Item -LiteralPath $TemporaryPath -Force
    }
}

$WrittenHash = (Get-FileHash -LiteralPath $ResolvedPath -Algorithm SHA256).Hash
if ($WrittenHash -ne $ExpectedOutputHash) {
    throw "Written Asphyxia hash mismatch: $WrittenHash"
}
Write-Host "Asphyxia private-config patch applied: $ResolvedPath"
Write-Host "SHA-256: $WrittenHash"
