import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { dirname, extname, join } from "node:path";
import { fileURLToPath } from "node:url";

const webroot = join(dirname(fileURLToPath(import.meta.url)), "..", "webroot");
const port = Number(process.env.SKP_WEBUI_MOCK_PORT || 4173);

const status = {
  device: "aurora",
  marketName: "Xiaomi 14 Ultra",
  kernel: "6.1.75-android14",
  mode: "cool",
  modeLabel: "夏日限定",
  activeMode: "cool",
  thermalState: "active",
  thermalActive: true,
  thermalConfigFiles: 14,
  propertyOverridesActive: 7,
  propertyOverridesTotal: 7,
  transactionState: "clean",
  controllerEnabled: true,
  controllerState: "running",
  profilesReady: true,
  configExists: true
};

const runtimeEvents = [
  "2026-08-01 14:30:00 [BOOT_OK] 温控模式=cool，磁盘模式=cool，控制器=已调度",
  "2026-08-01 14:30:01 [MODE_OK] 设置模式=cool，磁盘模式=cool"
];

function eventTimestamp() {
  return new Date().toISOString().replace("T", " ").slice(0, 19);
}

function appendRuntimeEvent(event, detail) {
  runtimeEvents.push(`${eventTimestamp()} [${event}] ${detail}`);
  if (runtimeEvents.length > 100) runtimeEvents.splice(0, runtimeEvents.length - 100);
}

function runtimeLogText() {
  const thermalLabels = {
    active: "已生效",
    partial: "部分属性未生效",
    recovering: "正在恢复事务",
    error: "检测到错误",
    not_ready: "配置未就绪",
    mismatch: "模式不一致"
  };
  const controllerLabels = {
    running: "运行中",
    waiting: "等待开机",
    restarting: "正在重启",
    stopped: status.controllerEnabled ? "异常停止" : "未启用"
  };
  return `[当前验证]
温控状态=${thermalLabels[status.thermalState] || "未知"} (${status.thermalState})
设置模式=${status.mode}，磁盘模式=${status.activeMode || "未识别"}
配置文件=${status.thermalConfigFiles}，配置模板=${status.profilesReady ? "就绪" : "缺失/过期"}
系统属性覆盖=${status.propertyOverridesActive}/${status.propertyOverridesTotal}
事务状态=${status.transactionState === "clean" ? "正常" : status.transactionState} (${status.transactionState})
控制器=${controllerLabels[status.controllerState] || "未知"} (${status.controllerState})

[模块运行事件]
${runtimeEvents.join("\n")}

[控制器输出]
${status.controllerState === "running" ? "控制器运行中" : "暂无运行输出"}

[控制器启动器]
${status.controllerState === "running" ? "Asphyxia started: pid=1234" : "暂无记录"}`;
}

let config = `[limits]
"/data/system/mcd/df" = "000"

[config]
"/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq" = "0"

[config.com.example.game]
"/sys/class/thermal/thermal_message/sconfig" = "10"

[default.com.example.game]
"/sys/class/thermal/thermal_message/sconfig" = "0"
`;

const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8"
};

function send(response, statusCode, body, contentType = "text/plain; charset=utf-8") {
  response.writeHead(statusCode, {
    "Content-Type": contentType,
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store"
  });
  response.end(body);
}

async function readBody(request) {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  return Buffer.concat(chunks).toString("utf8");
}

createServer(async (request, response) => {
  const url = new URL(request.url || "/", `http://${request.headers.host}`);
  if (request.method === "GET" && url.pathname === "/api/status") {
    send(response, 200, JSON.stringify(status), "application/json; charset=utf-8");
    return;
  }

  if (request.method === "GET" && url.pathname === "/api/session") {
    return send(response, 200, "ok");
  }
  if (request.method === "GET" && url.pathname === "/api/config") {
    send(response, 200, config);
    return;
  }
  if (request.method === "GET" && url.pathname === "/api/log") {
    send(response, 200, runtimeLogText());
    return;
  }
  if (request.method === "GET" && url.pathname === "/api/walt-policies") {
    send(response, 200, JSON.stringify(["policy0", "policy4", "policy7"]),
      "application/json; charset=utf-8");
    return;
  }
  if (request.method === "POST" && url.pathname === "/api/mode") {
    const mode = (await readBody(request)).trim();
    const labels = { cool: "夏日限定", pro: "深度定制", extreme: "极致性能", danger: "丧心病狂" };
    if (!labels[mode]) return send(response, 400, "无效温控模式");
    status.mode = mode;
    status.activeMode = mode;
    status.modeLabel = labels[mode];
    appendRuntimeEvent("MODE_OK", `设置模式=${mode}，磁盘模式=${mode}`);
    send(response, 200, `已切换到${labels[mode]}`);
    return;
  }
  if (request.method === "POST" && url.pathname === "/api/controller") {
    status.controllerEnabled = (await readBody(request)).trim() === "true";
    status.controllerState = status.controllerEnabled ? "running" : "stopped";
    appendRuntimeEvent(
      "CONTROLLER",
      status.controllerEnabled ? "控制器已启用并启动" : "控制器已停用"
    );
    send(response, 200, status.controllerEnabled ? "控制器已启用" : "控制器已停用");
    return;
  }
  if (request.method === "POST" && url.pathname === "/api/config") {
    config = await readBody(request);
    appendRuntimeEvent("CONFIG", `控制器配置已保存，字节数=${Buffer.byteLength(config)}`);
    send(response, 200, "配置已保存");
    return;
  }

  const files = { "/": "index.html", "/index.html": "index.html", "/app.js": "app.js", "/style.css": "style.css" };
  const file = files[url.pathname];
  if (!file) return send(response, 404, "Not found");
  try {
    const body = await readFile(join(webroot, file));
    send(response, 200, body, types[extname(file)] || "application/octet-stream");
  } catch (error) {
    send(response, 500, String(error));
  }
}).listen(port, "127.0.0.1", () => {
  process.stdout.write(`http://127.0.0.1:${port}\n`);
});
