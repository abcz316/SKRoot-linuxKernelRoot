param(
    [string]$OriginalArchive = "",
    [string]$Destination = (Join-Path (Split-Path -Parent $PSScriptRoot) "dist\rollback\original_thermal_v5.7-260717.zip")
)

$ErrorActionPreference = "Stop"
$ExpectedHash = "047516C68CF211BCCD49208C4C97859A84A4D7311C7B4041AFD301E78FA75636"

if ([string]::IsNullOrWhiteSpace($OriginalArchive)) {
    $OriginalArchive = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE "Downloads") `
        -File -Filter "*.zip" |
        Where-Object {
            (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash -eq $ExpectedHash
        } |
        Select-Object -First 1 -ExpandProperty FullName
}

if ([string]::IsNullOrWhiteSpace($OriginalArchive) -or
    -not (Test-Path -LiteralPath $OriginalArchive -PathType Leaf)) {
    throw "Original archive was not found: $OriginalArchive"
}
$ActualHash = (Get-FileHash -LiteralPath $OriginalArchive -Algorithm SHA256).Hash
if ($ActualHash -ne $ExpectedHash) {
    throw "Original archive hash mismatch: $ActualHash"
}

$Parent = Split-Path -Parent ([IO.Path]::GetFullPath($Destination))
New-Item -ItemType Directory -Force -Path $Parent | Out-Null
Copy-Item -LiteralPath $OriginalArchive -Destination $Destination -Force
$RestoredHash = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash
if ($RestoredHash -ne $ExpectedHash) {
    throw "Rollback copy verification failed: $RestoredHash"
}

Write-Host "Original package restored: $Destination"
Write-Host "SHA-256: $RestoredHash"
