# 迁移记录

## 对应关系

| 原 KSU/Magisk 入口 | SKP 实现 |
| --- | --- |
| `module.prop` | `SKROOT_MODULE_NAME/VERSION/DESC/AUTHOR/ID32` |
| `customize.sh` 设备校验 | `module_on_install` |
| `Eclipse` 配置生成 | 安装回调内受超时约束且 fork 后仅调用异步信号安全 syscall 的 `execve` |
| 安装音量键模式选择 | 安全默认值 `cool` + SKP WebUI 四段模式控件 |
| `action.sh` / `thermal.sh` | `/api/mode` + 同文件系统 `RENAME_EXCHANGE` 事务与崩溃恢复 |
| `system.prop` | zygote64 前执行 `resetprop`，原值持久化并在卸载时恢复 |
| `service.sh` | `skroot_module_main` exec 独立 helper，由 helper 双 fork 并等待开机 |
| `uninstall.sh` | `module_on_uninstall` 精确停进程、恢复 OEM 配置和属性 |
| `window.ksu.exec` | 回环会话认证、同源校验、固定路径与固定数据格式的 CivetWeb API |
| 外置 `Asphyxia.toml` | `0600` 的 SKP 私有配置；旧文件仅作首次迁移源；二进制路径改为 `state/Asphyxia.toml` |

## 行为修正

- 不再先清空 live config 再假定复制成功；候选目录与 live config 位于同一挂载点，
  通过 `renameat2(RENAME_EXCHANGE)` 单次提交。事务树内身份文件可区分崩溃发生在
  交换前还是交换后。
- 不再无条件删除 OEM config；安装前保存一次稳定备份，卸载时恢复。
- OEM 备份和四套 profile 都带来源指纹与逐文件内容/元数据清单，固件变化、文件
  缺失或备份损坏时停止自动覆盖。
- 不再删除原有 `persist.*` 属性；记录属性是否存在及原值，卸载时准确恢复。
- 任一开机启动步骤失败时统一停止控制器并恢复七项属性，避免上一轮持久属性在
  备份校验或配置生成失败后继续生效。
- 不再执行来自 WebUI 的任意 shell 字符串。
- 不再从共享存储读取持续生效的 root 写节点规则。
- Asphyxia 原有的共享存储绝对配置路径改为相对的 `state/Asphyxia.toml`，并由 helper
  从模块私有目录无参数启动，保持原控制器调用约定并消除对共享默认路径的依赖。
- 不再以进程名全局 `killall`；PID 与 `/proc/<pid>/exe` 匹配，并扫描清理 PID 文件
  丢失的本模块实例和已卸载旧模块残留实例。
- 控制器配置保存改为原子替换，并保留最近一次 `.bak`。
- 控制器配置增加服务端 TOML 结构、重复项、权限值、目标路径和符号链接校验。
- CivetWeb API 拒绝非回环 peer，通过随机 HttpOnly cookie 建立会话，并检查同源
  请求头；即使 SDK Web 服务器监听所有接口，LAN 请求也不能进入 API。
- 已持有随机会话 cookie 的回环 API 请求兼容省略 POST Origin/Referer 的 Android
  WebView；所有实际提供的 Host、Origin/Referer 和 Fetch Metadata 仍会严格校验。
- 前端对无法无损往返的 TOML 进入只读保护；编辑操作不再解除该保护。
- WebUI 操作结果改为固定浮层，模式切换或控制器错误不再隐藏在长配置列表底部；
  Asphyxia 输出以及 helper 记录的启动 PID、退出码或终止信号写入模块私有
  `state/controller.log`。控制器 supervisor 保留 PID 并对短暂退出做有界退避重启，
  WebUI 在退避期间显示重启状态。
- 模式事务对 Android 16 上不可用的 immutable ioctl、厂商文件 chown 和 SELinux
  恢复按 best-effort 处理；交换前失败会清理 marker，旧候选目录可整体退役，普通
  退役目录有上限，原厂回滚使用独立的 bypass 清理路径并在删除备份前持久化 marker。
- API 将格式校验错误与文件系统/事务错误分别映射到 HTTP 400/500；控制器配置保存
  会先备份旧字节，不要求旧配置本身仍能通过新格式校验。
- 打包逐项写入标准 `/` ZIP 路径并直接检查原始条目名，避免 Windows
  `Compress-Archive` 生成反斜杠目录；固定条目顺序和时间戳以支持确定性复建。

## 保留边界

`Eclipse`、`miui-thermal` 和 `Asphyxia` 是原包唯一的算法实现，且没有源码。
本次重构没有猜测性重写其加密与设备规则，而是将它们限制为哈希固定、环境固定、
路径固定的 ARM64 用户态载荷。其生命周期和权限边界已迁入 SKP 原生代码。

后续若要实现“零旧二进制”，必须取得源码，或建立覆盖多代 MIUI/HyperOS、不同
Qualcomm 平台和新旧温控密钥的输入输出 fixture；否则无法证明生成配置等价。
