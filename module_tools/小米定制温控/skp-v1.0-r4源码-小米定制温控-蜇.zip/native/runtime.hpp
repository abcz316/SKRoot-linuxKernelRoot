#pragma once

#include <filesystem>
#include <string>

namespace custom_thermal {

namespace fs = std::filesystem;

std::string install_module(const fs::path& module_dir);
std::string start_module(const fs::path& module_dir);
void uninstall_module(const fs::path& module_dir);

std::string status_json(const fs::path& module_dir);
std::string runtime_log_text(const fs::path& module_dir);
std::string runtime_description(const fs::path& module_dir);
std::string walt_policies_json();

// Used by the WebUI to distinguish a bad mode value from a runtime failure.
bool is_valid_mode_request(const std::string& requested_mode);

bool select_mode(const fs::path& module_dir, const std::string& mode,
                 std::string& message);
bool set_controller_enabled(const fs::path& module_dir, bool enabled,
                            std::string& message);
bool validate_controller_config_request(const std::string& content,
                                        std::string& message);
bool read_controller_config(const fs::path& module_dir, std::string& content,
                            std::string& message);
bool write_controller_config(const fs::path& module_dir, const std::string& content,
                             std::string& message);

}  // namespace custom_thermal
