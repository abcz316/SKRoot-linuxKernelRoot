#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <sys/wait.h>

#include "controller_process.hpp"

#include <fcntl.h>
#include <signal.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <thread>

namespace {

using namespace std::chrono_literals;

std::string child_path(const std::string& module_dir, const char* suffix) {
    return module_dir + suffix;
}

bool write_pid_atomic(const std::string& path, pid_t pid) {
    const std::string temporary = path + ".tmp." + std::to_string(::getpid());
    const int descriptor = ::open(temporary.c_str(),
                                  O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC |
                                      O_NOFOLLOW,
                                  0600);
    if (descriptor < 0) return false;
    char text[32];
    const int length = std::snprintf(text, sizeof(text), "%d\n",
                                     static_cast<int>(pid));
    bool ok = length > 0;
    size_t offset = 0;
    while (ok && offset < static_cast<size_t>(length)) {
        const ssize_t written = ::write(descriptor, text + offset,
                                        static_cast<size_t>(length) - offset);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) {
            ok = false;
            break;
        }
        offset += static_cast<size_t>(written);
    }
    if (ok && ::fsync(descriptor) != 0) ok = false;
    if (::close(descriptor) != 0) ok = false;
    if (ok && ::rename(temporary.c_str(), path.c_str()) != 0) ok = false;
    if (!ok) (void)::unlink(temporary.c_str());
    return ok;
}

pid_t read_pid(const std::string& path) {
    std::ifstream stream(path);
    long value = -1;
    stream >> value;
    return stream && value > 1 && value <= 4194304
               ? static_cast<pid_t>(value)
               : -1;
}

std::string read_small_file(const std::string& path, size_t limit = 4096) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) return {};
    std::string value;
    char buffer[512];
    while (stream && value.size() <= limit) {
        stream.read(buffer, sizeof(buffer));
        value.append(buffer, static_cast<size_t>(stream.gcount()));
    }
    return value.size() <= limit ? value : std::string();
}

bool controller_enabled(const std::string& module_dir) {
    const std::string settings =
        read_small_file(child_path(module_dir, "/state/settings.conf"));
    size_t begin = 0;
    while (begin < settings.size()) {
        const size_t end = settings.find('\n', begin);
        const std::string line = settings.substr(
            begin, end == std::string::npos ? std::string::npos : end - begin);
        if (line == "controller=1") return true;
        if (line == "controller=0") return false;
        if (end == std::string::npos) break;
        begin = end + 1;
    }
    return false;
}

std::string property(const char* key) {
    char value[PROP_VALUE_MAX] = {};
    const int length = __system_property_get(key, value);
    return length > 0 ? std::string(value, static_cast<size_t>(length))
                      : std::string();
}

void redirect_and_close_descriptors(const std::string& module_dir) {
    const int input = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
    int output = ::open(child_path(module_dir, "/state/controller.log").c_str(),
                        O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (output < 0) output = ::open("/dev/null", O_WRONLY | O_CLOEXEC);
    if (input < 0 || output < 0) {
        if (input >= 0) ::close(input);
        if (output >= 0) ::close(output);
        _exit(126);
    }
    if (::dup2(input, STDIN_FILENO) < 0 ||
        ::dup2(output, STDOUT_FILENO) < 0 ||
        ::dup2(output, STDERR_FILENO) < 0) {
        _exit(126);
    }
    if (input > STDERR_FILENO) ::close(input);
    if (output > STDERR_FILENO && output != input) ::close(output);
    const long open_max = ::sysconf(_SC_OPEN_MAX);
    const int maximum = open_max > 0 && open_max < 1048576
                            ? static_cast<int>(open_max)
                            : 65536;
    for (int fd = STDERR_FILENO + 1; fd < maximum; ++fd) ::close(fd);
}

[[noreturn]] void exit_supervisor(const std::string& module_dir, int code) {
    (void)::unlink(child_path(module_dir, "/state/controller.pid").c_str());
    (void)::unlink(child_path(module_dir, "/state/controller_waiter.pid").c_str());
    (void)::unlink(child_path(module_dir, "/state/controller_supervisor.pid").c_str());
    _exit(code);
}

int run_controller_once(const std::string& module_dir) {
    const std::string executable = child_path(module_dir, "/bin/Asphyxia");
    const std::string pid_file = child_path(module_dir, "/state/controller.pid");
    const pid_t controller = ::fork();
    if (controller < 0) {
        std::fprintf(stderr, "[custom_thermal_helper] controller fork failed: errno=%d\n",
                     errno);
        return 124;
    }
    if (controller == 0) {
        // The packaged binary resolves its patched state/Asphyxia.toml path here.
        char* const arguments[] = {const_cast<char*>(executable.c_str()), nullptr};
        char path[] = "PATH=/system/bin:/system/xbin:/vendor/bin:/odm/bin:/product/bin";
        char android_root[] = "ANDROID_ROOT=/system";
        char android_data[] = "ANDROID_DATA=/data";
        char library_path[] =
            "LD_LIBRARY_PATH=/system/lib64:/vendor/lib64:/odm/lib64:/product/lib64";
        char* const environment[] = {path, android_root, android_data, library_path,
                                     nullptr};
        ::execve(executable.c_str(), arguments, environment);
        std::fprintf(stderr, "[custom_thermal_helper] Asphyxia exec failed: errno=%d\n",
                     errno);
        _exit(127);
    }

    if (!write_pid_atomic(pid_file, controller)) {
        std::fprintf(stderr, "[custom_thermal_helper] PID write failed: errno=%d\n", errno);
        (void)::kill(controller, SIGTERM);
        while (::waitpid(controller, nullptr, 0) < 0 && errno == EINTR) {
        }
        return 125;
    }
    std::fprintf(stderr, "[custom_thermal_helper] Asphyxia started: pid=%d, "
                         "config=state/Asphyxia.toml\n",
                 static_cast<int>(controller));

    int status = 0;
    pid_t waited = -1;
    do {
        waited = ::waitpid(controller, &status, 0);
    } while (waited < 0 && errno == EINTR);
    (void)::unlink(pid_file.c_str());
    if (waited < 0) {
        std::fprintf(stderr, "[custom_thermal_helper] waitpid failed: errno=%d\n", errno);
        return 123;
    }
    if (WIFEXITED(status)) {
        const int code = WEXITSTATUS(status);
        std::fprintf(stderr, "[custom_thermal_helper] Asphyxia exited: code=%d\n", code);
        return code;
    }
    if (WIFSIGNALED(status)) {
        const int signal = WTERMSIG(status);
        std::fprintf(stderr, "[custom_thermal_helper] Asphyxia terminated: signal=%d\n",
                     signal);
        return signal < 127 ? 128 + signal : 255;
    }
    std::fprintf(stderr, "[custom_thermal_helper] Asphyxia ended: status=%d\n", status);
    return 122;
}

[[noreturn]] void run_controller(const std::string& module_dir) {
    if (::chdir(module_dir.c_str()) != 0) {
        std::fprintf(stderr, "[custom_thermal_helper] chdir failed: errno=%d\n", errno);
        exit_supervisor(module_dir, 125);
    }

    constexpr int kMaximumConsecutiveFailures = 5;
    constexpr auto kStableRuntime = std::chrono::minutes(5);
    int consecutive_failures = 0;
    int last_code = 0;
    while (controller_enabled(module_dir)) {
        const auto started = std::chrono::steady_clock::now();
        last_code = run_controller_once(module_dir);
        if (!controller_enabled(module_dir)) exit_supervisor(module_dir, 0);

        if (std::chrono::steady_clock::now() - started >= kStableRuntime) {
            consecutive_failures = 0;
        }
        ++consecutive_failures;
        if (consecutive_failures >= kMaximumConsecutiveFailures) {
            std::fprintf(stderr,
                         "[custom_thermal_helper] restart limit reached: failures=%d, code=%d\n",
                         consecutive_failures, last_code);
            exit_supervisor(module_dir, last_code == 0 ? 122 : last_code);
        }

        int delay_seconds = 1 << (consecutive_failures - 1);
        if (delay_seconds > 16) delay_seconds = 16;
        std::fprintf(stderr,
                     "[custom_thermal_helper] restarting Asphyxia in %d second(s): attempt=%d\n",
                     delay_seconds, consecutive_failures + 1);
        for (int second = 0; second < delay_seconds; ++second) {
            if (!controller_enabled(module_dir)) exit_supervisor(module_dir, 0);
            std::this_thread::sleep_for(1s);
        }
    }
    exit_supervisor(module_dir, 0);
}

[[noreturn]] void daemon_child(const std::string& module_dir, bool wait_for_boot) {
    redirect_and_close_descriptors(module_dir);
    (void)::prctl(PR_SET_NAME, custom_thermal::kControllerWaiterProcessName, 0, 0, 0);
    const std::string supervisor_file =
        child_path(module_dir, "/state/controller_supervisor.pid");
    if (!write_pid_atomic(supervisor_file, ::getpid())) _exit(125);
    if (!wait_for_boot) run_controller(module_dir);

    const std::string waiter_file =
        child_path(module_dir, "/state/controller_waiter.pid");
    if (!write_pid_atomic(waiter_file, ::getpid())) {
        exit_supervisor(module_dir, 125);
    }
    while (property("sys.boot_completed") != "1") {
        if (!controller_enabled(module_dir)) {
            exit_supervisor(module_dir, 0);
        }
        std::this_thread::sleep_for(1s);
    }
    constexpr int kPostBootGraceSeconds = 15;
    std::fprintf(stderr,
                 "[custom_thermal_helper] Android boot completed; starting controller "
                 "in %d second(s)\n",
                 kPostBootGraceSeconds);
    for (int second = 0; second < kPostBootGraceSeconds; ++second) {
        if (!controller_enabled(module_dir)) {
            exit_supervisor(module_dir, 0);
        }
        std::this_thread::sleep_for(1s);
    }
    (void)::unlink(waiter_file.c_str());
    run_controller(module_dir);
}

bool process_executable_matches(pid_t pid, const std::string& expected) {
    if (pid <= 1 || (::kill(pid, 0) != 0 && errno != EPERM)) return false;
    const std::string link = "/proc/" + std::to_string(pid) + "/exe";
    char buffer[4096];
    const ssize_t length = ::readlink(link.c_str(), buffer, sizeof(buffer) - 1);
    if (length <= 0) return false;
    buffer[length] = '\0';
    return expected == buffer;
}

bool process_name_matches(pid_t pid, const char* expected) {
    if (pid <= 1 || (::kill(pid, 0) != 0 && errno != EPERM)) return false;
    std::string name = read_small_file("/proc/" + std::to_string(pid) + "/comm", 128);
    while (!name.empty() && (name.back() == '\n' || name.back() == '\r')) {
        name.pop_back();
    }
    return name == expected;
}

int launch(const std::string& module_dir, bool wait_for_boot) {
    const pid_t first = ::fork();
    if (first < 0) return 1;
    if (first == 0) {
        if (::setsid() < 0) _exit(124);
        const pid_t daemon = ::fork();
        if (daemon < 0) _exit(124);
        if (daemon > 0) _exit(0);
        daemon_child(module_dir, wait_for_boot);
    }

    int status = 0;
    while (::waitpid(first, &status, 0) < 0 && errno == EINTR) {
    }
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) return 2;

    const std::string pid_file = child_path(
        module_dir, wait_for_boot ? "/state/controller_waiter.pid"
                                  : "/state/controller.pid");
    const std::string executable = child_path(module_dir, "/bin/Asphyxia");
    const std::string helper = child_path(module_dir, "/bin/custom_thermal_helper");
    for (int attempt = 0; attempt < 30; ++attempt) {
        const pid_t pid = read_pid(pid_file);
        const bool matches = wait_for_boot
                                 ? process_name_matches(
                                       pid, custom_thermal::kControllerWaiterProcessName) &&
                                       process_executable_matches(pid, helper)
                                 : process_executable_matches(pid, executable);
        if (matches) return 0;
        std::this_thread::sleep_for(100ms);
    }
    return 3;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 3 || argv[1] == nullptr || argv[2] == nullptr) return 64;
    const std::string operation = argv[1];
    const std::string module_dir = argv[2];
    if (module_dir.empty() || module_dir.front() != '/' ||
        module_dir.find('\n') != std::string::npos) {
        return 65;
    }
    if (operation == "start") return launch(module_dir, false);
    if (operation == "wait") return launch(module_dir, true);
    return 64;
}
