#include "platform.hpp"

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <sys/syscall.h>

#include <fcntl.h>
#include <linux/fs.h>
#include <signal.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <thread>

#ifndef RENAME_EXCHANGE
#define RENAME_EXCHANGE (1U << 1)
#endif

#ifndef SYS_renameat2
#if defined(__NR_renameat2)
#define SYS_renameat2 __NR_renameat2
#endif
#endif

#ifndef SYS_close_range
#if defined(__NR_close_range)
#define SYS_close_range __NR_close_range
#endif
#endif

namespace custom_thermal::platform {

namespace {

bool copy_file_contents(const fs::path& source, const fs::path& destination,
                        mode_t mode, std::string* error) {
    const int input = ::open(source.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (input < 0) {
        if (error) *error = "open source failed: " + source.string();
        return false;
    }

    const int output = ::open(destination.c_str(),
                              O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW,
                              mode);
    if (output < 0) {
        ::close(input);
        if (error) *error = "open destination failed: " + destination.string();
        return false;
    }

    bool ok = true;
    char buffer[64 * 1024];
    for (;;) {
        const ssize_t count = ::read(input, buffer, sizeof(buffer));
        if (count == 0) break;
        if (count < 0) {
            if (errno == EINTR) continue;
            ok = false;
            break;
        }

        ssize_t offset = 0;
        while (offset < count) {
            const ssize_t written =
                ::write(output, buffer + offset, static_cast<size_t>(count - offset));
            if (written < 0 && errno == EINTR) continue;
            if (written <= 0) {
                ok = false;
                break;
            }
            offset += written;
        }
        if (!ok) break;
    }

    if (ok && ::fsync(output) != 0) ok = false;
    if (::close(output) != 0) ok = false;
    ::close(input);
    if (!ok && error) *error = "copy failed: " + source.string();
    return ok;
}

bool apply_metadata(const fs::path& source, const fs::path& destination,
                    bool preserve_metadata) {
    struct stat status {};
    if (::lstat(source.c_str(), &status) != 0) return false;

    const mode_t mode = preserve_metadata ? (status.st_mode & 07777)
                                          : (S_ISDIR(status.st_mode) ? 0755 : 0644);
    if (::chmod(destination.c_str(), mode) != 0) return false;
    if (preserve_metadata && ::chown(destination.c_str(), status.st_uid, status.st_gid) != 0) {
        return false;
    }
    return true;
}

bool copy_tree_entry(const fs::path& source, const fs::path& destination,
                     bool preserve_metadata, std::string* error) {
    struct stat status {};
    if (::lstat(source.c_str(), &status) != 0) {
        if (error) *error = "stat failed: " + source.string();
        return false;
    }
    if (S_ISLNK(status.st_mode)) {
        if (error) *error = "symbolic links are not accepted: " + source.string();
        return false;
    }
    if (S_ISDIR(status.st_mode)) {
        if (!ensure_directory(destination, 0755)) {
            if (error) *error = "create directory failed: " + destination.string();
            return false;
        }
        return apply_metadata(source, destination, preserve_metadata);
    }
    if (!S_ISREG(status.st_mode)) {
        if (error) *error = "unsupported file type: " + source.string();
        return false;
    }

    if (!ensure_directory(destination.parent_path(), 0755)) {
        if (error) *error = "create parent failed: " + destination.parent_path().string();
        return false;
    }
    const mode_t mode = preserve_metadata ? (status.st_mode & 07777) : 0644;
    if (!copy_file_contents(source, destination, mode, error)) return false;
    return apply_metadata(source, destination, preserve_metadata);
}

int open_child_output(const fs::path& log_path) {
    int output = -1;
    if (!log_path.empty()) {
        output = ::open(log_path.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    }
    if (output < 0) output = ::open("/dev/null", O_WRONLY | O_CLOEXEC);
    return output;
}

void redirect_preopened_child_streams(int input, int output, int maximum_fd) {
    if (::dup2(input, STDIN_FILENO) < 0 ||
        ::dup2(output, STDOUT_FILENO) < 0 ||
        ::dup2(output, STDERR_FILENO) < 0) {
        _exit(126);
    }
#if defined(SYS_close_range)
    if (::syscall(SYS_close_range, static_cast<unsigned int>(STDERR_FILENO + 1),
                  ~0U, 0U) == 0) {
        return;
    }
#endif
    for (int descriptor = STDERR_FILENO + 1; descriptor < maximum_fd; ++descriptor) {
        ::close(descriptor);
    }
}

}  // namespace

std::string clean_directory(const char* path) {
    std::string result = path ? path : "";
    while (!result.empty() && result.back() == '/') result.pop_back();
    return result;
}

std::string get_property(const char* key) {
    char value[PROP_VALUE_MAX] = {};
    const int length = __system_property_get(key, value);
    if (length <= 0) return {};
    return std::string(value, static_cast<size_t>(length));
}

std::string kernel_release() {
    struct utsname information {};
    if (::uname(&information) != 0) return {};
    return information.release;
}

bool kernel_at_least(int required_major, int required_minor) {
    const std::string release = kernel_release();
    int major = -1;
    int minor = -1;
    if (std::sscanf(release.c_str(), "%d.%d", &major, &minor) != 2) return false;
    return major > required_major ||
           (major == required_major && minor >= required_minor);
}

bool read_text_file(const fs::path& path, std::string& output, size_t max_bytes) {
    output.clear();
    std::error_code error;
    const uintmax_t size = fs::file_size(path, error);
    if (error || size > max_bytes) return false;

    std::ifstream stream(path, std::ios::binary);
    if (!stream) return false;
    output.assign(std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>());
    return stream.good() || stream.eof();
}

bool write_text_file_atomic(const fs::path& path, const std::string& content,
                            mode_t mode) {
    std::error_code parent_error;
    if (!fs::is_directory(path.parent_path(), parent_error)) {
        parent_error.clear();
        if (!ensure_directory(path.parent_path(), 0755)) return false;
    }
    const fs::path temporary = path.string() + ".tmp." + std::to_string(::getpid());
    const int descriptor = ::open(temporary.c_str(),
                                  O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW,
                                  mode);
    if (descriptor < 0) return false;

    bool ok = true;
    size_t offset = 0;
    while (offset < content.size()) {
        const ssize_t written = ::write(descriptor, content.data() + offset,
                                        content.size() - offset);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) {
            ok = false;
            break;
        }
        offset += static_cast<size_t>(written);
    }
    if (ok && ::fsync(descriptor) != 0) ok = false;
    if (::close(descriptor) != 0) ok = false;
    if (ok && ::chmod(temporary.c_str(), mode) != 0) ok = false;
    if (ok && ::rename(temporary.c_str(), path.c_str()) != 0) ok = false;
    if (!ok) ::unlink(temporary.c_str());
    return ok;
}

bool ensure_directory(const fs::path& path, mode_t mode) {
    if (path.empty()) return false;
    std::error_code error;
    fs::create_directories(path, error);
    if (error) return false;
    return ::chmod(path.c_str(), mode) == 0;
}

bool remove_children(const fs::path& directory, std::string* error) {
    std::error_code iterator_error;
    fs::directory_iterator iterator(directory, iterator_error);
    if (iterator_error) {
        if (error) *error = "open directory failed: " + directory.string();
        return false;
    }
    for (const auto& entry : iterator) {
        std::error_code remove_error;
        fs::remove_all(entry.path(), remove_error);
        if (remove_error) {
            if (error) *error = "remove failed: " + entry.path().string();
            return false;
        }
    }
    return true;
}

bool copy_tree(const fs::path& source, const fs::path& destination,
               bool preserve_metadata, std::string* error) {
    std::error_code status_error;
    if (!fs::is_directory(source, status_error) || status_error) {
        if (error) *error = "source directory is missing: " + source.string();
        return false;
    }
    if (!copy_tree_entry(source, destination, preserve_metadata, error)) return false;

    std::error_code iterator_error;
    fs::recursive_directory_iterator iterator(
        source, fs::directory_options::skip_permission_denied, iterator_error);
    const fs::recursive_directory_iterator end;
    while (iterator != end) {
        if (iterator_error) {
            if (error) *error = "walk failed: " + source.string();
            return false;
        }
        const fs::path relative = iterator->path().lexically_relative(source);
        if (relative.empty() || *relative.begin() == "..") {
            if (error) *error = "unsafe relative path: " + iterator->path().string();
            return false;
        }
        if (!copy_tree_entry(iterator->path(), destination / relative,
                             preserve_metadata, error)) {
            return false;
        }
        iterator.increment(iterator_error);
    }
    return true;
}

bool tree_has_regular_file(const fs::path& directory) {
    std::error_code error;
    fs::recursive_directory_iterator iterator(
        directory, fs::directory_options::skip_permission_denied, error);
    const fs::recursive_directory_iterator end;
    while (!error && iterator != end) {
        if (iterator->is_regular_file(error) && !error) return true;
        iterator.increment(error);
    }
    return false;
}

bool atomic_replace_directory(const fs::path& candidate,
                              const fs::path& destination,
                              std::string* error) {
    struct stat candidate_status {};
    if (::lstat(candidate.c_str(), &candidate_status) != 0 ||
        !S_ISDIR(candidate_status.st_mode)) {
        if (error) *error = "candidate directory is missing: " + candidate.string();
        return false;
    }

    struct stat destination_status {};
    const bool destination_exists =
        ::lstat(destination.c_str(), &destination_status) == 0;
    if (destination_exists && !S_ISDIR(destination_status.st_mode)) {
        if (error) *error = "destination is not a directory: " + destination.string();
        return false;
    }

    int result = -1;
    if (destination_exists) {
#if defined(SYS_renameat2)
        result = static_cast<int>(::syscall(SYS_renameat2, AT_FDCWD,
                                            candidate.c_str(), AT_FDCWD,
                                            destination.c_str(), RENAME_EXCHANGE));
#else
        errno = ENOSYS;
#endif
    } else {
        result = ::rename(candidate.c_str(), destination.c_str());
    }
    if (result != 0) {
        if (error) {
            *error = "atomic directory replacement failed: " +
                     std::string(std::strerror(errno));
        }
        return false;
    }

    const fs::path parent = destination.parent_path();
    const int descriptor = ::open(parent.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (descriptor >= 0) {
        (void)::fsync(descriptor);
        ::close(descriptor);
    }
    return true;
}

bool set_immutable(const fs::path& path, bool immutable) {
    const int descriptor = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) return false;
    unsigned long flags = 0;
    bool ok = ::ioctl(descriptor, FS_IOC_GETFLAGS, &flags) == 0;
    if (ok) {
        const unsigned long updated = immutable ? (flags | FS_IMMUTABLE_FL)
                                                : (flags & ~FS_IMMUTABLE_FL);
        if (updated != flags) ok = ::ioctl(descriptor, FS_IOC_SETFLAGS, &updated) == 0;
    }
    ::close(descriptor);
    return ok;
}

bool get_immutable(const fs::path& path, bool& immutable) {
    immutable = false;
    const int descriptor = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) return false;
    unsigned long flags = 0;
    const bool ok = ::ioctl(descriptor, FS_IOC_GETFLAGS, &flags) == 0;
    ::close(descriptor);
    if (ok) immutable = (flags & FS_IMMUTABLE_FL) != 0;
    return ok;
}

void set_tree_immutable(const fs::path& root, bool immutable,
                        bool regular_files_only_when_locking) {
    if (!immutable) (void)set_immutable(root, false);

    std::error_code error;
    fs::recursive_directory_iterator iterator(
        root, fs::directory_options::skip_permission_denied, error);
    const fs::recursive_directory_iterator end;
    while (!error && iterator != end) {
        const bool regular = iterator->is_regular_file(error);
        const bool directory = !error && iterator->is_directory(error);
        if (!error && (regular || (!immutable && directory) ||
                       (immutable && !regular_files_only_when_locking && directory))) {
            (void)set_immutable(iterator->path(), immutable);
        }
        iterator.increment(error);
    }
    if (immutable && !regular_files_only_when_locking) (void)set_immutable(root, true);
}

ProcessResult run_process(const std::vector<std::string>& arguments,
                          std::chrono::seconds timeout,
                          const fs::path& log_path) {
    ProcessResult result;
    if (arguments.empty() || arguments.front().empty()) return result;

    std::vector<char*> argv;
    argv.reserve(arguments.size() + 1);
    for (const std::string& argument : arguments) {
        argv.push_back(const_cast<char*>(argument.c_str()));
    }
    argv.push_back(nullptr);
    char* executable = argv.front();
    char** argv_data = argv.data();
    char path[] = "PATH=/system/bin:/system/xbin:/vendor/bin:/odm/bin:/product/bin";
    char android_root[] = "ANDROID_ROOT=/system";
    char android_data[] = "ANDROID_DATA=/data";
    char library_path[] =
        "LD_LIBRARY_PATH=/system/lib64:/vendor/lib64:/odm/lib64:/product/lib64";
    char* const environment[] = {path, android_root, android_data, library_path, nullptr};
    const int input = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
    const int output = open_child_output(log_path);
    const long open_max = ::sysconf(_SC_OPEN_MAX);
    const int maximum_fd = open_max > 0 && open_max < 1048576
                               ? static_cast<int>(open_max)
                               : 65536;
    if (input < 0 || output < 0) {
        if (input >= 0) ::close(input);
        if (output >= 0) ::close(output);
        return result;
    }

    const pid_t child = ::fork();
    if (child < 0) {
        ::close(input);
        ::close(output);
        return result;
    }
    if (child == 0) {
        redirect_preopened_child_streams(input, output, maximum_fd);
        ::execve(executable, argv_data, environment);
        _exit(127);
    }

    ::close(input);
    ::close(output);

    result.started = true;
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    int status = 0;
    for (;;) {
        const pid_t waited = ::waitpid(child, &status, WNOHANG);
        if (waited == child) break;
        if (waited < 0 && errno != EINTR) {
            result.started = false;
            return result;
        }
        if (std::chrono::steady_clock::now() >= deadline) {
            result.timed_out = true;
            ::kill(child, SIGKILL);
            while (::waitpid(child, &status, 0) < 0 && errno == EINTR) {
            }
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    if (WIFEXITED(status)) result.exit_code = WEXITSTATUS(status);
    if (WIFSIGNALED(status)) result.term_signal = WTERMSIG(status);
    return result;
}

bool write_pid_file(const fs::path& path, pid_t pid) {
    return pid > 1 && write_text_file_atomic(path, std::to_string(pid) + "\n", 0600);
}

pid_t read_pid_file(const fs::path& path) {
    std::string text;
    if (!read_text_file(path, text, 64)) return -1;
    char* end = nullptr;
    errno = 0;
    const long parsed = std::strtol(text.c_str(), &end, 10);
    if (errno != 0 || end == text.c_str() || parsed <= 1 || parsed > 4194304) return -1;
    return static_cast<pid_t>(parsed);
}

bool process_alive(pid_t pid) {
    return pid > 1 && (::kill(pid, 0) == 0 || errno == EPERM);
}

std::string process_comm(pid_t pid) {
    std::string value;
    if (!read_text_file(fs::path("/proc") / std::to_string(pid) / "comm", value, 128)) {
        return {};
    }
    return trim_ascii(std::move(value));
}

std::string process_cmdline(pid_t pid) {
    std::string value;
    if (!read_text_file(fs::path("/proc") / std::to_string(pid) / "cmdline", value, 4096)) {
        return {};
    }
    const size_t separator = value.find('\0');
    if (separator != std::string::npos) value.resize(separator);
    return value;
}

std::string process_executable(pid_t pid) {
    const fs::path path = fs::path("/proc") / std::to_string(pid) / "exe";
    char buffer[4096];
    const ssize_t size = ::readlink(path.c_str(), buffer, sizeof(buffer) - 1);
    if (size <= 0) return {};
    buffer[size] = '\0';
    std::string result(buffer, static_cast<size_t>(size));
    constexpr const char* deleted = " (deleted)";
    if (result.size() >= std::strlen(deleted) &&
        result.compare(result.size() - std::strlen(deleted), std::strlen(deleted), deleted) == 0) {
        result.resize(result.size() - std::strlen(deleted));
    }
    return result;
}

bool stop_process(pid_t pid, std::chrono::milliseconds grace_period) {
    if (!process_alive(pid)) return true;
    if (::kill(pid, SIGTERM) != 0 && errno != ESRCH) return false;
    const auto deadline = std::chrono::steady_clock::now() + grace_period;
    while (process_alive(pid) && std::chrono::steady_clock::now() < deadline) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    if (process_alive(pid)) {
        if (::kill(pid, SIGKILL) != 0 && errno != ESRCH) return false;
    }
    return true;
}

std::string json_escape(const std::string& value) {
    static constexpr char hexadecimal[] = "0123456789abcdef";
    std::string escaped;
    escaped.reserve(value.size() + 16);
    for (const unsigned char character : value) {
        switch (character) {
            case '"': escaped += "\\\""; break;
            case '\\': escaped += "\\\\"; break;
            case '\b': escaped += "\\b"; break;
            case '\f': escaped += "\\f"; break;
            case '\n': escaped += "\\n"; break;
            case '\r': escaped += "\\r"; break;
            case '\t': escaped += "\\t"; break;
            default:
                if (character < 0x20) {
                    escaped += "\\u00";
                    escaped += hexadecimal[(character >> 4) & 0x0f];
                    escaped += hexadecimal[character & 0x0f];
                } else {
                    escaped.push_back(static_cast<char>(character));
                }
        }
    }
    return escaped;
}

std::string trim_ascii(std::string value) {
    const auto whitespace = [](unsigned char character) { return std::isspace(character) != 0; };
    value.erase(value.begin(), std::find_if_not(value.begin(), value.end(), whitespace));
    value.erase(std::find_if_not(value.rbegin(), value.rend(), whitespace).base(), value.end());
    return value;
}

}  // namespace custom_thermal::platform
