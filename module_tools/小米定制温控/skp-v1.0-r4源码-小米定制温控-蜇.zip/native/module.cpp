#include "platform.hpp"
#include "runtime.hpp"

#include "kernel_module_kit_umbrella.h"

#include <fcntl.h>
#include <unistd.h>

#include <array>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <exception>
#include <filesystem>
#include <mutex>
#include <string>

namespace {

#define MODULE_DESCRIPTION \
    "小米/红米原生 SKP 定制温控，支持四档模式与 Asphyxia 控制器"

std::filesystem::path module_directory(const char* module_private_dir) {
    return custom_thermal::platform::clean_directory(module_private_dir);
}

std::string random_session_token() {
    std::array<unsigned char, 32> bytes {};
    const int descriptor = ::open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (descriptor < 0) return {};
    size_t offset = 0;
    while (offset < bytes.size()) {
        const ssize_t count = ::read(descriptor, bytes.data() + offset,
                                     bytes.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) break;
        offset += static_cast<size_t>(count);
    }
    ::close(descriptor);
    if (offset != bytes.size()) return {};

    static constexpr char hexadecimal[] = "0123456789abcdef";
    std::string token;
    token.reserve(bytes.size() * 2);
    for (const unsigned char byte : bytes) {
        token.push_back(hexadecimal[(byte >> 4) & 0x0f]);
        token.push_back(hexadecimal[byte & 0x0f]);
    }
    return token;
}

std::string request_header(mg_connection* connection, const char* name) {
    const char* value = connection ? mg_get_header(connection, name) : nullptr;
    return value ? value : "";
}

bool starts_with(const std::string& value, const std::string& prefix) {
    return value.rfind(prefix, 0) == 0;
}

class ThermalWebHandler final : public kernel_module::WebUIHttpHandler {
public:
    void onPrepareCreate(const char* root_key, const char* module_private_dir,
                         uint32_t port) override {
        (void)root_key;
        try {
            module_dir_ = module_directory(module_private_dir);
            port_ = port;
            session_token_ = random_session_token();
        } catch (...) {
            module_dir_.clear();
            session_token_.clear();
        }
    }

    bool handleGet(CivetServer* server, mg_connection* connection,
                   const std::string& path, const std::string& query) override {
        (void)server;
        (void)query;
        try {
            if (path == "/api/session") return establish_session(connection);
            if (starts_with(path, "/api/") && !authorize_api(connection, false)) {
                return true;
            }
            if (path == "/api/status") {
                std::lock_guard<std::mutex> lock(mutex_);
                kernel_module::webui::send_json(
                    connection, 200, custom_thermal::status_json(module_dir_));
                return true;
            }
            if (path == "/api/config") {
                std::lock_guard<std::mutex> lock(mutex_);
                std::string content;
                std::string message;
                const bool ok =
                    custom_thermal::read_controller_config(module_dir_, content, message);
                kernel_module::webui::send_text(connection, ok ? 200 : 500,
                                                ok ? content : message);
                return true;
            }
            if (path == "/api/log") {
                std::lock_guard<std::mutex> lock(mutex_);
                kernel_module::webui::send_text(
                    connection, 200, custom_thermal::runtime_log_text(module_dir_));
                return true;
            }
            if (path == "/api/walt-policies") {
                kernel_module::webui::send_json(
                    connection, 200, custom_thermal::walt_policies_json());
                return true;
            }
        } catch (const std::exception& exception) {
            std::fprintf(stderr, "[custom_thermal_skp] WebUI GET: %s\n",
                         exception.what());
            kernel_module::webui::send_text(connection, 500, "模块内部错误");
            return true;
        } catch (...) {
            kernel_module::webui::send_text(connection, 500, "模块内部错误");
            return true;
        }
        return false;
    }

    bool handlePost(CivetServer* server, mg_connection* connection,
                    const std::string& path, const std::string& body) override {
        (void)server;
        try {
            if (starts_with(path, "/api/") && !authorize_api(connection, true)) {
                return true;
            }
            std::lock_guard<std::mutex> lock(mutex_);
            std::string message;

            if (path == "/api/mode") {
                const bool valid = custom_thermal::is_valid_mode_request(body);
                const bool ok = valid && custom_thermal::select_mode(module_dir_, body, message);
                if (!valid && message.empty()) message = "无效温控模式";
                if (ok) {
                    kernel_module::set_current_module_description(
                        custom_thermal::runtime_description(module_dir_));
                    std::fprintf(stderr, "[custom_thermal_skp] mode changed: %s\n",
                                 custom_thermal::platform::trim_ascii(body).c_str());
                } else {
                    std::fprintf(stderr, "[custom_thermal_skp] mode change failed: %s\n",
                                 message.c_str());
                }
                // A valid mode can still fail because of storage, permissions, or recovery.
                // Keep 400 for malformed input only so the UI and callers can retry correctly.
                kernel_module::webui::send_text(connection, ok ? 200 : (valid ? 500 : 400),
                                                message.empty() ? "温控模式切换失败" : message);
                return true;
            }
            if (path == "/api/controller") {
                const std::string value = custom_thermal::platform::trim_ascii(body);
                if (value != "1" && value != "0" && value != "true" && value != "false") {
                    kernel_module::webui::send_text(connection, 400,
                                                    "控制器状态必须是 true 或 false");
                    return true;
                }
                const bool enabled = value == "1" || value == "true";
                const bool ok =
                    custom_thermal::set_controller_enabled(module_dir_, enabled, message);
                kernel_module::set_current_module_description(
                    custom_thermal::runtime_description(module_dir_));
                if (!ok) {
                    std::fprintf(stderr, "[custom_thermal_skp] controller change failed: %s\n",
                                 message.c_str());
                }
                kernel_module::webui::send_text(connection, ok ? 200 : 500, message);
                return true;
            }
            if (path == "/api/config") {
                if (!custom_thermal::validate_controller_config_request(body, message)) {
                    kernel_module::webui::send_text(
                        connection, 400,
                        message.empty() ? "控制器配置格式无效" : message);
                    return true;
                }
                const bool ok =
                    custom_thermal::write_controller_config(module_dir_, body, message);
                kernel_module::webui::send_text(
                    connection, ok ? 200 : 500,
                    message.empty() ? "控制器配置保存失败" : message);
                return true;
            }
        } catch (const std::exception& exception) {
            std::fprintf(stderr, "[custom_thermal_skp] WebUI POST: %s\n",
                         exception.what());
            kernel_module::webui::send_text(connection, 500, "模块内部错误");
            return true;
        } catch (...) {
            kernel_module::webui::send_text(connection, 500, "模块内部错误");
            return true;
        }
        return false;
    }

private:
    bool valid_transport(mg_connection* connection, bool require_browser_context) const {
        if (session_token_.empty() || port_ == 0) return false;
        const mg_request_info* request = mg_get_request_info(connection);
        if (request == nullptr) return false;
        const std::string remote = request->remote_addr;
        if (remote != "127.0.0.1" && remote != "::1" &&
            remote != "::ffff:127.0.0.1") {
            return false;
        }
        const std::string host = request_header(connection, "Host");
        const std::string port = std::to_string(port_);
        if (host != "127.0.0.1:" + port && host != "localhost:" + port &&
            host != "[::1]:" + port) {
            return false;
        }
        const std::string expected_origin = "http://" + host;
        const std::string origin = request_header(connection, "Origin");
        const std::string referer = request_header(connection, "Referer");
        const std::string fetch_site = request_header(connection, "Sec-Fetch-Site");
        if (!origin.empty() && origin != expected_origin) return false;
        if (!referer.empty() && !starts_with(referer, expected_origin + "/")) return false;
        if (!fetch_site.empty() && fetch_site != "same-origin" && fetch_site != "none") {
            return false;
        }
        const bool browser_context = !origin.empty() || !referer.empty() ||
                                     fetch_site == "same-origin";
        // The session bootstrap still requires browser metadata. Once the
        // random HttpOnly cookie is presented, authenticated loopback clients
        // may omit Origin/Referer (some Android WebViews do so on POST).
        return !require_browser_context || browser_context;
    }

    bool cookie_matches(mg_connection* connection) const {
        const std::string cookie = request_header(connection, "Cookie");
        const std::string expected = "skp_thermal_session=" + session_token_;
        size_t begin = 0;
        while (begin < cookie.size()) {
            while (begin < cookie.size() && (cookie[begin] == ' ' || cookie[begin] == ';')) {
                ++begin;
            }
            const size_t end = cookie.find(';', begin);
            const std::string item = cookie.substr(
                begin, end == std::string::npos ? std::string::npos : end - begin);
            if (item == expected) return true;
            if (end == std::string::npos) break;
            begin = end + 1;
        }
        return false;
    }

    bool establish_session(mg_connection* connection) {
        if (!valid_transport(connection, true)) {
            kernel_module::webui::send_text(connection, 403, "WebUI 会话来源无效");
            return true;
        }
        kernel_module::webui::KvMap headers = {
            {"Cache-Control", "no-store"},
            {"X-Content-Type-Options", "nosniff"},
            {"Set-Cookie", "skp_thermal_session=" + session_token_ +
                               "; Path=/; HttpOnly; SameSite=Strict"},
        };
        kernel_module::webui::send_text(connection, 200, "ok", &headers);
        return true;
    }

    bool authorize_api(mg_connection* connection, bool mutation) const {
        (void)mutation;
        if (valid_transport(connection, false) && cookie_matches(connection)) return true;
        kernel_module::webui::send_text(connection, 403, "WebUI 会话无效");
        return false;
    }

    std::filesystem::path module_dir_;
    std::mutex mutex_;
    uint32_t port_ = 0;
    std::string session_token_;
};

}  // namespace

int skroot_module_main(const char* root_key, const char* module_private_dir) {
    (void)root_key;
    try {
        const std::filesystem::path module_dir = module_directory(module_private_dir);
        if (module_dir.empty()) return -1;

        const std::string error = custom_thermal::start_module(module_dir);
        if (!error.empty()) {
            std::fprintf(stderr, "[custom_thermal_skp] %s\n", error.c_str());
            kernel_module::set_current_module_description("启动失败：" + error);
            return -1;
        }
        kernel_module::set_current_module_description(
            custom_thermal::runtime_description(module_dir));
        return 0;
    } catch (const std::exception& exception) {
        std::fprintf(stderr, "[custom_thermal_skp] startup exception: %s\n",
                     exception.what());
        kernel_module::set_current_module_description("启动异常");
        return -1;
    } catch (...) {
        kernel_module::set_current_module_description("启动异常");
        return -1;
    }
}

std::string module_on_install(const char* root_key, const char* module_private_dir) {
    (void)root_key;
    try {
        const std::filesystem::path module_dir = module_directory(module_private_dir);
        if (module_dir.empty()) return "SKP 未提供模块私有目录";
        return custom_thermal::install_module(module_dir);
    } catch (const std::exception& exception) {
        return std::string("安装异常：") + exception.what();
    } catch (...) {
        return "安装异常";
    }
}

void module_on_uninstall(const char* root_key, const char* module_private_dir) {
    (void)root_key;
    try {
        const std::filesystem::path module_dir = module_directory(module_private_dir);
        if (!module_dir.empty()) custom_thermal::uninstall_module(module_dir);
    } catch (const std::exception& exception) {
        std::fprintf(stderr, "[custom_thermal_skp] uninstall exception: %s\n",
                     exception.what());
    } catch (...) {
        std::fprintf(stderr, "[custom_thermal_skp] uninstall exception\n");
    }
}

SKROOT_MODULE_NAME("定制温控")
SKROOT_MODULE_VERSION("1.0")
SKROOT_MODULE_DESC(MODULE_DESCRIPTION)
SKROOT_MODULE_AUTHOR("苏疫杆菌/蜃")
SKROOT_MODULE_ID32("be4b666b97e92f1ddcf4b212ba436b40")
SKROOT_MODULE_WEB_UI(ThermalWebHandler)
SKROOT_MODULE_ON_INSTALL(module_on_install)
SKROOT_MODULE_ON_UNINSTALL(module_on_uninstall)
