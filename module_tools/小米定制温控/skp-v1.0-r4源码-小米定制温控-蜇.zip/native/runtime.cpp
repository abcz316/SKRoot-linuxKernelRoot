#include "runtime.hpp"

#include "platform.hpp"
#include "controller_process.hpp"

#include <sys/stat.h>
#include <sys/system_properties.h>

#include <signal.h>
#include <unistd.h>

#include <fcntl.h>
#include <limits.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cctype>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <mutex>
#include <sstream>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

namespace custom_thermal {

namespace {

using namespace std::chrono_literals;

constexpr const char* kThermalRoot = "/data/vendor/thermal";
constexpr const char* kThermalConfig = "/data/vendor/thermal/config";
constexpr const char* kStockBackup =
    "/data/vendor/thermal/.custom_thermal_skp_stock";
constexpr const char* kTransactionCandidate =
    "/data/vendor/thermal/.custom_thermal_skp_candidate";
constexpr const char* kTransactionMarker =
    "/data/vendor/thermal/.custom_thermal_skp_transaction";
constexpr const char* kTransactionIdentityFile = ".custom_thermal_skp_txn_id";
constexpr size_t kMaxRetiredCandidates = 4;
constexpr const char* kLegacyExternalConfig =
    "/sdcard/Android/Eclipse/Asphyxia.toml";

bool filesystem_entry_missing(const std::error_code& error) {
    return error == std::make_error_code(std::errc::no_such_file_or_directory) ||
           error.value() == ENOENT;
}

struct ModeInfo {
    const char* id;
    const char* label;
};

constexpr std::array<ModeInfo, 4> kModes = {{
    {"cool", "夏日限定"},
    {"pro", "深度定制"},
    {"extreme", "极致性能"},
    {"danger", "丧心病狂"},
}};

constexpr std::array<std::pair<const char*, const char*>, 7> kPropertyOverrides = {{
    {"persist.sys.enable_templimit", "false"},
    {"persist.sys.smartpower.display_thermal_temp_threshold", "99"},
    {"ro.vendor.display.hwc_thermal_dimming", "false"},
    {"ro.vendor.fps.switch.thermal", "false"},
    {"ro.vendor.thermal.dimming.enable", "false"},
    {"ro.thermal.iec.enable", "false"},
    {"ro.vendor.mi_sf.pq_thermal", "false"},
}};

struct Settings {
    std::string mode = "cool";
    bool controller_enabled = false;
};

struct RuntimeStatusSnapshot {
    Settings settings;
    std::string market;
    std::string active_mode;
    bool profiles_ready = false;
    size_t config_files = 0;
    size_t active_properties = 0;
    size_t total_properties = kPropertyOverrides.size();
    std::string transaction_state;
    std::string thermal_state;
    bool thermal_active = false;
    bool config_exists = false;
    std::string controller_state;
};

fs::path state_directory(const fs::path& module_dir) {
    return module_dir / "state";
}

fs::path settings_path(const fs::path& module_dir) {
    return state_directory(module_dir) / "settings.conf";
}

fs::path controller_path(const fs::path& module_dir) {
    return module_dir / "bin" / "Asphyxia";
}

fs::path controller_helper_path(const fs::path& module_dir) {
    return module_dir / "bin" / "custom_thermal_helper";
}

fs::path controller_pid_path(const fs::path& module_dir) {
    return state_directory(module_dir) / "controller.pid";
}

fs::path controller_config_path(const fs::path& module_dir) {
    return state_directory(module_dir) / "Asphyxia.toml";
}

fs::path waiter_pid_path(const fs::path& module_dir) {
    return state_directory(module_dir) / "controller_waiter.pid";
}

fs::path supervisor_pid_path(const fs::path& module_dir) {
    return state_directory(module_dir) / "controller_supervisor.pid";
}

fs::path runtime_log_path(const fs::path& module_dir) {
    return state_directory(module_dir) / "runtime.log";
}

std::mutex& runtime_log_mutex() {
    static std::mutex mutex;
    return mutex;
}

std::string clean_log_field(std::string value, size_t maximum) {
    if (value.size() > maximum) value.resize(maximum);
    for (char& character : value) {
        const unsigned char byte = static_cast<unsigned char>(character);
        if (character == '\n' || character == '\r' || character == '\t' || byte < 0x20) {
            character = ' ';
        }
    }
    return value;
}

void append_runtime_log(const fs::path& module_dir, const std::string& event,
                        const std::string& detail) {
    std::lock_guard<std::mutex> lock(runtime_log_mutex());
    const fs::path directory = state_directory(module_dir);
    if (!platform::ensure_directory(directory, 0700)) return;
    const fs::path path = runtime_log_path(module_dir);

    struct stat status {};
    if (::lstat(path.c_str(), &status) == 0 && S_ISREG(status.st_mode) &&
        status.st_size > 256 * 1024) {
        const fs::path previous = path.string() + ".1";
        (void)::unlink(previous.c_str());
        (void)::rename(path.c_str(), previous.c_str());
    }

    std::time_t now = std::time(nullptr);
    struct tm local_time {};
    char timestamp[32] = "0000-00-00 00:00:00";
    if (::localtime_r(&now, &local_time) != nullptr) {
        (void)std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S",
                            &local_time);
    }
    const std::string line = std::string(timestamp) + " [" +
                             clean_log_field(event, 48) + "] " +
                             clean_log_field(detail, 1024) + "\n";
    const int descriptor = ::open(path.c_str(),
                                  O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC |
                                      O_NOFOLLOW,
                                  0600);
    if (descriptor < 0) return;
    size_t offset = 0;
    while (offset < line.size()) {
        const ssize_t written =
            ::write(descriptor, line.data() + offset, line.size() - offset);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) break;
        offset += static_cast<size_t>(written);
    }
    (void)::close(descriptor);
}

std::string read_log_tail(const fs::path& path, size_t maximum) {
    const int descriptor = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) return {};
    struct stat status {};
    if (::fstat(descriptor, &status) != 0 || !S_ISREG(status.st_mode) ||
        status.st_size < 0) {
        (void)::close(descriptor);
        return {};
    }
    const off_t start = status.st_size > static_cast<off_t>(maximum)
                            ? status.st_size - static_cast<off_t>(maximum)
                            : 0;
    if (::lseek(descriptor, start, SEEK_SET) < 0) {
        (void)::close(descriptor);
        return {};
    }
    std::string output;
    output.resize(static_cast<size_t>(status.st_size - start));
    size_t offset = 0;
    while (offset < output.size()) {
        const ssize_t count =
            ::read(descriptor, output.data() + offset, output.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) break;
        offset += static_cast<size_t>(count);
    }
    (void)::close(descriptor);
    output.resize(offset);
    if (start > 0) {
        const size_t newline = output.find('\n');
        if (newline != std::string::npos) output.erase(0, newline + 1);
    }
    for (char& character : output) {
        const unsigned char byte = static_cast<unsigned char>(character);
        if (character == '\0' || (byte < 0x20 && character != '\n' &&
                                   character != '\r' && character != '\t')) {
            character = ' ';
        }
    }
    return output;
}

bool mode_is_valid(const std::string& mode) {
    return std::any_of(kModes.begin(), kModes.end(), [&](const ModeInfo& item) {
        return mode == item.id;
    });
}

const char* mode_label(const std::string& mode) {
    const auto match = std::find_if(kModes.begin(), kModes.end(), [&](const ModeInfo& item) {
        return mode == item.id;
    });
    return match == kModes.end() ? "未知" : match->label;
}

std::string sanitize_component(const std::string& input) {
    std::string result;
    result.reserve(input.size());
    for (const unsigned char character : input) {
        if (std::isalnum(character) != 0 || character == '.' || character == '_' ||
            character == '-') {
            result.push_back(static_cast<char>(character));
        } else {
            result.push_back('_');
        }
    }
    while (!result.empty() && result.front() == '.') result.erase(result.begin());
    return result;
}

std::string current_device() {
    return sanitize_component(platform::get_property("ro.product.device"));
}

fs::path device_profile_directory(const fs::path& module_dir) {
    return module_dir / "profiles" / current_device();
}

fs::path thermal_source_directory();

bool tree_manifest(const fs::path& root, std::string& output, std::string& error) {
    std::vector<fs::path> entries = {root};
    std::error_code filesystem_error;
    fs::recursive_directory_iterator iterator(
        root, fs::directory_options::skip_permission_denied, filesystem_error);
    const fs::recursive_directory_iterator end;
    while (!filesystem_error && iterator != end) {
        entries.push_back(iterator->path());
        if (entries.size() > 8192) {
            error = "配置目录文件数量超过限制";
            return false;
        }
        iterator.increment(filesystem_error);
    }
    if (filesystem_error) {
        error = "无法遍历配置目录清单";
        return false;
    }
    std::sort(entries.begin(), entries.end(), [&](const fs::path& left,
                                                   const fs::path& right) {
        return left.lexically_relative(root).generic_string() <
               right.lexically_relative(root).generic_string();
    });

    output.clear();
    for (const fs::path& path : entries) {
        struct stat status {};
        if (::lstat(path.c_str(), &status) != 0 || S_ISLNK(status.st_mode) ||
            (!S_ISDIR(status.st_mode) && !S_ISREG(status.st_mode))) {
            error = "配置目录包含无效条目";
            return false;
        }
        std::string relative = path.lexically_relative(root).generic_string();
        if (relative.empty()) relative = ".";
        if (relative.find('\n') != std::string::npos ||
            relative.find('\t') != std::string::npos) {
            error = "配置目录文件名包含无效字符";
            return false;
        }
        output += S_ISDIR(status.st_mode) ? "D\t" : "F\t";
        output += relative + "\t" +
                  std::to_string(static_cast<unsigned int>(status.st_mode & 07777)) +
                  "\t" + std::to_string(static_cast<unsigned int>(status.st_uid)) +
                  "\t" + std::to_string(static_cast<unsigned int>(status.st_gid));
        if (S_ISREG(status.st_mode)) {
            const int descriptor = ::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
            if (descriptor < 0) {
                error = "无法读取配置清单文件";
                return false;
            }
            uint64_t hash = 14695981039346656037ULL;
            char buffer[64 * 1024];
            bool ok = true;
            for (;;) {
                const ssize_t count = ::read(descriptor, buffer, sizeof(buffer));
                if (count == 0) break;
                if (count < 0) {
                    if (errno == EINTR) continue;
                    ok = false;
                    break;
                }
                for (ssize_t index = 0; index < count; ++index) {
                    hash ^= static_cast<unsigned char>(buffer[index]);
                    hash *= 1099511628211ULL;
                }
            }
            ::close(descriptor);
            if (!ok) {
                error = "无法计算配置文件校验值";
                return false;
            }
            char hash_text[17];
            std::snprintf(hash_text, sizeof(hash_text), "%016llx",
                          static_cast<unsigned long long>(hash));
            output += "\t" + std::to_string(static_cast<long long>(status.st_size)) +
                      "\t" + hash_text;
        }
        output += '\n';
    }
    return true;
}

bool profile_manifest(const fs::path& module_dir, std::string& output,
                      std::string& error) {
    output.clear();
    const fs::path base = device_profile_directory(module_dir);
    for (const ModeInfo& mode : kModes) {
        std::string manifest;
        if (!tree_manifest(base / mode.id, manifest, error)) return false;
        output += "[" + std::string(mode.id) + "]\n" + manifest;
    }
    return true;
}

std::string thermal_source_fingerprint() {
    const fs::path source = thermal_source_directory();
    if (source.empty()) return {};
    struct stat status {};
    const fs::path normal = source / "thermal-normal.conf";
    if (::stat(normal.c_str(), &status) != 0) return {};
    return source.string() + "\n" + std::to_string(static_cast<long long>(status.st_size)) +
           "\n" + std::to_string(static_cast<long long>(status.st_mtime)) + "\n" +
           std::to_string(static_cast<long long>(status.st_ino));
}

Settings load_settings(const fs::path& module_dir) {
    Settings settings;
    std::string text;
    if (!platform::read_text_file(settings_path(module_dir), text, 4096)) return settings;

    std::istringstream stream(text);
    std::string line;
    while (std::getline(stream, line)) {
        const size_t separator = line.find('=');
        if (separator == std::string::npos) continue;
        const std::string key = platform::trim_ascii(line.substr(0, separator));
        const std::string value = platform::trim_ascii(line.substr(separator + 1));
        if (key == "mode" && mode_is_valid(value)) settings.mode = value;
        if (key == "controller") settings.controller_enabled = value == "1";
    }
    return settings;
}

bool save_settings(const fs::path& module_dir, const Settings& settings) {
    if (!mode_is_valid(settings.mode)) return false;
    const std::string text = "mode=" + settings.mode + "\ncontroller=" +
                             (settings.controller_enabled ? "1\n" : "0\n");
    return platform::write_text_file_atomic(settings_path(module_dir), text, 0600);
}

bool prepare_resources(const fs::path& module_dir, std::string& error) {
    const std::array<fs::path, 5> executables = {
        module_dir / "bin" / "Asphyxia",
        module_dir / "bin" / "Eclipse",
        module_dir / "bin" / "miui-thermal",
        module_dir / "bin" / "resetprop",
        controller_helper_path(module_dir),
    };
    for (const fs::path& path : executables) {
        struct stat status {};
        if (::stat(path.c_str(), &status) != 0 || !S_ISREG(status.st_mode)) {
            error = "安装包缺少资源：" + path.filename().string();
            return false;
        }
        if (::chmod(path.c_str(), 0700) != 0) {
            error = "无法设置资源权限：" + path.filename().string();
            return false;
        }
    }
    if (!platform::ensure_directory(state_directory(module_dir), 0700)) {
        error = "无法创建模块状态目录";
        return false;
    }
    return true;
}

fs::path thermal_source_directory() {
    constexpr std::array<const char*, 2> candidates = {"/vendor/etc", "/odm/etc"};
    for (const char* candidate : candidates) {
        std::error_code error;
        if (fs::is_regular_file(fs::path(candidate) / "thermal-normal.conf", error) &&
            !error) {
            return candidate;
        }
    }
    return {};
}

std::string validate_device() {
    if (!platform::kernel_at_least(5, 10)) return "仅支持 Linux 5.10 及以上内核";
    std::error_code error;
    const bool xiaomi = fs::is_directory("/mi_ext", error) ||
                        fs::is_directory("/dev/mi_display", error);
    if (!xiaomi) return "仅支持小米/红米设备";
    if (current_device().empty()) return "无法读取 ro.product.device";
    if (thermal_source_directory().empty()) return "未找到 thermal-normal.conf";
    if (!fs::is_directory(kThermalRoot, error) || error) {
        return "未找到 /data/vendor/thermal";
    }
    error.clear();
    if (!fs::is_directory(kThermalConfig, error) || error) {
        return "未找到 /data/vendor/thermal/config";
    }
    return {};
}

bool profiles_are_ready(const fs::path& module_dir) {
    const fs::path base = device_profile_directory(module_dir);
    if (current_device().empty()) return false;
    std::string stamp;
    if (!platform::read_text_file(base / ".source", stamp, 4096) ||
        platform::trim_ascii(stamp) !=
            platform::trim_ascii(thermal_source_fingerprint())) {
        return false;
    }
    const bool mode_markers_valid =
        std::all_of(kModes.begin(), kModes.end(), [&](const ModeInfo& mode) {
        const fs::path profile = base / mode.id;
        std::string marker;
        return platform::tree_has_regular_file(profile) &&
               platform::read_text_file(profile / "files.ini", marker, 128) &&
               platform::trim_ascii(marker) == mode.id;
    });
    if (!mode_markers_valid) return false;
    std::string expected_manifest;
    std::string actual_manifest;
    std::string manifest_error;
    return platform::read_text_file(base / ".manifest", expected_manifest,
                                    2 * 1024 * 1024) &&
           profile_manifest(module_dir, actual_manifest, manifest_error) &&
           expected_manifest == actual_manifest;
}

bool generate_profiles(const fs::path& module_dir, std::string& error) {
    if (profiles_are_ready(module_dir)) return true;
    const fs::path source = thermal_source_directory();
    const std::string device = current_device();
    if (source.empty() || device.empty()) {
        error = "温控源目录或设备代号无效";
        return false;
    }

    const fs::path profiles_root = module_dir / "profiles";
    const fs::path output = profiles_root / device;
    std::error_code filesystem_error;
    fs::remove_all(output, filesystem_error);
    if (filesystem_error || !platform::ensure_directory(output, 0700)) {
        error = "无法创建温控配置输出目录";
        return false;
    }

    const std::vector<std::string> arguments = {
        (module_dir / "bin" / "Eclipse").string(),
        source.string(),
        output.string(),
        (module_dir / "bin" / "miui-thermal").string(),
    };
    const platform::ProcessResult result = platform::run_process(
        arguments, std::chrono::seconds(180), state_directory(module_dir) / "transform.log");
    if (!result.ok()) {
        error = result.timed_out ? "温控配置生成超时" : "温控配置生成器执行失败";
        return false;
    }
    std::string manifest;
    if (!profile_manifest(module_dir, manifest, error) ||
        !platform::write_text_file_atomic(output / ".manifest", manifest, 0600) ||
        !platform::write_text_file_atomic(output / ".source",
                                          thermal_source_fingerprint() + "\n", 0600)) {
        error = "无法记录温控配置来源";
        return false;
    }
    if (!profiles_are_ready(module_dir)) {
        error = "温控配置生成结果不完整";
        return false;
    }
    return true;
}

constexpr std::array<const char*, 6> kThermalMetadataPaths = {{
    "/data/vendor/thermal",
    "/data/vendor/thermal/config",
    "/data/vendor/thermal/decrypt.txt",
    "/data/vendor/thermal/report.dump",
    "/data/vendor/thermal/thermal-global-mode",
    "/data/vendor/thermal/thermal.dump",
}};

bool capture_thermal_metadata(const fs::path& backup, std::string& error) {
    std::string content;
    for (const char* path : kThermalMetadataPaths) {
        struct stat status {};
        if (::lstat(path, &status) != 0) continue;
        content += path;
        content += '\t';
        content += std::to_string(static_cast<unsigned int>(status.st_mode & 07777));
        content += '\t';
        content += std::to_string(static_cast<unsigned int>(status.st_uid));
        content += '\t';
        content += std::to_string(static_cast<unsigned int>(status.st_gid));
        content += '\n';
    }
    if (!platform::write_text_file_atomic(backup / ".metadata", content, 0600)) {
        error = "无法保存原始温控元数据";
        return false;
    }
    return true;
}

bool restore_thermal_metadata(const fs::path& backup, std::string& error) {
    std::string content;
    if (!platform::read_text_file(backup / ".metadata", content, 16 * 1024)) {
        error = "无法读取原始温控元数据";
        return false;
    }
    std::istringstream stream(content);
    std::string line;
    bool restored_root = false;
    bool restored_config = false;
    while (std::getline(stream, line)) {
        std::array<std::string, 4> fields;
        size_t begin = 0;
        bool parsed = true;
        for (size_t index = 0; index < fields.size(); ++index) {
            const size_t end = index + 1 == fields.size() ? std::string::npos
                                                          : line.find('\t', begin);
            if (end == std::string::npos && index + 1 != fields.size()) {
                parsed = false;
                break;
            }
            fields[index] = line.substr(begin, end - begin);
            begin = end == std::string::npos ? line.size() : end + 1;
        }
        const bool allowed_path = std::any_of(
            kThermalMetadataPaths.begin(), kThermalMetadataPaths.end(),
            [&](const char* path) { return fields[0] == path; });
        if (!parsed || !allowed_path || fields[1].empty() || fields[2].empty() ||
            fields[3].empty()) {
            error = "原始温控元数据格式无效";
            return false;
        }
        char* mode_end = nullptr;
        char* uid_end = nullptr;
        char* gid_end = nullptr;
        const unsigned long mode = std::strtoul(fields[1].c_str(), &mode_end, 10);
        const unsigned long uid = std::strtoul(fields[2].c_str(), &uid_end, 10);
        const unsigned long gid = std::strtoul(fields[3].c_str(), &gid_end, 10);
        if (*mode_end != '\0' || *uid_end != '\0' || *gid_end != '\0' || mode > 07777) {
            error = "原始温控元数据数值无效";
            return false;
        }
        if (::chmod(fields[0].c_str(), static_cast<mode_t>(mode)) != 0 ||
            ::chown(fields[0].c_str(), static_cast<uid_t>(uid),
                    static_cast<gid_t>(gid)) != 0) {
            error = "恢复原始温控元数据失败：" + fields[0];
            return false;
        }
        if (fields[0] == kThermalRoot) restored_root = true;
        if (fields[0] == kThermalConfig) restored_config = true;
    }
    if (!restored_root || !restored_config) {
        error = "原始温控元数据缺少必要目录";
        return false;
    }
    return true;
}

std::string backup_identity() {
    return std::string("v2\n") + current_device() + "\n" +
           thermal_source_fingerprint() + "\n";
}

bool stock_backup_is_valid(std::string& error) {
    const fs::path backup = kStockBackup;
    std::error_code filesystem_error;
    if (!fs::is_regular_file(backup / ".complete", filesystem_error) ||
        filesystem_error || !fs::is_directory(backup / "data", filesystem_error) ||
        filesystem_error) {
        error = "原厂温控备份缺失或不完整";
        return false;
    }
    std::string identity;
    if (!platform::read_text_file(backup / ".identity", identity, 4096) ||
        identity != backup_identity()) {
        error = "原厂温控备份与当前固件不匹配";
        return false;
    }
    std::string expected_manifest;
    std::string actual_manifest;
    if (!platform::read_text_file(backup / ".manifest", expected_manifest,
                                  2 * 1024 * 1024) ||
        !tree_manifest(backup / "data", actual_manifest, error) ||
        expected_manifest != actual_manifest) {
        if (error.empty()) error = "原厂温控备份完整性校验失败";
        return false;
    }
    return true;
}

bool backup_stock_config(const fs::path& module_dir, std::string& error) {
    (void)module_dir;
    const fs::path backup = kStockBackup;
    std::error_code filesystem_error;
    const bool backup_complete =
        fs::is_regular_file(backup / ".complete", filesystem_error);
    if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
        error = "无法检查原始温控备份：" + filesystem_error.message();
        return false;
    }
    filesystem_error.clear();
    if (backup_complete) {
        if (stock_backup_is_valid(error)) return true;
        error += "；为避免覆盖旧备份，已停止安装";
        return false;
    }

    const fs::path temporary = std::string(kStockBackup) + ".tmp";
    fs::remove_all(temporary, filesystem_error);
    if (filesystem_error || !platform::ensure_directory(temporary / "data", 0700)) {
        error = "无法创建原始温控备份目录";
        return false;
    }

    const fs::path config = kThermalConfig;
    if (fs::is_directory(config, filesystem_error) && !filesystem_error) {
        if (!platform::copy_tree(config, temporary / "data", true, &error)) return false;
    }
    if (!capture_thermal_metadata(temporary, error)) return false;
    std::string manifest;
    if (!tree_manifest(temporary / "data", manifest, error) ||
        !platform::write_text_file_atomic(temporary / ".manifest", manifest, 0600)) {
        error = "无法生成原始温控备份清单";
        return false;
    }
    if (!platform::write_text_file_atomic(temporary / ".identity",
                                          backup_identity(), 0600) ||
        !platform::write_text_file_atomic(temporary / ".complete", "v2\n", 0600)) {
        error = "无法完成原始温控备份";
        return false;
    }
    fs::rename(temporary, backup, filesystem_error);
    if (filesystem_error) {
        error = "无法提交原始温控备份";
        return false;
    }
    return true;
}

bool set_owner_if_present(const char* path, uid_t uid, gid_t gid,
                          std::string& error) {
    struct stat status {};
    if (::lstat(path, &status) != 0) {
        if (errno == ENOENT) return true;
        error = std::string("无法读取温控文件元数据：") + path;
        return false;
    }
    if (::chown(path, uid, gid) != 0) {
        const int saved_errno = errno;
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: chown %s failed: errno=%d (%s)\n",
                     path, saved_errno, std::strerror(saved_errno));
    }
    return true;
}

bool set_config_tree_permissions(const fs::path& config, std::string& error) {
    struct stat status {};
    if (::lstat(config.c_str(), &status) != 0 || !S_ISDIR(status.st_mode)) {
        error = "温控配置目录不存在";
        return false;
    }
    if (::chmod(config.c_str(), 0771) != 0) {
        error = "无法设置温控配置目录权限";
        return false;
    }
    if (::chown(config.c_str(), 0, 1000) != 0) {
        const int saved_errno = errno;
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: chown %s failed: errno=%d (%s)\n",
                     config.c_str(), saved_errno, std::strerror(saved_errno));
    }

    std::error_code filesystem_error;
    fs::recursive_directory_iterator iterator(
        config, fs::directory_options::skip_permission_denied, filesystem_error);
    const fs::recursive_directory_iterator end;
    while (!filesystem_error && iterator != end) {
        const fs::path path = iterator->path();
        const bool directory = iterator->is_directory(filesystem_error);
        const bool regular = !filesystem_error && iterator->is_regular_file(filesystem_error);
        if (filesystem_error || (!directory && !regular)) {
            error = "温控配置包含不支持的文件类型";
            return false;
        }
        if (::chmod(path.c_str(), directory ? 0771 : 0644) != 0) {
            error = "无法设置温控配置文件权限：" + path.filename().string();
            return false;
        }
        if (::chown(path.c_str(), 0, 1000) != 0) {
            const int saved_errno = errno;
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: chown %s failed: errno=%d (%s)\n",
                         path.c_str(), saved_errno, std::strerror(saved_errno));
        }
        iterator.increment(filesystem_error);
    }
    if (filesystem_error) {
        error = "无法遍历温控配置目录";
        return false;
    }
    return true;
}

bool set_config_permissions(const fs::path& config, std::string& error) {
    if (::chmod(kThermalRoot, 0771) != 0) {
        const int saved_errno = errno;
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: chmod %s failed: errno=%d (%s)\n",
                     kThermalRoot, saved_errno, std::strerror(saved_errno));
    }
    return set_config_tree_permissions(config, error) &&
           set_owner_if_present("/data/vendor/thermal/decrypt.txt", 0, 1000, error) &&
           set_owner_if_present("/data/vendor/thermal/report.dump", 1000, 1000, error) &&
           set_owner_if_present("/data/vendor/thermal/thermal-global-mode", 1000, 1000,
                                error) &&
           set_owner_if_present("/data/vendor/thermal/thermal.dump", 1000, 1000, error);
}

bool restore_thermal_contexts(std::string& error) {
    constexpr const char* restorecon = "/system/bin/restorecon";
    if (::access(restorecon, X_OK) != 0) return true;
    if (!platform::run_process({restorecon, "-DFR", kThermalRoot},
                               std::chrono::seconds(30)).ok()) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: restorecon failed for %s\n",
                     kThermalRoot);
    }
    return true;
}

bool set_config_immutable_checked(const fs::path& config, bool immutable,
                                  std::string& error) {
    struct stat root_status {};
    if (::lstat(config.c_str(), &root_status) != 0) {
        if (errno == ENOENT) return true;
        error = "无法读取温控配置目录属性";
        return false;
    }
    if (!S_ISDIR(root_status.st_mode)) {
        error = "温控配置路径不是目录";
        return false;
    }

    if (!immutable && !platform::set_immutable(config, false)) {
        const int saved_errno = errno;
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: unlock %s failed: errno=%d (%s)\n",
                     config.c_str(), saved_errno, std::strerror(saved_errno));
    }
    std::error_code filesystem_error;
    fs::recursive_directory_iterator iterator(
        config, fs::directory_options::skip_permission_denied, filesystem_error);
    const fs::recursive_directory_iterator end;
    while (!filesystem_error && iterator != end) {
        const bool regular = iterator->is_regular_file(filesystem_error);
        const bool directory = !filesystem_error && iterator->is_directory(filesystem_error);
        if (filesystem_error) {
            error = "温控配置包含不支持的文件类型";
            return false;
        }
        if (!regular && !directory) {
            // Vendor trees may contain sockets or symlinks.  They are not
            // candidates for immutable flags, but must not block a mode swap.
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: skipping non-regular config entry: %s\n",
                         iterator->path().c_str());
            iterator.increment(filesystem_error);
            continue;
        }
        const bool transaction_identity =
            iterator->path().filename() == kTransactionIdentityFile;
        if ((regular || !immutable) && !(immutable && transaction_identity) &&
            !platform::set_immutable(iterator->path(), immutable)) {
            const int saved_errno = errno;
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: %s %s failed: errno=%d (%s)\n",
                         immutable ? "lock" : "unlock", iterator->path().c_str(),
                         saved_errno, std::strerror(saved_errno));
        }
        iterator.increment(filesystem_error);
    }
    if (filesystem_error) {
        error = "无法遍历温控配置锁定状态";
        return false;
    }
    return true;
}

std::string transaction_nonce() {
    return std::to_string(static_cast<long long>(::getpid())) + "-" +
           std::to_string(static_cast<long long>(
               std::chrono::steady_clock::now().time_since_epoch().count()));
}

bool retire_transaction_candidate(std::string& error,
                                  bool bypass_retired_limit = false) {
    const fs::path candidate = kTransactionCandidate;
    std::error_code filesystem_error;
    if (!fs::exists(candidate, filesystem_error)) {
        if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
            error = "无法检查温控事务候选目录：" + filesystem_error.message();
            return false;
        }
        return true;
    }

    size_t retired_count = 0;
    fs::directory_iterator iterator(kThermalRoot, filesystem_error);
    const fs::directory_iterator end;
    while (!filesystem_error && iterator != end) {
        if (iterator->path().filename().string().rfind(
                ".custom_thermal_skp_retired.", 0) == 0) {
            ++retired_count;
        }
        iterator.increment(filesystem_error);
    }
    if (filesystem_error) {
        error = "无法检查退役温控事务目录：" + filesystem_error.message();
        return false;
    }
    if (!bypass_retired_limit && retired_count >= kMaxRetiredCandidates) {
        error = "退役温控事务目录已达到上限";
        return false;
    }

    // The old live tree can contain immutable vendor files.  Unlocking is
    // best-effort; renaming the whole directory still gives the next
    // transaction an immediately reusable candidate path.
    std::string ignored;
    (void)set_config_immutable_checked(candidate, false, ignored);
    for (int attempt = 0; attempt < 8; ++attempt) {
        const fs::path retired = std::string(kThermalRoot) +
                                 "/.custom_thermal_skp_retired." +
                                 transaction_nonce() + "." + std::to_string(attempt);
        filesystem_error.clear();
        fs::rename(candidate, retired, filesystem_error);
        if (!filesystem_error) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] retired stale transaction candidate: %s\n",
                         retired.c_str());
            return true;
        }
    }

    filesystem_error.clear();
    fs::remove_all(candidate, filesystem_error);
    if (!filesystem_error) return true;
    error = "无法清理温控事务候选目录：" + filesystem_error.message();
    return false;
}

bool remove_transaction_candidate(std::string& error,
                                  bool bypass_retired_limit = false) {
    const fs::path candidate = kTransactionCandidate;
    std::error_code filesystem_error;
    if (!fs::exists(candidate, filesystem_error)) {
        if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
            error = "无法检查温控事务候选目录：" + filesystem_error.message();
            return false;
        }
        return true;
    }
    std::string ignored;
    (void)set_config_immutable_checked(candidate, false, ignored);
    fs::remove_all(candidate, filesystem_error);
    if (!filesystem_error) return true;

    // Immutable children may make recursive deletion fail.  Move the tree
    // out of the active name so future mode changes are not blocked.
    std::string retire_error;
    if (retire_transaction_candidate(retire_error, bypass_retired_limit)) return true;
    error = "无法清理温控事务候选目录：" + retire_error;
    return false;
}

void cleanup_retired_candidates() {
    std::error_code iterator_error;
    fs::directory_iterator iterator(kThermalRoot, iterator_error);
    const fs::directory_iterator end;
    std::vector<fs::path> retired_paths;
    while (!iterator_error && iterator != end) {
        const std::string name = iterator->path().filename().string();
        if (name.rfind(".custom_thermal_skp_retired.", 0) == 0) {
            retired_paths.push_back(iterator->path());
        }
        iterator.increment(iterator_error);
    }
    if (iterator_error) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: retired candidate scan failed: %s\n",
                     iterator_error.message().c_str());
    }
    for (const fs::path& retired : retired_paths) {
        std::string ignored;
        std::error_code type_error;
        if (fs::is_directory(retired, type_error) && !type_error) {
            (void)set_config_immutable_checked(retired, false, ignored);
        }
        std::error_code remove_error;
        fs::remove_all(retired, remove_error);
        if (remove_error) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: retired candidate cleanup failed: %s (%s)\n",
                         retired.c_str(), remove_error.message().c_str());
        }
    }
}

bool remove_live_transaction_identity(std::string& error) {
    const fs::path identity = fs::path(kThermalConfig) / kTransactionIdentityFile;
    if (::unlink(identity.c_str()) == 0 || errno == ENOENT) return true;
    error = "无法清理 live config 的事务身份文件";
    return false;
}

bool remove_transaction_marker_file(std::string& error) {
    if (::unlink(kTransactionMarker) == 0 || errno == ENOENT) return true;
    error = "无法清理温控事务标记";
    return false;
}

bool sync_thermal_root(std::string& error) {
    const int descriptor = ::open(kThermalRoot, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (descriptor < 0) {
        error = "无法打开温控根目录以持久化事务";
        return false;
    }
    int result = -1;
    do {
        result = ::fsync(descriptor);
    } while (result != 0 && errno == EINTR);
    const int saved_errno = errno;
    ::close(descriptor);
    if (result == 0) return true;
    error = "无法持久化温控事务目录：" + std::string(std::strerror(saved_errno));
    return false;
}

bool abort_mode_transaction(bool relock_previous, std::string& error,
                            bool bypass_retired_limit = false) {
    const fs::path config = kThermalConfig;
    // The marker lives below the thermal root.  Unlock it before cleanup;
    // unsupported FS_IOC flags are intentionally only warnings.
    (void)platform::set_immutable(kThermalRoot, false);

    bool cleanup_ok = true;
    std::string cleanup_error;
    if (!remove_transaction_marker_file(cleanup_error)) {
        cleanup_ok = false;
        error = "清理温控事务标记失败：" + cleanup_error;
    }
    cleanup_error.clear();
    if (!remove_transaction_candidate(cleanup_error, bypass_retired_limit)) {
        cleanup_ok = false;
        if (!error.empty()) error += "；";
        error += "清理温控事务候选目录失败：" + cleanup_error;
    }

    // Restore the pre-transaction lock state last.  A lock ioctl failure is
    // non-fatal on Android filesystems that do not expose FS_IOC_SETFLAGS.
    cleanup_error.clear();
    if (!set_config_immutable_checked(config, relock_previous, cleanup_error)) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: transaction lock restore failed: %s\n",
                     cleanup_error.c_str());
    }
    return cleanup_ok;
}

bool config_tree_has_immutable_file(const fs::path& config) {
    std::error_code filesystem_error;
    fs::recursive_directory_iterator iterator(
        config, fs::directory_options::skip_permission_denied, filesystem_error);
    const fs::recursive_directory_iterator end;
    while (!filesystem_error && iterator != end) {
        if (iterator->is_regular_file(filesystem_error) && !filesystem_error) {
            bool immutable = false;
            if (platform::get_immutable(iterator->path(), immutable) && immutable) {
                return true;
            }
        }
        iterator.increment(filesystem_error);
    }
    return false;
}

bool rollback_exchanged_config(bool relock_previous, std::string& error,
                               bool bypass_retired_limit = false) {
    const fs::path candidate = kTransactionCandidate;
    const fs::path config = kThermalConfig;
    (void)platform::set_immutable(kThermalRoot, false);
    std::string unlock_error;
    if (!set_config_immutable_checked(config, false, unlock_error)) {
        error = "温控事务回滚前解锁失败：" + unlock_error;
        return false;
    }
    if (!platform::atomic_replace_directory(candidate, config, &error)) return false;
    std::string cleanup_error;
    if (!set_config_immutable_checked(config, relock_previous, cleanup_error)) {
        error = "温控事务已交换回原配置，但锁定状态恢复失败：" + cleanup_error;
        return false;
    }
    std::string marker_error;
    if (!remove_transaction_marker_file(marker_error)) {
        error = marker_error;
        return false;
    }
    if (!remove_transaction_candidate(cleanup_error, bypass_retired_limit)) {
        error = "温控事务已回滚，但候选目录清理失败：" + cleanup_error;
        return false;
    }
    return true;
}

bool recover_pending_transaction(std::string& error) {
    cleanup_retired_candidates();
    std::error_code filesystem_error;
    const bool marker_exists = fs::is_regular_file(kTransactionMarker, filesystem_error);
    if (!marker_exists) {
        // A missing marker is the normal state on first install.  The
        // filesystem overload reports ENOENT through error_code, so do not
        // turn an absent optional artifact into an install rejection.
        if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
            error = "无法检查温控事务标记：" + filesystem_error.message();
            return false;
        }
        filesystem_error.clear();
        const bool candidate_exists = fs::exists(kTransactionCandidate, filesystem_error);
        if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: orphan candidate check failed: %s\n",
                         filesystem_error.message().c_str());
            filesystem_error.clear();
        }
        if (candidate_exists && !filesystem_error) {
            std::string cleanup_error;
            if (!remove_transaction_candidate(cleanup_error)) {
                // An orphaned candidate is never a reason to stop the
                // controller; keep it for a later best-effort cleanup.
                std::fprintf(stderr,
                             "[custom_thermal_skp] warning: orphan candidate cleanup failed: %s\n",
                             cleanup_error.c_str());
            }
        }
        return true;
    }

    std::string state;
    if (!platform::read_text_file(kTransactionMarker, state, 4096)) {
        error = "无法读取未完成的温控事务";
        return false;
    }
    const bool candidate_exists = fs::is_directory(kTransactionCandidate, filesystem_error);
    if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
        error = "无法检查温控事务候选目录";
        return false;
    }
    filesystem_error.clear();
    const bool previous_was_locked =
        state.find("\nold_locked=1\n") != std::string::npos;
    const bool stock_transaction =
        state.find("\nkind=stock\n") != std::string::npos;
    if (state.rfind("committed\n", 0) == 0) {
        (void)platform::set_immutable(kThermalRoot, false);
        std::string cleanup_error;
        bool identity_cleaned = remove_live_transaction_identity(cleanup_error);
        if (!identity_cleaned) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: committed identity cleanup failed: %s\n",
                         cleanup_error.c_str());
        }
        if (stock_transaction) {
            if (!set_config_immutable_checked(kThermalConfig, false, error) ||
                !restore_thermal_metadata(kStockBackup, error) ||
                !restore_thermal_contexts(error)) {
                return false;
            }
        } else {
            if (!set_config_immutable_checked(kThermalConfig, false, error) ||
                !set_config_permissions(kThermalConfig, error) ||
                !restore_thermal_contexts(error) ||
                !set_config_immutable_checked(kThermalConfig, true, error)) {
                return false;
            }
        }
        if (!identity_cleaned) {
            cleanup_error.clear();
            identity_cleaned = remove_live_transaction_identity(cleanup_error);
            if (!identity_cleaned) {
                // Preserve the committed marker and candidate for a later retry.
                std::fprintf(stderr,
                             "[custom_thermal_skp] warning: committed identity cleanup retry failed: %s\n",
                             cleanup_error.c_str());
                return true;
            }
        }
        if (candidate_exists) {
            cleanup_error.clear();
            if (!remove_transaction_candidate(cleanup_error, stock_transaction)) {
                std::fprintf(stderr,
                             "[custom_thermal_skp] warning: committed candidate cleanup failed: %s\n",
                             cleanup_error.c_str());
            }
        }
        cleanup_error.clear();
        const bool marker_removed = remove_transaction_marker_file(cleanup_error);
        if (!marker_removed) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: committed marker cleanup failed: %s\n",
                         cleanup_error.c_str());
        }
        bool marker_durable = marker_removed;
        if (stock_transaction && marker_removed) {
            cleanup_error.clear();
            marker_durable = sync_thermal_root(cleanup_error);
            if (!marker_durable) {
                std::fprintf(stderr,
                             "[custom_thermal_skp] warning: committed marker fsync failed: %s\n",
                             cleanup_error.c_str());
            }
        }
        if (stock_transaction && marker_durable) {
            fs::remove_all(kStockBackup, filesystem_error);
            if (filesystem_error) {
                std::fprintf(stderr,
                             "[custom_thermal_skp] warning: stock backup cleanup failed: %s\n",
                             filesystem_error.message().c_str());
            }
        }
        return true;
    }
    if (state.rfind("pending\n", 0) != 0 ||
        !fs::is_directory(kThermalConfig, filesystem_error) || filesystem_error) {
        error = "检测到无法自动恢复的温控事务";
        return false;
    }
    const size_t identity_offset = state.find("id=");
    const size_t identity_end = identity_offset == std::string::npos
                                    ? std::string::npos
                                    : state.find('\n', identity_offset);
    if (identity_offset == std::string::npos || identity_end == std::string::npos) {
        error = "温控事务缺少身份标记";
        return false;
    }
    const std::string identity =
        state.substr(identity_offset + 3, identity_end - identity_offset - 3);
    std::string live_identity;
    std::string candidate_identity;
    (void)platform::read_text_file(fs::path(kThermalConfig) /
                                       kTransactionIdentityFile,
                                   live_identity, 256);
    (void)platform::read_text_file(fs::path(kTransactionCandidate) /
                                       kTransactionIdentityFile,
                                   candidate_identity, 256);
    if (platform::trim_ascii(live_identity) == identity) {
        if (candidate_exists) {
            return rollback_exchanged_config(previous_was_locked, error,
                                              stock_transaction);
        }

        // The exchange completed and the old tree was already retired before
        // the marker was updated.  Finish the harmless cleanup in place.
        std::string cleanup_error;
        (void)set_config_immutable_checked(kThermalConfig, previous_was_locked,
                                           cleanup_error);
        if (!remove_live_transaction_identity(cleanup_error)) {
            error = "无法清理已交换配置的事务身份：" + cleanup_error;
            return false;
        }
        if (!remove_transaction_marker_file(cleanup_error)) {
            error = "无法清理已交换配置的事务标记：" + cleanup_error;
            return false;
        }
        return true;
    }
    if (platform::trim_ascii(candidate_identity) == identity) {
        std::string cleanup_error;
        if (!abort_mode_transaction(previous_was_locked, cleanup_error,
                                    stock_transaction)) {
            error = "恢复未提交事务时清理失败：" + cleanup_error;
            return false;
        }
        return true;
    }
    if (!candidate_exists) {
        error = "温控事务候选目录已丢失";
        return false;
    }
    error = "温控事务目录身份不匹配";
    return false;
}

bool prepare_mode_candidate(const fs::path& profile, const std::string& mode,
                            std::string& identity, std::string& error) {
    if (!remove_transaction_candidate(error)) return false;
    const fs::path candidate = kTransactionCandidate;
    const auto fail_prepare = [&](const std::string& reason) {
        std::string cleanup_error;
        if (!remove_transaction_candidate(cleanup_error)) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: failed to discard partial candidate: %s\n",
                         cleanup_error.c_str());
        }
        error = reason;
        return false;
    };
    if (!platform::copy_tree(profile, candidate, false, &error)) {
        const std::string reason = error;
        return fail_prepare(reason);
    }
    if (!platform::write_text_file_atomic(candidate / "files.ini", mode + "\n", 0644)) {
        return fail_prepare("无法写入模式标记");
    }
    identity = mode + "-" + std::to_string(static_cast<long long>(::getpid())) + "-" +
               std::to_string(static_cast<long long>(
                   std::chrono::steady_clock::now().time_since_epoch().count()));
    if (!platform::write_text_file_atomic(candidate / kTransactionIdentityFile,
                                          identity + "\n", 0600)) {
        return fail_prepare("无法写入温控事务身份");
    }
    if (!set_config_tree_permissions(candidate, error)) {
        const std::string reason = error;
        return fail_prepare(reason);
    }
    return true;
}

bool commit_mode_candidate(const std::string& mode, const std::string& identity,
                           std::string& error) {
    const fs::path candidate = kTransactionCandidate;
    const fs::path config = kThermalConfig;
    const bool previous_was_locked = config_tree_has_immutable_file(config);
    const auto fail_before_exchange = [&](const std::string& primary) {
        std::string cleanup_error;
        if (!abort_mode_transaction(previous_was_locked, cleanup_error)) {
            error = primary + "；事务清理失败：" + cleanup_error;
        } else {
            error = primary;
        }
        return false;
    };

    (void)platform::set_immutable(kThermalRoot, false);
    if (!platform::write_text_file_atomic(kTransactionMarker,
                                          "pending\nid=" + identity + "\nmode=" + mode +
                                              "\nkind=mode\nold_locked=" +
                                              (previous_was_locked ? "1\n" : "0\n"),
                                          0600)) {
        return fail_before_exchange("无法记录温控事务");
    }

    std::string unlock_error;
    if (!set_config_immutable_checked(config, false, unlock_error)) {
        return fail_before_exchange(unlock_error);
    }
    std::string replace_error;
    if (!platform::atomic_replace_directory(candidate, config, &replace_error)) {
        return fail_before_exchange(replace_error);
    }

    std::string finalize_error;
    const bool finalized = set_config_permissions(config, finalize_error) &&
                           restore_thermal_contexts(finalize_error) &&
                           set_config_immutable_checked(config, true, finalize_error);
    if (!finalized) {
        std::string rollback_error;
        if (!rollback_exchanged_config(previous_was_locked, rollback_error)) {
            error = finalize_error + "；自动回滚失败：" + rollback_error;
            return false;
        }
        error = finalize_error + "；已恢复切换前配置";
        return false;
    }

    if (!platform::write_text_file_atomic(kTransactionMarker,
                                          "committed\nid=" + identity + "\nmode=" + mode +
                                              "\nkind=mode\nold_locked=" +
                                              (previous_was_locked ? "1\n" : "0\n"),
                                          0600)) {
        std::string rollback_error;
        if (!rollback_exchanged_config(previous_was_locked, rollback_error)) {
            error = "无法提交温控事务且自动回滚失败：" + rollback_error;
            return false;
        }
        error = "无法提交温控事务；已恢复切换前配置";
        return false;
    }

    std::string cleanup_error;
    if (!remove_live_transaction_identity(cleanup_error)) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: live transaction identity cleanup failed: %s\n",
                     cleanup_error.c_str());
        // Keep the committed marker so the next callback can finish cleanup.
        ::sync();
        return true;
    }
    if (!remove_transaction_candidate(cleanup_error)) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: transaction candidate cleanup failed: %s\n",
                     cleanup_error.c_str());
        // The committed marker lets the next lifecycle callback finish cleanup.
        ::sync();
        return true;
    }
    (void)platform::set_immutable(kThermalRoot, false);
    if (!remove_transaction_marker_file(cleanup_error)) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: transaction marker cleanup failed: %s\n",
                     cleanup_error.c_str());
        // The committed marker is harmless and will be retried later.
        ::sync();
        return true;
    }
    ::sync();
    return true;
}

bool apply_mode_profile(const fs::path& module_dir, const std::string& mode,
                        std::string& error) {
    if (!mode_is_valid(mode)) {
        error = "无效温控模式";
        return false;
    }
    const fs::path profile = device_profile_directory(module_dir) / mode;
    if (!platform::tree_has_regular_file(profile)) {
        error = "温控模式配置缺失：" + mode;
        return false;
    }

    if (!recover_pending_transaction(error)) return false;
    std::string identity;
    if (!prepare_mode_candidate(profile, mode, identity, error)) return false;
    return commit_mode_candidate(mode, identity, error);
}

std::string active_mode_from_disk() {
    std::string mode;
    if (!platform::read_text_file(fs::path(kThermalConfig) / "files.ini", mode, 64)) {
        return {};
    }
    mode = platform::trim_ascii(std::move(mode));
    return mode_is_valid(mode) ? mode : std::string();
}

size_t regular_file_count(const fs::path& root) {
    std::error_code error;
    fs::recursive_directory_iterator iterator(
        root, fs::directory_options::skip_permission_denied, error);
    const fs::recursive_directory_iterator end;
    size_t count = 0;
    while (!error && iterator != end && count < 100000) {
        if (iterator->is_regular_file(error) && !error) ++count;
        iterator.increment(error);
    }
    return error ? 0 : count;
}

size_t active_property_override_count() {
    return static_cast<size_t>(std::count_if(
        kPropertyOverrides.begin(), kPropertyOverrides.end(),
        [](const auto& item) { return platform::get_property(item.first) == item.second; }));
}

std::string thermal_transaction_state() {
    struct stat status {};
    if (::lstat(kTransactionMarker, &status) != 0) {
        return errno == ENOENT ? "clean" : "error";
    }
    if (!S_ISREG(status.st_mode)) return "invalid";
    std::string marker;
    if (!platform::read_text_file(kTransactionMarker, marker, 4096)) return "error";
    if (marker.rfind("pending\n", 0) == 0) return "pending";
    if (marker.rfind("committed\n", 0) == 0) return "committed";
    return "invalid";
}

bool property_exists(const char* key) {
    return __system_property_find(key) != nullptr;
}

fs::path original_properties_path(const fs::path& module_dir) {
    return state_directory(module_dir) / "original_properties.tsv";
}

bool capture_original_properties(const fs::path& module_dir, std::string& error) {
    const fs::path path = original_properties_path(module_dir);
    std::error_code filesystem_error;
    if (fs::is_regular_file(path, filesystem_error) && !filesystem_error) return true;

    std::string content;
    for (const auto& [key, ignored] : kPropertyOverrides) {
        (void)ignored;
        const bool present = property_exists(key);
        std::string value = present ? platform::get_property(key) : std::string();
        std::replace(value.begin(), value.end(), '\t', ' ');
        std::replace(value.begin(), value.end(), '\n', ' ');
        content += key;
        content += present ? "\t1\t" : "\t0\t";
        content += value;
        content += '\n';
    }
    if (!platform::write_text_file_atomic(path, content, 0600)) {
        error = "无法保存原始系统属性";
        return false;
    }
    return true;
}

bool run_resetprop(const fs::path& module_dir,
                   const std::vector<std::string>& arguments) {
    std::vector<std::string> command;
    command.reserve(arguments.size() + 1);
    command.push_back((module_dir / "bin" / "resetprop").string());
    command.insert(command.end(), arguments.begin(), arguments.end());
    return platform::run_process(command, std::chrono::seconds(10)).ok();
}

bool starts_with(const std::string& value, const char* prefix) {
    return value.rfind(prefix, 0) == 0;
}

bool apply_property_overrides(const fs::path& module_dir, std::string& error) {
    bool success = true;
    for (const auto& [key, value] : kPropertyOverrides) {
        const bool current = run_resetprop(module_dir, {"-n", key, value});
        bool persistent = true;
        if (starts_with(key, "persist.")) {
            persistent = run_resetprop(module_dir, {"-p", key, value});
        }
        success = current && persistent && success;
    }
    if (!success) error = "部分温控系统属性应用失败";
    return success;
}

void restore_original_properties(const fs::path& module_dir) {
    std::string content;
    if (!platform::read_text_file(original_properties_path(module_dir), content, 64 * 1024)) {
        return;
    }
    std::istringstream stream(content);
    std::string line;
    while (std::getline(stream, line)) {
        const size_t first = line.find('\t');
        const size_t second = first == std::string::npos ? std::string::npos
                                                         : line.find('\t', first + 1);
        if (first == std::string::npos || second == std::string::npos) continue;
        const std::string key = line.substr(0, first);
        const bool present = line.substr(first + 1, second - first - 1) == "1";
        const std::string value = line.substr(second + 1);
        if (present) {
            (void)run_resetprop(module_dir, {"-n", key, value});
            if (starts_with(key, "persist.")) {
                (void)run_resetprop(module_dir, {"-p", key, value});
            }
        } else {
            (void)run_resetprop(module_dir, {"--delete", key});
            if (starts_with(key, "persist.")) {
                (void)run_resetprop(module_dir, {"-p", "--delete", key});
            }
        }
    }
}

bool decode_toml_string(const std::string& input, std::string& output) {
    const std::string value = platform::trim_ascii(input);
    output.clear();
    if (value.size() < 2 || (value.front() != '"' && value.front() != '\'' ) ||
        value.back() != value.front()) {
        return false;
    }
    const char quote = value.front();
    for (size_t index = 1; index + 1 < value.size(); ++index) {
        const unsigned char character = static_cast<unsigned char>(value[index]);
        if (quote == '\'' ) {
            if (character == '\'' || character < 0x20) return false;
            output.push_back(static_cast<char>(character));
            continue;
        }
        if (character == '"') return false;
        if (character != '\\') {
            if (character < 0x20) return false;
            output.push_back(static_cast<char>(character));
            continue;
        }
        if (++index + 1 >= value.size()) return false;
        switch (value[index]) {
            case 'b': output.push_back('\b'); break;
            case 't': output.push_back('\t'); break;
            case 'n': output.push_back('\n'); break;
            case 'f': output.push_back('\f'); break;
            case 'r': output.push_back('\r'); break;
            case '"': output.push_back('"'); break;
            case '\\': output.push_back('\\'); break;
            default: return false;
        }
    }
    return true;
}

bool strip_toml_comment(const std::string& input, std::string& output) {
    bool double_quote = false;
    bool single_quote = false;
    bool escaped = false;
    for (size_t index = 0; index < input.size(); ++index) {
        const char character = input[index];
        if (escaped) {
            escaped = false;
            continue;
        }
        if (double_quote && character == '\\') {
            escaped = true;
            continue;
        }
        if (!single_quote && character == '"') {
            double_quote = !double_quote;
            continue;
        }
        if (!double_quote && character == '\'') {
            single_quote = !single_quote;
            continue;
        }
        if (!double_quote && !single_quote && character == '#') {
            output = input.substr(0, index);
            return true;
        }
    }
    if (double_quote || single_quote || escaped) return false;
    output = input;
    return true;
}

size_t find_toml_equals(const std::string& line) {
    bool double_quote = false;
    bool single_quote = false;
    bool escaped = false;
    for (size_t index = 0; index < line.size(); ++index) {
        const char character = line[index];
        if (escaped) {
            escaped = false;
            continue;
        }
        if (double_quote && character == '\\') {
            escaped = true;
            continue;
        }
        if (!single_quote && character == '"') {
            double_quote = !double_quote;
            continue;
        }
        if (!double_quote && character == '\'') {
            single_quote = !single_quote;
            continue;
        }
        if (!double_quote && !single_quote && character == '=') return index;
    }
    return std::string::npos;
}

bool package_name_is_valid(const std::string& package) {
    return !package.empty() && package.size() <= 255 &&
           std::all_of(package.begin(), package.end(), [](unsigned char character) {
               return std::isalnum(character) != 0 || character == '.' ||
                      character == '_' || character == '-';
           });
}

bool target_path_is_allowed(const std::string& path, std::string& error) {
    if (path.empty() || path.size() >= 4096 || path.front() != '/' ||
        path.back() == '/' || path.find("//") != std::string::npos ||
        path.find("/../") != std::string::npos ||
        path.find("/./") != std::string::npos ||
        (path.size() >= 3 && path.compare(path.size() - 3, 3, "/..") == 0) ||
        (path.size() >= 2 && path.compare(path.size() - 2, 2, "/.") == 0)) {
        error = "目标路径格式无效";
        return false;
    }
    const bool sys_path = path.rfind("/sys/", 0) == 0;
    const bool proc_path = path.rfind("/proc/sys/", 0) == 0;
    const bool thermal_path = path.rfind("/data/vendor/thermal/", 0) == 0;
    const bool allowed_prefix = sys_path || proc_path || thermal_path;
    if (!allowed_prefix && path != "/data/system/mcd/df") {
        error = "目标路径不在允许范围内：" + path;
        return false;
    }

    const auto resolved_is_allowed = [&](const std::string& resolved) {
        if (sys_path) return resolved == "/sys" || resolved.rfind("/sys/", 0) == 0;
        if (proc_path) {
            return resolved == "/proc/sys" || resolved.rfind("/proc/sys/", 0) == 0;
        }
        if (thermal_path) {
            return resolved == "/data/vendor/thermal" ||
                   resolved.rfind("/data/vendor/thermal/", 0) == 0;
        }
        return resolved == "/data/system/mcd/df";
    };

    char resolved_buffer[PATH_MAX];
    if (::realpath(path.c_str(), resolved_buffer) != nullptr) {
        struct stat status {};
        if (!resolved_is_allowed(resolved_buffer) ||
            ::stat(resolved_buffer, &status) != 0 || !S_ISREG(status.st_mode)) {
            error = "目标路径解析后不在允许范围或不是普通文件：" + path;
            return false;
        }
        return true;
    }
    if (errno != ENOENT) {
        error = "无法检查目标路径：" + path;
        return false;
    }

    std::string existing_parent = path;
    while (existing_parent.size() > 1) {
        const size_t separator = existing_parent.rfind('/');
        existing_parent = separator == 0 ? "/" : existing_parent.substr(0, separator);
        if (::realpath(existing_parent.c_str(), resolved_buffer) != nullptr) {
            struct stat status {};
            if (!resolved_is_allowed(resolved_buffer) ||
                ::stat(resolved_buffer, &status) != 0 || !S_ISDIR(status.st_mode)) {
                error = "目标路径父级解析后不在允许范围：" + path;
                return false;
            }
            return true;
        }
        if (errno != ENOENT) {
            error = "无法检查目标路径父级：" + path;
            return false;
        }
    }
    error = "目标路径没有可验证的父目录：" + path;
    return false;
}

bool parse_controller_section(const std::string& raw, std::string& section,
                              std::string& error) {
    if (raw == "config" || raw == "limits") {
        section = raw;
        return true;
    }
    constexpr std::array<const char*, 3> prefixes = {
        "config.", "default.", "APP.",
    };
    for (const char* prefix : prefixes) {
        if (raw.rfind(prefix, 0) != 0) continue;
        std::string package;
        const std::string package_text = raw.substr(std::strlen(prefix));
        if (!package_text.empty() &&
            (package_text.front() == '"' || package_text.front() == '\'')) {
            if (!decode_toml_string(package_text, package)) {
                error = "应用表名称格式无效";
                return false;
            }
        } else {
            package = package_text;
        }
        if (!package_name_is_valid(package)) {
            error = "应用包名格式无效";
            return false;
        }
        section = std::string(raw.rfind("default.", 0) == 0 ? "default:" : "config:") +
                  package;
        return true;
    }
    error = "控制器配置包含不支持的表";
    return false;
}

bool validate_controller_config(const std::string& content, std::string& error) {
    if (content.size() > 256 * 1024 || content.find('\0') != std::string::npos) {
        error = "控制器配置过大或包含无效字符";
        return false;
    }

    std::unordered_set<std::string> sections;
    std::unordered_set<std::string> keys;
    std::string section;
    std::istringstream stream(content);
    std::string raw_line;
    size_t line_number = 0;
    size_t rule_count = 0;
    while (std::getline(stream, raw_line)) {
        ++line_number;
        if (raw_line.size() > 8192) {
            error = "控制器配置第 " + std::to_string(line_number) + " 行过长";
            return false;
        }
        if (!raw_line.empty() && raw_line.back() == '\r') raw_line.pop_back();
        const std::string trimmed = platform::trim_ascii(raw_line);
        if (trimmed.empty() || trimmed.front() == '#') continue;

        std::string without_comment;
        if (!strip_toml_comment(raw_line, without_comment)) {
            error = "控制器配置第 " + std::to_string(line_number) + " 行引号未闭合";
            return false;
        }
        const std::string line = platform::trim_ascii(without_comment);
        if (line.empty()) continue;
        if (line.front() == '[') {
            if (line.size() < 3 || line.back() != ']' || line[1] == '[') {
                error = "控制器配置第 " + std::to_string(line_number) + " 行表格式无效";
                return false;
            }
            std::string parsed_section;
            if (!parse_controller_section(
                    platform::trim_ascii(line.substr(1, line.size() - 2)),
                    parsed_section, error)) {
                error += "（第 " + std::to_string(line_number) + " 行）";
                return false;
            }
            if (!sections.insert(parsed_section).second) {
                error = "控制器配置包含重复表（第 " +
                        std::to_string(line_number) + " 行）";
                return false;
            }
            section = std::move(parsed_section);
            continue;
        }
        if (section.empty()) {
            error = "控制器配置规则必须位于受支持的表中（第 " +
                    std::to_string(line_number) + " 行）";
            return false;
        }
        const size_t separator = find_toml_equals(line);
        if (separator == std::string::npos) {
            error = "控制器配置第 " + std::to_string(line_number) + " 行缺少等号";
            return false;
        }
        std::string path;
        std::string value;
        if (!decode_toml_string(line.substr(0, separator), path) ||
            !decode_toml_string(line.substr(separator + 1), value)) {
            error = "控制器配置第 " + std::to_string(line_number) +
                    " 行必须使用单行字符串键值";
            return false;
        }
        if (value.size() > 4096 ||
            std::any_of(value.begin(), value.end(), [](unsigned char character) {
                return character < 0x20;
            })) {
            error = "控制器配置第 " + std::to_string(line_number) + " 行值无效";
            return false;
        }
        if (!target_path_is_allowed(path, error)) {
            error += "（第 " + std::to_string(line_number) + " 行）";
            return false;
        }
        if (section == "limits" &&
            (value.size() != 3 ||
             !std::all_of(value.begin(), value.end(), [](char character) {
                 return character >= '0' && character <= '7';
             }))) {
            error = "权限值必须是 000 到 777（第 " +
                    std::to_string(line_number) + " 行）";
            return false;
        }
        if (!keys.insert(section + "\n" + path).second) {
            error = "控制器配置包含重复路径（第 " +
                    std::to_string(line_number) + " 行）";
            return false;
        }
        if (++rule_count > 2048) {
            error = "控制器配置规则数量超过限制";
            return false;
        }
    }
    if (rule_count == 0) {
        error = "控制器配置至少需要一条规则";
        return false;
    }
    return true;
}

bool ensure_controller_config(const fs::path& module_dir, std::string& error) {
    const fs::path config = controller_config_path(module_dir);
    std::error_code filesystem_error;
    const bool config_exists = fs::exists(config, filesystem_error);
    if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
        error = "无法检查模块私有控制器配置";
        return false;
    }
    filesystem_error.clear();
    if (config_exists && !fs::is_regular_file(config, filesystem_error)) {
        error = "模块私有控制器配置路径不是普通文件";
        return false;
    }
    if (filesystem_error) {
        error = "无法检查模块私有控制器配置类型";
        return false;
    }

    if (config_exists) {
        std::string current;
        if (!platform::read_text_file(config, current, 256 * 1024)) {
            error = "无法读取模块私有控制器配置";
            return false;
        }
        std::string validation_error;
        if (validate_controller_config(current, validation_error)) return true;
        if (validation_error != "控制器配置至少需要一条规则") {
            error = validation_error;
            return false;
        }
        std::fprintf(stderr,
                     "[custom_thermal_skp] repairing empty controller config: %s\n",
                     config.c_str());
    }

    std::string initial;
    const bool legacy_read =
        platform::read_text_file(kLegacyExternalConfig, initial, 256 * 1024);
    if (legacy_read && !platform::trim_ascii(initial).empty()) {
        std::string legacy_error;
        if (!validate_controller_config(initial, legacy_error)) {
            error = "旧控制器配置校验失败：" + legacy_error;
            return false;
        }
    } else {
        initial.clear();
        if (!platform::read_text_file(module_dir / "defaults" / "Asphyxia.toml",
                                      initial, 256 * 1024) ||
            platform::trim_ascii(initial).empty()) {
            error = "内置控制器配置缺失或为空";
            return false;
        }
    }
    if (!validate_controller_config(initial, error)) {
        error = "内置控制器配置校验失败：" + error;
        return false;
    }
    if (!platform::ensure_directory(state_directory(module_dir), 0700)) {
        error = "无法创建模块私有配置目录";
        return false;
    }
    if (!platform::write_text_file_atomic(config, initial, 0600)) {
        error = "无法创建模块私有控制器配置";
        return false;
    }
    append_runtime_log(module_dir, "CONFIG",
                       config_exists ? "空配置已恢复为内置默认配置"
                                     : "缺失配置已创建为内置默认配置");
    return true;
}

bool controller_process_matches(const fs::path& module_dir, pid_t pid) {
    if (!platform::process_alive(pid)) return false;
    const std::string expected = controller_path(module_dir).string();
    return platform::process_cmdline(pid) == expected ||
           platform::process_executable(pid) == expected;
}

bool controller_supervisor_matches(const fs::path& module_dir, pid_t pid) {
    if (!platform::process_alive(pid)) return false;
    return platform::process_executable(pid) ==
               controller_helper_path(module_dir).string() &&
           platform::process_comm(pid) == kControllerWaiterProcessName;
}

void stop_controller_processes(const fs::path& module_dir) {
    const fs::path supervisor_file = supervisor_pid_path(module_dir);
    const pid_t supervisor = platform::read_pid_file(supervisor_file);
    if (controller_supervisor_matches(module_dir, supervisor)) {
        (void)platform::stop_process(supervisor, 2s);
    }
    (void)::unlink(supervisor_file.c_str());

    const fs::path waiter_file = waiter_pid_path(module_dir);
    const pid_t waiter = platform::read_pid_file(waiter_file);
    if (controller_supervisor_matches(module_dir, waiter)) {
        (void)platform::stop_process(waiter, 2s);
    }
    (void)::unlink(waiter_file.c_str());

    const fs::path controller_file = controller_pid_path(module_dir);
    const pid_t controller = platform::read_pid_file(controller_file);
    if (controller_process_matches(module_dir, controller)) {
        (void)platform::stop_process(controller, 3s);
    }
    (void)::unlink(controller_file.c_str());

    const std::string expected_controller = controller_path(module_dir).string();
    const std::string expected_helper = controller_helper_path(module_dir).string();
    std::error_code filesystem_error;
    fs::directory_iterator iterator("/proc", filesystem_error);
    const fs::directory_iterator end;
    while (!filesystem_error && iterator != end) {
        const std::string name = iterator->path().filename().string();
        if (!name.empty() &&
            std::all_of(name.begin(), name.end(), [](unsigned char character) {
                return std::isdigit(character) != 0;
            })) {
            char* parse_end = nullptr;
            errno = 0;
            const long value = std::strtol(name.c_str(), &parse_end, 10);
            if (errno == 0 && parse_end != name.c_str() && *parse_end == '\0' &&
                value > 1 && value <= 4194304) {
                const pid_t pid = static_cast<pid_t>(value);
                const std::string executable = platform::process_executable(pid);
                if (executable == expected_controller ||
                     (executable == expected_helper &&
                      platform::process_comm(pid) == kControllerWaiterProcessName)) {
                    (void)platform::stop_process(pid, 3s);
                }
            }
        }
        iterator.increment(filesystem_error);
    }
}

void stop_legacy_controller_processes(const fs::path& module_dir) {
    const std::string current = controller_path(module_dir).string();
    std::error_code filesystem_error;
    fs::directory_iterator iterator("/proc", filesystem_error);
    const fs::directory_iterator end;
    while (!filesystem_error && iterator != end) {
        const std::string name = iterator->path().filename().string();
        if (!name.empty() &&
            std::all_of(name.begin(), name.end(), [](unsigned char character) {
                return std::isdigit(character) != 0;
            })) {
            char* parse_end = nullptr;
            errno = 0;
            const long value = std::strtol(name.c_str(), &parse_end, 10);
            if (errno == 0 && parse_end != name.c_str() && *parse_end == '\0' &&
                value > 1 && value <= 4194304) {
                const pid_t pid = static_cast<pid_t>(value);
                const std::string executable = platform::process_executable(pid);
                const std::string command = platform::process_cmdline(pid);
                const bool legacy =
                    executable.rfind("/data/adb/modules/Eclipse/", 0) == 0 ||
                    command.rfind("/data/adb/modules/Eclipse/", 0) == 0 ||
                    executable == "/sdcard/Android/Eclipse/Asphyxia";
                if (legacy && executable != current) {
                    (void)platform::stop_process(pid, 3s);
                }
            }
        }
        iterator.increment(filesystem_error);
    }
}

bool spawn_controller_now(const fs::path& module_dir) {
    stop_controller_processes(module_dir);
    return platform::run_process(
               {controller_helper_path(module_dir).string(), "start",
                module_dir.string()},
               std::chrono::seconds(10),
               state_directory(module_dir) / "controller_helper.log")
        .ok();
}

bool schedule_controller_after_boot(const fs::path& module_dir) {
    stop_controller_processes(module_dir);
    return platform::run_process(
               {controller_helper_path(module_dir).string(), "wait",
                module_dir.string()},
               std::chrono::seconds(10),
               state_directory(module_dir) / "controller_helper.log")
        .ok();
}

bool controller_is_running(const fs::path& module_dir) {
    return controller_process_matches(module_dir,
                                      platform::read_pid_file(controller_pid_path(module_dir)));
}

bool controller_is_waiting(const fs::path& module_dir) {
    const pid_t pid = platform::read_pid_file(waiter_pid_path(module_dir));
    return controller_supervisor_matches(module_dir, pid);
}

bool controller_is_restarting(const fs::path& module_dir) {
    return controller_supervisor_matches(
        module_dir, platform::read_pid_file(supervisor_pid_path(module_dir)));
}

bool restore_stock_config(const fs::path& module_dir, std::string& error) {
    (void)module_dir;
    const fs::path backup = kStockBackup;
    std::string previous_transaction;
    (void)platform::read_text_file(kTransactionMarker, previous_transaction, 4096);
    const bool resuming_committed_stock =
        previous_transaction.rfind("committed\n", 0) == 0 &&
        previous_transaction.find("\nkind=stock\n") != std::string::npos;
    if (!recover_pending_transaction(error)) return false;
    if (resuming_committed_stock) return true;

    std::error_code filesystem_error;
    if (!fs::is_regular_file(backup / ".complete", filesystem_error) ||
        filesystem_error) {
        error = "未找到可信原厂备份，温控配置保持不变";
        return false;
    }
    std::string identity_record;
    if (!platform::read_text_file(backup / ".identity", identity_record, 4096) ||
        identity_record != backup_identity()) {
        error = "原厂备份与当前固件不匹配，温控配置保持不变";
        return false;
    }

    if (!remove_transaction_candidate(error, true)) return false;
    const fs::path candidate = kTransactionCandidate;
    const auto fail_stock_prepare = [&](const std::string& reason) {
        std::string cleanup_error;
        if (!remove_transaction_candidate(cleanup_error, true)) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: failed to discard stock candidate: %s\n",
                         cleanup_error.c_str());
        }
        error = reason;
        return false;
    };
    if (!platform::copy_tree(backup / "data", candidate, true, &error)) {
        const std::string reason = error;
        return fail_stock_prepare(reason);
    }
    const std::string identity =
        "stock-" + std::to_string(static_cast<long long>(::getpid())) + "-" +
        std::to_string(static_cast<long long>(
            std::chrono::steady_clock::now().time_since_epoch().count()));
    if (!platform::write_text_file_atomic(candidate / kTransactionIdentityFile,
                                          identity + "\n", 0600)) {
        return fail_stock_prepare("无法记录原厂配置恢复事务");
    }
    const bool previous_was_locked =
        config_tree_has_immutable_file(kThermalConfig);
    (void)platform::set_immutable(kThermalRoot, false);
    if (!platform::write_text_file_atomic(
            kTransactionMarker,
            "pending\nid=" + identity + "\nkind=stock\nold_locked=" +
                (previous_was_locked ? "1\n" : "0\n"),
            0600)) {
        std::string cleanup_error;
        (void)abort_mode_transaction(previous_was_locked, cleanup_error, true);
        return fail_stock_prepare("无法记录原厂配置恢复事务");
    }

    std::string unlock_error;
    if (!set_config_immutable_checked(kThermalConfig, false, unlock_error)) {
        std::string cleanup_error;
        (void)abort_mode_transaction(previous_was_locked, cleanup_error, true);
        error = unlock_error;
        return false;
    }
    std::string replace_error;
    if (!platform::atomic_replace_directory(candidate, kThermalConfig, &replace_error)) {
        std::string cleanup_error;
        (void)abort_mode_transaction(previous_was_locked, cleanup_error, true);
        error = replace_error;
        return false;
    }

    std::string finalize_error;
    const bool finalized =
        set_config_immutable_checked(kThermalConfig, false, finalize_error) &&
        restore_thermal_metadata(backup, finalize_error) &&
        restore_thermal_contexts(finalize_error);
    if (!finalized) {
        std::string rollback_error;
        if (!rollback_exchanged_config(previous_was_locked, rollback_error, true)) {
            error = finalize_error + "；原厂恢复自动回滚失败：" + rollback_error;
            return false;
        }
        error = finalize_error + "；已恢复卸载前配置";
        return false;
    }
    if (!platform::write_text_file_atomic(
            kTransactionMarker,
            "committed\nid=" + identity + "\nkind=stock\nold_locked=" +
                (previous_was_locked ? "1\n" : "0\n"),
            0600)) {
        std::string rollback_error;
        if (!rollback_exchanged_config(previous_was_locked, rollback_error, true)) {
            error = "无法提交原厂恢复事务且自动回滚失败：" + rollback_error;
            return false;
        }
        error = "无法提交原厂恢复事务；已恢复卸载前配置";
        return false;
    }

    std::string cleanup_error;
    if (!remove_live_transaction_identity(cleanup_error)) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: stock identity cleanup failed: %s\n",
                     cleanup_error.c_str());
        return true;
    }
    if (!remove_transaction_candidate(cleanup_error, true)) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: stock candidate cleanup failed: %s\n",
                     cleanup_error.c_str());
        return true;
    }
    (void)platform::set_immutable(kThermalRoot, false);
    if (!remove_transaction_marker_file(cleanup_error)) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: stock marker cleanup failed: %s\n",
                     cleanup_error.c_str());
        return true;
    }
    cleanup_error.clear();
    if (!sync_thermal_root(cleanup_error)) {
        // Keep the stock backup if the marker removal is not yet durable.
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: stock marker fsync failed: %s\n",
                     cleanup_error.c_str());
        return true;
    }
    fs::remove_all(backup, filesystem_error);
    if (filesystem_error) {
        std::fprintf(stderr,
                     "[custom_thermal_skp] warning: stock backup cleanup failed: %s\n",
                     filesystem_error.message().c_str());
    }
    ::sync();
    return true;
}

std::string quoted_json(const std::string& value) {
    return "\"" + platform::json_escape(value) + "\"";
}

RuntimeStatusSnapshot runtime_status_snapshot(const fs::path& module_dir) {
    RuntimeStatusSnapshot snapshot;
    snapshot.settings = load_settings(module_dir);
    snapshot.market = platform::get_property("ro.product.odm.marketname");
    snapshot.active_mode = active_mode_from_disk();
    snapshot.profiles_ready = profiles_are_ready(module_dir);
    snapshot.config_files = regular_file_count(kThermalConfig);
    snapshot.active_properties = active_property_override_count();
    snapshot.transaction_state = thermal_transaction_state();
    snapshot.thermal_state = "active";
    if (snapshot.transaction_state == "pending") snapshot.thermal_state = "recovering";
    else if (snapshot.transaction_state == "error" ||
             snapshot.transaction_state == "invalid") {
        snapshot.thermal_state = "error";
    } else if (!snapshot.profiles_ready || snapshot.config_files == 0) {
        snapshot.thermal_state = "not_ready";
    } else if (snapshot.active_mode.empty() ||
               snapshot.active_mode != snapshot.settings.mode) {
        snapshot.thermal_state = "mismatch";
    } else if (snapshot.active_properties != snapshot.total_properties) {
        snapshot.thermal_state = "partial";
    }
    snapshot.thermal_active = snapshot.thermal_state == "active";

    std::error_code filesystem_error;
    snapshot.config_exists =
        fs::is_regular_file(controller_config_path(module_dir), filesystem_error) &&
        !filesystem_error;
    snapshot.controller_state = "stopped";
    if (controller_is_running(module_dir)) snapshot.controller_state = "running";
    else if (controller_is_waiting(module_dir)) snapshot.controller_state = "waiting";
    else if (controller_is_restarting(module_dir)) snapshot.controller_state = "restarting";
    return snapshot;
}

const char* thermal_state_label(const std::string& state) {
    if (state == "active") return "已生效";
    if (state == "partial") return "部分属性未生效";
    if (state == "recovering") return "正在恢复事务";
    if (state == "error") return "检测到错误";
    if (state == "not_ready") return "配置未就绪";
    if (state == "mismatch") return "模式不一致";
    return "未知";
}

const char* transaction_state_label(const std::string& state) {
    if (state == "clean") return "正常";
    if (state == "pending") return "待恢复";
    if (state == "committed") return "已提交待清理";
    if (state == "error") return "错误";
    if (state == "invalid") return "无效";
    return "未知";
}

const char* controller_state_label(const std::string& state, bool enabled) {
    if (state == "running") return "运行中";
    if (state == "waiting") return "等待开机";
    if (state == "restarting") return "正在重启";
    if (state == "stopped") return enabled ? "异常停止" : "未启用";
    return "未知";
}

}  // namespace

std::string install_module(const fs::path& module_dir) {
    const auto fail_install = [&](const std::string& message) {
        append_runtime_log(module_dir, "INSTALL_FAIL", message);
        return message;
    };
    append_runtime_log(module_dir, "INSTALL", "开始安装模块");
    std::error_code legacy_error;
    if (fs::is_directory("/data/adb/modules/Eclipse", legacy_error) && !legacy_error) {
        return fail_install("检测到旧版 Eclipse Magisk/KernelSU 模块，请先卸载并重启");
    }
    const std::string validation = validate_device();
    if (!validation.empty()) return fail_install(validation);
    stop_legacy_controller_processes(module_dir);

    std::string error;
    if (!prepare_resources(module_dir, error)) return fail_install(error);
    if (!recover_pending_transaction(error)) return fail_install(error);
    if (!capture_original_properties(module_dir, error)) return fail_install(error);
    if (!generate_profiles(module_dir, error)) return fail_install(error);
    if (!backup_stock_config(module_dir, error)) return fail_install(error);

    Settings settings = load_settings(module_dir);
    if (!save_settings(module_dir, settings)) return fail_install("无法保存模块设置");
    if (!apply_mode_profile(module_dir, settings.mode, error)) {
        const std::string apply_error = error;
        std::string restore_error;
        if (!restore_stock_config(module_dir, restore_error)) {
            return fail_install(apply_error + "；恢复原厂配置失败：" + restore_error);
        }
        return fail_install(apply_error);
    }
    append_runtime_log(module_dir, "INSTALL_OK",
                       "温控模式=" + settings.mode + "，磁盘模式=" +
                           active_mode_from_disk());
    return {};
}

std::string start_module(const fs::path& module_dir) {
    const auto fail_start = [&](const std::string& message) {
        append_runtime_log(module_dir, "BOOT_FAIL", message);
        try {
            stop_controller_processes(module_dir);
        } catch (...) {
        }
        try {
            restore_original_properties(module_dir);
        } catch (...) {
        }
        return message;
    };

    append_runtime_log(module_dir, "BOOT", "开始执行开机回调");

    const std::string validation = validate_device();
    if (!validation.empty()) return fail_start(validation);
    stop_legacy_controller_processes(module_dir);

    std::string error;
    if (!prepare_resources(module_dir, error)) return fail_start(error);
    if (!recover_pending_transaction(error)) return fail_start(error);
    if (!stock_backup_is_valid(error)) return fail_start(error);
    if (!capture_original_properties(module_dir, error)) return fail_start(error);
    if (!generate_profiles(module_dir, error)) return fail_start(error);

    const Settings settings = load_settings(module_dir);
    if (active_mode_from_disk() != settings.mode &&
        !apply_mode_profile(module_dir, settings.mode, error)) {
        return fail_start(error);
    }
    if (!apply_property_overrides(module_dir, error)) {
        return fail_start(error);
    }

    if (settings.controller_enabled) {
        if (!ensure_controller_config(module_dir, error)) {
            return fail_start(error);
        }
        if (!schedule_controller_after_boot(module_dir)) {
            return fail_start("控制器等待进程启动失败");
        }
    } else {
        stop_controller_processes(module_dir);
    }
    append_runtime_log(module_dir, "BOOT_OK",
                       "温控模式=" + settings.mode + "，磁盘模式=" +
                           active_mode_from_disk() + "，控制器=" +
                           (settings.controller_enabled ? "已调度" : "未启用"));
    return {};
}

void uninstall_module(const fs::path& module_dir) {
    try {
        stop_controller_processes(module_dir);
    } catch (...) {
        std::fprintf(stderr, "[custom_thermal_skp] uninstall: stop process exception\n");
    }
    try {
        std::string error;
        if (!restore_stock_config(module_dir, error)) {
            std::fprintf(stderr, "[custom_thermal_skp] uninstall: %s\n", error.c_str());
        }
    } catch (...) {
        std::fprintf(stderr, "[custom_thermal_skp] uninstall: config restore exception\n");
    }
    try {
        restore_original_properties(module_dir);
    } catch (...) {
        std::fprintf(stderr, "[custom_thermal_skp] uninstall: property restore exception\n");
    }
}

bool is_valid_mode_request(const std::string& requested_mode) {
    return mode_is_valid(platform::trim_ascii(requested_mode));
}

bool select_mode(const fs::path& module_dir, const std::string& requested_mode,
                 std::string& message) {
    const std::string mode = platform::trim_ascii(requested_mode);
    const auto fail_mode = [&](const std::string& reason) {
        message = reason;
        append_runtime_log(module_dir, "MODE_FAIL",
                           "请求模式=" + mode + "，原因=" + reason);
        return false;
    };
    if (!mode_is_valid(mode)) {
        return fail_mode("无效温控模式");
    }
    std::string error;
    if (!profiles_are_ready(module_dir) && !generate_profiles(module_dir, error)) {
        return fail_mode(error);
    }
    const Settings previous = load_settings(module_dir);
    if (!apply_mode_profile(module_dir, mode, error)) {
        return fail_mode(error);
    }
    Settings settings = previous;
    settings.mode = mode;
    if (!save_settings(module_dir, settings)) {
        std::string rollback_error;
        if (previous.mode != mode &&
            !apply_mode_profile(module_dir, previous.mode, rollback_error)) {
            return fail_mode("设置持久化失败，且模式回滚失败：" + rollback_error);
        }
        return fail_mode("设置持久化失败，已恢复原模式");
    }
    message = std::string("已切换到") + mode_label(mode);
    append_runtime_log(module_dir, "MODE_OK",
                       "设置模式=" + mode + "，磁盘模式=" +
                           active_mode_from_disk());
    return true;
}

bool set_controller_enabled(const fs::path& module_dir, bool enabled,
                            std::string& message) {
    const auto fail_controller = [&](const std::string& reason) {
        message = reason;
        append_runtime_log(module_dir, "CONTROLLER_FAIL",
                           std::string("目标=") + (enabled ? "启用" : "停用") +
                               "，原因=" + reason);
        return false;
    };
    Settings settings = load_settings(module_dir);
    if (!enabled) {
        settings.controller_enabled = false;
        if (!save_settings(module_dir, settings)) {
            return fail_controller("无法保存控制器设置");
        }
        stop_controller_processes(module_dir);
        message = "控制器已停用";
        append_runtime_log(module_dir, "CONTROLLER", "控制器已停用");
        return true;
    }

    std::string error;
    if (!ensure_controller_config(module_dir, error)) {
        return fail_controller(error);
    }
    settings.controller_enabled = true;
    if (!save_settings(module_dir, settings)) {
        return fail_controller("无法保存控制器设置");
    }

    // Persist before launch so every helper path observes a consistent state.
    if (!spawn_controller_now(module_dir)) {
        settings.controller_enabled = false;
        const bool settings_rolled_back = save_settings(module_dir, settings);
        if (!settings_rolled_back) {
            std::fprintf(stderr,
                         "[custom_thermal_skp] warning: failed to roll back controller setting\n");
        }
        stop_controller_processes(module_dir);
        return fail_controller(settings_rolled_back ? "控制器启动失败，已恢复停用状态"
                                                    : "控制器启动失败，且无法恢复启用设置");
    }
    message = "控制器已启用";
    append_runtime_log(module_dir, "CONTROLLER", "控制器已启用并启动");
    return true;
}

bool validate_controller_config_request(const std::string& content,
                                        std::string& message) {
    return validate_controller_config(content, message);
}

bool read_controller_config(const fs::path& module_dir, std::string& content,
                            std::string& message) {
    if (!ensure_controller_config(module_dir, message)) {
        content.clear();
        return false;
    }
    const fs::path config = controller_config_path(module_dir);
    if (!platform::read_text_file(config, content, 256 * 1024)) {
        message = "无法读取控制器配置";
        return false;
    }
    return true;
}

bool write_controller_config(const fs::path& module_dir, const std::string& content,
                             std::string& message) {
    if (!validate_controller_config(content, message)) return false;
    if (!platform::ensure_directory(state_directory(module_dir), 0700)) {
        message = "无法创建控制器配置目录";
        return false;
    }
    const fs::path config = controller_config_path(module_dir);
    std::error_code filesystem_error;
    const bool config_exists = fs::exists(config, filesystem_error);
    if (filesystem_error && !filesystem_entry_missing(filesystem_error)) {
        message = "无法检查当前控制器配置";
        return false;
    }
    filesystem_error.clear();
    if (config_exists) {
        if (!fs::is_regular_file(config, filesystem_error) || filesystem_error) {
            message = "当前控制器配置不是普通文件";
            return false;
        }
        std::string previous;
        if (!platform::read_text_file(config, previous, 1024 * 1024)) {
            message = "无法读取当前控制器配置以进行备份";
            return false;
        }
        if (!platform::write_text_file_atomic(config.string() + ".bak", previous, 0600)) {
            message = "无法备份当前控制器配置";
            return false;
        }
    }
    if (!platform::write_text_file_atomic(config, content, 0600)) {
        message = "无法保存控制器配置";
        return false;
    }
    message = "配置已保存";
    append_runtime_log(module_dir, "CONFIG",
                       "控制器配置已保存，字节数=" +
                           std::to_string(content.size()));
    return true;
}

std::string status_json(const fs::path& module_dir) {
    const RuntimeStatusSnapshot snapshot = runtime_status_snapshot(module_dir);

    std::string json = "{";
    json += "\"device\":" + quoted_json(current_device()) + ",";
    json += "\"marketName\":" + quoted_json(snapshot.market) + ",";
    json += "\"kernel\":" + quoted_json(platform::kernel_release()) + ",";
    json += "\"mode\":" + quoted_json(snapshot.settings.mode) + ",";
    json += "\"modeLabel\":" + quoted_json(mode_label(snapshot.settings.mode)) + ",";
    json += "\"activeMode\":" + quoted_json(snapshot.active_mode) + ",";
    json += "\"thermalState\":" + quoted_json(snapshot.thermal_state) + ",";
    json += "\"thermalActive\":";
    json += snapshot.thermal_active ? "true," : "false,";
    json += "\"thermalConfigFiles\":" + std::to_string(snapshot.config_files) + ",";
    json += "\"propertyOverridesActive\":" +
            std::to_string(snapshot.active_properties) + ",";
    json += "\"propertyOverridesTotal\":" +
            std::to_string(snapshot.total_properties) + ",";
    json += "\"transactionState\":" + quoted_json(snapshot.transaction_state) + ",";
    json += "\"controllerEnabled\":";
    json += snapshot.settings.controller_enabled ? "true," : "false,";
    json += "\"controllerState\":" + quoted_json(snapshot.controller_state) + ",";
    json += "\"profilesReady\":";
    json += snapshot.profiles_ready ? "true," : "false,";
    json += "\"configExists\":";
    json += snapshot.config_exists ? "true" : "false";
    json += "}";
    return json;
}

std::string runtime_log_text(const fs::path& module_dir) {
    const RuntimeStatusSnapshot snapshot = runtime_status_snapshot(module_dir);
    const std::string runtime = read_log_tail(runtime_log_path(module_dir), 48 * 1024);
    const std::string controller =
        read_log_tail(state_directory(module_dir) / "controller.log", 48 * 1024);
    const std::string launcher =
        read_log_tail(state_directory(module_dir) / "controller_helper.log", 16 * 1024);
    std::string output = "[当前验证]\n";
    output += "温控状态=" + std::string(thermal_state_label(snapshot.thermal_state)) +
              " (" + snapshot.thermal_state + ")\n";
    output += "设置模式=" + snapshot.settings.mode + "，磁盘模式=" +
              (snapshot.active_mode.empty() ? "未识别" : snapshot.active_mode) + "\n";
    output += "配置文件=" + std::to_string(snapshot.config_files) +
              "，配置模板=" + (snapshot.profiles_ready ? "就绪" : "缺失/过期") + "\n";
    output += "系统属性覆盖=" + std::to_string(snapshot.active_properties) + "/" +
              std::to_string(snapshot.total_properties) + "\n";
    output += "事务状态=" +
              std::string(transaction_state_label(snapshot.transaction_state)) + " (" +
              snapshot.transaction_state + ")\n";
    output += "控制器=" +
              std::string(controller_state_label(snapshot.controller_state,
                                                snapshot.settings.controller_enabled)) +
              " (" + snapshot.controller_state + ")\n";
    output += "\n[模块运行事件]\n";
    output += runtime.empty() ? "暂无记录\n" : runtime;
    output += "\n[控制器输出]\n";
    output += controller.empty() ? "暂无记录\n" : controller;
    output += "\n[控制器启动器]\n";
    output += launcher.empty() ? "暂无记录\n" : launcher;
    return output;
}

std::string runtime_description(const fs::path& module_dir) {
    const Settings settings = load_settings(module_dir);
    const char* controller = settings.controller_enabled ? "控制器已启用" : "控制器未启用";
    return std::string("原生 SKP 定制温控 [") + mode_label(settings.mode) + "] [" +
           controller + "]";
}

std::string walt_policies_json() {
    const fs::path root = "/sys/devices/system/cpu/cpufreq";
    std::vector<std::pair<int, std::string>> policies;
    std::error_code error;
    fs::directory_iterator iterator(root, error);
    if (!error) {
        for (const auto& entry : iterator) {
            const std::string name = entry.path().filename().string();
            if (name.rfind("policy", 0) != 0 || name.size() <= 6) continue;
            const std::string suffix = name.substr(6);
            if (!std::all_of(suffix.begin(), suffix.end(), [](unsigned char character) {
                    return std::isdigit(character) != 0;
                })) {
                continue;
            }
            if (!fs::is_regular_file(entry.path() / "walt" / "up_rate_limit_us", error) ||
                !fs::is_regular_file(entry.path() / "walt" / "down_rate_limit_us", error)) {
                error.clear();
                continue;
            }
            char* end = nullptr;
            errno = 0;
            const long policy = std::strtol(suffix.c_str(), &end, 10);
            if (errno != 0 || end == suffix.c_str() || *end != '\0' ||
                policy < 0 || policy > 1048576) {
                continue;
            }
            policies.emplace_back(static_cast<int>(policy), name);
        }
    }
    std::sort(policies.begin(), policies.end());
    std::string json = "[";
    for (size_t index = 0; index < policies.size(); ++index) {
        if (index != 0) json += ',';
        json += quoted_json(policies[index].second);
    }
    json += ']';
    return json;
}

}  // namespace custom_thermal
