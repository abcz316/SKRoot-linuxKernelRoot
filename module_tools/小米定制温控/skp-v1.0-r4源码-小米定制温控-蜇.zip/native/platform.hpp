#pragma once

#include <sys/types.h>

#include <chrono>
#include <filesystem>
#include <string>
#include <vector>

namespace custom_thermal::platform {

namespace fs = std::filesystem;

struct ProcessResult {
    bool started = false;
    bool timed_out = false;
    int exit_code = -1;
    int term_signal = 0;

    [[nodiscard]] bool ok() const {
        return started && !timed_out && term_signal == 0 && exit_code == 0;
    }
};

std::string clean_directory(const char* path);
std::string get_property(const char* key);
std::string kernel_release();
bool kernel_at_least(int required_major, int required_minor);

bool read_text_file(const fs::path& path, std::string& output,
                    size_t max_bytes = 1024 * 1024);
bool write_text_file_atomic(const fs::path& path, const std::string& content,
                            mode_t mode = 0600);
bool ensure_directory(const fs::path& path, mode_t mode = 0755);
bool remove_children(const fs::path& directory, std::string* error = nullptr);
bool copy_tree(const fs::path& source, const fs::path& destination,
               bool preserve_metadata, std::string* error = nullptr);
bool tree_has_regular_file(const fs::path& directory);

// Replace a directory without exposing a partially copied tree. When the
// destination exists this uses renameat2(RENAME_EXCHANGE), leaving the old
// destination at the candidate path for the caller to remove or roll back.
bool atomic_replace_directory(const fs::path& candidate,
                              const fs::path& destination,
                              std::string* error = nullptr);

bool set_immutable(const fs::path& path, bool immutable);
bool get_immutable(const fs::path& path, bool& immutable);
void set_tree_immutable(const fs::path& root, bool immutable,
                        bool regular_files_only_when_locking = true);

ProcessResult run_process(const std::vector<std::string>& arguments,
                          std::chrono::seconds timeout,
                          const fs::path& log_path = {});

bool write_pid_file(const fs::path& path, pid_t pid);
pid_t read_pid_file(const fs::path& path);
bool process_alive(pid_t pid);
std::string process_comm(pid_t pid);
std::string process_cmdline(pid_t pid);
std::string process_executable(pid_t pid);
bool stop_process(pid_t pid, std::chrono::milliseconds grace_period);

std::string json_escape(const std::string& value);
std::string trim_ascii(std::string value);

}  // namespace custom_thermal::platform
