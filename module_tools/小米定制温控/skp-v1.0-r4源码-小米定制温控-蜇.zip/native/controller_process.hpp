#pragma once

namespace custom_thermal {

// Linux TASK_COMM_LEN includes the trailing NUL, so keep this at <= 15 bytes.
inline constexpr char kControllerWaiterProcessName[] = "skp-thrm-wait";
static_assert(sizeof(kControllerWaiterProcessName) - 1 <= 15,
              "controller waiter process name exceeds TASK_COMM_LEN");

}  // namespace custom_thermal
