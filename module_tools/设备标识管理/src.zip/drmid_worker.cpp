#include "drmid_worker.h"

#include "common.h"
#include "drmid_backend.h"
#include "file_lifecycle.h"
#include "runtime_profile.h"
#include "runtime_control.h"
#include "binder_ioctl_resolver.h"
#include "device_id_fingerprint.h"

#include <dirent.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#include <array>
#include <cerrno>
#include <cinttypes>
#include <cstdio>
#include <cstring>
#include <limits>
#include <map>
#include <sstream>
#include <iostream>
#include <cstdlib>
#include <vector>

#include "kernel_module_kit_umbrella.h"

namespace device_identity::drm {
namespace {

constexpr char kWorkerPidName[] = "drm_worker_pid";
constexpr char kWorkerStateName[] = "drm_worker_state";
constexpr char kWorkerResultName[] = "drm_worker_result";
constexpr char kWorkerBootName[] = "drm_worker_boot";
constexpr char kWorkerPathName[] = "webroot/device_identity_drm_worker";
constexpr char kEnabledName[] = "drm_enabled";

std::string join_path(const std::string& dir, const char* name) {
    if (dir.empty()) return {};
    return dir + (dir.back() == '/' ? "" : "/") + name;
}

bool read_private_record(const std::string& dir, const char* key,
                         void* output, size_t size) {
    if (dir.empty() || key == nullptr || output == nullptr || size == 0) return false;
    const std::string path = join_path(dir, key);
    const int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return false;
    size_t used = 0;
    while (used < size) {
        const ssize_t count = read(fd, static_cast<uint8_t*>(output) + used, size - used);
        if (count > 0) used += static_cast<size_t>(count);
        else if (count < 0 && errno == EINTR) continue;
        else break;
    }
    uint8_t extra = 0;
    const ssize_t tail = read(fd, &extra, 1);
    close(fd);
    return used == size && tail == 0;
}

bool write_private_record(const std::string& dir, const char* key,
                          const void* input, size_t size) {
    if (dir.empty() || key == nullptr || input == nullptr || size == 0) return false;
    const std::string path = join_path(dir, key);
    const std::string temporary = path + ".tmp." + std::to_string(getpid());
    const int fd = open(temporary.c_str(), O_WRONLY | O_CREAT | O_TRUNC |
                         O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return false;
    size_t used = 0;
    while (used < size) {
        const ssize_t count = write(fd, static_cast<const uint8_t*>(input) + used,
                                    size - used);
        if (count > 0) used += static_cast<size_t>(count);
        else if (count < 0 && errno == EINTR) continue;
        else break;
    }
    const bool durable = used == size && fchmod(fd, 0600) == 0 && fsync(fd) == 0;
    const bool closed = close(fd) == 0;
    if (!durable || !closed || rename(temporary.c_str(), path.c_str()) != 0) {
        unlink(temporary.c_str());
        return false;
    }
    const int directory_fd = open(dir.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (directory_fd >= 0) { fsync(directory_fd); close(directory_fd); }
    return true;
}

bool read_i32(const std::string& dir, const char* key, int32_t& value) {
    return read_private_record(dir, key, &value, sizeof(value));
}
bool write_i32(const std::string& dir, const char* key, int32_t value) {
    return write_private_record(dir, key, &value, sizeof(value));
}
bool read_u32(const std::string& dir, const char* key, uint32_t& value) {
    return read_private_record(dir, key, &value, sizeof(value));
}
bool write_u32(const std::string& dir, const char* key, uint32_t value) {
    return write_private_record(dir, key, &value, sizeof(value));
}

bool process_alive(pid_t pid) { return pid > 1 && kill(pid, 0) == 0; }

bool process_is_worker(pid_t pid) {
    if (!process_alive(pid)) return false;
    std::string cmd;
    if (!jiebiao::read_stream_file("/proc/" + std::to_string(pid) + "/cmdline", cmd, 4096)) return false;
    return cmd.find("device_identity_drm_worker") != std::string::npos;
}

bool reap_worker(pid_t pid) {
    if (pid <= 1) return false;
    int status = 0;
    for (;;) {
        const pid_t result = waitpid(pid, &status, WNOHANG);
        if (result == pid) return true;
        if (result == 0) return false;
        if (result < 0 && errno == EINTR) continue;
        return false;
    }
}

bool parse_hex(const std::string& text, std::array<uint8_t, drmid::kVirtualStreamBytes>& out) {
    out = {};
    if (text.size() != drmid::kWidevineDeviceUniqueIdBytes * 2) return false;
    auto nibble = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    };
    for (size_t i = 0; i < drmid::kWidevineDeviceUniqueIdBytes; ++i) {
        const int h = nibble(text[i * 2]);
        const int l = nibble(text[i * 2 + 1]);
        if (h < 0 || l < 0) return false;
        out[i] = static_cast<uint8_t>((h << 4) | l);
    }
    return true;
}

std::string id_hex(const std::array<uint8_t, drmid::kVirtualStreamBytes>& id) {
    static constexpr char kHex[] = "0123456789abcdef";
    std::string text;
    text.reserve(drmid::kWidevineDeviceUniqueIdBytes * 2);
    for (size_t i = 0; i < drmid::kWidevineDeviceUniqueIdBytes; ++i) {
        text.push_back(kHex[id[i] >> 4]);
        text.push_back(kHex[id[i] & 0xf]);
    }
    return text;
}

std::string state_name(WorkerState state) {
    switch (state) {
        case WorkerState::kStarting: return "starting";
        case WorkerState::kRunning: return "running";
        case WorkerState::kFailed: return "failed";
        case WorkerState::kDisabled: return "disabled";
        case WorkerState::kWaitingHal: return "waiting-hal";
        default: return "stopped";
    }
}

}  // namespace

std::string worker_path(const std::string& private_dir) {
    return join_path(private_dir, kWorkerPathName);
}

bool detect_legacy_module_conflict(const char* root_key,
                                   ConflictStatus& status) {
    status = {};
    if (root_key == nullptr || *root_key == '\0') return false;
    std::vector<skroot_env::module_record> modules;
    if (is_failed(skroot_env::get_all_modules_list(root_key, modules))) return false;
    for (const auto& module : modules) {
        const std::string id(module.desc.id32);
        if (id == kLegacyJiebiaoModuleId || id == kLegacyDrmidModuleId) {
            status.detected = true;
            status.module_id = id;
            status.module_version = module.desc.version;
            return true;
        }
    }
    return true;
}

bool worker_alive(const std::string& private_dir, pid_t* pid_out) {
    int32_t pid = 0;
    if (!read_i32(private_dir, kWorkerPidName, pid) || !process_is_worker(pid)) {
        if (pid_out) *pid_out = 0;
        return false;
    }
    if (pid_out) *pid_out = static_cast<pid_t>(pid);
    return true;
}

bool mark_startup_waiting(const std::string& private_dir, bool waiting) {
    if (!write_u32(private_dir, kWorkerBootName, waiting ? 1U : 0U)) return false;
    if (waiting && !write_u32(private_dir, kWorkerStateName,
                              static_cast<uint32_t>(WorkerState::kStarting))) {
        return false;
    }
    return true;
}

bool stop_worker(const std::string& private_dir, std::string& detail) {
    detail.clear();
    pid_t pid = 0;
    if (!worker_alive(private_dir, &pid)) {
        write_i32(private_dir, kWorkerPidName, 0);
        write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(WorkerState::kStopped));
        write_u32(private_dir, kWorkerBootName, 0);
        detail = "not-running";
        return true;
    }
    kill(pid, SIGTERM);
    for (int i = 0; i < 40 && process_alive(pid); ++i) usleep(100000);
    if (process_alive(pid)) kill(pid, SIGKILL);
    reap_worker(pid);
    write_i32(private_dir, kWorkerPidName, 0);
    write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(WorkerState::kStopped));
    write_u32(private_dir, kWorkerBootName, 0);
    detail = "stopped=" + std::to_string(pid);
    return true;
}

bool mark_waiting_hal(const std::string& private_dir, bool waiting) {
    return write_u32(private_dir, kWorkerBootName, 0) &&
        write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(
            waiting ? WorkerState::kWaitingHal : WorkerState::kStarting));
}

bool start_worker(const std::string& private_dir,
                  bool resolve_only,
                  std::string& detail,
                  const std::string& root_key) {
    detail.clear();
    if (worker_alive(private_dir)) { detail = "already-running"; return true; }
    int32_t stale_pid = 0;
    if (read_i32(private_dir, kWorkerPidName, stale_pid) && stale_pid > 1) {
        // Reap a completed direct child when possible.  ECHILD is expected
        // when this call originates in the WebUI process rather than the
        // supervisor.
        reap_worker(static_cast<pid_t>(stale_pid));
    }
    const std::string path = worker_path(private_dir);
    if (access(path.c_str(), X_OK) != 0) { detail = "worker-missing"; return false; }
    if (!write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(WorkerState::kStarting))) {
        detail = "state-write-failed"; return false;
    }
    write_u32(private_dir, kWorkerBootName, 0);
    int root_pipe[2] = {-1, -1};
    if (!root_key.empty() && pipe(root_pipe) != 0) {
        detail = "root-channel-failed";
        return false;
    }
    const pid_t supervisor_pid = getpid();
    const pid_t child = fork();
    if (child < 0) {
        if (root_pipe[0] >= 0) close(root_pipe[0]);
        if (root_pipe[1] >= 0) close(root_pipe[1]);
        detail = "fork-failed";
        return false;
    }
    if (child == 0) {
        if (root_pipe[1] >= 0) close(root_pipe[1]);
        // Keep the worker from becoming an orphan if the supervisor is
        // terminated unexpectedly.  This bounds the resident process set and
        // lets the next supervisor start a clean worker instance.
        if (prctl(PR_SET_PDEATHSIG, SIGTERM) != 0 || getppid() != supervisor_pid) {
            _exit(128);
        }
        setsid();
        prctl(PR_SET_NAME, "device_identity_drm", 0, 0, 0);
        setenv("DRMID_DAEMON_MODE", "1", 1);
        if (resolve_only) setenv("DRMID_RESOLVE_ONLY", "1", 1);
        setenv("DRMID_FOREGROUND", "1", 1);
        setenv("DRMID_EXEC_DAEMON", "1", 1);
        setenv("DEVICE_IDENTITY_PRIVATE_DIR", private_dir.c_str(), 1);
        if (root_pipe[0] >= 0) {
            char fd_text[24];
            std::snprintf(fd_text, sizeof(fd_text), "%d", root_pipe[0]);
            setenv("DEVICE_IDENTITY_ROOT_FD", fd_text, 1);
        }
        execl(path.c_str(), path.c_str(), nullptr);
        _exit(127);
    }
    if (root_pipe[0] >= 0) close(root_pipe[0]);
    if (root_pipe[1] >= 0) {
        size_t used = 0;
        while (used < root_key.size()) {
            const ssize_t written = write(root_pipe[1], root_key.data() + used,
                                          root_key.size() - used);
            if (written > 0) {
                used += static_cast<size_t>(written);
            } else if (written < 0 && errno == EINTR) {
                continue;
            } else {
                break;
            }
        }
        close(root_pipe[1]);
    }
    write_i32(private_dir, kWorkerPidName, static_cast<int32_t>(child));
    detail = "spawned=" + std::to_string(child);
    return true;
}


bool initialize_runtime(const std::string& private_dir,
                        drmid::ReplacementConfig& config,
                        bool& created,
                        std::string& detail) {
    created = false;
    detail.clear();
    drmid::RuntimeProfile profile;
    const KModErr profile_err = drmid::load_or_create_runtime_profile(
        false, private_dir.c_str(), profile);
    if (is_failed(profile_err)) { detail = "profile=" + to_string(profile_err); return false; }
    if (!read_runtime(private_dir, config, detail)) {
        config = {};
        config.mode = drmid::ReplacementMode::kDryRun;
        config.virtual_id_length = drmid::kWidevineDeviceUniqueIdBytes;
        config.config_generation = 1;
        config.seed_generation = profile.seed_generation;
        // A newly installed module receives an independent random 32-byte ID.
        // The profile seed remains available for lifecycle bookkeeping, but
        // is no longer exposed as a selectable ID source.
        const int fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
        const ssize_t got = fd >= 0
            ? read(fd, config.virtual_id.data(), drmid::kWidevineDeviceUniqueIdBytes)
            : -1;
        if (fd >= 0) close(fd);
        if (got != static_cast<ssize_t>(drmid::kWidevineDeviceUniqueIdBytes)) {
            detail = "initial-random-id-failed";
            return false;
        }
        config.profile_fingerprint = drmid::virtual_id_fingerprint(
            config.virtual_id.data(), config.virtual_id_length);
        if (!write_runtime(private_dir, config, detail)) return false;
        created = true;
    }
    return true;
}

bool read_runtime(const std::string& private_dir,
                  drmid::ReplacementConfig& config,
                  std::string& detail) {
    detail.clear();
    const std::string path = drmid::default_runtime_control_path(private_dir.c_str());
    const KModErr err = drmid::read_runtime_control_file(path.c_str(), config);
    if (is_failed(err)) { detail = to_string(err); return false; }
    return true;
}

bool write_runtime(const std::string& private_dir,
                   const drmid::ReplacementConfig& config,
                   std::string& detail) {
    detail.clear();
    const std::string path = drmid::default_runtime_control_path(private_dir.c_str());
    const KModErr err = drmid::write_runtime_control_file(path.c_str(), config);
    if (is_failed(err)) { detail = to_string(err); return false; }
    return true;
}

bool publish_runtime(const std::string& private_dir,
                     const drmid::ReplacementConfig& config,
                     drmid::ControlIpcResponse* response,
                     std::string& detail) {
    detail.clear();
    const std::string socket = drmid::default_control_socket_path(private_dir.c_str());
    drmid::ControlIpcResponse result{};
    KModErr err = drmid::send_control_ipc_request(
        socket.c_str(), drmid::ControlIpcOperation::kApply, result);
    // A lost acknowledgement may follow a completed publish. Query once,
    // without reissuing a mutation, and verify every public policy field.
    const std::string original_error = is_failed(err) ? "ipc=" + to_string(err) :
        "result=" + std::to_string(result.result);
    if (is_failed(err)) {
        err = drmid::send_control_ipc_request(socket.c_str(), drmid::ControlIpcOperation::kStatus, result);
        if (is_failed(err)) { detail = original_error + ",status=" + to_string(err); return false; }
    }
    if (response) *response = result;
    if (result.config_generation != config.config_generation ||
        result.seed_generation != config.seed_generation ||
        result.profile_fingerprint != config.profile_fingerprint ||
        result.replacement_mode != static_cast<uint32_t>(config.mode) ||
        result.virtual_id_length != config.virtual_id_length) {
        detail = original_error + ",active-config-mismatch,expected-generation=" +
            std::to_string(config.config_generation) + ",active-generation=" +
            std::to_string(result.config_generation);
        return false;
    }
    detail = "active-verified,generation=" + std::to_string(config.config_generation);
    return true;
}

bool set_runtime_mode(const std::string& private_dir,
                      drmid::ReplacementMode mode,
                      bool publish,
                      drmid::ControlIpcResponse* response,
                      std::string& detail) {
    detail.clear();
    drmid::ReplacementConfig previous{};
    if (!read_runtime(private_dir, previous, detail)) return false;
    if (previous.mode == mode) {
        if (publish && worker_alive(private_dir)) {
            if (!publish_runtime(private_dir, previous, response, detail)) return false;
        }
        detail = "mode-unchanged";
        return true;
    }
    if (previous.config_generation == std::numeric_limits<uint64_t>::max()) {
        detail = "generation-overflow";
        return false;
    }
    drmid::ReplacementConfig next = previous;
    next.mode = mode;
    next.config_generation++;
    if (!write_runtime(private_dir, next, detail)) return false;
    if (publish && worker_alive(private_dir)) {
        if (!publish_runtime(private_dir, next, response, detail)) return false;
    } else {
        detail = "mode-written-offline";
    }
    return true;
}

bool set_enabled(const std::string& private_dir,
                 bool enabled,
                 std::string& detail,
                 const std::string& root_key) {
    // Kept as a compatibility shim for older callers.  Keep the disabled path
    // worker-free as well as dry-run: dry-run still installs the global Binder
    // hook and is therefore not a low-power state.
    const uint32_t enabled_record = enabled ? 1U : 0U;
    if (!write_u32(private_dir, kEnabledName, enabled_record)) {
        detail = "enabled-write-failed";
        return false;
    }
    const auto mode = enabled ? drmid::ReplacementMode::kWriteTest
                              : drmid::ReplacementMode::kDryRun;
    if (!enabled) {
        std::string stop_detail;
        const bool stop_ok = stop_worker(private_dir, stop_detail);
        std::string mode_detail;
        const bool mode_ok = set_runtime_mode(
            private_dir, mode, false, nullptr, mode_detail);
        detail = "stop=" + stop_detail + ",mode=" + mode_detail;
        return stop_ok && mode_ok;
    }
    if (worker_alive(private_dir)) {
        const auto status = read_status(private_dir);
        if (!status.control_connected) {
            std::string mode_detail;
            const bool mode_ok = set_runtime_mode(
                private_dir, mode, false, nullptr, mode_detail);
            detail = "mode=" + mode_detail + ",worker-not-ready";
            return mode_ok;
        }
        return set_runtime_mode(private_dir, mode, true, nullptr, detail);
    }
    if (!set_runtime_mode(private_dir, mode, false, nullptr, detail)) return false;
    return start_worker(private_dir, false, detail, root_key);
}

bool build_randomized_runtime(const drmid::ReplacementConfig& previous,
                              drmid::ReplacementConfig& next,
                              std::string& detail) {
    detail.clear();
    if (previous.config_generation == 0 || previous.seed_generation == 0 ||
        previous.virtual_id_length != drmid::kWidevineDeviceUniqueIdBytes ||
        previous.config_generation == std::numeric_limits<uint64_t>::max()) {
        detail = previous.config_generation == std::numeric_limits<uint64_t>::max()
                     ? "generation-overflow"
                     : "invalid-previous-runtime";
        return false;
    }
    next = previous;
    const int fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    const ssize_t count = fd >= 0
        ? read(fd, next.virtual_id.data(), drmid::kWidevineDeviceUniqueIdBytes)
        : -1;
    if (fd >= 0) close(fd);
    if (count != static_cast<ssize_t>(drmid::kWidevineDeviceUniqueIdBytes)) {
        detail = "random-read-failed";
        return false;
    }
    next.virtual_id_length = drmid::kWidevineDeviceUniqueIdBytes;
    next.profile_fingerprint = drmid::virtual_id_fingerprint(
        next.virtual_id.data(), next.virtual_id_length);
    next.config_generation++;
    detail = "generated";
    return next.profile_fingerprint != 0;
}

bool randomize_runtime(const std::string& private_dir,
                       drmid::ReplacementConfig& previous,
                       drmid::ReplacementConfig& next,
                       std::string& detail) {
    if (!read_runtime(private_dir, previous, detail)) return false;
    return build_randomized_runtime(previous, next, detail);
}

bool restore_runtime(const std::string& private_dir,
                     const drmid::ReplacementConfig& previous,
                     std::string& detail) {
    drmid::ReplacementConfig persisted{};
    if (!read_runtime(private_dir, persisted, detail)) return false;
    uint64_t newest = std::max(previous.config_generation, persisted.config_generation);
    const bool alive = worker_alive(private_dir);
    if (alive) {
        drmid::ControlIpcResponse active{};
        const std::string socket = drmid::default_control_socket_path(private_dir.c_str());
        const KModErr err = drmid::send_control_ipc_request(socket.c_str(), drmid::ControlIpcOperation::kStatus, active);
        if (is_failed(err) || active.result != 0) {
            detail = "restore-status-failed";
            return false;
        }
        newest = std::max(newest, active.config_generation);
    }
    if (newest == std::numeric_limits<uint64_t>::max()) {
        detail = "restore-generation-overflow";
        return false;
    }
    drmid::ReplacementConfig restored = previous;
    restored.config_generation = newest + 1;
    if (!write_runtime(private_dir, restored, detail)) return false;
    if (!alive) {
        detail = "restored-offline";
        return true;
    }
    drmid::ControlIpcResponse response{};
    return publish_runtime(private_dir, restored, &response, detail);
}

std::string serialize_runtime(const drmid::ReplacementConfig& config) {
    return "v1\nmode=" +
           std::to_string(static_cast<uint32_t>(config.mode)) +
           "\ngeneration=" + std::to_string(config.config_generation) +
           "\nseed=" + std::to_string(config.seed_generation) +
           "\nfingerprint=" + std::to_string(config.profile_fingerprint) +
           "\nid=" + id_hex(config.virtual_id) + "\n";
}

bool parse_runtime(const std::string& text,
                   drmid::ReplacementConfig& config) {
    std::istringstream input(text);
    std::string line;
    std::map<std::string, std::string> fields;
    if (!std::getline(input, line) || line != "v1") return false;
    while (std::getline(input, line)) {
        const size_t equal = line.find('=');
        if (equal != std::string::npos) fields[line.substr(0, equal)] = line.substr(equal + 1);
    }
    const auto mode_it = fields.find("mode");
    const auto generation_it = fields.find("generation");
    const auto seed_it = fields.find("seed");
    const auto fingerprint_it = fields.find("fingerprint");
    const auto id_it = fields.find("id");
    if (mode_it == fields.end() || generation_it == fields.end() ||
        seed_it == fields.end() || fingerprint_it == fields.end() ||
        id_it == fields.end()) return false;
    char* end = nullptr;
    const unsigned long mode = std::strtoul(mode_it->second.c_str(), &end, 10);
    if (!end || *end || mode > static_cast<unsigned long>(drmid::ReplacementMode::kWriteTest)) return false;
    config = {};
    config.mode = static_cast<drmid::ReplacementMode>(mode);
    config.config_generation = std::strtoull(generation_it->second.c_str(), &end, 10);
    if (!end || *end) return false;
    config.seed_generation = std::strtoull(seed_it->second.c_str(), &end, 10);
    if (!end || *end) return false;
    config.profile_fingerprint = std::strtoull(fingerprint_it->second.c_str(), &end, 10);
    if (!end || *end) return false;
    config.virtual_id_length = drmid::kWidevineDeviceUniqueIdBytes;
    if (!parse_hex(id_it->second, config.virtual_id)) return false;
    return config.config_generation != 0 &&
           config.profile_fingerprint == drmid::virtual_id_fingerprint(
                config.virtual_id.data(), config.virtual_id_length);
}

std::string status_json(const Status& status) {
    const auto& c = status.control;
    std::string json = "{\"state\":" + jiebiao::json_string(state_name(status.state)) +
        ",\"pid\":" + std::to_string(static_cast<long>(status.pid)) +
        ",\"result\":" + std::to_string(status.last_result) +
        ",\"connected\":" + (status.control_connected ? "true" : "false") +
        ",\"startup_waiting\":" + (status.startup_waiting ? "true" : "false") +
        ",\"kernel_release\":" + jiebiao::json_string(status.kernel_release) +
        ",\"binder_backend\":" + jiebiao::json_string(status.binder_backend) +
        ",\"resolution_source\":" + jiebiao::json_string(status.resolution_source) +
        ",\"file_offset_source\":" + jiebiao::json_string(status.file_offset_source) +
        ",\"ioctl_offset_source\":" + jiebiao::json_string(status.ioctl_offset_source) +
        ",\"capabilities\":" + jiebiao::json_string(status.capabilities) +
        ",\"entry_fingerprint\":" + jiebiao::json_string(status.entry_fingerprint) +
        ",\"entry_semantics\":" + std::to_string(status.entry_semantics) +
        ",\"symbol_validations\":" + std::to_string(status.symbol_validations) +
        ",\"device_fingerprint\":" + jiebiao::json_string(status.device_fingerprint) +
        ",\"original_fingerprint\":" + jiebiao::json_string(status.device_fingerprint) +
        ",\"virtual_fingerprint\":" + [&] {
            char hex[17];
            std::snprintf(hex, sizeof(hex), "%016" PRIx64, c.profile_fingerprint);
            return jiebiao::json_string(hex);
        }() +
        ",\"virtualized\":" +
            ((status.state == WorkerState::kRunning &&
              c.replacement_mode == static_cast<uint32_t>(drmid::ReplacementMode::kWriteTest) &&
              c.profile_fingerprint != 0)
                 ? "true" : "false") +
        ",\"generation\":" + std::to_string(c.config_generation) +
        ",\"mode\":" + std::to_string(c.replacement_mode) +
        ",\"virtual_id_length\":" + std::to_string(c.virtual_id_length) +
        ",\"server_request_hits\":" + std::to_string(c.server_request_hits) +
        ",\"replacement_candidates\":" + std::to_string(c.replacement_candidates) +
        ",\"write_ok\":" + std::to_string(c.replacement_write_ok) +
        ",\"rejections\":" + std::to_string(c.rejections) +
        ",\"hal_count\":" + std::to_string(c.hal_count) + "}";
    return json;
}

Status read_status(const std::string& private_dir) {
    Status status;
    uint32_t raw = static_cast<uint32_t>(WorkerState::kStopped);
    read_u32(private_dir, kWorkerStateName, raw);
    status.state = static_cast<WorkerState>(raw);
    int32_t pid = 0; read_i32(private_dir, kWorkerPidName, pid); status.pid = pid;
    uint32_t result = 0; read_u32(private_dir, kWorkerResultName, result); status.last_result = static_cast<int32_t>(result);
    status.control_connected = worker_alive(private_dir);
    const std::string control_path = drmid::default_control_socket_path(private_dir.c_str());
    if (!control_path.empty()) {
        status.control_connected = is_ok(drmid::send_control_ipc_request(
            control_path.c_str(), drmid::ControlIpcOperation::kStatus, status.control));
    }
    if (!status.control_connected) {
        drmid::ReplacementConfig persisted{};
        std::string runtime_detail;
        if (read_runtime(private_dir, persisted, runtime_detail)) {
            status.control.config_generation = persisted.config_generation;
            status.control.seed_generation = persisted.seed_generation;
            status.control.profile_fingerprint = persisted.profile_fingerprint;
            status.control.replacement_mode = static_cast<uint32_t>(persisted.mode);
            status.control.virtual_id_length = persisted.virtual_id_length;
        }
    }
    const bool alive = worker_alive(private_dir, &status.pid);
    if (status.control_connected) {
        status.state = WorkerState::kRunning;
        write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(WorkerState::kRunning));
        // The supervisor leaves this marker set while the Binder worker is
        // negotiating the post-boot stability gate. Clear it only after the
        // control socket is actually ready, so WebUI never mistakes an
        // initial transport delay for a completed backend.
        write_u32(private_dir, kWorkerBootName, 0);
    } else if (alive && status.state != WorkerState::kWaitingHal) {
        status.state = WorkerState::kStarting;
    } else if (!alive && status.state != WorkerState::kFailed &&
               status.state != WorkerState::kDisabled) {
        status.state = WorkerState::kStopped;
    }
    uint32_t boot_waiting = 0;
    read_u32(private_dir, kWorkerBootName, boot_waiting);
    if (!status.control_connected && boot_waiting != 0 &&
        status.state != WorkerState::kFailed &&
        status.state != WorkerState::kDisabled && status.state != WorkerState::kWaitingHal) {
        status.state = WorkerState::kStarting;
    }
    status.startup_waiting = !status.control_connected &&
                             status.state == WorkerState::kStarting &&
                             (alive || boot_waiting != 0);
    std::string capability_path = drmid::default_binder_capability_path(private_dir.c_str());
    drmid::BinderCapabilityStatus binder;
    if (is_ok(drmid::read_binder_capability_status(capability_path.c_str(), binder))) {
        status.kernel_release = binder.kernel_release;
        status.binder_backend = drmid::binder_backend_name(binder.backend);
        status.file_offset_source = drmid::binder_offset_source_name(binder.file_f_op_source);
        status.ioctl_offset_source = drmid::binder_offset_source_name(binder.fops_unlocked_ioctl_source);
        const bool symbol_scan =
            binder.file_f_op_source == drmid::BinderOffsetSource::kSymbolScan ||
            binder.fops_unlocked_ioctl_source == drmid::BinderOffsetSource::kSymbolScan;
        status.resolution_source = symbol_scan ? "fd+sdk+symbol-scan" : "fd+sdk+symbol-check";
        char hex[17]; std::snprintf(hex, sizeof(hex), "%016" PRIx64, binder.capabilities); status.capabilities = hex;
        std::snprintf(hex, sizeof(hex), "%016" PRIx64, binder.entry_fingerprint); status.entry_fingerprint = hex;
        status.entry_semantics = binder.entry_semantics;
        status.symbol_validations = binder.symbol_validations;
    }
    uint64_t fp = 0;
    if (is_ok(drmid::read_original_id_fingerprint(private_dir.c_str(), fp))) {
        char hex[17]; std::snprintf(hex, sizeof(hex), "%016" PRIx64, fp); status.device_fingerprint = hex;
    }
    return status;
}

int worker_main(const char* module_private_dir) {
    const std::string private_dir = module_private_dir ? module_private_dir : "";
    if (private_dir.empty()) return 2;
    // Redirect stdout/stderr to a debug log file for diagnosis
    {
        std::string log_path = private_dir;
        if (!log_path.empty() && log_path.back() != '/') log_path.push_back('/');
        log_path += "drm_worker_debug.log";
        int fd = open(log_path.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0644);
        if (fd >= 0) {
            dup2(fd, STDOUT_FILENO);
            dup2(fd, STDERR_FILENO);
            close(fd);
            setvbuf(stdout, nullptr, _IOLBF, 0);
        }
    }
    printf("=== worker_main started pid=%d ===\n", getpid());
    uint32_t state = static_cast<uint32_t>(WorkerState::kStarting); write_u32(private_dir, kWorkerStateName, state);
    write_u32(private_dir, kWorkerBootName, 0);
    drmid::DaemonLockHandle daemon_lock;
    if (!drmid::acquire_daemon_lock(private_dir.c_str(), daemon_lock)) {
        return 0;
    }
    drmid::cleanup_seed_temp_orphans(private_dir.c_str());
    if (!drmid::write_daemon_lock_pid(daemon_lock, getpid())) {
        drmid::release_daemon_lock(daemon_lock);
        write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(WorkerState::kFailed));
        return static_cast<int>(to_num(KModErr::ERR_MODULE_STORAGE_WRITE));
    }
    std::string root_key;
    if (const char* fd_text = std::getenv("DEVICE_IDENTITY_ROOT_FD")) {
        char* end = nullptr;
        const long raw_fd = std::strtol(fd_text, &end, 10);
        if (end && *end == '\0' && raw_fd >= 0 && raw_fd < 1024) {
            const int fd = static_cast<int>(raw_fd);
            std::array<char, 256> chunk{};
            while (root_key.size() < 4096) {
                const ssize_t count = read(fd, chunk.data(), chunk.size());
                if (count > 0) {
                    root_key.append(chunk.data(), static_cast<size_t>(count));
                    continue;
                }
                if (count < 0 && errno == EINTR) continue;
                break;
            }
            close(fd);
            unsetenv("DEVICE_IDENTITY_ROOT_FD");
        }
    }
    KModErr err = KModErr::OK;
    if (!root_key.empty()) {
        err = skroot_env::get_root(root_key.c_str());
        if (is_failed(err)) {
            write_u32(private_dir, kWorkerResultName, static_cast<uint32_t>(to_num(err)));
            write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(WorkerState::kFailed));
            std::fill(root_key.begin(), root_key.end(), '\0');
            drmid::release_daemon_lock(daemon_lock);
            return static_cast<int>(to_num(err));
        }
    }
    err = run_backend(root_key.empty() ? nullptr : root_key.c_str(), private_dir.c_str());
    std::fill(root_key.begin(), root_key.end(), '\0');
    write_u32(private_dir, kWorkerResultName, static_cast<uint32_t>(to_num(err)));
    write_i32(private_dir, kWorkerPidName, 0);
    write_u32(private_dir, kWorkerStateName, static_cast<uint32_t>(is_ok(err) ? WorkerState::kStopped : WorkerState::kFailed));
    write_u32(private_dir, kWorkerBootName, 0);
    drmid::release_daemon_lock(daemon_lock);
    return static_cast<int>(to_num(err));
}

}  // namespace device_identity::drm
