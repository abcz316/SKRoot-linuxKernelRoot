#!/usr/bin/env python3
"""Build a deterministic, run-once SKRoot Pro module archive."""

from __future__ import annotations

import hashlib
from pathlib import Path, PurePosixPath
import re
import zipfile


ROOT = Path(__file__).resolve().parent
SO = ROOT / "libs" / "arm64-v8a" / "libmodule_device_identity_manager.so"
WORKER = ROOT / "libs" / "arm64-v8a" / "device_identity_drm_worker"
RESOURCES = ROOT / "resources"
WEBROOT = ROOT / "webroot"
DIST = ROOT / "dist"
VERSION = "1.0.5"
SDK_VERSION = "4.6.1"
DISPLAY_NAME = "设备标识管理"
AUTHOR = "斓梦语、蜃、榆爱"
MODULE_ID = "deviceIdentityManagerSKP20260904"
PACKAGE_BASENAME = "设备标识管理"
ZIP = DIST / f"{PACKAGE_BASENAME}-{VERSION}-arm64-run-once.zip"
SDK_STATIC = (
    ROOT
    / ".sdk-cache"
    / "kernel_module_kit"
    / "lib"
    / "libkernel_module_kit_static.a"
)
EXPECTED_SDK_SHA256 = "5b304a9d7e1c2d5d8aa2e7d2a95710d37b1f261e1a92ffe640737d747ed93f91"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def production_sources() -> str:
    return "\n".join(
        path.read_text(encoding="utf-8")
        for suffix in ("*.cpp", "*.h")
        for path in sorted(ROOT.glob(suffix))
    )


def verify_module_metadata() -> None:
    source = (ROOT / "module_main.cpp").read_text(encoding="utf-8")
    expected = (
        f'SKROOT_MODULE_NAME("{DISPLAY_NAME}")',
        f'SKROOT_MODULE_VERSION("{VERSION}")',
        f'SKROOT_MODULE_AUTHOR("{AUTHOR}")',
        f'SKROOT_MODULE_ID32("{MODULE_ID}")',
    )
    missing = [marker for marker in expected if marker not in source]
    if missing:
        raise SystemExit("module metadata mismatch: " + ", ".join(missing))
    if len(MODULE_ID.encode("ascii")) != 32:
        raise SystemExit("SKP module ID must be exactly 32 ASCII bytes")


def verify_sdk_baseline() -> None:
    if not SDK_STATIC.is_file():
        raise SystemExit(f"SKP SDK static library missing: {SDK_STATIC}")
    actual = sha256_file(SDK_STATIC)
    if actual != EXPECTED_SDK_SHA256:
        raise SystemExit(
            f"SKP SDK baseline mismatch: expected={EXPECTED_SDK_SHA256} actual={actual}"
        )


def verify_resources() -> None:
    resetprop = RESOURCES / "resetprop"
    if not resetprop.is_file():
        raise SystemExit("resetprop resource is missing")
    helper = RESOURCES / "oaid-runtime.jar"
    stamp = RESOURCES / "oaid-runtime.source.sha256"
    if not helper.is_file() or not stamp.is_file() or stamp.read_text().strip() != sha256_file(ROOT / "java/OplusOaidRuntime.java"):
        raise SystemExit("OAID runtime helper missing or stale; run python3 build_oaid_helper.py")
    with zipfile.ZipFile(helper) as archive:
        if archive.testzip() is not None or archive.namelist() != ["classes.dex"]:
            raise SystemExit("Invalid OAID runtime helper")


def verify_production_scope() -> None:
    source = production_sources().lower()
    forbidden_markers = (
        "tricky_store",
        "persistent_keys",
        "com.helper.bootinfo",
        "binder_ctl",
        "libbinder_aux.so",
        "/data/adb/modules/ksu32402_model_switcher",
        "kernelsu.js",
        "adb_enabled",
        "development_settings_enabled",
        "kminstallkeybox",
        "/data/vendor/tzstorage",
        "/data/mediadrm",
        "/data/vendor/mediadrm",
        "/data/system/usagestats",
        "wificonfigstore.xml",
        "setenforce",
    )
    present = [marker for marker in forbidden_markers if marker in source]
    if present:
        raise SystemExit("excluded production marker present: " + ", ".join(present))

    web_source = (ROOT / "web_ui.cpp").read_text(encoding="utf-8")
    routes = set(re.findall(r'path == "(/api/[a-z/-]+)"', web_source))
    expected_routes = {
        "/api/session",
        "/api/session/ping",
        "/api/session/close",
        "/api/status",
        "/api/config",
        "/api/randomize",
        "/api/reset-ssaid",
        "/api/local-reset",
        "/api/drm-stop",
        "/api/action-result",
        "/api/log",
    }
    if routes != expected_routes:
        raise SystemExit(
            f"WebUI route drift: missing={sorted(expected_routes-routes)} extra={sorted(routes-expected_routes)}"
        )


def verify_built_payload() -> None:
    if not SO.is_file():
        raise SystemExit(f"native build output missing: {SO}")
    data = SO.read_bytes()
    required = (MODULE_ID.encode("ascii"), VERSION.encode("ascii"))
    missing = [marker.decode("ascii") for marker in required if marker not in data]
    if missing:
        raise SystemExit("native payload metadata missing: " + ", ".join(missing))
    forbidden = (
        b"tricky_store",
        b"persistent_keys",
        b"com.helper.bootinfo",
        b"binder_ctl",
        b"libbinder_aux.so",
        b"kernelsu.js",
        b"/data/adb/modules/ksu32402_model_switcher",
        b"kminstallkeybox",
        b"/data/vendor/tzstorage",
        b"/data/mediadrm",
        b"/data/vendor/mediadrm",
        b"/data/system/usagestats",
        b"wificonfigstore.xml",
        b"setenforce",
        b"adb_enabled",
        b"development_settings_enabled",
    )
    present = [marker.decode("ascii") for marker in forbidden if marker in data.lower()]
    if present:
        raise SystemExit("excluded native payload marker present: " + ", ".join(present))
    if not WORKER.is_file():
        raise SystemExit(f"DRM worker build output missing: {WORKER}")
    worker_data = WORKER.read_bytes()
    for marker in (b"hal-outbound-binder-global", b"drmid_control_v5.sock"):
        if marker not in worker_data:
            raise SystemExit(f"DRM worker marker missing: {marker.decode('ascii')}")
    for marker in (b"si_object_do_invoke", b"free_si_object", b"widevine.mbn"):
        if marker in worker_data:
            raise SystemExit(f"retired TEE marker in DRM worker: {marker.decode('ascii')}")


def archive_inputs() -> list[tuple[Path, str, int]]:
    items: list[tuple[Path, str, int]] = [
        (SO, SO.name, 0o100644),
        (WORKER, "webroot/device_identity_drm_worker", 0o100755),
    ]
    items.append((RESOURCES / "resetprop", "resources/resetprop", 0o100755))
    items.append((RESOURCES / "oaid-runtime.jar", "resources/oaid-runtime.jar", 0o100600))
    for asset in sorted(path for path in WEBROOT.rglob("*") if path.is_file()):
        relative = asset.relative_to(ROOT).as_posix()
        if relative == "webroot/device_identity_drm_worker":
            continue
        items.append((asset, relative, 0o100644))
    return items


def validate_member_name(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name or name.startswith("data/"):
        raise SystemExit(f"unsafe archive member: {name}")


def write_member(archive: zipfile.ZipFile, source: Path, name: str, mode: int) -> None:
    validate_member_name(name)
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = mode << 16
    archive.writestr(info, source.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_archive(expected: set[str]) -> None:
    with zipfile.ZipFile(ZIP, "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise SystemExit("duplicate module ZIP member")
        actual = set(names)
        if actual != expected:
            raise SystemExit(
                f"unexpected module ZIP members: missing={sorted(expected-actual)} extra={sorted(actual-expected)}"
            )
        for info in archive.infolist():
            validate_member_name(info.filename)
            if info.file_size > 8 * 1024 * 1024:
                raise SystemExit(f"oversized module ZIP member: {info.filename}")


def main() -> int:
    verify_module_metadata()
    verify_sdk_baseline()
    verify_resources()
    verify_production_scope()
    verify_built_payload()

    items = archive_inputs()
    expected = {name for _, name, _ in items}
    DIST.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP, "w") as archive:
        for source, name, mode in items:
            write_member(archive, source, name, mode)
    verify_archive(expected)

    manifest = "".join(
        f"{sha256_file(package)}  {package.name}\n"
        for package in sorted(DIST.glob("*.zip"))
    )
    (DIST / "SHA256SUMS").write_text(manifest, encoding="utf-8")
    print(ZIP)
    print(sha256_file(ZIP))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
