#include "oaid_engine.h"

#include "common.h"

#include <algorithm>
#include <cctype>
#include <map>
#include <set>
#include <unistd.h>

namespace jiebiao {
namespace {

constexpr size_t kMaxOplusOaidUsers = 64;

bool is_hex(std::string_view value, size_t length) {
    return value.size() == length &&
           std::all_of(value.begin(), value.end(), [](unsigned char ch) {
               return std::isxdigit(ch);
           });
}

bool numeric_user(std::string_view value) {
    return !value.empty() && value.size() <= 5 &&
           std::all_of(value.begin(), value.end(), [](unsigned char ch) {
               return std::isdigit(ch);
           });
}

size_t tag_end(const std::string& xml, size_t start) {
    char quote = '\0';
    for (size_t index = start; index < xml.size() && index - start <= 8192; ++index) {
        const char ch = xml[index];
        if (quote) {
            if (ch == quote) quote = '\0';
        } else if (ch == '\'' || ch == '"') {
            quote = ch;
        } else if (ch == '>') {
            return index;
        }
    }
    return std::string::npos;
}

bool attribute_range(const std::string& tag,
                     std::string_view name,
                     size_t& value_start,
                     size_t& value_length) {
    size_t cursor = 0;
    while ((cursor = tag.find(name, cursor)) != std::string::npos) {
        const bool left_ok = cursor == 0 || tag[cursor - 1] == '<' ||
                             std::isspace(static_cast<unsigned char>(tag[cursor - 1]));
        size_t equals = cursor + name.size();
        while (equals < tag.size() &&
               std::isspace(static_cast<unsigned char>(tag[equals]))) ++equals;
        if (!left_ok || equals >= tag.size() || tag[equals] != '=') {
            cursor += name.size();
            continue;
        }
        ++equals;
        while (equals < tag.size() &&
               std::isspace(static_cast<unsigned char>(tag[equals]))) ++equals;
        if (equals >= tag.size() || (tag[equals] != '\'' && tag[equals] != '"')) return false;
        const char quote = tag[equals++];
        const size_t end = tag.find(quote, equals);
        if (end == std::string::npos) return false;
        value_start = equals;
        value_length = end - equals;
        return true;
    }
    return false;
}

std::string attribute_value(const std::string& tag, std::string_view name) {
    size_t start = 0;
    size_t length = 0;
    return attribute_range(tag, name, start, length)
        ? tag.substr(start, length) : std::string();
}

bool replace_attribute(std::string& tag, std::string_view name, const std::string& value) {
    size_t start = 0;
    size_t length = 0;
    if (!attribute_range(tag, name, start, length)) return false;
    tag.replace(start, length, value);
    return true;
}

bool ouid_tag_boundary(const std::string& xml, size_t start) {
    const size_t next = start + 5;
    return next < xml.size() &&
           (std::isspace(static_cast<unsigned char>(xml[next])) ||
            xml[next] == '>' || xml[next] == '/');
}

bool parse_payload(const std::string& payload,
                   std::map<std::string, std::string>& values) {
    values.clear();
    if (payload.empty() || payload.find_first_of("\t\r\n") != std::string::npos) return false;
    size_t cursor = 0;
    while (cursor < payload.size()) {
        const size_t end = payload.find(';', cursor);
        const std::string item = payload.substr(cursor,
            (end == std::string::npos ? payload.size() : end) - cursor);
        const size_t equals = item.find('=');
        if (equals == std::string::npos || item.find('=', equals + 1) != std::string::npos) return false;
        const std::string user = item.substr(0, equals);
        const std::string value = item.substr(equals + 1);
        if (!numeric_user(user) || !is_hex(value, 64) || values.contains(user) ||
            values.size() >= kMaxOplusOaidUsers) return false;
        values[user] = value;
        if (end == std::string::npos) break;
        cursor = end + 1;
        if (cursor == payload.size()) return false;
    }
    return !values.empty();
}

}  // namespace

bool inspect_oplus_openid_xml(const std::string& xml,
                              std::vector<OplusOaidValue>& values,
                              std::string& detail) {
    values.clear();
    if (xml.empty() || xml.find('\0') != std::string::npos) {
        detail = "invalid-text";
        return false;
    }
    const size_t root = xml.find("<openid_config");
    if (root == std::string::npos || xml.find("</openid_config>", root) == std::string::npos) {
        detail = "root-not-found";
        return false;
    }
    const size_t root_end = tag_end(xml, root);
    if (root_end == std::string::npos) {
        detail = "malformed-root";
        return false;
    }
    const std::string root_tag = xml.substr(root, root_end - root + 1);
    if (attribute_value(root_tag, "version") != "1") {
        detail = "unsupported-version";
        return false;
    }

    std::set<std::string> users;
    size_t cursor = root_end + 1;
    while ((cursor = xml.find("<ouid", cursor)) != std::string::npos) {
        if (!ouid_tag_boundary(xml, cursor)) {
            cursor += 5;
            continue;
        }
        const size_t end = tag_end(xml, cursor);
        if (end == std::string::npos) {
            detail = "malformed-ouid";
            return false;
        }
        const std::string tag = xml.substr(cursor, end - cursor + 1);
        const std::string user = attribute_value(tag, "name");
        const std::string value = attribute_value(tag, "value");
        if (!numeric_user(user) || !is_hex(value, 64)) {
            detail = "invalid-ouid-entry";
            return false;
        }
        if (!users.insert(user).second || values.size() >= kMaxOplusOaidUsers) {
            detail = "duplicate-or-too-many-users";
            return false;
        }
        values.push_back({user, value});
        cursor = end + 1;
    }
    if (values.empty()) {
        detail = "ouid-not-found";
        return false;
    }
    detail = "format-v1,users=" + std::to_string(values.size());
    return true;
}

bool build_oplus_oaid_payload(const std::string& xml,
                              std::string& payload,
                              std::string& detail) {
    std::vector<OplusOaidValue> current;
    if (!inspect_oplus_openid_xml(xml, current, detail)) return false;
    payload.clear();
    for (const auto& item : current) {
        if (!payload.empty()) payload.push_back(';');
        payload += item.user + '=' + random_hex(64, true);
    }
    std::string validation = xml;
    size_t changed = 0;
    return rewrite_oplus_openid_xml(validation, payload, changed, detail) &&
           changed == current.size();
}

bool rewrite_oplus_openid_xml(std::string& xml,
                              const std::string& payload,
                              size_t& changed,
                              std::string& detail) {
    changed = 0;
    std::vector<OplusOaidValue> current;
    if (!inspect_oplus_openid_xml(xml, current, detail)) return false;
    std::map<std::string, std::string> replacements;
    if (!parse_payload(payload, replacements) || replacements.size() != current.size()) {
        detail = "invalid-payload";
        return false;
    }
    for (const auto& item : current) {
        if (!replacements.contains(item.user)) {
            detail = "payload-user-mismatch";
            return false;
        }
    }

    size_t cursor = 0;
    while ((cursor = xml.find("<ouid", cursor)) != std::string::npos) {
        if (!ouid_tag_boundary(xml, cursor)) {
            cursor += 5;
            continue;
        }
        const size_t end = tag_end(xml, cursor);
        if (end == std::string::npos) {
            detail = "malformed-ouid";
            return false;
        }
        std::string tag = xml.substr(cursor, end - cursor + 1);
        const std::string user = attribute_value(tag, "name");
        const auto replacement = replacements.find(user);
        if (replacement == replacements.end() ||
            !replace_attribute(tag, "value", replacement->second)) {
            detail = "replace-failed";
            return false;
        }
        xml.replace(cursor, end - cursor + 1, tag);
        ++changed;
        cursor += tag.size();
    }

    std::vector<OplusOaidValue> verified;
    if (!inspect_oplus_openid_xml(xml, verified, detail) || verified.size() != replacements.size()) {
        detail = "roundtrip-failed";
        return false;
    }
    for (const auto& item : verified) {
        if (!replacements.contains(item.user) || replacements.at(item.user) != item.value) {
            detail = "roundtrip-mismatch";
            return false;
        }
    }
    detail = "ok,users=" + std::to_string(changed);
    return changed != 0;
}

bool oplus_oaid_payload_value(const std::string& payload,
                             const std::string& user,
                             std::string& value) {
    std::map<std::string, std::string> values;
    if (!parse_payload(payload, values)) return false;
    const auto item = values.find(user);
    if (item == values.end()) return false;
    value = item->second;
    return true;
}

bool parse_oplus_oaid_provider_output(const std::string& output,
                                      std::string& value,
                                      std::string& detail) {
    value.clear();
    const size_t marker = output.find("OUID=");
    if (marker == std::string::npos) {
        detail = "provider-value-missing";
        return false;
    }
    const size_t start = marker + 5;
    size_t end = start;
    while (end < output.size() && std::isxdigit(static_cast<unsigned char>(output[end]))) ++end;
    value = output.substr(start, end - start);
    if (!is_hex(value, 64)) {
        value.clear();
        detail = "provider-value-invalid";
        return false;
    }
    detail = "provider-read";
    return true;
}

bool read_oplus_oaid_provider(std::string& value, std::string& detail) {
    return read_oplus_oaid_provider_for_user(0, value, detail);
}

bool read_oplus_oaid_provider_for_user(uint32_t user_id,
                                       std::string& value,
                                       std::string& detail) {
    value.clear();
    std::string output;
    // OPLUS returns an empty OUID to uid 0 even in the shell SELinux domain.
    // Keep the transaction privileged, but make this read-only Binder query as
    // Android's shell uid/gid so it observes the same value as adb/content.
    if (run_process_as(2000, 2000,
                       {"/system/bin/content", "call", "--user", std::to_string(user_id), "--uri",
                        "content://com.oplus.omes.oaid_status_provider",
                        "--method", "OUID"}, &output, 64 * 1024) != 0) {
        detail = "provider-call-failed";
        return false;
    }
    return parse_oplus_oaid_provider_output(output, value, detail);
}

namespace {
bool run_oaid_bridge(const std::string& private_dir, const char* action,
                     std::string& output, std::string& detail) {
    const std::string jar = private_dir + "/resources/oaid-runtime.jar";
    if (access(jar.c_str(), R_OK) != 0) {
        detail = "runtime-helper-missing";
        return false;
    }
    const int status = run_process({"/system/bin/env", "CLASSPATH=" + jar,
        "/system/bin/app_process", "/system/bin", "OplusOaidRuntime", action}, &output, 16384);
    if (status != 0) {
        // run_process 把 stdout 和 stderr 合并进 output。OPPO 桥真正的失败原因
        // （OAID_ERROR=ClassNotFound / NoSuchMethod / oui-unchanged / timeout）打在
        // stderr，这里必须把它一并带出来，否则 WebUI/daemon.log 只看到退出码、
        // 定位不到是哪台 OPPO 新系统把私有 OUID 接口改了。
        detail = "runtime-helper-failed-exit=" + std::to_string(status);
        if (!output.empty()) {
            std::string tail = output;
            const auto pos = tail.find("OAID_ERROR=");
            if (pos != std::string::npos) {
                tail = tail.substr(pos);
            }
            for (char& ch : tail) {
                if (ch == '\n' || ch == '\r') ch = ';';
            }
            while (!tail.empty() && tail.back() == ';') tail.pop_back();
            if (tail.size() > 160) tail.resize(160);
            detail += ":" + tail;
        }
        return false;
    }
    return true;
}
}

bool probe_oplus_oaid_runtime(const std::string& private_dir, std::string& detail) {
    std::string output;
    if (!run_oaid_bridge(private_dir, "probe", output, detail)) return false;
    const auto lines = split_lines(output);
    if (std::find(lines.begin(), lines.end(), "OAID_RUNTIME=ready") == lines.end()) {
        detail = "runtime-helper-protocol-invalid";
        return false;
    }
    detail = "runtime-ready-user=0";
    return true;
}

bool rotate_oplus_oaid_runtime(const std::string& private_dir,
                               std::string& target, std::string& detail) {
    target.clear();
    std::string before;
    if (!read_oplus_oaid_provider(before, detail)) return false;

    // 从 openid_config.xml 读取所有用户列表（含双开/分身用户）
    std::vector<uint32_t> all_users;
    {
        std::string xml;
        std::vector<OplusOaidValue> entries;
        if (read_file("/data/system/openid_config.xml", xml, 1024 * 1024)) {
            std::string d;
            if (inspect_oplus_openid_xml(xml, entries, d)) {
                for (const auto& e : entries) {
                    all_users.push_back(static_cast<uint32_t>(std::stoul(e.user)));
                }
            }
        }
    }
    // 记录所有用户重置前的值
    std::map<uint32_t, std::string> before_all;
    before_all[0] = before;
    for (uint32_t uid : all_users) {
        if (uid == 0) continue;
        std::string v, d;
        if (read_oplus_oaid_provider_for_user(uid, v, d)) before_all[uid] = v;
    }

    std::string output;
    if (!run_oaid_bridge(private_dir, "rotate", output, detail)) return false;
    if (!parse_oplus_oaid_provider_output(output, target, detail) || target == before) {
        detail = "runtime-target-invalid-or-unchanged";
        return false;
    }
    // An OEM call returning successfully is not proof that consumers see it.
    // 验证主用户
    bool primary_verified = false;
    for (unsigned attempt = 0; attempt < 8; ++attempt) {
        std::string actual;
        if (read_oplus_oaid_provider(actual, detail) && actual == target) {
            primary_verified = true;
            break;
        }
        if (attempt != 7) usleep(250000);
    }
    if (!primary_verified) {
        detail = "runtime-provider-mismatch-user0";
        return false;
    }
    // 验证其他用户（双开/分身）也变了
    size_t multi_ok = 0;
    for (uint32_t uid : all_users) {
        if (uid == 0) continue;
        const auto it = before_all.find(uid);
        if (it == before_all.end()) continue;
        std::string actual, d;
        if (read_oplus_oaid_provider_for_user(uid, actual, d) &&
            !actual.empty() && actual != it->second) {
            ++multi_ok;
        }
    }
    detail = "runtime-verified-user0";
    if (!all_users.empty()) {
        detail += ",multi-users-changed=" + std::to_string(multi_ok) + "/" +
                  std::to_string(all_users.size() - 1);
    }
    return true;
}

}  // namespace jiebiao
