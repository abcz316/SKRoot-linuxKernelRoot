#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace jiebiao {

struct OplusOaidValue {
    std::string user;
    std::string value;
};

bool inspect_oplus_openid_xml(const std::string& xml,
                              std::vector<OplusOaidValue>& values,
                              std::string& detail);
bool build_oplus_oaid_payload(const std::string& xml,
                              std::string& payload,
                              std::string& detail);
bool rewrite_oplus_openid_xml(std::string& xml,
                              const std::string& payload,
                              size_t& changed,
                              std::string& detail);
bool oplus_oaid_payload_value(const std::string& payload,
                             const std::string& user,
                             std::string& value);
bool parse_oplus_oaid_provider_output(const std::string& output,
                                      std::string& value,
                                      std::string& detail);
bool read_oplus_oaid_provider(std::string& value, std::string& detail);
bool read_oplus_oaid_provider_for_user(uint32_t user_id,
                                       std::string& value,
                                       std::string& detail);
bool probe_oplus_oaid_runtime(const std::string& private_dir, std::string& detail);
bool rotate_oplus_oaid_runtime(const std::string& private_dir,
                               std::string& target, std::string& detail);

}  // namespace jiebiao
