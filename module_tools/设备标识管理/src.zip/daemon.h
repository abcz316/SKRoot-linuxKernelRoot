#pragma once

#include "state_store.h"

#include <string>

namespace jiebiao {

std::string apply_early_config(const std::string& private_dir,
                               const ModuleConfig& config,
                               bool install_kernel_serial_hook);

bool start_background_daemon(const char* root_key, const std::string& private_dir);
bool background_daemon_alive(const std::string& private_dir);
void stop_background_daemon();

}  // namespace jiebiao
