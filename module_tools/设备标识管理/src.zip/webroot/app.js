"use strict";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const PREVIEW_MODE = window.location.protocol === "file:";

const previewState = {
  ok: true,
  config: { schema: 5, master_enabled: true },
  device: {
    brand: "HONOR",
    model: "Android 16 测试设备",
    device: "arm64-device",
    serial: "A1B2C3D4E5F60708",
    fingerprint: "vendor/device/product:16/BUILD/preview:user/release-keys",
  },
  daemon: { alive: true, pid: 2468 },
  drm: {
    state: "running", pid: 2471, result: 0, connected: true,
    startup_waiting: false,
    kernel_release: "6.12.38-android16-preview", binder_backend: "classic",
    resolution_source: "fd+sdk+symbol-check", capabilities: "00000000000003ff",
    file_offset_source: "sdk", ioctl_offset_source: "symbol-scan",
    entry_semantics: 3, symbol_validations: 2,
    entry_fingerprint: "91e83cb1f610da20", original_fingerprint: "2ca86f5bf1d91347",
    device_fingerprint: "2ca86f5bf1d91347", virtual_fingerprint: "9e54b289dd0e72c1",
    virtualized: true, generation: 3, mode: 1, virtual_id_length: 32,
    server_request_hits: 184, replacement_candidates: 180, write_ok: 180,
    rejections: 4, hal_count: 1,
  },
  legacy_conflict: { detected: false, id: "", version: "" },
  identity_comparison: {
    serial: { original: "PREVIEW-ORIGINAL", current: "A1B2C3D4E5F60708", state: "applied" },
    soc_serial: { original: "0x10000001", current: "0x7f36a2c9", state: "applied" },
    androidid: { original: "19a03e2f61c20b74", current: "74be18d36a207fc1", state: "applied" },
    oaid: { original: "4c1eb57b-9f64-4560-a2bd-84e20a668a20", current: "a91673df-8045-4e22-97de-f392b11303df", state: "applied" },
    drmid: { original: "2ca86f5bf1d91347", current: "9e54b289dd0e72c1", state: "applied" },
  },
  identity_verification: {
    serial: { state: "passed" }, soc_serial: { state: "passed" },
    androidid: { state: "passed" }, oaid: { state: "passed" }, drmid: { state: "passed" },
  },
  users: [{ id: 0, label: "主用户 (0)", format: "abx", ready: true }],
  identity_surfaces: [
    { id: "module_identity", state: "ready", detail: "existing-properties-and-kernel-layer" },
    { id: "oplus_oaid", state: "ready", detail: "format-v1,provider-match" },
    { id: "appset", state: "ready", detail: "transactional-reset" },
    { id: "ssaid", state: "ready", detail: "ABX · multi-user" },
    { id: "oem_oaid", state: "unsupported", detail: "provider-detected-probe-only" },
    { id: "gsf_gms", state: "unsupported", detail: "provider-detected-probe-only" },
  ],
  global_reset: { state: "idle", detail: "", reboot_required: false },
  last_action: { sequence: 0, result: null },
};

function previewResponse(path, values) {
  if (path === "/api/session") return { ok: true, token: "local-preview", heartbeat_ms: 4000 };
  if (path === "/api/session/ping" || path === "/api/session/close") return { ok: true };
  if (path === "/api/status") return previewState;
  if (path === "/api/log") return { ok: true, log: "[preview] supervisor online\n[preview] DRM Binder worker running\n[preview] WebUI 本地预览模式" };
  if (path === "/api/action-result") {
    return { ok: true, sequence: previewState.last_action.sequence, result: previewState.last_action.result };
  }
  if (path === "/api/config") {
    previewState.config.master_enabled = values.master_enabled === "1";
    previewState.drm.state = "running";
    previewState.drm.connected = true;
    previewState.drm.mode = previewState.config.master_enabled ? 1 : 0;
    const previewCurrents = {
      serial: "A1B2C3D4E5F60708",
      soc_serial: "0x7f36a2c9",
      androidid: "74be18d36a207fc1",
      oaid: "a91673df-8045-4e22-97de-f392b11303df",
      drmid: "9e54b289dd0e72c1",
    };
    for (const [key, item] of Object.entries(previewState.identity_comparison)) {
      item.current = previewState.config.master_enabled ? previewCurrents[key] : "待应用";
      item.state = previewState.config.master_enabled ? "applied" : "pending";
    }
    for (const item of Object.values(previewState.identity_verification)) {
      item.state = previewState.config.master_enabled ? "passed" : "pending";
    }
    previewState.last_action = {
      sequence: previewState.last_action.sequence + 1,
      result: { ok: true, detail: "preview-policy-updated" },
    };
    return { ok: true, sequence: previewState.last_action.sequence };
  }
  if (path === "/api/drm-stop") {
    previewState.drm.state = "stopped";
    previewState.drm.connected = false;
    previewState.drm.mode = 0;
    previewState.identity_comparison.drm.state = "unknown";
    previewState.identity_verification.drm.state = "unsupported";
    previewState.last_action = {
      sequence: previewState.last_action.sequence + 1,
      result: { ok: true, detail: "preview-drm-stopped" },
    };
    return { ok: true, sequence: previewState.last_action.sequence };
  }
  previewState.last_action = {
    sequence: previewState.last_action.sequence + 1,
    result: { ok: true, detail: "preview" },
  };
  return { ok: true, sequence: previewState.last_action.sequence, message: "preview" };
}

let token = "";
let toastTimer = 0;
let transactionPollTimer = 0;
let currentStatus = null;
let heartbeatTimer = 0;
let blurCloseTimer = 0;
let mutationInFlight = false;
let statusRetryTimer = 0;
let statusRequestInFlight = null;
let sessionClosed = false;
let disconnectStarted = false;
let drawerOpen = false;
let drawerHistoryPushed = false;
let drawerLastFocus = null;
let logLoaded = false;
let confirmOpen = false;
let confirmLastFocus = null;
let confirmResolver = null;
let screenState = "connecting";

const screenStateCopy = {
  connecting: { status: "正在连接后台", title: "正在连接后台", message: "正在建立安全连接，请稍候…" },
  syncing: { status: "正在同步后台", title: "正在同步后台", message: "正在读取模块状态，请稍候…" },
  "waiting-stable": { status: "正在等待稳定切入", title: "模块暂未完全启用", message: "请等待系统稳定后重新进入（约1-2分钟）" },
  ready: { status: "后台已连接", title: "", message: "" },
  disconnected: { status: "后台已退出", title: "后台已退出", message: "请重新从管理器打开" },
};

function setText(selector, value, fallback = "—") {
  const element = $(selector);
  if (element) element.textContent = value === undefined || value === null || value === "" ? fallback : String(value);
}

function showToast(message, error = false) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", error);
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("show"), 3200);
}

async function post(path, values = {}, authenticated = true) {
  if (PREVIEW_MODE) return previewResponse(path, values);
  if (sessionClosed && path !== "/api/session") {
    throw new Error("后台已退出，请重新从管理器打开");
  }
  const form = new URLSearchParams();
  if (authenticated) form.set("token", token);
  for (const [key, value] of Object.entries(values)) form.set(key, value ?? "");
  const response = await fetch(path, {
    method: "POST",
    cache: "no-store",
    headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
    body: form.toString(),
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error(`服务返回了无效响应 (${response.status})`);
  }
  if (!response.ok || result.ok === false) {
    const error = new Error(result.message || result.error || `请求失败 (${response.status})`);
    error.httpStatus = response.status;
    error.sessionTerminal = response.status === 401 || result.error === "session" || result.error === "webui-exited";
    throw error;
  }
  return result;
}

function setScreenState(nextState) {
  const next = screenStateCopy[nextState] ? nextState : "syncing";
  screenState = next;
  document.body.dataset.screenState = next;
  const gate = $("#screenGate");
  const main = $(".app-shell");
  const topbar = $(".topbar");
  const copy = screenStateCopy[next];
  const title = next === "disconnected" ? "后台已退出" : copy.title;
  const message = next === "disconnected" ? "请重新从管理器打开" : copy.message;
  if (gate) {
    gate.setAttribute("aria-hidden", next === "ready" ? "true" : "false");
    setText("#screenGateStatus", copy.status);
    setText("#screenGateTitle", title);
    setText("#screenGateMessage", message);
  }
  // Keep the status pill semantically aligned with the full-screen gate even
  // while the main page is hidden. This also prevents stale "正在连接" text
  // from flashing when a boot-wait response arrives.
  if (next === "waiting-stable") {
    setText("#statusText", "正在等待稳定切入");
    $("#refreshStatus").dataset.state = "waiting";
  } else if (next === "connecting") {
    setText("#statusText", "正在连接");
    $("#refreshStatus").dataset.state = "loading";
  } else if (next === "syncing") {
    setText("#statusText", "正在同步后台");
    $("#refreshStatus").dataset.state = "loading";
  } else if (next === "disconnected") {
    setText("#statusText", "后台已退出");
    $("#refreshStatus").dataset.state = "bad";
  }
  const ready = next === "ready";
  document.body.classList.toggle("screen-ready", ready);
  [main, topbar].forEach((element) => {
    if (!element) return;
    element.setAttribute("aria-hidden", ready ? "false" : "true");
  });
  if (!ready) {
    $$('button, input, select, textarea').forEach((element) => { element.disabled = true; });
  }
}

function isTerminalSessionError(error) {
  return Boolean(error?.sessionTerminal || error?.httpStatus === 401);
}

function scheduleStatusRetry(delayMs = 1200) {
  if (statusRetryTimer || sessionClosed) return;
  statusRetryTimer = window.setTimeout(() => {
    statusRetryTimer = 0;
    loadStatus().catch(() => {});
  }, delayMs);
}

async function ensureSession() {
  if (token) return;
  const result = await post("/api/session", {}, false);
  token = result.token || "";
  if (!token) throw new Error("未取得 WebUI 会话");
  sessionClosed = false;
  startHeartbeat(result.heartbeat_ms || 4000);
}

function closeDrawerUi(restoreFocus = true) {
  const layer = $("#drawerLayer");
  const drawer = $("#advancedDrawer");
  layer.classList.remove("is-open");
  layer.setAttribute("aria-hidden", "true");
  drawer.setAttribute("aria-hidden", "true");
  document.body.classList.remove("drawer-open");
  drawerOpen = false;
  if (restoreFocus && drawerLastFocus && document.contains(drawerLastFocus)) drawerLastFocus.focus();
}

function selectDrawerTab(name, expandDrm = false) {
  const selected = ["device", "drm", "coverage", "logs"].includes(name) ? name : "device";
  $$("[data-drawer-tab]").forEach((tab) => {
    const active = tab.dataset.drawerTab === selected;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-selected", active ? "true" : "false");
  });
  $$("[data-drawer-panel]").forEach((panel) => {
    const active = panel.dataset.drawerPanel === selected;
    panel.classList.toggle("is-active", active);
    panel.hidden = !active;
  });
  if (selected === "drm" && expandDrm) $("#drmDiagnosticDetails").open = true;
  if (selected === "logs" && !logLoaded) {
    loadLog().catch((error) => showToast(error.message || "日志读取失败", true));
  }
}

function openDrawer(tab = "device", expandDrm = false) {
  if (sessionClosed) return;
  drawerLastFocus = document.activeElement;
  selectDrawerTab(tab, expandDrm);
  const layer = $("#drawerLayer");
  const drawer = $("#advancedDrawer");
  layer.classList.add("is-open");
  layer.setAttribute("aria-hidden", "false");
  drawer.setAttribute("aria-hidden", "false");
  document.body.classList.add("drawer-open");
  if (!drawerOpen) {
    drawerOpen = true;
    history.pushState({ ...(history.state || {}), deviceIdentityDrawer: true }, "", window.location.href);
    drawerHistoryPushed = true;
  }
  window.setTimeout(() => $("#closeAdvancedDrawer").focus(), 20);
}

function requestCloseDrawer() {
  if (!drawerOpen) return;
  if (drawerHistoryPushed) {
    history.back();
  } else {
    closeDrawerUi();
  }
}

function showDisconnectedPage() {
  sessionClosed = true;
  clearInterval(heartbeatTimer);
  heartbeatTimer = 0;
  clearTimeout(statusRetryTimer);
  statusRetryTimer = 0;
  closeDrawerUi(false);
  closeConfirm(false);
  setScreenState("disconnected");
}

function sendSessionClose() {
  if (PREVIEW_MODE || disconnectStarted) return;
  disconnectStarted = true;
  clearInterval(heartbeatTimer);
  heartbeatTimer = 0;
  sessionClosed = true;
  if (!token) return;
  const body = new URLSearchParams({ token }).toString();
  const blob = new Blob([body], { type: "application/x-www-form-urlencoded;charset=UTF-8" });
  if (navigator.sendBeacon) {
    navigator.sendBeacon("/api/session/close", blob);
  } else {
    fetch("/api/session/close", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
      body,
      keepalive: true,
    }).catch(() => {});
  }
}

function drmWaitingForStableCutIn(drm) {
  if (drm?.startup_waiting === true) return true;
  const state = String(drm?.state || "").trim().toLowerCase().replaceAll("_", "-");
  return ["waiting", "waiting-stable", "waiting-for-stable", "stabilizing"].includes(state);
}

function closeConfirm(restoreFocus = true, accepted = false) {
  const layer = $("#confirmLayer");
  const dialog = $("#confirmDialog");
  if (!layer || !dialog) return;
  layer.classList.remove("is-open");
  layer.setAttribute("aria-hidden", "true");
  dialog.setAttribute("aria-hidden", "true");
  document.body.classList.remove("confirm-open");
  confirmOpen = false;
  const resolver = confirmResolver;
  confirmResolver = null;
  if (resolver) resolver(accepted);
  if (restoreFocus && confirmLastFocus && document.contains(confirmLastFocus)) confirmLastFocus.focus();
}

function showConfirm({ title, message, confirmLabel = "确认继续", tone = "primary", kicker = "CONFIRM ACTION" }) {
  if (sessionClosed) return Promise.resolve(false);
  closeConfirm(false);
  confirmLastFocus = document.activeElement;
  const layer = $("#confirmLayer");
  const dialog = $("#confirmDialog");
  $("#confirmKicker").textContent = kicker;
  $("#confirmTitle").textContent = title;
  $("#confirmMessage").textContent = message;
  $("#confirmAccept").textContent = confirmLabel;
  dialog.dataset.tone = tone;
  layer.classList.add("is-open");
  layer.setAttribute("aria-hidden", "false");
  dialog.setAttribute("aria-hidden", "false");
  document.body.classList.add("confirm-open");
  confirmOpen = true;
  window.setTimeout(() => $("#confirmCancel").focus(), 20);
  return new Promise((resolve) => { confirmResolver = resolve; });
}

function startHeartbeat(intervalMs) {
  clearInterval(heartbeatTimer);
  heartbeatTimer = window.setInterval(async () => {
    if (sessionClosed || document.visibilityState !== "visible") return;
    try {
      await post("/api/session/ping");
    } catch (error) {
      if (isTerminalSessionError(error)) showDisconnectedPage();
      else {
        setScreenState("syncing");
        scheduleStatusRetry();
      }
    }
  }, Math.max(2500, Number(intervalMs) || 4000));
}

function closeWebUiSession() {
  // file:// is a local visual preview and does not own an exposed SKP listener.
  if (PREVIEW_MODE) return;
  if (disconnectStarted) return;
  showDisconnectedPage();
  sendSessionClose();
}

function handleWindowBlur() {
  clearTimeout(blurCloseTimer);
  blurCloseTimer = window.setTimeout(() => {
    if (document.visibilityState === "hidden") closeWebUiSession();
  }, 350);
}

function handleWindowFocus() {
  clearTimeout(blurCloseTimer);
  blurCloseTimer = 0;
}

function formatAction(lastAction) {
  if (!lastAction || !lastAction.sequence) return "暂无";
  const result = lastAction.result;
  if (!result) return `#${lastAction.sequence} 等待中`;
  return `#${lastAction.sequence} ${result.ok ? "完成" : "异常"}`;
}

function globalResetLabel(state) {
  return {
    idle: "尚未安排",
    prepared: "准备完成，等待重启",
    "early-applied": "重启后正在完成",
    applied: "完整重置已完成",
    "preflight-failed": "检查失败，未执行重置",
    "rolled-back": "操作异常，已恢复原值",
  }[state] || state || "尚未安排";
}

function drmDisplayState(drm) {
  // The home card is the current replacement policy, not a historical traffic
  // counter. A freshly enabled backend can legitimately have zero writes until
  // an app asks Widevine for deviceUniqueId, while diagnostics already report
  // the equal-length replacement mode as active.
  if (drm.connected && Number(drm.mode) === 1) return "已写入";
  return "未写入";
}

function verificationCount(data) {
  const verification = data.identity_verification || {};
  const keys = ["serial", "soc_serial", "androidid", "ufs_serial", "oaid", "drmid"];
  return `${keys.filter((key) => verification[key]?.state === "passed").length}/${keys.length}`;
}

function drmHasIssue(data) {
  const drm = data.drm || {};
  const state = String(drm.state || "").toLowerCase();
  const verification = data.identity_verification?.drmid?.state;
  return Boolean(data.legacy_conflict?.detected) || !drm.connected ||
    (state && state !== "running") || Number(drm.result || 0) !== 0 ||
    verification === "mismatch" || verification === "unsupported";
}

function drmNeedsStatusRetry(data) {
  if (PREVIEW_MODE || sessionClosed || !data.daemon?.alive || data.legacy_conflict?.detected) return false;
  const drm = data.drm || {};
  if (["stopped", "disabled", "failed"].includes(drm.state)) return false;
  if (drm.state === "waiting-hal") return true;
  if (drm.state === "starting" || drm.startup_waiting) return true;
  return drm.state === "running" && (!drm.connected ||
    (data.config?.master_enabled && data.identity_verification?.drmid?.state === "pending"));
}

function renderStatus(data) {
  currentStatus = data;
  const daemonAlive = Boolean(data.daemon?.alive);
  const config = data.config || {};
  const device = data.device || {};
  const drm = data.drm || {};
  const identityEnabled = Boolean(config.master_enabled);

  if (drmWaitingForStableCutIn(drm)) {
    setScreenState("waiting-stable");
    // Keep the same session alive while the daemon waits for the first stable
    // cut-in. A single guarded timer is used so repeated status responses do
    // not create a polling storm.
    scheduleStatusRetry(1500);
    return;
  }

  // The supervisor can report a ready page during the short interval between
  // worker fork and control-socket publication. Keep polling that transient
  // state so users do not need to press the global refresh button.
  if (drmNeedsStatusRetry(data)) {
    if (drm.state === "waiting-hal") scheduleStatusRetry(5000);
    else scheduleStatusRetry(1500);
  }

  $("#refreshStatus").dataset.state = daemonAlive ? "ok" : "bad";
  setText("#statusText", daemonAlive ? "模块运行中" : "后台未运行");
  setText("#metricDaemon", daemonAlive ? `运行中 · PID ${data.daemon.pid}` : "未连接");
  setText("#metricMark", identityEnabled ? "已开启" : "已关闭");
  setText("#metricDrm", drmDisplayState(drm));
  setText("#metricAction", verificationCount(data));
  setText("#overviewMasterHint", identityEnabled ? "核心标识修改正在生效" : "原值已恢复，目标值已保留");
  setText("#overviewDrmHint", drmDisplayState(drm) === "已写入" ? "已成功写入等长替换回复" : "当前没有写入替换回复");

  setText("#deviceModel", device.model, "未知机型");
  setText("#deviceSubline", [device.brand, device.device].filter(Boolean).join(" · "));
  setText("#deviceBrand", device.brand);
  setText("#deviceName", device.device);
  setText("#deviceSerial", device.serial);
  setText("#deviceFingerprint", device.fingerprint);

  $("#markEnabled").checked = identityEnabled;
  setText("#masterStateLabel", identityEnabled ? "当前已开启" : "当前已关闭");
  $("#masterStateLabel").dataset.state = identityEnabled ? "on" : "off";
  setText("#masterDescription", identityEnabled
    ? "核心标识正在应用；DRM 后端按需运行。"
    : "核心标识修改已暂停并恢复原值；DRM 后端已停止。");

  const conflict = data.legacy_conflict || {};
  let conflictBanner = $("#legacyConflictBanner");
  if (conflict.detected) {
    if (!conflictBanner) {
      conflictBanner = document.createElement("p");
      conflictBanner.id = "legacyConflictBanner";
      conflictBanner.className = "legacy-conflict";
      $(".app-shell").prepend(conflictBanner);
    }
    conflictBanner.textContent = `检测到旧模块 ${conflict.id || "—"}（${conflict.version || "未知版本"}），设备标识管理保持停用。`;
  } else if (conflictBanner) {
    conflictBanner.remove();
  }

  const comparison = data.identity_comparison || {};
  const stateLabels = {
    applied: "已生效",
    pending: "待应用",
    unchanged: "未修改",
    unknown: "未捕获",
    unsupported: "暂不支持",
    mismatch: "未达到预期",
  };
  $$('[data-identity-original]').forEach((element) => {
    const item = comparison[element.dataset.identityOriginal] || {};
    element.textContent = item.original || (item.state === "unsupported" ? (item.detail || "暂不支持") : "未捕获");
  });
  $$('[data-identity-current]').forEach((element) => {
    const item = comparison[element.dataset.identityCurrent] || {};
    element.textContent = item.current || (item.state === "pending" ? "待应用" :
      item.state === "mismatch" ? "未达到预期" :
      item.state === "unsupported" ? (item.detail || "暂不支持") : "未捕获");
  });
  $$('[data-identity-state]').forEach((element) => {
    const item = comparison[element.dataset.identityState] || {};
    const state = item.state || "unknown";
    element.textContent = stateLabels[state] || state;
    element.dataset.state = state;
  });

  const verification = data.identity_verification || {};
  const socSource = verification.soc_serial?.source || "";
  const socName = $("[data-identity-card='soc_serial'] .identity-name");
  if (socName) socName.textContent = socSource.includes("chipid") ?
    "Chip ID (ro.boot.chipid)" : "CPU ID (ro.boot.cpuid)";
  const verificationLabels = {
    passed: "验证通过",
    mismatch: "验证失败",
    pending: "等待应用",
    unsupported: "暂不支持",
    unchanged: "尚未更换",
  };
  $$('[data-verification-state], [data-verification-inline]').forEach((element) => {
    const key = element.dataset.verificationState || element.dataset.verificationInline;
    const item = verification[key] || {};
    const state = item.state || "unsupported";
    element.textContent = verificationLabels[state] || state;
    element.dataset.state = state;
  });

  const drmMode = Number(drm.mode) === 1 ? "Write-test 等长替换" :
    Number(drm.mode) === 0 ? "Dry-run（仅观察）" : "未知";
  const drmState = drm.state || (drm.connected ? "running" : "stopped");
  const counters = `${drm.replacement_candidates ?? 0} / ${drm.write_ok ?? 0} / ${drm.rejections ?? 0}`;
  const drmFields = {
    state: `${drmState}${drm.connected ? " · 已连接" : " · 未连接"}`,
    binder_backend: drm.binder_backend || "—",
    kernel_release: drm.kernel_release || "—",
    resolution_source: drm.resolution_source || "—",
    offset_sources: `${drm.file_offset_source || "—"} / ${drm.ioctl_offset_source || "—"}`,
    capabilities: drm.capabilities || "—",
    entry_fingerprint: drm.entry_fingerprint || "—",
    entry_checks: `${drm.entry_semantics ?? 0} / ${drm.symbol_validations ?? 0}`,
    original_fingerprint: drm.original_fingerprint || drm.device_fingerprint || "—",
    virtual_fingerprint: drm.virtual_fingerprint || "—",
    generation: drm.generation ?? "—",
    mode: drmMode,
    server_request_hits: drm.server_request_hits ?? 0,
    hal_count: drm.hal_count ?? 0,
    counters,
  };
  Object.entries(drmFields).forEach(([key, value]) => {
    $$(`[data-drm-field="${key}"]`).forEach((node) => { node.textContent = String(value); });
  });
  setText("#drmSummaryMode", drmMode);
  setText("#drmSummaryCounters", `${drm.server_request_hits ?? 0} / ${drm.write_ok ?? 0} / ${drm.rejections ?? 0}`);
  const drmHint = $("#drmDiagnosticHint");
  if (drmHint) {
    drmHint.textContent = drm.connected
      ? (Number(drm.mode) === 1 ? "Binder 后端正在执行全局等长替换。" : "Binder 后端当前为 Dry-run。")
      : drm.state === "waiting-hal" ? "等待 Widevine HAL，尚未安装 Binder Hook。" :
        "Binder 后端未连接，系统保持原始 Binder 路径。";
    drmHint.className = drm.connected ? "diagnostic-ok" : "diagnostic-warn";
  }
  const drmIssue = drmHasIssue(data);
  $("#drmDiagnosticDetails").open = drmIssue;

  const drmStopButton = $("#drmStopButton");
  drmStopButton.title = drm.connected ? "停止 DRM Binder 后端" : "DRM 后端当前未连接";

  const userSelect = $("#ssaidUser");
  const selectedUser = userSelect.value || "0";
  userSelect.replaceChildren();
  const allOption = document.createElement("option");
  allOption.value = "all";
  allOption.textContent = "全部用户";
  userSelect.append(allOption);
  for (const user of data.users || []) {
    const option = document.createElement("option");
    option.value = String(user.id);
    option.textContent = `${user.label} · ${String(user.format).toUpperCase()}${user.ready ? "" : " · 暂未支持"}`;
    option.disabled = !user.ready;
    userSelect.append(option);
  }
  userSelect.value = [...userSelect.options].some((option) => option.value === selectedUser && !option.disabled)
    ? selectedUser : ([...userSelect.options].find((option) => option.value === "0" && !option.disabled)?.value || "all");

  const surfaceGrid = $("#surfaceGrid");
  surfaceGrid.replaceChildren();
  for (const surface of data.identity_surfaces || []) {
    const item = document.createElement("div");
    item.className = "surface-item";
    item.dataset.state = surface.state || "absent";
    const name = document.createElement("strong");
    name.textContent = surface.id;
    const state = document.createElement("span");
    state.textContent = surface.state || "unknown";
    const detail = document.createElement("small");
    detail.textContent = surface.detail || "—";
    item.append(name, state, detail);
    surfaceGrid.append(item);
  }
  if (!surfaceGrid.children.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "后台尚未完成覆盖探测";
    surfaceGrid.append(empty);
  }

  const reset = data.global_reset || { state: "idle" };
  setText("#globalResetState", globalResetLabel(reset.state), "尚未安排");
  setText("#randomizeTiming", identityEnabled ? "立即应用" : "保存为待应用");
  $("#randomizeTiming").dataset.pending = identityEnabled ? "false" : "true";
  const transactionPending = reset.state === "prepared" || reset.state === "early-applied";
  if (!sessionClosed) {
    $$("button, input, select, textarea").forEach((element) => { element.disabled = false; });
  }
  drmStopButton.disabled = sessionClosed || mutationInFlight || !drm.connected;
  for (const selector of ["#markEnabled", "#randomizeButton", "#ssaidButton", "#localResetButton"]) {
    $(selector).disabled = transactionPending || mutationInFlight;
  }
  clearTimeout(transactionPollTimer);
  if (reset.state === "early-applied") {
    transactionPollTimer = window.setTimeout(() => {
      loadStatus().catch(() => {});
    }, 1500);
  }
  // Switch to the usable page only after every status-dependent field has been
  // rendered successfully. This avoids a ready-page flash followed by a
  // second error transition when a late field is malformed.
  setScreenState("ready");
}

function loadStatus(showMessage = false, forceFresh = false) {
  if (statusRequestInFlight) {
    return forceFresh
      ? statusRequestInFlight.then(() => loadStatus(showMessage, true))
      : statusRequestInFlight;
  }
  statusRequestInFlight = fetchStatus(showMessage).finally(() => {
    statusRequestInFlight = null;
  });
  return statusRequestInFlight;
}

async function fetchStatus(showMessage = false) {
  try {
    if (screenState !== "ready") setScreenState(token ? "syncing" : "connecting");
    await ensureSession();
    const data = await post("/api/status");
    clearTimeout(statusRetryTimer);
    statusRetryTimer = 0;
    renderStatus(data);
    if (showMessage) showToast("状态已刷新");
    return data;
  } catch (error) {
    if (isTerminalSessionError(error)) {
      showDisconnectedPage();
      if (showMessage) showToast(error.message, true);
      throw error;
    }
    setScreenState("syncing");
    scheduleStatusRetry();
    if (showMessage) showToast("后台暂时未响应，正在重试", true);
    return currentStatus;
  }
}

async function loadLog(showMessage = false) {
  const data = await post("/api/log");
  setText("#logOutput", data.log, "暂无日志");
  logLoaded = true;
  if (showMessage) showToast("日志已刷新");
}

function syncMutationControls() {
  const pending = ["prepared", "early-applied"].includes(currentStatus?.global_reset?.state);
  const disabled = mutationInFlight || pending || sessionClosed || screenState !== "ready";
  for (const id of ["markEnabled", "randomizeButton", "ssaidButton", "localResetButton", "drmStopButton"]) {
    $("#" + id).disabled = disabled || (id === "drmStopButton" && !currentStatus?.drm?.connected);
  }
}

async function withButton(button, task) {
  const mutating = ["randomizeButton", "ssaidButton", "localResetButton", "drmStopButton"].includes(button.id);
  if (mutating && mutationInFlight) return;
  if (mutating) { mutationInFlight = true; syncMutationControls(); }
  button.disabled = true;
  try {
    await task();
  } catch (error) {
    try { await loadStatus(false, true); } catch { /* Keep the original action error. */ }
    showToast(error.message || "操作失败", true);
  } finally {
    if (mutating) mutationInFlight = false;
    const state = currentStatus?.global_reset?.state;
    const transactionPending = state === "prepared" || state === "early-applied";
    button.disabled = sessionClosed || transactionPending ||
      (button.id === "drmStopButton" && currentStatus?.drm?.connected === false);
    if (mutating) syncMutationControls();
  }
}

async function waitForAction(sequence) {
  if (!sequence) return;
  for (let attempt = 0; attempt < 30; attempt += 1) {
    await new Promise((resolve) => window.setTimeout(resolve, 700));
    const data = await post("/api/action-result");
    if (data.sequence !== sequence || !data.result) continue;
    await Promise.all([loadStatus(false, true), loadLog()]);
    if (!data.result.ok) throw new Error(data.result.detail || "后台任务异常");
    return data.result;
  }
  throw new Error("后台任务仍在处理中，请稍后刷新状态");
}

async function copyIdentityValue(button) {
  const target = $(button.dataset.copyTarget || "");
  const value = target?.textContent?.trim() || "";
  if (!value || value === "—" || value === "未捕获" || value === "待应用") {
    throw new Error("当前没有可复制的值");
  }
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(value);
  } else {
    window.prompt("请长按复制以下内容", value);
  }
  showToast("已复制到剪贴板");
}

$("#markEnabled").addEventListener("change", () => {
  const control = $("#markEnabled");
  const requested = control.checked;
  if (mutationInFlight) {
    control.checked = Boolean(currentStatus?.config?.master_enabled);
    return;
  }
  mutationInFlight = true;
  syncMutationControls();
  control.disabled = true;
  (async () => {
    try {
      const result = await post("/api/config", { master_enabled: requested ? "1" : "0" });
      showToast(requested ? "设备标识管理已开启，正在应用" : "设备标识管理已关闭，正在恢复");
      await waitForAction(result.sequence);
      await loadStatus();
      showToast(requested ? "设备标识管理已生效" : "设备标识管理已关闭");
    } catch (error) {
      try {
        await loadStatus();
      } catch {
        control.checked = Boolean(currentStatus?.config?.master_enabled);
      }
      showToast(error.message || "配置应用失败", true);
    } finally {
      mutationInFlight = false;
      syncMutationControls();
    }
  })();
});

$("#randomizeButton").addEventListener("click", () => {
  withButton($("#randomizeButton"), async () => {
    const enabled = Boolean(currentStatus?.config?.master_enabled);
    const accepted = await showConfirm({
      title: enabled ? "立即更换设备标识？" : "保存一套新的设备标识？",
      message: enabled
        ? "将更换 Serial、SoC Serial、Android ID、OAID 和 DRM ID。\n为让 Android ID 一次生效，应用完成后系统界面会自动软重启一次（约一分钟，应用重新打开，不丢数据、不重启整机），请提前保存手头操作。\n受支持设备的系统 OAID 由模块重置，部分设备需重启后完全生效。"
        : "将生成新的 Serial、SoC Serial、Android ID、OAID 和 DRM ID，并保存为待应用。\n开启设备标识管理后才会应用到系统。",
      confirmLabel: enabled ? "立即应用" : "保存待应用",
      kicker: enabled ? "APPLY NEW IDENTITIES" : "SAVE FOR LATER",
    });
    if (!accepted) return;
    const result = await post("/api/randomize");
    showToast("正在生成新的核心标识…");
    await waitForAction(result.sequence);
    const oaidPassed = currentStatus?.identity_verification?.oaid?.state === "passed";
    showToast(!enabled ? "新的核心标识已保存，OAID 更换已排队" :
      oaidPassed ? "新的核心标识与 OAID 已验证生效（OAID 无需重启）" : "其它标识已应用，OAID 请查看实际验证状态");
  });
});

$("#ssaidButton").addEventListener("click", () => {
  withButton($("#ssaidButton"), async () => {
    const packageName = $("#ssaidPackage").value.trim();
    if (!packageName) throw new Error("请输入应用包名");
    await post("/api/reset-ssaid", { package: packageName, user: $("#ssaidUser").value });
    showToast("已安排 SSAID 重置，请重启设备");
  });
});

$("#localResetButton").addEventListener("click", () => {
  withButton($("#localResetButton"), async () => {
    const accepted = await showConfirm({
      title: "安排彻底重置？",
      message: "现在只会检查并备份全部支持的标识，不会立即写入。\n完成预检后需要手动重启设备；写入失败时会使用备份回滚。",
      confirmLabel: "检查并安排",
      tone: "danger",
      kicker: "FULL RESET",
    });
    if (!accepted) return;
    const result = await post("/api/local-reset", { confirm: "RESET_IDENTIFIERS" });
    showToast("正在检查并备份全部标识…");
    await waitForAction(result.sequence);
    showToast("检查和备份完成，请重启设备执行完整重置");
  });
});

$("#drmStopButton").addEventListener("click", () => {
  withButton($("#drmStopButton"), async () => {
    if (!(await showConfirm({
      title: "退出 DRM 后端？",
      message: "退出后仅停止 DRM Worker，设备标识管理的其他功能不受影响。重新打开模块或重启后台可恢复。",
      confirmLabel: "退出后端",
      tone: "danger",
      kicker: "STOP DRM BACKEND",
    }))) return;
    const result = await post("/api/drm-stop");
    showToast("正在退出 DRM 后端");
    await waitForAction(result.sequence);
    await loadStatus();
    showToast("DRM 后端已退出");
  });
});

$("#refreshStatus").addEventListener("click", () => withButton($("#refreshStatus"), () => loadStatus(true)));
$("#refreshLog").addEventListener("click", () => withButton($("#refreshLog"), () => loadLog(true)));
$("#advancedInfoButton").addEventListener("click", () => openDrawer("device"));
$("#openDiagnosticsButton").addEventListener("click", () => openDrawer("drm", true));
$("#closeAdvancedDrawer").addEventListener("click", requestCloseDrawer);
$("#drawerBackdrop").addEventListener("click", requestCloseDrawer);
$("#confirmCancel").addEventListener("click", () => closeConfirm(true, false));
$("#confirmAccept").addEventListener("click", () => closeConfirm(true, true));
$("#confirmBackdrop").addEventListener("click", () => closeConfirm(true, false));

$$("[data-drawer-tab]").forEach((tab) => {
  tab.addEventListener("click", () => selectDrawerTab(tab.dataset.drawerTab, tab.dataset.drawerTab === "drm" && drmHasIssue(currentStatus || {})));
});
$$("[data-copy-target]").forEach((button) => {
  button.addEventListener("click", () => copyIdentityValue(button).catch((error) => showToast(error.message || "复制失败", true)));
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && confirmOpen) {
    event.preventDefault();
    closeConfirm(true, false);
  } else if (event.key === "Escape" && drawerOpen) {
    event.preventDefault();
    requestCloseDrawer();
  }
});
window.addEventListener("popstate", () => {
  if (!drawerOpen) return;
  drawerHistoryPushed = false;
  closeDrawerUi();
});

async function bootstrap() {
  try {
    setScreenState("connecting");
    await ensureSession();
    setScreenState("syncing");
    await loadStatus();
  } catch (error) {
    if (isTerminalSessionError(error)) {
      showDisconnectedPage();
      showToast(error.message || "后台已退出，请重新从管理器打开", true);
    } else {
      setScreenState("syncing");
      scheduleStatusRetry();
    }
  }
}

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") closeWebUiSession();
});
window.addEventListener("blur", handleWindowBlur);
window.addEventListener("focus", handleWindowFocus);
document.addEventListener("freeze", closeWebUiSession, { once: true });
window.addEventListener("pageshow", (event) => {
  if (event.persisted) showDisconnectedPage();
});
window.addEventListener("pagehide", closeWebUiSession, { once: true });
window.addEventListener("beforeunload", closeWebUiSession, { once: true });

bootstrap();
