#pragma once

#include <cstddef>
#include <string>

namespace jiebiao {

struct UsbGadgetSerialResult {
    size_t detected = 0;
    size_t applied = 0;
    size_t failed = 0;
    size_t rebound = 0;
    std::string detail;
};

struct UsbGadgetSerialReadback {
    std::string state;
    std::string source;
    std::string detail;
    size_t detected = 0;
};

UsbGadgetSerialResult apply_usb_gadget_serial(const std::string& serial);
UsbGadgetSerialResult restore_usb_gadget_serial();
UsbGadgetSerialReadback verify_usb_gadget_serial(const std::string& expected);

}  // namespace jiebiao
