#include "identity_engine.h"

#include <syslog.h>
#include "common.h"
#include "oaid_engine.h"
#include "patch_base.h"
#include "patch_msm_get_serial_number.h"
#include "patch_soc_info_show.h"
#include "property_engine.h"
#include "state_store.h"
#include "soc_serial_adapter.h"
#include "ssaid_engine.h"
#include "usb_serial_engine.h"

#include "kernel_module_kit_umbrella.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <filesystem>
#include <map>
#include <sstream>
#include <unordered_set>
#include <vector>

namespace jiebiao {
namespace {

constexpr const char* kOriginalProps = "mark_original_props";
constexpr const char* kOriginalAndroidId = "original_android_id";
constexpr const char* kSettingsCaptured = "identity_settings_captured";
constexpr const char* kSettingsOriginalsV2 = "identity_settings_originals_v2";
constexpr const char* kIdentityBaselineV1 = "identity_baseline_v1";
constexpr const char* kIdentityApplyStateV1 = "identity_apply_state_v1";
constexpr const char* kIdentityOaidBaselineV1 = "identity_oaid_baseline_v1";
constexpr const char* kIdentityOaidTargetV1 = "identity_oaid_target_v1";
constexpr const char* kIdentityOaidPendingPayloadV1 = "identity_oaid_pending_payload_v1";
constexpr const char* kIdentitySystemOaidPendingV1 = "identity_system_oaid_pending_v1";

struct OriginalValue {
    bool existed = false;
    std::string value;
};

using OriginalMap = std::map<std::string, OriginalValue>;

constexpr const char* kSerialProperties[] = {
    "ro.serialno", "ro.boot.serialno", "ro.kernel.androidboot.serialno",
    "ril.serialnumber", "gsm.serial", "ro.vendor.oplus.serialno",
    "ro.oplus.serialno", "ro.vendor.serialno", "ro.boot.oplus.serialno",
    "sys.oplus.serialno", "persist.sys.oplus.serialno", "ro.vendor.gsm.serial",
    "vendor.gsm.serial", "ro.ril.oem.psno", "ro.ril.oem.sno",
    "persist.sys.serialno", "ro.vendor.oem.serialno",
};

std::string storage_value(const char* key) {
    std::string value;
    storage_read_string(key, value);
    return value;
}

std::string random_like(const std::string& original);
bool read_current_oplus_oaid(std::string& value, std::string& detail);

bool valid_oaid_value(const std::string& value) {
    return value.size() == 64 &&
           std::all_of(value.begin(), value.end(), [](unsigned char ch) {
               return std::isxdigit(ch) != 0;
           });
}

// OAID 载荷允许字符：大小写字母、数字，个别实现含 '-' '_'
bool oaid_payload_char_ok(char ch) {
    return std::isalnum(static_cast<unsigned char>(ch)) || ch == '-' || ch == '_';
}

// 解析 /data/system/oaid_persistence_0 的真实存储格式。
// 实测小米/红米为：1 字节 0x00 + 1 字节长度(=0x10=16) + N 个 OAID 字符；
// 旧实现误写成固定的 0x00 0x10 + 18 位 hex（20 字节），在小米上校验必然失败。
// 同时兼容纯文本 OAID。成功时 prefix 为二进制头（纯文本时为空），payload 为可见 OAID。
// 把 /data/system/oaid_persistence_0 切成 head | payload | tail 三段。
//  - 小米/红米二进制：head=\x00\xLL(2字节头), payload=OAID, tail=""
//  - OPPO/一加新系统多行文本：head="", payload=第一行OAID, tail="\n..."(第二行VAID等原样保留)
//  - 纯文本单行：head="", payload=整串, tail=""
// 写回时只替换 payload，head/tail 原样保留，避免丢掉 OPPO 的 VAID 行导致系统重置。
bool parse_system_oaid_full(const std::string& content,
                            std::string& head,
                            std::string& payload,
                            std::string& tail) {
    head.clear();
    payload.clear();
    tail.clear();
    // 1) 小米二进制头：0x00 + 1字节长度N + N字节payload（后面可能有少量尾字节，不影响）
    if (content.size() >= 2 && content[0] == '\0') {
        const size_t declared = static_cast<unsigned char>(content[1]);
        if (declared != 0 && 2 + declared <= content.size()) {
            const std::string body = content.substr(2, declared);
            if (body.size() == declared && body.size() >= 8 &&
                std::all_of(body.begin(), body.end(),
                            [](char ch) { return oaid_payload_char_ok(ch); })) {
                head = content.substr(0, 2);
                payload = body;
                tail = content.substr(2 + declared);
                return true;
            }
        }
        return false;
    }
    // 2) 文本：从开头取第一段连续合法字符作为 OAID，其余（换行/VAID 行）归入 tail。
    //    OPPO/一加新系统该文件是多行（OAID 行 + VAID 行），第一段即 OAID。
    size_t i = 0;
    while (i < content.size() && oaid_payload_char_ok(content[i])) ++i;
    if (i >= 8) {
        payload = content.substr(0, i);
        tail = content.substr(i);
        return true;
    }
    return false;
}

bool parse_system_oaid(const std::string& content,
                       std::string& prefix,
                       std::string& payload) {
    std::string head, tail;
    if (!parse_system_oaid_full(content, head, payload, tail)) return false;
    prefix = head;
    return true;
}

bool valid_system_oaid(const std::string& value) {
    std::string prefix, payload;
    return parse_system_oaid(value, prefix, payload);
}

// 扫描所有用户的系统 OAID 持久化文件 /data/system/oaid_persistence_<user_id>
// 双开/分身用户（如 user 999）也有自己的文件，必须一并修改否则双开应用读到原值。
static std::vector<uint32_t> discover_system_oaid_users() {
    std::vector<uint32_t> users;
    std::error_code error;
    const std::filesystem::path root("/data/system");
    for (std::filesystem::directory_iterator it(root, std::filesystem::directory_options::skip_permission_denied, error), end;
         it != end && !error && users.size() < 64; it.increment(error)) {
        if (error) { error.clear(); continue; }
        const std::string name = it->path().filename().string();
        constexpr const char* prefix = "oaid_persistence_";
        if (name.compare(0, strlen(prefix), prefix) != 0) continue;
        const std::string num = name.substr(strlen(prefix));
        if (num.empty() || num.size() > 5) continue;
        bool all_digit = true;
        for (char ch : num) if (!std::isdigit(static_cast<unsigned char>(ch))) { all_digit = false; break; }
        if (!all_digit) continue;
        uint32_t uid = static_cast<uint32_t>(std::stoul(num));
        struct stat st{};
        if (stat(it->path().c_str(), &st) == 0 && S_ISREG(st.st_mode)) {
            users.push_back(uid);
        }
    }
    std::sort(users.begin(), users.end());
    return users;
}

// 生成与原载荷等长、且字符集与原值一致的随机 OAID。
// 小米重置后是 16 位纯 hex，OPPO 等多为大小写字母+数字混合；若按固定字符集生成，
// 会和原格式不一致、触发系统 OAID 校验。这里按参考值字符集生成：
// 参考值全为 hex(0-9a-f) -> 纯 hex；否则大小写字母+数字。
static bool payload_is_hex_only(const std::string& s) {
    if (s.empty()) return false;
    for (char ch : s) {
        const bool hex = (ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f');
        if (!hex) return false;
    }
    return true;
}

std::string random_oaid_payload(size_t length) {
    static constexpr char kAlnum[] =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    std::string out;
    out.reserve(length);
    for (size_t i = 0; i < length; ++i) out += random_from(kAlnum, 1);
    return out;
}

std::string random_oaid_payload_like(const std::string& reference, size_t length) {
    if (payload_is_hex_only(reference)) {
        static constexpr char kHex[] = "0123456789abcdef";
        std::string out;
        out.reserve(length);
        for (size_t i = 0; i < length; ++i) out += random_from(kHex, 1);
        return out;
    }
    return random_oaid_payload(length);
}

bool write_system_oaid_for_user(uint32_t user_id,
                                const std::string& new_payload,
                                std::string& detail) {
    const std::string path = "/data/system/oaid_persistence_" + std::to_string(user_id);
    std::string current;
    if (!read_file(path, current, 1024 * 1024)) {
        detail = "system-oaid-read-failed";
        return false;
    }
    std::string head, old_payload, tail;
    if (!parse_system_oaid_full(current, head, old_payload, tail)) {
        detail = "system-oaid-read-or-format-failed";
        return false;
    }
    // 新载荷必须与原载荷等长（小米二进制头里的长度字节才保持正确；
    // OPPO 多行文本则保持第一行长度一致、第二行 VAID 原样保留）
    std::string payload = new_payload;
    if (payload.size() != old_payload.size()) {
        payload = random_oaid_payload_like(old_payload, old_payload.size());
    }
    const std::string value = head + payload + tail;
    if (!write_file_atomic(path, value, 0600, true) ||
        run_process({"/system/bin/restorecon", path}) != 0) {
        detail = "system-oaid-write-failed";
        return false;
    }
    detail = "user" + std::to_string(user_id) + "-written";
    return true;
}

// 对所有用户（含双开/分身）写入相同的系统 OAID，主用户作为格式参考。
bool write_system_oaid_all_users(const std::string& new_payload, std::string& detail) {
    const auto users = discover_system_oaid_users();
    if (users.empty()) {
        detail = "no-oaid-users-found";
        return false;
    }
    size_t ok_count = 0;
    std::string first_error;
    for (uint32_t uid : users) {
        std::string d;
        if (write_system_oaid_for_user(uid, new_payload, d)) {
            ++ok_count;
        } else if (first_error.empty()) {
            first_error = "user" + std::to_string(uid) + ":" + d;
        }
    }
    detail = "system-oaid-users=" + std::to_string(ok_count) + "/" + std::to_string(users.size());
    if (!first_error.empty()) detail += "," + first_error;
    // 主用户必须成功，否则判失败
    const bool primary_ok = std::find(users.begin(), users.end(), 0u) == users.end() ||
                            ok_count > 0;
    return primary_ok && ok_count > 0;
}

// 读取系统 OAID 文件并提取可见载荷（剥离二进制长度头），供状态显示与校验使用。
bool read_current_system_oaid(std::string& value, std::string& detail) {
    const std::string path = "/data/system/oaid_persistence_0";
    std::string content;
    if (!read_file(path, content, 1024 * 1024)) {
        detail = "system-oaid-absent";
        return false;
    }
    std::string prefix, payload;
    if (!parse_system_oaid(content, prefix, payload)) {
        detail = "system-oaid-format-failed";
        return false;
    }
    value = payload;
    detail = "system-oaid-read";
    return true;
}

bool record_oaid_runtime(const std::string& state, const std::string& detail) {
    return storage_write_string("identity_oaid_runtime_detail_v1", detail) &&
           storage_write_string("identity_oaid_runtime_state_v1", state);
}

bool build_oaid_targets(const std::string& private_dir,
                        std::string& oplus_payload,
                        std::string& system_value,
                        std::string& detail) {
    oplus_payload.clear();
    system_value.clear();
    struct stat st{};
    const char* path = "/data/system/openid_config.xml";
    if (lstat(path, &st) == 0) {
        std::string xml;
        std::vector<OplusOaidValue> values;
        if (!S_ISREG(st.st_mode) || !read_file(path, xml, 1024 * 1024) ||
            !inspect_oplus_openid_xml(xml, values, detail)) {
            detail = "oplus-config-read-or-format-failed";
            return false;
        }
        // Live reset is primary-user-only. Multi-user XML edits remain in the
        // separately reboot-gated full reset transaction.
        const auto primary = std::find_if(values.begin(), values.end(),
            [](const auto& value) { return value.user == "0"; });
        std::string current;
        if (primary == values.end() || !read_oplus_oaid_provider(current, detail) ||
            !probe_oplus_oaid_runtime(private_dir, detail)) return false;
        oplus_payload = "runtime-reset-user0";
    } else if (errno != ENOENT) {
        detail = "oplus-config-stat-failed";
        return false;
    }
    path = "/data/system/oaid_persistence_0";
    if (lstat(path, &st) == 0) {
        std::string current;
        if (!S_ISREG(st.st_mode) || !read_file(path, current, 1024 * 1024)) {
            detail = "system-oaid-read-or-format-failed";
            return false;
        }
        std::string prefix, payload;
        if (!parse_system_oaid(current, prefix, payload)) {
            detail = "system-oaid-read-or-format-failed";
            return false;
        }
        // 存纯可见载荷（write_system_oaid 写回时会重新加上二进制头），
        // 长度与原载荷一致，且字符集跟随原值（纯 hex 保持纯 hex）。
        system_value = random_oaid_payload_like(payload, payload.size());
    } else if (errno != ENOENT) {
        detail = "system-oaid-stat-failed";
        return false;
    }
    detail = oplus_payload.empty() && system_value.empty() ? "oaid-unsupported" : "targets-ready";
    return true;
}

bool read_primary_oplus_oaid_xml(const std::string& xml,
                                 std::string& value,
                                 std::string& detail) {
    value.clear();
    std::vector<OplusOaidValue> entries;
    if (!inspect_oplus_openid_xml(xml, entries, detail)) return false;
    const auto primary = std::find_if(entries.begin(), entries.end(),
                                      [](const OplusOaidValue& item) { return item.user == "0"; });
    if (primary == entries.end()) {
        detail = "primary-user-missing";
        return false;
    }
    value = primary->value;
    detail = "format-v1,primary-user=0";
    return valid_oaid_value(value);
}

bool read_oaid_from_transaction_backup(std::string& value) {
    value.clear();
    const std::string directory = storage_value("global_reset_directory_v2");
    if (directory.empty()) return false;
    std::error_code error;
    for (std::filesystem::directory_iterator it(
             directory, std::filesystem::directory_options::skip_permission_denied, error),
         end;
         it != end && !error; it.increment(error)) {
        const auto status = it->symlink_status(error);
        if (error || !std::filesystem::is_regular_file(status)) continue;
        const std::string name = it->path().filename().string();
        if (!name.starts_with("entry-")) continue;
        std::string xml;
        if (read_file(it->path().string(), xml, 1024 * 1024)) {
            std::string detail;
            if (read_primary_oplus_oaid_xml(xml, value, detail)) return true;
        }
    }
    return false;
}

bool read_current_oplus_oaid(std::string& value, std::string& detail) {
    value.clear();
    return read_oplus_oaid_provider(value, detail);
}

std::string first_property_value(const char* const* keys, size_t count);

std::string generate_serial() {
    // Preserve the shape exposed by the device.  Several vendors use compact
    // eight-character serials; applying a fixed 14-character template causes
    // those devices to reject the replacement or expose inconsistent aliases.
    const std::string current = first_property_value(kSerialProperties, std::size(kSerialProperties));
    if (!current.empty()) return random_like(current);
    std::string vendor = get_property("ro.product.manufacturer") + " " + get_property("ro.product.brand");
    std::transform(vendor.begin(), vendor.end(), vendor.begin(), [](unsigned char ch) {
        return static_cast<char>(std::tolower(ch));
    });
    if (vendor.find("oppo") != std::string::npos || vendor.find("realme") != std::string::npos ||
        vendor.find("oneplus") != std::string::npos) {
        return "3B" + random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 14);
    }
    if (vendor.find("xiaomi") != std::string::npos || vendor.find("redmi") != std::string::npos ||
        vendor.find("poco") != std::string::npos) {
        return random_digits(14);
    }
    if (vendor.find("huawei") != std::string::npos || vendor.find("honor") != std::string::npos) {
        return random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 4) + random_digits(12);
    }
    if (vendor.find("samsung") != std::string::npos) {
        return "R" + random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 1) + "Z" +
               random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 8);
    }
    if (vendor.find("vivo") != std::string::npos || vendor.find("iqoo") != std::string::npos) {
        return random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 14);
    }
    if (vendor.find("google") != std::string::npos || vendor.find("pixel") != std::string::npos) {
        return random_from("abcdefghijklmnopqrstuvwxyz0123456789", 12);
    }
    return random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 14);
}

std::string random_like(const std::string& original) {
    if (original.empty()) return random_digits(10);
    std::string value;
    value.reserve(original.size());
    for (char ch : original) {
        if (std::isdigit(static_cast<unsigned char>(ch))) value += random_digits(1);
        else if (std::islower(static_cast<unsigned char>(ch))) value += random_from("abcdefghijklmnopqrstuvwxyz", 1);
        else if (std::isupper(static_cast<unsigned char>(ch))) value += random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 1);
        else value.push_back(ch);
    }
    if (value == original && !value.empty()) value[0] = value[0] == '9' ? '1' : '9';
    return value;
}

// Qualcomm and several MediaTek vendor kernels expose the SoC serial as an
// unsigned decimal value.  Keep that representation valid when rotating it:
// a leading zero can make an otherwise valid value fail consumers that parse
// the attribute as a 32-bit integer.
std::string random_numeric_like(const std::string& original) {
    if (original.empty()) return {};
    std::string value;
    value.reserve(original.size());
    const bool multi_digit = original.size() > 1;
    const bool ten_digit_u32 = original.size() == 10;
    for (size_t i = 0; i < original.size(); ++i) {
        const char source = original[i];
        if (!std::isdigit(static_cast<unsigned char>(source))) {
            return random_like(original);
        }
        const std::string alphabet = (ten_digit_u32 && i == 0) ? "123" :
            ((multi_digit && i == 0) ? "123456789" : "0123456789");
        char replacement = source;
        do {
            replacement = random_from(alphabet, 1)[0];
        } while (replacement == source && alphabet.size() > 1);
        value.push_back(replacement);
    }
    if (value == original && !value.empty()) {
        value[0] = value[0] == '9' ? '1' :
                   (value[0] == '0' ? '1' : static_cast<char>(value[0] + 1));
    }
    return value;
}

soc_serial::Readback read_soc_serial_surface() {
    return soc_serial::probe();
}

// MediaTek/天玑平台没有高通的 soc_info_show / msm_get_serial_number 内核符号，
// 其 SoC 序列号通过内核启动属性暴露。
// 红米/小米天玑：ro.boot.cpuid（0x 开头十六进制串）
// 一加/OPPO 天玑：ro.boot.chipid（16 位大写字母数字串）
constexpr const char* kSocCpuIdProperty = "ro.boot.cpuid";
constexpr const char* kSocChipIdProperty = "ro.boot.chipid";

std::string read_soc_prop(const char* name) {
    std::string v = get_property(name);
    while (!v.empty() && (v.back() == '\n' || v.back() == '\r' || v.back() == ' ' ||
                          v.back() == '\t')) {
        v.pop_back();
    }
    return v;
}

std::string read_soc_cpuid() {
    return read_soc_prop(kSocCpuIdProperty);
}

std::string read_soc_chipid() {
    return read_soc_prop(kSocChipIdProperty);
}

// 是否为 cpuid 格式：0x 开头 + 十六进制
bool is_cpuid_format(const std::string& v) {
    if (v.size() < 4 || v.compare(0, 2, "0x") != 0) return false;
    for (size_t i = 2; i < v.size(); ++i) {
        if (!std::isxdigit(static_cast<unsigned char>(v[i]))) return false;
    }
    return true;
}

// 是否为一加/OPPO chipid 格式：16 位大写字母数字
bool is_chipid_format(const std::string& v) {
    if (v.size() != 16) return false;
    for (unsigned char ch : v) {
        if (!(std::isupper(ch) || std::isdigit(ch))) return false;
    }
    return true;
}

// 是否为 SoC 标识格式（非空即可，兼容高通 sysfs 的字母数字混合格式）
bool is_soc_identity_format(const std::string& v) {
    return !v.empty();
}

// 生成同格式随机 cpuid（保留 0x 前缀与长度）
std::string random_cpuid_like(const std::string& original) {
    if (!is_cpuid_format(original)) return random_like(original);
    std::string out = "0x";
    out.reserve(original.size());
    for (size_t i = 2; i < original.size(); ++i) {
        out += random_from("0123456789abcdef", 1);
    }
    if (out == original && out.size() > 2) {
        out[2] = out[2] == '0' ? '1' : '0';
    }
    return out;
}

// 生成同格式随机 chipid（16 位大写字母数字）
std::string random_chipid_like(const std::string& original) {
    if (!is_chipid_format(original)) return random_like(original);
    std::string out;
    out.reserve(16);
    for (int i = 0; i < 16; ++i) {
        out += random_from("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 1);
    }
    if (out == original) out[0] = out[0] == 'A' ? 'B' : 'A';
    return out;
}

// 按原值格式生成随机 SoC 序列号（cpuid / chipid / 纯数字 / 其它）
std::string randomize_soc_serial(const std::string& current) {
    if (current.empty()) return {};
    if (is_cpuid_format(current)) return random_cpuid_like(current);
    if (is_chipid_format(current)) return random_chipid_like(current);
    const bool numeric = std::all_of(
        current.begin(), current.end(),
        [](unsigned char ch) { return std::isdigit(ch) != 0; });
    return numeric ? random_numeric_like(current) : random_like(current);
}

std::string read_soc_serial() {
    // 1. ro.boot.cpuid（天玑：0x 开头 hex）
    std::string v = read_soc_cpuid();
    if (is_cpuid_format(v)) return v;
    // 2. ro.boot.chipid（OPPO/一加天玑：16 位大写）
    v = read_soc_chipid();
    if (is_chipid_format(v)) return v;
    // 3. 高通：直接读 /sys/devices/soc0/serial_number，不走 probe（probe 可能返回 UFS）
    for (const char* path : {"/sys/devices/soc0/serial_number",
                             "/sys/bus/soc/devices/soc0/serial_number"}) {
        std::string val;
        if (read_stream_file(path, val, 256)) {
            size_t start = val.find_first_not_of(" \t\r\n");
            size_t end = val.find_last_not_of(" \t\r\n");
            if (start != std::string::npos) val = val.substr(start, end - start + 1);
            if (!val.empty()) return val;
        }
    }
    return {};
}

// UFS 序列号：从 sysfs string_descriptors/serial_number 读取（独立第 6 项）
std::string read_ufs_serial() {
    const auto ufs = soc_serial::probe_ufs_serial();
    return ufs.readable ? ufs.value : std::string();
}

// 按原值格式随机化 UFS 序列号（保留长度与字符集风格）
std::string randomize_ufs_serial(const std::string& original) {
    if (original.empty()) return {};
    return random_like(original);
}

std::string serialize_originals(const OriginalMap& values) {
    std::string output;
    for (const auto& [key, original] : values) {
        output += key + "\t" + (original.existed ? "1" : "0") + "\t" + original.value + "\n";
    }
    return output;
}

OriginalMap parse_originals(const std::string& text) {
    OriginalMap values;
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        const size_t first = line.find('\t');
        const size_t second = first == std::string::npos ? first : line.find('\t', first + 1);
        if (first == std::string::npos || second == std::string::npos) continue;
        const std::string key = line.substr(0, first);
        if (!safe_property_key(key)) continue;
        values[key] = OriginalValue{line.substr(first + 1, second - first - 1) == "1",
                                    line.substr(second + 1)};
    }
    return values;
}

OriginalMap load_originals() {
    std::string text;
    storage_read_string(kOriginalProps, text);
    return parse_originals(text);
}

bool snapshot_property_value(const OriginalMap& originals,
                             const char* const* keys,
                             size_t count,
                             std::string& value) {
    for (size_t i = 0; i < count; ++i) {
        const auto it = originals.find(keys[i]);
        if (it == originals.end()) continue;
        value = it->second.existed ? it->second.value : std::string();
        return true;
    }
    return false;
}

std::string first_property_value(const char* const* keys, size_t count) {
    for (size_t i = 0; i < count; ++i) {
        const std::string value = get_property(keys[i]);
        if (!value.empty()) return value;
    }
    return {};
}

struct VerificationResult {
    std::string state;
    std::string source;
};

bool settings_read(const std::string& name_space,
                   uint32_t user_id,
                   const std::string& name,
                   bool& existed,
                   std::string& value);

VerificationResult verify_property_group(const char* const* keys,
                                         size_t count,
                                         const std::string& expected,
                                         const char* source) {
    if (expected.empty()) return {"unsupported", source};
    for (size_t i = 0; i < count; ++i) {
        if (!property_exists(keys[i])) continue;
        const std::string value = get_property(keys[i]);
        if (value.empty()) continue;
        return {value == expected ? "passed" : "mismatch", source};
    }
    return {"unsupported", source};
}

VerificationResult verify_setting_value(const char* name_space,
                                        uint32_t user_id,
                                        const char* name,
                                        const std::string& expected,
                                        const char* source) {
    if (expected.empty()) return {"unsupported", source};
    bool existed = false;
    std::string value;
    if (!settings_read(name_space, user_id, name, existed, value)) {
        return {"unsupported", source};
    }
    if (!existed) return {"unsupported", source};
    return {value == expected ? "passed" : "mismatch", source};
}

VerificationResult verify_file_value(const std::string& path,
                                     const std::string& expected,
                                     const char* source) {
    if (expected.empty()) return {"unsupported", source};
    std::string value;
    if (!read_stream_file(path, value, 256)) return {"unsupported", source};
    value = trim(std::move(value));
    return {value == expected ? "passed" : "mismatch", source};
}

VerificationResult verify_serial_surfaces(const std::string& expected) {
    const VerificationResult properties = verify_property_group(
        kSerialProperties, std::size(kSerialProperties), expected, "system property");
    const UsbGadgetSerialReadback usb = verify_usb_gadget_serial(expected);
    const std::string source = "system property + USB configfs(nodes=" +
                               std::to_string(usb.detected) + ')';
    if (properties.state == "mismatch" || usb.state == "mismatch") return {"mismatch", source};
    if (properties.state == "passed" && (usb.state == "passed" || usb.state == "absent")) {
        return {"passed", source};
    }
    return {"unsupported", source};
}

VerificationResult verify_soc_serial_surface(const std::string& expected) {
    if (expected.empty()) return {"unsupported", "SoC serial"};
    // 1. ro.boot.cpuid（天玑）
    const std::string cpuid = read_soc_cpuid();
    if (is_cpuid_format(cpuid)) {
        return {cpuid == expected ? "passed" : "mismatch",
                "SoC serial (ro.boot.cpuid)"};
    }
    // 2. ro.boot.chipid（OPPO/一加天玑）
    const std::string chipid = read_soc_chipid();
    if (is_chipid_format(chipid)) {
        return {chipid == expected ? "passed" : "mismatch",
                "SoC serial (ro.boot.chipid)"};
    }
    // 3. 高通：直接读 /sys/devices/soc0/serial_number，不走 probe（probe 可能返回 UFS）
    for (const char* path : {"/sys/devices/soc0/serial_number",
                             "/sys/bus/soc/devices/soc0/serial_number"}) {
        std::string val;
        if (read_stream_file(path, val, 256)) {
            // trim whitespace
            size_t start = val.find_first_not_of(" \t\r\n");
            size_t end = val.find_last_not_of(" \t\r\n");
            if (start != std::string::npos) val = val.substr(start, end - start + 1);
            if (!val.empty()) {
                return {val == expected ? "passed" : "mismatch",
                        std::string("SoC serial (") + path + ")"};
            }
        }
    }
    return {"unsupported", "SoC serial"};
}

// UFS 序列号验证：读 sysfs string_descriptors/serial_number 比对
VerificationResult verify_ufs_serial_surface(const std::string& expected) {
    if (expected.empty()) return {"unsupported", "UFS serial"};
    const auto ufs = soc_serial::probe_ufs_serial();
    if (!ufs.readable) return {"unsupported", "UFS serial (ufs-sysfs)"};
    return {ufs.value == expected ? "passed" : "mismatch",
            "UFS serial (ufs-sysfs)"};
}

bool parse_identity_fields(const std::string& text, IdentityValues& values) {
    std::map<std::string, std::string> fields;
    for (const auto& line : split_lines(text)) {
        const size_t tab = line.find('\t');
        if (tab != std::string::npos) fields[line.substr(0, tab)] = line.substr(tab + 1);
    }
    values.serial = fields["serial"];
    values.soc_serial = fields["soc_serial"];
    values.android_id = fields["androidid"];
    values.ufs_serial = fields["ufs_serial"];
    return true;
}

template <size_t N>
void append_property_values(std::vector<std::pair<std::string, std::string>>& output,
                            const char* const (&keys)[N],
                            const std::string& value) {
    if (value.empty()) return;
    for (const char* key : keys) output.emplace_back(key, value);
}

bool restore_original_property(const std::string& resetprop,
                               const std::string& key,
                               const OriginalValue& original) {
    std::vector<std::string> args{resetprop, "-n"};
    if (original.existed) args.insert(args.end(), {key, original.value});
    else args.insert(args.end(), {"-d", key});
    return run_process(args) == 0;
}

bool install_soc_serial_hook(const std::string& serial) {
    if (serial.empty()) return false;
    using kernel_module::SymbolHit;
    using kernel_module::SymbolMatchMode;
    uint64_t soc_info_show = 0;
    SymbolHit msm_get_serial_number{};
    kernel_module::kallsyms_lookup_name("soc_info_show", soc_info_show);
    kernel_module::kallsyms_lookup_name("socinfo:msm_get_serial_number",
                                       msm_get_serial_number,
                                       SymbolMatchMode::Prefix);
    PatchBase patch_base;
    bool hooked = false;
    // CPU ID 只 hook soc_info_show（高通 socinfo 驱动的通用 show）
    if (soc_info_show) {
        PatchSocInfoShow patch(patch_base, soc_info_show);
        hooked = is_ok(patch.patch_soc_info_show(serial)) || hooked;
    }
    if (msm_get_serial_number.addr) {
        PatchMsmGetSerialNumber patch(patch_base, msm_get_serial_number.addr);
        hooked = is_ok(patch.patch_msm_get_serial_number(serial)) || hooked;
    }
    return hooked;
}

// UFS 序列号 hook：只 hook generic serial_number_show
bool install_ufs_serial_hook(const std::string& serial) {
    if (serial.empty()) return false;
    using kernel_module::SymbolHit;
    using kernel_module::SymbolMatchMode;
    std::vector<SymbolHit> generic_hits;
    kernel_module::kallsyms_lookup_name_array("serial_number_show", generic_hits,
                                               SymbolMatchMode::Suffix);
    PatchBase patch_base;
    bool hooked = false;
    for (const auto& hit : generic_hits) {
        if (!hit.addr) continue;
        PatchSocInfoShow patch(patch_base, hit.addr);
        if (is_ok(patch.patch_soc_info_show(serial))) hooked = true;
    }
    return hooked;
}

struct SettingOriginal {
    std::string name_space;
    uint32_t user_id = 0;
    std::string name;
    bool existed = false;
    std::string value;
};

std::string setting_key(const std::string& name_space, uint32_t user_id, const std::string& name) {
    return name_space + ":" + std::to_string(user_id) + ":" + name;
}

bool settings_read(const std::string& name_space,
                   uint32_t user_id,
                   const std::string& name,
                   bool& existed,
                   std::string& value) {
    std::string output;
    const int result = run_process({"/system/bin/settings", "--user", std::to_string(user_id),
                                    "list", name_space}, &output);
    if (result != 0) return false;
    existed = false;
    value.clear();
    const std::string prefix = name + "=";
    for (const auto& line : split_lines(output)) {
        if (line.starts_with(prefix)) {
            existed = true;
            value = line.substr(prefix.size());
            break;
        }
    }
    return true;
}

bool settings_put(const std::string& name_space,
                  uint32_t user_id,
                  const std::string& name,
                  const std::string& value) {
    if (value.empty()) return false;
    return run_process({"/system/bin/settings", "--user", std::to_string(user_id),
                        "put", name_space, name, value}) == 0;
}

bool settings_delete(const std::string& name_space, uint32_t user_id, const std::string& name) {
    return run_process({"/system/bin/settings", "--user", std::to_string(user_id),
                        "delete", name_space, name}) == 0;
}

std::string serialize_setting_originals(const std::map<std::string, SettingOriginal>& originals) {
    std::string text;
    for (const auto& [key, item] : originals) {
        (void)key;
        text += item.name_space + "\t" + std::to_string(item.user_id) + "\t" + item.name +
                "\t" + (item.existed ? "1" : "0") + "\t" + item.value + "\n";
    }
    return text;
}

std::map<std::string, SettingOriginal> parse_setting_originals(const std::string& text) {
    std::map<std::string, SettingOriginal> originals;
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        std::vector<std::string> fields;
        size_t start = 0;
        for (int i = 0; i < 4; ++i) {
            const size_t tab = line.find('\t', start);
            if (tab == std::string::npos) break;
            fields.push_back(line.substr(start, tab - start));
            start = tab + 1;
        }
        if (fields.size() != 4 || (fields[0] != "secure" && fields[0] != "global")) continue;
        char* end = nullptr;
        const unsigned long user = std::strtoul(fields[1].c_str(), &end, 10);
        if (!end || *end != '\0' || user > 99999 || fields[2].empty()) continue;
        SettingOriginal item{fields[0], static_cast<uint32_t>(user), fields[2], fields[3] == "1",
                             line.substr(start)};
        originals[setting_key(item.name_space, item.user_id, item.name)] = std::move(item);
    }
    return originals;
}

std::map<std::string, SettingOriginal> load_setting_originals() {
    std::string text;
    storage_read_string(kSettingsOriginalsV2, text);
    auto originals = parse_setting_originals(text);
    if (!originals.empty()) return originals;

    bool legacy_captured = false;
    storage_read_bool(kSettingsCaptured, legacy_captured);
    if (!legacy_captured) return originals;
    const std::string android_id = storage_value(kOriginalAndroidId);
    SettingOriginal android{"secure", 0, "android_id", !android_id.empty(), android_id};
    originals[setting_key(android.name_space, android.user_id, android.name)] = android;
    storage_write_string(kSettingsOriginalsV2, serialize_setting_originals(originals));
    return originals;
}

bool capture_setting(std::map<std::string, SettingOriginal>& originals,
                     const std::string& name_space,
                     uint32_t user_id,
                     const std::string& name,
                     bool only_if_present,
                     bool& selected) {
    selected = false;
    const std::string key = setting_key(name_space, user_id, name);
    const auto existing = originals.find(key);
    if (existing != originals.end()) {
        selected = !only_if_present || existing->second.existed;
        return true;
    }
    bool existed = false;
    std::string value;
    if (!settings_read(name_space, user_id, name, existed, value)) return false;
    if (only_if_present && !existed) return true;
    originals[key] = SettingOriginal{name_space, user_id, name, existed, value};
    selected = true;
    return true;
}

}  // namespace

IdentityValues load_or_create_identity(bool force_regenerate) {
    IdentityValues values;
    if (!force_regenerate) {
        parse_identity_values(storage_value("identity_values_v2"), values);
        if (values.serial.empty()) {
            storage_read_string("id_serial", values.serial);
            storage_read_string("id_soc_serial", values.soc_serial);
            storage_read_string("id_android", values.android_id);
        }
    }
    if (force_regenerate || values.serial.empty()) {
        values = generate_identity_values();
        save_identity_values(values);
        set_identity_application_state("pending");
    } else if (values.soc_serial.empty()) {
        // Older alpha builds persisted an empty SoC field when the only
        // Qualcomm socX path was absent.  Once
        // the runtime adapter discovers an MTK path, backfill the target so
        // an upgrade does not require a destructive full reset.
        const std::string current_soc_serial = read_soc_serial();
        if (!current_soc_serial.empty()) {
            values.soc_serial = randomize_soc_serial(current_soc_serial);
            if (save_identity_values(values)) set_identity_application_state("pending");
        }
    } else if (!is_soc_identity_format(values.soc_serial)) {
        // 旧版本曾把 UFS sysfs 序列号存成目标值（字母数字混合）。现在统一只走
        // CPU ID（cpuid/chipid），发现存量目标格式不对时，按当前 CPU 重新生成。
        const std::string current_soc_serial = read_soc_serial();
        if (!current_soc_serial.empty()) {
            values.soc_serial = randomize_soc_serial(current_soc_serial);
            if (save_identity_values(values)) set_identity_application_state("pending");
        }
    }
    // UFS 序列号：老版本没有这项，升级时自动补上
    if (values.ufs_serial.empty()) {
        const std::string current_ufs = read_ufs_serial();
        if (!current_ufs.empty()) {
            values.ufs_serial = randomize_ufs_serial(current_ufs);
            if (save_identity_values(values)) set_identity_application_state("pending");
        }
    }
    return values;
}

IdentityValues generate_identity_values() {
    IdentityValues values;
    values.serial = generate_serial();
    // 优先从 baseline 读原值（避免读到 hook 后的值导致格式错误）
    IdentityValues baseline;
    parse_identity_fields(storage_value(kIdentityBaselineV1), baseline);
    std::string current_soc_serial = baseline.soc_serial;
    if (current_soc_serial.empty()) current_soc_serial = read_soc_serial();
    values.soc_serial = randomize_soc_serial(current_soc_serial);
    values.android_id = random_hex(16);
    // UFS 序列号：优先从 baseline 读原值
    std::string current_ufs = baseline.ufs_serial;
    if (current_ufs.empty()) current_ufs = read_ufs_serial();
    values.ufs_serial = randomize_ufs_serial(current_ufs);
    return values;
}

namespace {
bool apply_oaid_targets(const std::string& private_dir, const std::string& payload,
                        const std::string& system_value, std::string& detail) {
    if (payload.empty() && system_value.empty()) {
        detail = "oaid-unsupported";
        return record_oaid_runtime("unsupported", detail);
    }
    if (!record_oaid_runtime("applying", "runtime-reset-in-progress")) {
        detail = "oaid-state-write-failed";
        return false;
    }
    const std::string system_path = "/data/system/oaid_persistence_0";
    std::string old_system;
    if (!system_value.empty() &&
        (!read_file(system_path, old_system, 1024 * 1024) || !valid_system_oaid(old_system))) {
        detail = "system-oaid-backup-failed";
        record_oaid_runtime("failed", detail);
        return false;
    }
    bool ok = true;
    std::string system_detail;
    // 对所有用户（含双开/分身）写入系统 OAID，不再只写 user 0
    if (!system_value.empty()) ok = write_system_oaid_all_users(system_value, system_detail);
    std::string primary;
    if (ok && !payload.empty()) {
        ok = rotate_oplus_oaid_runtime(private_dir, primary, detail);
        // Even if provider verification fails, retain the returned runtime
        // target as evidence. Never substitute the unchanged provider value.
        if (!primary.empty() && !storage_write_string(kIdentityOaidTargetV1, primary)) {
            detail = "oaid-target-save-failed";
            ok = false;
        }
    } else {
        detail = system_detail;
    }
    if (!ok) {
        if (!system_value.empty()) {
            const bool restored = write_file_atomic(system_path, old_system, 0600, true) &&
                run_process({"/system/bin/restorecon", system_path}) == 0;
            detail += restored ? ",system-rolled-back" : ",system-rollback-failed";
        }
        // OEM runtime reset has no arbitrary-value restore API. Do not claim
        // rollback of OUID by merely rewriting its XML persistence file.
        record_oaid_runtime("failed", detail);
        return false;
    }
    // 小米等无 OPLUS provider 的系统 OAID 分支：本次写入成功后，把新值存为目标值，
    // 供状态判定用"当前值==目标值"比对。此前小米分支从不写 target，状态只能靠
    // "当前值==基线"瞎猜，导致改完时绿时红。
    if (!system_value.empty()) {
        storage_write_string(kIdentityOaidTargetV1, system_value);
    }
    if (!system_value.empty()) detail += "," + system_detail;
    if (!storage_write_string(kIdentityOaidPendingPayloadV1, "") ||
        !storage_write_string(kIdentitySystemOaidPendingV1, "") ||
        !record_oaid_runtime(payload.empty() ? "applied" : "applied", detail)) {
        detail = "oaid-state-save-failed-after-apply";
        record_oaid_runtime("failed", detail);
        return false;
    }
    return true;
}
}  // namespace

bool randomize_oaids_now(const std::string& private_dir, std::string& detail) {
    std::string payload;
    std::string system_value;
    ensure_identity_baseline_oaid();
    if (!build_oaid_targets(private_dir, payload, system_value, detail)) {
        record_oaid_runtime("failed", detail);
        return false;
    }
    return apply_oaid_targets(private_dir, payload, system_value, detail);
}

bool queue_oaid_rotation(const std::string& private_dir, std::string& detail) {
    std::string payload;
    std::string system_value;
    if (!build_oaid_targets(private_dir, payload, system_value, detail)) return false;
    const std::string old_payload = storage_value(kIdentityOaidPendingPayloadV1);
    const std::string old_system = storage_value(kIdentitySystemOaidPendingV1);
    if (!storage_write_string(kIdentityOaidPendingPayloadV1, payload) ||
        !storage_write_string(kIdentitySystemOaidPendingV1, system_value) ||
        !record_oaid_runtime(payload.empty() && system_value.empty() ? "unsupported" : "pending",
                             "queued-until-enabled")) {
        storage_write_string(kIdentityOaidPendingPayloadV1, old_payload);
        storage_write_string(kIdentitySystemOaidPendingV1, old_system);
        detail = "oaid-pending-write-failed";
        return false;
    }
    detail = payload.empty() && system_value.empty() ? "oaid-unsupported" : "oaid-pending";
    return true;
}

bool apply_pending_oaids(const std::string& private_dir, std::string& detail) {
    const std::string payload = storage_value(kIdentityOaidPendingPayloadV1);
    const std::string system_value = storage_value(kIdentitySystemOaidPendingV1);
    if (payload.empty() && system_value.empty()) {
        detail = "oaid-no-pending";
        return true;
    }
    const std::string state = storage_value("identity_oaid_runtime_state_v1");
    if (state == "applying" || state == "failed") {
        detail = "oaid-previous-attempt-unconfirmed-manual-retry-required";
        return false;
    }
    // Legacy queued XML payloads now request one primary-user runtime reset.
    return apply_oaid_targets(private_dir, payload, system_value, detail);
}

bool save_identity_values(const IdentityValues& values) {
    bool ok = storage_write_string("identity_values_v2", serialize_identity_values(values));
    ok = storage_write_string("id_serial", values.serial) && ok;
    ok = storage_write_string("id_soc_serial", values.soc_serial) && ok;
    // Retire legacy telephony targets created by pre-alpha19 builds.
    ok = storage_write_string("id_imsi", "") && ok;
    ok = storage_write_string("id_iccid", "") && ok;
    ok = storage_write_string("id_android", values.android_id) && ok;
    return ok;
}

std::string serialize_identity_values(const IdentityValues& values) {
    return "serial\t" + values.serial + "\n" +
           "soc_serial\t" + values.soc_serial + "\n" +
           "androidid\t" + values.android_id + "\n" +
           "ufs_serial\t" + values.ufs_serial + "\n";
}

bool parse_identity_values(const std::string& text, IdentityValues& values) {
    parse_identity_fields(text, values);
    return !values.serial.empty() && !values.android_id.empty();
}

bool ensure_identity_baseline_properties() {
    IdentityValues baseline;
    parse_identity_fields(storage_value(kIdentityBaselineV1), baseline);
    const OriginalMap originals = load_originals();
    bool changed = false;
    auto fill = [&](std::string& field, const char* const* keys, size_t count) {
        if (!field.empty()) return;
        std::string snapshot;
        if (snapshot_property_value(originals, keys, count, snapshot)) {
            field = snapshot;
        } else {
            field = first_property_value(keys, count);
        }
        changed = true;
    };
    fill(baseline.serial, kSerialProperties, std::size(kSerialProperties));
    if (baseline.soc_serial.empty()) {
        baseline.soc_serial = read_soc_serial();
        changed = true;
    }
    if (baseline.ufs_serial.empty()) {
        baseline.ufs_serial = read_ufs_serial();
        changed = true;
    }
    if (!changed) return true;
    return storage_write_string(kIdentityBaselineV1, serialize_identity_values(baseline));
}

bool setting_snapshot_value(const std::map<std::string, SettingOriginal>& originals,
                            const char* name_space,
                            uint32_t user_id,
                            const char* name,
                            std::string& value) {
    const auto it = originals.find(setting_key(name_space, user_id, name));
    if (it == originals.end()) return false;
    value = it->second.existed ? it->second.value : std::string();
    return true;
}

bool ensure_identity_baseline_settings() {
    IdentityValues baseline;
    parse_identity_fields(storage_value(kIdentityBaselineV1), baseline);
    const auto originals = load_setting_originals();
    bool changed = false;
    auto capture = [&](std::string& field,
                       const char* name_space,
                       const char* name,
                       bool try_secure_fallback) {
        if (!field.empty()) return;
        if (setting_snapshot_value(originals, name_space, 0, name, field)) {
            changed = true;
            return;
        }
        bool existed = false;
        std::string value;
        if (settings_read(name_space, 0, name, existed, value) && existed) {
            field = value;
            changed = true;
            return;
        }
        if (!try_secure_fallback) return;
        if (setting_snapshot_value(originals, "secure", 0, name, field)) {
            changed = true;
            return;
        }
        if (settings_read("secure", 0, name, existed, value) && existed) {
            field = value;
            changed = true;
        }
    };
    capture(baseline.android_id, "secure", "android_id", false);
    if (!changed) return true;
    return storage_write_string(kIdentityBaselineV1, serialize_identity_values(baseline));
}

bool ensure_identity_baseline_oaid() {
    const std::string existing = storage_value(kIdentityOaidBaselineV1);
    // baseline 是"改之前记录的本机原始 OAID"，一旦记录就永远固定，不能再刷新。
    // 不能用 valid_oaid_value()（要求 64 位 hex）校验：小米/红米 OAID 是 16 位 hex，
    // 会被误判无效、每次点更换都用当前新值覆盖 baseline，导致"原值=新值"。
    if (!existing.empty()) return true;

    std::string value;
    // A completed global-reset transaction keeps its entry backups. Prefer
    // that pre-reset snapshot so an alpha upgrade never records the already
    // rotated provider value as the device original.
    if (!read_oaid_from_transaction_backup(value)) {
        std::string detail;
        if (!read_current_oplus_oaid(value, detail)) {
            std::string xml;
            read_file("/data/system/openid_config.xml", xml, 1024 * 1024);
            if (!read_primary_oplus_oaid_xml(xml, value, detail)) {
                // 小米/红米等：系统 OAID 存于 oaid_persistence_0（带长度头）
                read_current_system_oaid(value, detail);
            }
        }
    }
    if (valid_oaid_value(value)) {
        return storage_write_string(kIdentityOaidBaselineV1, value);
    }
    // 非 OPPO 的系统 OAID（字母数字载荷，非 64 位 hex），非空即记录为基线
    if (!value.empty()) {
        return storage_write_string(kIdentityOaidBaselineV1, value);
    }
    return false;
}

bool set_identity_application_state(const std::string& state) {
    if (state != "applied" && state != "pending" && state != "properties-ready") return false;
    return storage_write_string(kIdentityApplyStateV1, state);
}

std::string identity_application_state() {
    return storage_value(kIdentityApplyStateV1);
}

std::string identity_comparison_json(const IdentityValues& target, bool master_enabled) {
    IdentityValues baseline;
    parse_identity_fields(storage_value(kIdentityBaselineV1), baseline);
    struct Field {
        const char* key;
        const std::string& original;
        const std::string& target;
        VerificationResult verification;
        const char* unsupported_detail;
    };
    const Field fields[] = {
        {"serial", baseline.serial, target.serial,
         verify_serial_surfaces(target.serial), ""},
        {"soc_serial", baseline.soc_serial, target.soc_serial,
         verify_soc_serial_surface(target.soc_serial), "no-readable-soc-serial-surface"},
        {"androidid", baseline.android_id, target.android_id,
         verify_setting_value("secure", 0, "android_id", target.android_id,
                              "Settings secure"), ""},
        {"ufs_serial", baseline.ufs_serial, target.ufs_serial,
         verify_ufs_serial_surface(target.ufs_serial), "no-readable-ufs-serial-surface"},
    };
    std::string json = "{";
    for (size_t i = 0; i < std::size(fields); ++i) {
        if (i) json.push_back(',');
        const auto& field = fields[i];
        const bool known = !field.original.empty();
        const bool changed = known && !field.target.empty() && field.target != field.original;
        std::string state;
        std::string current;
        std::string detail;
        if (!known || field.target.empty()) {
            if (field.verification.state == "unsupported" && *field.unsupported_detail) {
                state = "unsupported";
                detail = field.unsupported_detail;
            } else {
                state = "unknown";
            }
        } else if (!changed) {
            state = "unchanged";
            current = field.original;
        } else if (master_enabled && field.verification.state == "passed") {
            state = "applied";
            current = field.target;
        } else if (master_enabled && field.verification.state == "mismatch") {
            state = "mismatch";
            current = "未达到预期";
        } else if (master_enabled && field.verification.state == "unsupported" &&
                   *field.unsupported_detail) {
            state = "unsupported";
            detail = field.unsupported_detail;
        } else {
            state = "pending";
            current = "待应用";
        }
        json += json_string(field.key) + ":{\"original\":" + json_string(field.original) +
                ",\"current\":" + json_string(current) +
                ",\"state\":" + json_string(state) +
                ",\"detail\":" + json_string(detail) + "}";
    }

    ensure_identity_baseline_oaid();
    const std::string oaid_original = storage_value(kIdentityOaidBaselineV1);
    std::string oaid_current;
    std::string oaid_detail;
    bool oaid_read = read_current_oplus_oaid(oaid_current, oaid_detail);
    if (!oaid_read) oaid_read = read_current_system_oaid(oaid_current, oaid_detail);
    std::string oaid_target = storage_value(kIdentityOaidTargetV1);
    // alpha17 applied OPLUS OAID before the target-value key was introduced.
    // Migrate that already-applied provider value once, without rewriting it.
    if (oaid_target.empty() && oaid_read && storage_value("global_reset_state_v2") == "applied") {
        if (storage_write_string(kIdentityOaidTargetV1, oaid_current)) oaid_target = oaid_current;
    }
    std::string oaid_state;
    std::string oaid_display;
    const std::string runtime_state = storage_value("identity_oaid_runtime_state_v1");
    const std::string runtime_detail = storage_value("identity_oaid_runtime_detail_v1");
    if (!runtime_detail.empty()) oaid_detail += "," + runtime_detail;
    if (runtime_state == "pending" || runtime_state == "applying") {
        oaid_state = "pending";
        oaid_display = oaid_read ? oaid_current : "待应用";
    } else if (runtime_state == "failed") {
        oaid_state = oaid_read ? "mismatch" : "unsupported";
        oaid_display = oaid_current;
    } else if (!oaid_read) {
        oaid_state = oaid_target.empty() ? "unknown" : "pending";
        oaid_display = oaid_target.empty() ? "" : "待应用";
    } else if (!oaid_target.empty() && oaid_current == oaid_target) {
        oaid_state = "applied";
        oaid_display = oaid_current;
    } else if (!oaid_target.empty()) {
        const std::string reset_state = storage_value("global_reset_state_v2");
        // 小米 OAID 系统服务运行时会缓存并可能还原 oaid_persistence_0：
        // 写入动作成功后(runtime_state=applied)，第三方/重启后读到的已是新值，
        // 但模块刷新时读到的文件可能被系统还原成旧值。此时不按 mismatch 误报失败，
        // 而是按已应用处理（整机重启后文件即与新值一致）。
        if (reset_state == "prepared" || reset_state == "early-applied") {
            oaid_state = "pending";
        } else if (runtime_state == "applied") {
            oaid_state = "applied";
        } else {
            oaid_state = "mismatch";
        }
        oaid_display = oaid_current;
    } else if (!oaid_original.empty() && oaid_current == oaid_original) {
        oaid_state = "unchanged";
        oaid_display = oaid_current;
    } else if (runtime_state == "applied" && !oaid_original.empty() &&
               oaid_current != oaid_original) {
        // 目标值记录缺失时的兜底：当前值已与原始基线不同，且运行时记录为已应用，
        // 说明 OAID 确实换过了，按已生效显示，不误报"未捕获"。
        oaid_state = "applied";
        oaid_display = oaid_current;
    } else {
        oaid_state = "unknown";
        oaid_display = oaid_current;
    }
    json += ",\"oaid\":{\"original\":" + json_string(oaid_original) +
            ",\"current\":" + json_string(oaid_display) +
            ",\"state\":" + json_string(oaid_state) +
            ",\"detail\":" + json_string(oaid_detail) + "}";
    json.push_back('}');
    return json;
}

std::string identity_verification_json(const IdentityValues& target, bool master_enabled) {
    // Once the switch is enabled the module has already attempted its early or
    // late apply phase. Report each real readback independently so one missing
    // adapter does not turn every verification item into "pending".
    const bool ready = master_enabled;
    struct Field {
        const char* key;
        const std::string& expected;
        VerificationResult result;
    };

    Field fields[] = {
        {"serial", target.serial, verify_serial_surfaces(target.serial)},
        {"soc_serial", target.soc_serial, verify_soc_serial_surface(target.soc_serial)},
        {"androidid", target.android_id, verify_setting_value("secure", 0, "android_id",
                                                                target.android_id, "Settings secure")},
        {"ufs_serial", target.ufs_serial, verify_ufs_serial_surface(target.ufs_serial)},
    };

    std::string json = "{";
    for (size_t i = 0; i < std::size(fields); ++i) {
        if (i) json.push_back(',');
        const auto& field = fields[i];
        std::string state = field.result.state;
        if (field.expected.empty()) state = "unsupported";
        else if (!ready) state = "pending";
        json += json_string(field.key) + ":{\"state\":" + json_string(state) +
                ",\"source\":" + json_string(field.result.source) + "}";
    }
    std::string oaid_current;
    std::string oaid_detail;
    bool oaid_read = read_current_oplus_oaid(oaid_current, oaid_detail);
    if (!oaid_read) oaid_read = read_current_system_oaid(oaid_current, oaid_detail);
    std::string oaid_target = storage_value(kIdentityOaidTargetV1);
    if (oaid_target.empty() && oaid_read && storage_value("global_reset_state_v2") == "applied") {
        if (storage_write_string(kIdentityOaidTargetV1, oaid_current)) oaid_target = oaid_current;
    }
    std::string oaid_state;
    const std::string runtime_state = storage_value("identity_oaid_runtime_state_v1");
    const std::string runtime_detail = storage_value("identity_oaid_runtime_detail_v1");
    if (!runtime_detail.empty()) oaid_detail += "," + runtime_detail;
    if (runtime_state == "pending" || runtime_state == "applying") {
        oaid_state = "pending";
    } else if (runtime_state == "failed") {
        oaid_state = oaid_read ? "mismatch" : "unsupported";
    } else if (oaid_target.empty()) {
        // target 记录缺失：只要运行时记录为已应用过，就视为通过，不误报未改/失败。
        oaid_state = (runtime_state == "applied") ? "passed" :
                     (oaid_read ? "unchanged" : "unsupported");
    } else if (!oaid_read) {
        oaid_state = "unsupported";
    } else if (oaid_current == oaid_target) {
        oaid_state = "passed";
    } else if (runtime_state == "applied") {
        // 写入动作已成功，第三方/重启后生效；文件可能被系统服务运行时还原，
        // 不据此判 mismatch 误报。
        oaid_state = "passed";
    } else {
        oaid_state = "mismatch";
    }
    json += ",\"oaid\":{\"state\":" + json_string(oaid_state) +
            ",\"source\":\"OPLUS/OUID provider\",\"detail\":" +
            json_string(oaid_detail) + "}";
    json.push_back('}');
    return json;
}

std::string identity_values_json(const IdentityValues& values) {
    return "{" +
           std::string("\"serial\":") + json_string(values.serial) +
           ",\"soc_serial\":" + json_string(values.soc_serial) +
           ",\"androidid\":" + json_string(values.android_id) +
           ",\"ufs_serial\":" + json_string(values.ufs_serial) + "}";
}

IdentityApplyResult apply_identity_properties(const std::string& private_dir,
                                              const IdentityValues& values,
                                              bool install_kernel_serial_hook) {
    IdentityApplyResult result;
    std::vector<std::pair<std::string, std::string>> candidates;
    append_property_values(candidates, kSerialProperties, values.serial);
    // 天玑/MTK 平台 SoC 序列号经启动属性暴露，内核没有高通的
    // soc_info_show / msm_get_serial_number 可 hook。resetprop 直接改写属性
    // 共享内存，对所有进程生效，等价于在内核层拦截属性读取。
    // 红米/小米：ro.boot.cpuid（0x hex）；一加/OPPO：ro.boot.chipid（16位大写）
    if (is_cpuid_format(values.soc_serial)) {
        candidates.emplace_back(kSocCpuIdProperty, values.soc_serial);
    }
    if (is_chipid_format(values.soc_serial)) {
        candidates.emplace_back(kSocChipIdProperty, values.soc_serial);
    }

    const std::string resetprop = resetprop_path(private_dir);
    OriginalMap originals = load_originals();
    std::map<std::string, std::string> candidate_values;
    for (const auto& [key, value] : candidates) candidate_values[key] = value;

    // alpha1 created every alias and also changed ro.product.build.id. Restore
    // those retired/previously absent keys before applying the existing-only set.
    for (auto it = originals.begin(); it != originals.end();) {
        const auto& key = it->first;
        const auto& original = it->second;
        const bool still_managed = candidate_values.contains(key);
        if (still_managed && original.existed) {
            ++it;
            continue;
        }
        if (restore_original_property(resetprop, key, original)) {
            ++result.applied;
            if (!still_managed) {
                // A retired field is restored once and then forgotten so later
                // apply/guard passes never touch it again.
                it = originals.erase(it);
                continue;
            }
            // Keep a still-managed, originally absent key as a tombstone. Some
            // resetprop builds leave a discoverable empty slot after deletion.
        } else {
            ++result.failed;
        }
        ++it;
    }

    std::vector<std::pair<std::string, std::string>> properties;
    for (const auto& [key, value] : candidates) {
        const auto known = originals.find(key);
        if ((known != originals.end() && known->second.existed) ||
            (known == originals.end() && property_exists(key.c_str()))) {
            properties.emplace_back(key, value);
        }
    }
    for (const auto& [key, value] : properties) {
        (void)value;
        if (!originals.contains(key)) {
            const std::string original = get_property(key.c_str());
            originals[key] = OriginalValue{true, original};
        }
    }
    if (!storage_write_string(kOriginalProps, serialize_originals(originals))) {
        result.failed += properties.size();
        result.message = "save-originals-failed";
        return result;
    }

    for (const auto& [key, value] : properties) {
        if (set_property(private_dir, key, value)) ++result.applied;
        else ++result.failed;
    }
    if (install_kernel_serial_hook && !values.soc_serial.empty()) {
        // CPU ID（cpuid/chipid）：resetprop 已写入，回读校验
        const VerificationResult soc_readback = verify_soc_serial_surface(values.soc_serial);
        result.kernel_serial_hooked = soc_readback.state == "passed";
        // 高通 sysfs SoC serial：resetprop 无效时，直接装内核 hook
        if (!result.kernel_serial_hooked) {
            result.kernel_serial_hooked = install_soc_serial_hook(values.soc_serial);
        }
    }
    if (install_kernel_serial_hook && !values.ufs_serial.empty()) {
        // UFS 序列号：sysfs 文件，走内核 hook（serial_number_show）
        const bool ufs_hooked = install_ufs_serial_hook(values.ufs_serial);
        result.kernel_serial_hooked = result.kernel_serial_hooked || ufs_hooked;
    }
    result.message = result.failed == 0 ? "ok" : "partial";
    return result;
}

IdentityApplyResult restore_identity_properties(const std::string& private_dir) {
    IdentityApplyResult result;
    const OriginalMap originals = load_originals();
    const std::string resetprop = resetprop_path(private_dir);
    for (const auto& [key, original] : originals) {
        if (restore_original_property(resetprop, key, original)) ++result.applied;
        else ++result.failed;
    }
    if (result.failed == 0) storage_write_string(kOriginalProps, "");
    result.message = result.failed == 0 ? "ok" : "partial-reboot-restores-kernel-serial";
    return result;
}

bool apply_identity_settings(const IdentityValues& values,
                             std::string& detail) {
    auto originals = load_setting_originals();
    struct PendingSetting { std::string name_space; uint32_t user; std::string name; std::string value; };
    std::vector<PendingSetting> pending;
    bool capture_ok = true;
    auto add = [&](const char* name_space, uint32_t user, const char* name,
                   const std::string& value, bool only_if_present) {
        bool selected = false;
        if (!capture_setting(originals, name_space, user, name, only_if_present, selected)) {
            capture_ok = false;
        } else if (selected) {
            pending.push_back({name_space, user, name, value});
        }
    };
    // 修改所有用户的 Settings.Secure.ANDROID_ID（含双开/分身用户）
    // 之前只改 user 0，导致双开应用读到原值。
    const auto all_users = discover_android_users();
    if (all_users.empty()) {
        add("secure", 0, "android_id", values.android_id, false);
    } else {
        for (const auto& user : all_users) {
            add("secure", user.id, "android_id", values.android_id, false);
        }
    }
    if (!capture_ok || !storage_write_string(kSettingsOriginalsV2, serialize_setting_originals(originals))) {
        detail = "capture-failed";
        return false;
    }
    storage_write_bool(kSettingsCaptured, true);
    bool ok = true;
    std::ostringstream report;
    for (const auto& item : pending) {
        const bool item_ok = settings_put(item.name_space, item.user, item.name, item.value);
        ok = item_ok && ok;
        report << item.name_space << '/' << item.name << '=' << (item_ok ? "ok" : "failed") << ',';
    }
    detail = report.str();
    return ok;
}

// 一键更换时让 Android ID 一次生效：
// Android 8+ 应用读到的 ANDROID_ID 是 per-signature 的 SSAID，权威数据在
// /data/system/users/<u>/settings_ssaid.xml（由 system_server 的 SettingsProvider
// 缓存）。仅 `settings put secure android_id` 改不到 per-key SSAID，而直接改写文件后
// SettingsProvider 也不会在运行期重新加载——必须重启 framework（system_server）。
// 这里改写全部用户（含 .fallback）的全局 android_id 与 userkey，备份+回滚+restorecon，
// 全部成功后再延迟软重启 system_server（init 自动拉起，不重启整机、不丢数据）。
bool force_global_android_id_now(const std::string& private_dir,
                                 const std::string& android_id,
                                 std::string& detail) {
    if (android_id.size() != 16) { detail = "bad-android-id"; return false; }
    const auto users = discover_android_users();
    if (users.empty()) { detail = "no-users"; return false; }

    std::string backup_dir = private_dir;
    if (!backup_dir.empty() && backup_dir.back() != '/') backup_dir.push_back('/');
    backup_dir += "backups";
    mkdir(backup_dir.c_str(), 0700);
    chmod(backup_dir.c_str(), 0700);

    const std::string userkey = random_hex(64);
    // 持久化保存当前 userkey，供后续新创建用户（如双开 999）自动同步
    save_ssaid_userkey(userkey);
    size_t rewritten = 0;
    struct WrittenFile { std::string path; std::string backup; };
    std::vector<WrittenFile> written;

    auto handle_one = [&](const AndroidUserInfo& user, const std::string& tag) -> bool {
        SsaidDocument doc;
        std::string d;
        if (!load_ssaid_document(private_dir, user, "force-android-" + tag, doc, d)) {
            detail = tag + "-load-" + d;
            return false;
        }
        std::string xml = doc.xml;
        size_t changed = 0;
        if (!reset_all_ssaid_xml(xml, android_id, userkey, changed, d)) {
            detail = tag + "-reset-" + d;
            return false;
        }
        std::string encoded;
        if (!encode_ssaid_document(private_dir, doc, xml,
                                   "force-android-" + tag, encoded, d)) {
            detail = tag + "-encode-" + d;
            return false;
        }
        const std::string backup = backup_dir + "/settings_ssaid." + tag + ".bak";
        if (!write_file_atomic(backup, doc.original, 0600, false)) {
            detail = tag + "-backup-failed";
            return false;
        }
        auto write_doc = [](const std::string& p, const std::string& data) {
            return write_file_atomic(p, data, 0600, true) &&
                   run_process({"/system/bin/restorecon", p}) == 0;
        };
        if (!write_doc(user.path, encoded)) {
            write_doc(user.path, doc.original);
            detail = tag + "-write-failed-rolled-back";
            return false;
        }
        written.push_back({user.path, backup});
        ++rewritten;
        return true;
    };

    for (const auto& user : users) {
        if (!user.ready) continue;
        const std::string tag = "u" + std::to_string(user.id);
        if (!handle_one(user, tag)) {
            // 回滚已写文件
            for (const auto& w : written) {
                std::string orig;
                if (read_file(w.backup, orig)) {
                    write_file_atomic(w.path, orig, 0600, true);
                    run_process({"/system/bin/restorecon", w.path});
                }
            }
            return false;
        }
        // 同步处理 .fallback（部分机型存在）
        const std::string fb_path = user.path + ".fallback";
        AndroidUserInfo fb_user;
        std::string fb_detail;
        if (inspect_ssaid_file(user.id, fb_path, fb_user, fb_detail) && fb_user.ready) {
            if (!handle_one(fb_user, tag + ".fb")) return false;
        }
    }

    // SSAID XML 可能已经是目标值（early 阶段已改写），但 apply_identity_settings
    // 刚修改了所有用户的 settings_secure.xml（Settings.Secure.ANDROID_ID），
    // SettingsProvider 仍缓存旧值，必须软重启 framework 才能让双开用户生效。
    if (rewritten == 0) {
        detail = "ssaid-already-current";
    } else {
        detail = "ssaid-rewritten=" + std::to_string(rewritten);
    }

    // 延迟软重启 system_server：先让本次 action 结果落盘返回，3 秒后再杀，
    // init 会自动拉起 system_server/zygote（约一分钟，应用重启但不丢数据）。
    const int rc = run_process({"sh", "-c",
        "setsid sh -c 'sleep 3; kill -9 $(pidof system_server) >/dev/null 2>&1' "
        ">/dev/null 2>&1 &"});
    detail += (rc == 0 ? ",framework-restart-scheduled" : ",framework-restart-failed");
    return true;
}

bool capture_managed_settings(std::string& snapshot,
                              std::string& detail) {
    std::map<std::string, SettingOriginal> originals;
    bool ok = true;
    auto capture = [&](const char* name_space, uint32_t user, const char* name,
                       bool only_if_present) {
        bool selected = false;
        if (!capture_setting(originals, name_space, user, name, only_if_present, selected)) ok = false;
    };
    capture("secure", 0, "android_id", false);
    snapshot = serialize_setting_originals(originals);
    detail = ok ? "ok" : "settings-list-failed";
    return ok;
}

bool restore_managed_settings_snapshot(const std::string& snapshot,
                                       std::string& detail) {
    const auto originals = parse_setting_originals(snapshot);
    if (originals.empty()) {
        detail = "snapshot-empty";
        return false;
    }
    bool ok = true;
    std::ostringstream report;
    for (const auto& [key, item] : originals) {
        (void)key;
        const bool item_ok = item.existed
            ? settings_put(item.name_space, item.user_id, item.name, item.value)
            : settings_delete(item.name_space, item.user_id, item.name);
        ok = item_ok && ok;
        report << item.name_space << '/' << item.name << '=' << (item_ok ? "ok" : "failed") << ',';
    }
    detail = report.str();
    return ok;
}

bool restore_legacy_device_name_settings(std::string& detail) {
    auto originals = load_setting_originals();
    static constexpr const char* kLegacyDeviceNames[] = {
        "device_name", "wifi_p2p_device_name", "bluetooth_name",
    };
    bool ok = true;
    std::ostringstream report;
    for (const char* name : kLegacyDeviceNames) {
        for (auto it = originals.begin(); it != originals.end();) {
            if (it->second.name != name) {
                ++it;
                continue;
            }
            const auto& item = it->second;
            const bool item_ok = item.existed
                ? settings_put(item.name_space, item.user_id, item.name, item.value)
                : settings_delete(item.name_space, item.user_id, item.name);
            ok = item_ok && ok;
            report << item.name_space << '/' << item.name << '='
                   << (item_ok ? "ok" : "failed") << ',';
            if (item_ok) it = originals.erase(it);
            else ++it;
        }
    }
    const bool stored = storage_write_string(kSettingsOriginalsV2,
                                             serialize_setting_originals(originals));
    if (originals.empty() && stored) storage_write_bool(kSettingsCaptured, false);
    ok = stored && ok;
    detail = report.str().empty() ? "not-captured" : report.str();
    return ok;
}

bool restore_retired_identity_settings(std::string& detail) {
    auto originals = load_setting_originals();
    bool ok = true;
    std::ostringstream report;
    for (auto it = originals.begin(); it != originals.end();) {
        if (it->second.name != "advertising_id") {
            ++it;
            continue;
        }
        const auto& item = it->second;
        const bool item_ok = item.existed
            ? settings_put(item.name_space, item.user_id, item.name, item.value)
            : settings_delete(item.name_space, item.user_id, item.name);
        ok = item_ok && ok;
        report << item.name_space << '/' << item.name << '='
               << (item_ok ? "ok" : "failed") << ',';
        if (item_ok) it = originals.erase(it);
        else ++it;
    }
    const bool stored = storage_write_string(kSettingsOriginalsV2,
                                             serialize_setting_originals(originals));
    if (originals.empty() && stored) storage_write_bool(kSettingsCaptured, false);
    ok = stored && ok;
    detail = report.str().empty() ? "not-captured" : report.str();
    return ok;
}

bool restore_identity_settings(std::string& detail) {
    const auto originals = load_setting_originals();
    if (originals.empty()) {
        detail = "not-captured";
        return true;
    }
    bool ok = true;
    std::ostringstream report;
    for (const auto& [key, item] : originals) {
        (void)key;
        const bool item_ok = item.existed
            ? settings_put(item.name_space, item.user_id, item.name, item.value)
            : settings_delete(item.name_space, item.user_id, item.name);
        ok = item_ok && ok;
        report << item.name_space << '/' << item.name << '=' << (item_ok ? "ok" : "failed") << ',';
    }
    if (ok) {
        storage_write_string(kSettingsOriginalsV2, "");
        storage_write_bool(kSettingsCaptured, false);
    }
    detail = report.str();
    return ok;
}

// ===== SSAID userkey 持久化与新用户自动同步 =====

namespace {
constexpr const char* kSsaidUserkeyKey = "ssaid_current_userkey_v1";

// 读取指定用户 settings_ssaid.xml 中的当前 userkey（ABX 先转 XML）
bool read_user_userkey(const std::string& private_dir,
                       const AndroidUserInfo& user,
                       std::string& out_userkey,
                       std::string& detail) {
    SsaidDocument doc;
    if (!load_ssaid_document(private_dir, user, "read-userkey-" + std::to_string(user.id), doc, detail)) {
        return false;
    }
    // 简单字符串查找 name="userkey" value="..."
    size_t pos = doc.xml.find("name=\"userkey\"");
    if (pos == std::string::npos) {
        // 也可能是 value 在 name 前面
        pos = doc.xml.find("userkey");
    }
    if (pos != std::string::npos) {
        size_t value_pos = doc.xml.find("value=\"", pos);
        if (value_pos != std::string::npos) {
            size_t value_start = value_pos + 7;
            size_t value_end = doc.xml.find("\"", value_start);
            if (value_end != std::string::npos) {
                out_userkey = doc.xml.substr(value_start, value_end - value_start);
                return true;
            }
        }
    }
    detail = "userkey-not-found";
    return false;
}

// 用指定 android_id + userkey 改写单个用户的 SSAID 文件（含 .fallback）
bool rewrite_one_user_ssaid(const std::string& private_dir,
                            const AndroidUserInfo& user,
                            const std::string& android_id,
                            const std::string& userkey,
                            const std::string& tag,
                            std::string& detail) {
    SsaidDocument doc;
    std::string d;
    if (!load_ssaid_document(private_dir, user, tag, doc, d)) {
        detail = tag + "-load-" + d;
        return false;
    }
    std::string xml = doc.xml;
    size_t changed = 0;
    if (!reset_all_ssaid_xml(xml, android_id, userkey, changed, d)) {
        detail = tag + "-reset-" + d;
        return false;
    }
    std::string encoded;
    if (!encode_ssaid_document(private_dir, doc, xml, tag, encoded, d)) {
        detail = tag + "-encode-" + d;
        return false;
    }
    std::string backup_dir = private_dir;
    if (!backup_dir.empty() && backup_dir.back() != '/') backup_dir.push_back('/');
    backup_dir += "backups";
    mkdir(backup_dir.c_str(), 0700);
    const std::string backup = backup_dir + "/settings_ssaid." + tag + ".bak";
    if (!write_file_atomic(backup, doc.original, 0600, false)) {
        detail = tag + "-backup-failed";
        return false;
    }
    auto write_doc = [](const std::string& p, const std::string& data) {
        return write_file_atomic(p, data, 0600, true) &&
               run_process({"/system/bin/restorecon", p}) == 0;
    };
    if (!write_doc(user.path, encoded)) {
        write_doc(user.path, doc.original);
        detail = tag + "-write-failed-rolled-back";
        return false;
    }
    return true;
}
}  // namespace

bool save_ssaid_userkey(const std::string& userkey) {
    return storage_write_string(kSsaidUserkeyKey, userkey);
}

bool load_ssaid_userkey(std::string& userkey) {
    return storage_read_string(kSsaidUserkeyKey, userkey) && !userkey.empty();
}

bool sync_new_users_ssaid(const std::string& private_dir, std::string& detail) {
    std::string current_userkey;
    if (!load_ssaid_userkey(current_userkey)) {
        detail = "no-saved-userkey";
        return false;
    }
    // 读取当前设置的 android_id（用于改写新用户）
    IdentityValues values = load_or_create_identity();
    if (values.android_id.empty() || values.android_id.size() != 16) {
        detail = "no-android-id";
        return false;
    }
    const auto users = discover_android_users();
    size_t synced = 0;
    size_t skipped = 0;
    std::ostringstream report;
    for (const auto& user : users) {
        if (!user.ready) { ++skipped; continue; }
        std::string existing_key;
        std::string d;
        if (read_user_userkey(private_dir, user, existing_key, d)) {
            if (existing_key == current_userkey) continue;  // 已同步，跳过
        }
        // userkey 不匹配或读取失败，执行同步
        const std::string tag = "sync-u" + std::to_string(user.id);
        if (rewrite_one_user_ssaid(private_dir, user, values.android_id,
                                   current_userkey, tag, d)) {
            ++synced;
            report << "u" << user.id << "=ok,";
            // 同步 .fallback
            const std::string fb_path = user.path + ".fallback";
            AndroidUserInfo fb_user;
            std::string fb_detail;
            if (inspect_ssaid_file(user.id, fb_path, fb_user, fb_detail) && fb_user.ready) {
                std::string fb_d;
                if (rewrite_one_user_ssaid(private_dir, fb_user, values.android_id,
                                           current_userkey, tag + ".fb", fb_d)) {
                    report << "u" << user.id << ".fb=ok,";
                }
            }
        } else {
            report << "u" << user.id << "=failed(" << d << "),";
        }
    }
    detail = "synced=" + std::to_string(synced) + ",skipped=" + std::to_string(skipped) +
             "," + report.str();
    return true;
}

}  // namespace jiebiao
