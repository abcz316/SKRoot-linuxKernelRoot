#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace jiebiao {

enum class SsaidFormat {
    Xml,
    Abx,
    Unknown,
};

struct AndroidUserInfo {
    uint32_t id = 0;
    std::string label;
    std::string path;
    SsaidFormat format = SsaidFormat::Unknown;
    bool ready = false;
};

struct SsaidDocument {
    AndroidUserInfo user;
    std::string original;
    std::string xml;
};

bool inspect_ssaid_file(uint32_t user_id,
                        const std::string& path,
                        AndroidUserInfo& user,
                        std::string& detail);
std::vector<AndroidUserInfo> discover_android_users();
std::string android_users_json(const std::vector<AndroidUserInfo>& users);
bool parse_user_selector(const std::string& selector, bool& all_users, uint32_t& user_id);

bool reset_package_ssaid_xml(std::string& xml,
                             const std::string& package_name,
                             const std::string& replacement,
                             size_t& changed,
                             std::string& detail);
bool reset_all_ssaid_xml(std::string& xml,
                         const std::string& android_id,
                         const std::string& userkey,
                         size_t& changed,
                         std::string& detail);

bool load_ssaid_document(const std::string& private_dir,
                         const AndroidUserInfo& user,
                         const std::string& work_tag,
                         SsaidDocument& document,
                         std::string& detail);
bool encode_ssaid_document(const std::string& private_dir,
                           const SsaidDocument& document,
                           const std::string& xml,
                           const std::string& work_tag,
                           std::string& encoded,
                           std::string& detail);

}  // namespace jiebiao
