# 发热与耗电 A/B 验证

本文件用于验证 `1.0.1` 的发布包是否改善“间歇性高温、持续超过 1 小时”
现象。这里保留开发者提供的实机测量方法；本次仅合并和离线验证，未执行温度 A/B 测量，
不能据此断言发热已经解决。

## 测试条件

- 使用同一台 ARM64、Android 14+、Linux 6.1+ 设备；系统版本、内核、SIM、网络、
  屏幕亮度和后台应用保持一致。
- 两组都从相近电量（建议 60%--80%）开始，拔掉充电器，屏幕关闭并静置至少 30 分钟。
- A 组使用原始模块或卸载候选包；B 组使用
  `设备标识管理-1.0.1-arm64-run-once.zip`。
- 每组至少观察 2 小时；若复现周期更长，延长到 4 小时。不要把充电时的温度与
  放电时的温度直接比较。
- 安装或升级每个版本后重启，确认实际运行版本再开始采样。WebUI 不作为长期采样通道。

## 采样命令

以下命令在电脑端执行；`OUT` 是电脑上的日志目录，`<MODULE_PRIVATE_DIR>` 替换为
模块管理器显示的私有目录。每 5 分钟执行一次，或在发热开始/结束时执行一次。

```powershell
$OUT = "thermal-$(Get-Date -Format yyyyMMdd-HHmmss)"
New-Item -ItemType Directory -Force $OUT | Out-Null
adb shell 'date; getprop ro.build.version.release; getprop ro.build.version.sdk; uname -a' | Tee-Object "$OUT/device.txt"
adb shell 'dumpsys thermalservice; dumpsys cpuinfo; dumpsys batterystats --charged' | Tee-Object "$OUT/system.txt"
adb shell 'for f in /sys/class/thermal/thermal_zone*/temp; do printf "%s " "$f"; cat "$f"; done' | Tee-Object "$OUT/thermal.txt"
adb shell 'top -H -b -n 1 -m 30' | Tee-Object "$OUT/top.txt"
adb shell 'cat /proc/pressure/cpu; ps -A -o PID,PPID,NAME,etimes,%cpu,%mem,args' | Tee-Object "$OUT/processes.txt"
adb shell 'ls -l <MODULE_PRIVATE_DIR>; tail -n 200 <MODULE_PRIVATE_DIR>/daemon.log; tail -n 200 <MODULE_PRIVATE_DIR>/jiebiao.log' | Tee-Object "$OUT/module.log"
```

如设备的 `top` 不接受 `-m`，去掉该参数重试。温度节点单位通常为千分之一摄氏度，
电池电流/功耗还应以设备自带电池统计或功耗计为准，避免仅用单个温度节点下结论。

## 通过条件

重点比较以下指标，而不是只看一次最高温度：

1. 空闲 30 分钟和 2 小时的 SoC/电池温度中位数与峰值；
2. `dumpsys cpuinfo` 中 `device_identity`、`drm_worker` 和相关 HAL 的 CPU 占用；
3. Worker 是否仅在总开关开启时存在；关闭总开关后，`drm_worker_pid` 应为 0，
   `drm_worker_state` 应为 stopped；
4. `daemon.log` 是否出现重复的 `drm-worker-retry`，以及重试间隔是否为 10/20/40 秒
   后进入最长 5 分钟冷却；
5. 没有可验证 Widevine HAL 时，日志是否出现
   `waiting without global Binder hook`；HAL 全部退出时是否出现
   `removing global Binder hook`，而不是保持空目标集合长期运行；
6. 开启总开关并实际访问 Widevine 后，DRM ID 是否仍能正常读取/替换，且没有新的
   `replacement_copy_to_user_faults` 或 Binder 错误激增。

若关闭总开关后仍持续升温，先保留日志并核对 Worker 和 Hook 是否确实退出，再按相同条件
进行对照；仅凭温度不能排除模块影响。若只有开启总开关并访问 DRM 后升温，重点提交
`thermalservice`、`top`、`drm_worker_state`、`drm_worker_result` 和时间戳，便于继续
定位具体 HAL 或内核实现。
