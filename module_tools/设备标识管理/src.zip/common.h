#pragma once

#include <sys/types.h>

#include <cstdint>
#include <map>
#include <string>
#include <string_view>
#include <vector>

namespace jiebiao {

std::string trim(std::string value);
std::vector<std::string> split_lines(const std::string& text);
std::string join_lines(const std::vector<std::string>& values);

std::string json_escape(std::string_view value);
std::string json_string(std::string_view value);
std::string url_decode(std::string_view value);
std::map<std::string, std::string> parse_form(const std::string& body);

bool valid_package_name(std::string_view value);
bool safe_property_key(std::string_view key);
bool forbidden_property_key(std::string_view key);

std::string get_property(const char* key);
bool property_exists(const char* key);
int run_process(const std::vector<std::string>& argv,
                std::string* output = nullptr,
                size_t max_output = 1024 * 1024);
int run_process_as(uid_t uid,
                   gid_t gid,
                   const std::vector<std::string>& argv,
                   std::string* output = nullptr,
                   size_t max_output = 1024 * 1024);

bool read_file(const std::string& path, std::string& output, size_t max_bytes = 4 * 1024 * 1024);
bool read_stream_file(const std::string& path, std::string& output, size_t max_bytes);
bool write_file_atomic(const std::string& path,
                       const std::string& content,
                       uint32_t mode = 0600,
                       bool preserve_owner = false);
bool append_log(const std::string& private_dir, const std::string& line);

std::string random_from(std::string_view alphabet, size_t size);
std::string random_hex(size_t size, bool upper = false);
std::string random_digits(size_t size);
std::string random_uuid_v4();
uint64_t monotonic_millis();
std::string boot_id();

std::string shell_quote(std::string_view value);

}  // namespace jiebiao
