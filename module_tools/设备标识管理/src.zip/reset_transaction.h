#pragma once

#include <string>

namespace jiebiao {

bool prepare_global_reset(const std::string& private_dir, std::string& detail);
std::string execute_early_global_reset(const std::string& private_dir);
std::string finalize_global_reset(const std::string& private_dir);

std::string identity_surfaces_json();
std::string global_reset_status_json();
bool global_reset_pending();

}  // namespace jiebiao
