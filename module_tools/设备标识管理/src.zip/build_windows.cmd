@echo off
setlocal
pushd "%~dp0"
python build_oaid_helper.py
if errorlevel 1 (
  popd
  exit /b 1
)
if defined NDK_BUILD (
  set "NDK_BUILD_CMD=%NDK_BUILD%"
) else (
  set "NDK_BUILD_CMD=C:\Users\Administrator\AppData\Local\Android\Sdk\ndk\26.3.11579264\ndk-build.cmd"
)
if not exist "%NDK_BUILD_CMD%" (
  echo ndk-build was not found: %NDK_BUILD_CMD% 1>&2
  popd
  exit /b 2
)
call "%NDK_BUILD_CMD%" NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk %*
set "BUILD_STATUS=%ERRORLEVEL%"
popd
exit /b %BUILD_STATUS%
