# 设备标识管理 SKP 1.0.1

作者：斓梦语、蜃。面向 SKRoot Pro SDK 4.6.1 的合并模块，ID 为
`deviceIdentityManagerSKP20260904`。项目以 `module_jiebiao_skp` 的设备标识
功能为主体，并内建 DRMID 1.4.0 的全局 Binder 后端；仅支持 Android 14+、ARM64、
Linux 6.1+。新模块使用全新私有状态，不导入旧模块状态。

## 保留功能

- 首次安装及每次标识轮换时生成新的随机 DRM ID
- 系统属性、USB configfs gadget 序列号与 SoC sysfs 序列号（含 MediaTek 多路径探测）
- Android ID
- 单应用 SSAID 重置
- 普通 XML/ABX、多用户 SSAID 与 `userkey` 受控重置
- AppSetID、已知格式 OAID 和 Settings-backed AAID 的预检式全局重置
- 厂商 OAID 与 GSF/GMS provider 覆盖探测（未知格式只报告状态）
- Widevine DRM ID 按需 Binder 后端（关闭总开关时停止 Worker 和 Hook）
- Binder 能力发现、入口语义、HAL 生命周期和运行计数诊断

WebUI 的“当前标识组”和“实际读取验证”均包含 DRM ID 项，以原始/当前指纹和
Binder 链路状态呈现；“DRM Binder 诊断”保留为独立只读面板，并提供停止 DRM
Worker 的红色操作入口。停止只影响 DRM Worker，不修改设备标识的其他路径。

DRM ID 不再提供来源选择、派生或自定义输入。首次安装模块时随机生成 32 字节
ID；点击“快速更换设备标识”或执行“彻底重置全部标识”时原子生成并发布新的随机 ID。
“设备标识管理”开关现在即时生效，无需保存按钮。

WebUI 将两种操作明确区分：快速更换处理核心标识及受支持的主用户 OAID，并根据总开关立即
应用或保存为待应用；彻底重置还包含全部用户 SSAID、AppSetID 与受支持 OAID/AAID，
先执行检查和备份，之后由用户重启设备完成事务写入，异常时使用备份回滚。

DRM Binder 后端按需运行：关闭总开关时停止 Worker，持久化策略保留为 Dry-run；
开启后按需启动 Write-test 后端。缺少 Widevine HAL 时不安装全局 Hook；
HAL 全部退出后移除 Hook，由 supervisor 退避重试。安装或升级后仍需重启生效。

## WebUI 重构（当前候选）

- 采用本地实现的 shadcn-inspired 浅色优先界面，并跟随系统深色模式切换；不依赖外部 CDN、字体或脚本。
- 首屏按“总开关 → 后台/DRM 状态 → 当前标识 → 常用操作”分层，手机竖屏默认单列显示。
- 每项 Serial、SoC Serial、Android ID、OAID、DRM ID 同时展示原值、当前值、生效状态和实际读取验证结果，并提供复制按钮；验证结果直接并入当前标识卡，不再单独占用页面区块。
- 首屏“标识统计”显示五项标识中验证通过的数量（例如 `5/5`）；DRM Binder 卡片仅显示“已写入”或“未写入”，详细模式和计数放在高级诊断抽屉。
- 设备详情、DRM Binder 完整诊断、覆盖状态和运行日志统一放入“高级信息”抽屉；移动端从底部滑出，宽屏设备从侧面滑出。
- DRM 诊断正常时折叠摘要，后端未连接、解析异常或验证失败时自动展开；红色“退出 DRM 后端”操作仍保留。
- 抽屉支持标签切换、遮罩/关闭按钮、Esc 和浏览器返回键；页面隐藏、失焦、冻结或离开时继续关闭 WebUI 会话并显示重开提示。
- 开机早期 DRM Worker 处于“等待稳定切入”时，WebUI 显示等待提示并保持会话；无 HAL 时显示等待后端状态，允许关闭总开关，不无限阻塞整页。

## 常驻进程检查

- 当前生产路径只保留一个 supervisor 和至多一个按需 DRM Binder Worker；WebUI 使用 SDK 自带服务，不额外创建业务守护进程。
- supervisor 启动 Worker 后通过 `PR_SET_PDEATHSIG` 绑定父进程生命周期；supervisor 退出时发送 `SIGTERM`，并在停止路径回收 Worker，避免孤儿进程和僵尸进程。
- Worker 的 Binder 控制循环使用 `poll()`/pidfd/Unix socket 阻塞等待，不使用高频空转扫描；supervisor 仅每 2 秒执行一次必要的事务与串口守护检查。
- 本轮不采用 `/proc` 过滤、进程列表隐藏或伪造名称；优化目标是减少进程数量、缩短存活范围和降低空闲开销。

## 明确排除

- BL/Verified Boot 状态或 boot hash 属性覆盖
- 开机关闭 USB 调试或开发者选项
- Keybox、CRL、TrickyStore `target.txt`、`persistent_keys` 及其网络更新
- KSU `post-fs-data.sh`、`service.sh`、`system.prop` 和 WebUI shell bridge
- ptrace Widevine 注入器及相关 SELinux 规则
- TEE 后端、Keymaster、KmInstallKeybox、persist/tzstorage 清理
- ADB 开关复位、MediaDRM 目录清空、UsageStats/Wi-Fi 配置批量删除
- 机型属性模板以及设备名、蓝牙名、Wi-Fi P2P 名称跟随机型

## 合并的 DRM 性能修复

- 启动稳定性探测保持 250 ms 采样与 3 秒稳定窗口不变；当 readiness 位图未变化时，
  进度日志由约 2 秒一次降为 10 秒一次，减少早期启动阶段的格式化和日志写入开销。
- Binder Worker 的 HAL 生命周期监控仍使用 pidfd/控制 socket 事件等待；缺少 HAL 时采用
  最长 30 秒的有界退避；无 pidfd 的 procfs 检查间隔同为 30 秒。
- 保留私有状态清理语义：`drm_worker_*` 记录仍由统一生命周期清理处理，避免合并模块
  的 supervisor/Worker 状态残留。

## 构建

使用工作区内冻结并校验 SHA-256 的 SKP SDK 4.6.1：

```bash
./build.sh
python3 package.py
python3 -m unittest discover -s tests -v
```

`build.sh` 会优先使用 Linux NDK；在 WSL 中若只安装了 Windows NDK，则自动
转交 `build_windows.cmd`。也可通过 `NDK_BUILD` 指定其他 NDK 入口。

生成物位于 `dist/`，候选包为：
`设备标识管理-1.0.1-arm64-run-once.zip`。

模块采用单一 SKP 入口和 supervisor；DRM worker 作为共享模块私有目录中的
独立进程运行，不注册第二套 SKP 模块。WebUI 会话在页面隐藏、失焦、冻结、离开
或关闭时主动关闭连接和端口，页面显示“后台已退出，请重新从管理器打开”。

## v0.2.0-alpha2

- 配置架构升级至 v2；旧版配置迁移时设备名称跟随保持关闭
- 单应用 SSAID 可选指定用户或全部用户，并按用户执行应用数据清理
- 全局重置先在后台完成格式演练、哈希与备份，下一次开机早期才落盘
- 已支持目标出现备份、哈希或写入失败时执行事务回滚；未知 provider 保持原状并在 WebUI 展示
- 属性标识改为 existing-only，升级时恢复 alpha1 改动的 Build ID 并清理原本不存在的别名
- 移除 Build ID 随机化，保持 product/system/vendor 构建信息一致
- Android 16 SSAID `.fallback` 与主文件成对预检、备份、校验、更新和回滚

候选包不会自动安装、启用或重启设备。首次设备测试应先关闭设备标识管理，
确认模块启动及 WebUI 状态后，再逐项启用并记录结果。发热对照步骤见 `THERMAL_VALIDATION.md`。

## v0.2.0-alpha3

- 配置架构升级至 v3，完整移除机型属性模板、模板资源与模板 API
- 移除“设备名称跟随机型”配置及全局事务中的设备名称处理
- 升级时一次性恢复旧版曾覆盖的机型属性和设备名称，再清理遗留配置键
- WebUI 使用紧凑移动端布局，在保留可用触控区域的同时缩小文字、控件、卡片与留白

## v0.2.0-alpha4

- 修复 Android 16/API 36 `abx2xml` 要求显式输出参数导致的 SSAID 预检失败
- ABX 解码和编码后回环校验均显式使用 stdout 输出，并加入完整命令参数回归测试

## v0.2.0-alpha5

- 修复重启后事务停留在 `prepared` 或 `early-applied` 导致 WebUI 操作控件持续禁用
- 启动恢复路径可处理遗漏的早期执行；后台循环会重试未完成的 post-boot finalize
- WebUI 对 `early-applied` 状态自动刷新，事务进入终态后恢复操作控件

## v0.2.0-alpha6（历史功能，已移除）

- 修改 Android 安全补丁日期时，同步更新设备上已存在的 `ro.*.build.date.utc`、`ro.*.build.date` 及派生日期键
- 构建时间按补丁日期生成 UTC 中午时间，避免时区换算造成日期偏移
- 构建时间与补丁属性共用原值快照，关闭补丁设置或卸载模块时一并恢复
- 拒绝不存在的日历日期，避免产生无效构建时间

## v0.2.0-alpha7（历史功能，已移除）

- WebUI 将“标识与补丁”标题改为“设备标识修改”，并明确提示安全补丁日期独立设置

## v0.2.0-alpha8

- 当前标识组改为逐项显示设备原值、已应用现值或“待应用”状态
- 新增 `identity_baseline_v1` 原值基线与 `identity_comparison` 状态接口
- 兼容旧版属性/Settings 快照，覆盖状态卡继续独立展示 SSAID、AppSetID 与 OAID

## v0.2.0-alpha9

- 将 Android 安全补丁日期配置移到配置表单底部，紧邻保存按钮
- 去除开关旁的补丁提示，避免把安全补丁设置理解为设备标识开关的一部分

## v0.2.0-alpha10

- 新增“实际读取验证”组，逐项核验系统属性、Settings、内核文件和主机名接口
- 验证结果区分“验证通过”“未达到预期”“待应用”和“无法验证”
- API 新增 `identity_verification`，保留原有 `identity` 与 `identity_comparison` 字段

## v0.2.0-alpha11

- 校验后台守护进程命令行，避免 PID 被其他系统进程复用后误报在线
- WebUI 检测到残留 `early-applied` 事务且后台进程失效时自动完成收尾
- WebUI 状态页尝试拉起失效的模块后台守护进程，避免所有操作长期灰显

## v0.2.0-alpha12

- 使用流式读取处理 `/proc/<pid>/cmdline` 的零长度伪文件语义
- 修复真实后台进程被误判离线并在每次状态刷新时重复拉起的问题
- 实机安装后必须完整重启，再以新启动周期验证后台与事务状态

## v0.2.0-alpha13

- 新增适配 `/proc`、`/sys` 零长度及动态长度语义的流式读取函数
- SoC Serial、Boot ID 和后台启动周期判断改用流式读取
- 系统属性验证按首个实际可读主入口比对，避免厂商空别名或次级别名造成误判
- Boot ID 与 Hostname 缺少属性基线时使用实际系统接口补采集

## v0.2.0-alpha14

- 此版本历史上曾尝试通过 Telephony `iphonesubinfo` 服务核验 IMSI、ICCID；后续版本已移除该功能
- Hostname 同步写入真实 UTS 主机名，并在开机完成后再次应用和定期复核
- 实际读取验证改为逐项独立判定，不再因单个适配器缺失把全部项目显示为“待应用”
- SoC 型号 ID 不再误作唯一 CPU ID；GMS 存在但没有可用 Settings 项时明确报告适配器暂不支持
- 后台守护进程存活判定改用独立启动会话标记，不受已轮换 Boot ID 影响
- 实机确认厂商内核的 Boot ID 直写路径会导致重启，因此本版停用该写入并明确报告暂不支持

## v0.2.0-alpha15

- 移除设备上不支持的 Boot ID、CPU ID 和 Advertising ID 标识面及其生成、写入、恢复、验证和 UI 展示
- 完全移除 Hostname 项，不再修改、恢复或验证系统 Hostname
- 当前标识组与实际读取验证仅保留 Serial、SoC Serial、Android ID 及已验证的 OPLUS OAID
- 覆盖状态继续展示厂商 OAID/GSF/GMS 的探测状态，但不把未知 provider 当作可写入目标

## v0.2.0-alpha18

- 将已验证的 OPLUS/OUID OAID 纳入“当前标识组”原值/现值对照与“实际读取验证”，验证直接读取 provider，并与事务目标值比较。
- 新增 OAID 原值基线和事务目标持久化；优先从保留的全局事务备份恢复旧值，避免升级后把已轮换值当作原值。

## v0.2.0-alpha19

- 移除 IMSI/ICCID 的生成、属性写入、Telephony 回读验证、基线采集和 WebUI 项；升级时清理旧版保存的 telephony 目标。

## v0.2.0-alpha20

- “实际读取验证”改为与“当前标识组”一致的四宫格布局，保留移动端双列显示和逐项验证状态。

## v0.2.0-alpha21

- 完全删除媒体会话守护、扫描目录、白名单和相关运行时清理逻辑。
- 配置架构升级为 v4，安装迁移时清空旧媒体配置；核心模块不再读取或执行媒体守护。

## v0.2.0-alpha22

- WebUI 增加会话心跳与服务端空闲看门狗。
- 页面离开、切后台或关闭浏览器时主动关闭会话并关闭 WebUI 端口；浏览器异常退出由服务端看门狗兜底。
- 连接关闭后显示整页“后台已退出，请重新从管理器打开”提示，不自动重连。

## v0.2.0-alpha24

- Serial 覆盖新增 USB configfs gadget 通道，写入所有现存 gadget/language 的 `serialnumber` 节点。
- 首次写入前持久化各节点原值；关闭设备标识修改或卸载模块时逐节点恢复。
- Serial 实际读取验证同时核验系统属性和 USB configfs；守护循环会在 USB gadget 被系统重建后重新捕获并应用。
- 适配器不更改 USB 功能组合、ADB 开关、UDC 控制器选择或最终绑定状态。
- 成功写入后短暂重绑定当前 UDC，使已经连接的主机重新枚举并读取新 Serial；保留原控制器名称并在失败时重试恢复绑定。

## v0.2.0-alpha25

- 发布包名称统一为 `设备身份标识管理-版本-arm64-run-once.zip`，模块 ID 保持不变以兼容覆盖升级。
- WebUI 顶栏品牌字标和右上角状态图形改为设备身份校验图标，在线状态圆点继续独立显示。

## v0.2.0-alpha17

- 修复 OPLUS OAID provider 在 uid 0 调用时返回空 `OUID` 的实机兼容问题：只读回查子进程使用 Android shell uid/gid，事务文件读写仍保持原有权限边界。
- 增加真实 `content call` 输出解析测试及 SDK 测试控制器；控制器仅用于实机验证，不进入发布包。

## v0.2.0-alpha16

- 新增 OnePlus/OPLUS `OUID` 适配器，覆盖 `/data/system/openid_config.xml` 中所有已存在用户的 OAID
- 严格校验 `openid_config` v1、用户键与 64 位十六进制值，未知格式保持只读探测
- OPLUS OAID 纳入全局事务的预检、哈希、备份、原子替换、回滚与 SELinux 标签恢复
- 开机后通过 `com.oplus.omes.oaid_status_provider` 实际回读主用户 OAID并与文件值核验

## v1.0.0-alpha3

- SoC Serial 改为运行时适配器：按 `socX`、`/sys/devices/system/soc`、平台/SoC
  子树、SoC bus、`/sys/class/soc` 和 device-tree（含 `chosen`）路径探测，覆盖
  天玑内核常见的嵌套 sysfs 布局。
- Serial 生成会保留设备当前序列号的字符形状和长度，兼容常见的 8 位序列号。
- 数字 SoC Serial 轮换保持原长度和无前导零格式；10 位值的首位限制为 `1~3`，
  保持与随机设备序列号模块相同的 `uint32_t` 兼容范围。
- 快速更换设备标识同时轮换已识别的 OAID；可用 provider 通常即时回读，无需重启。
- 保留 Qualcomm serial hook，并增加 MTK/MediaTek `serial_number_show` 符号筛选、去重与逐项回退。
- device-tree 仅作为只读来源，不安装该路径的 hook；没有可读 SoC 来源时不生成随机占位目标。
- 持久化最近命中的适配器路径，节点变化后自动重新探测；新增 MTK fixture 与回归测试。
- 合并天玑适配更新，并保持顶层 `socX` 优先于嵌套节点；增加实际 C++ 适配器的
  路径选择、别名、DT 缓存升级和失效回退测试。离线测试不等同于天玑实机 hook 验证。

## v1.0.0-alpha4

- 修复 OPLUS OAID 文件已改而系统服务内存缓存未更新的问题。快速更换改用厂商
  `clearStdid`/`getStdid` 的 OUID 接口，仅处理主用户，不直接覆盖 OPLUS XML。
- provider 实际回读匹配新值才报告成功；未更换显示“尚未更换”，失败保留具体原因，
  当前值展示实际读数，不将未知/不支持接口视为已应用。
- OAID 失败不撤销已经成功的其它核心标识；快速更换完成或失败都会等待新的状态读取。
- 延后执行的系统 OAID 使用可打印十六进制存储，修复 SDK 字符串接口截断 NUL 前缀的问题。
- 构建新增 JDK 和 Android SDK D8 依赖，`build_oaid_helper.py` 生成私有 DEX 资源。
  可设置 `ANDROID_SDK_ROOT` 或 `D8_JAR`；资源和源码哈希一致时复用现有资源。
- 厂商运行时重置没有任意值回写接口；不能用 XML 文件恢复来声称实时 OAID 已回滚。
  全局重置仍使用原先的重启事务，与快速更换独立。
- 模块安装或升级后需要重启设备，才能进入新的启动周期并加载新版本。

## v1.0.0-alpha5（待实机复测）

- DRM 回滚保留旧标识值，但使用大于文件和内核当前值的新 generation，避免旧版本号
  被内核拒绝；相同 generation 不同内容拒绝发布，响应与目标不符不能报告成功。
- USB 识别系统先行完成的同控制器回绑；失败时恢复本次调用前的序列号和已捕获的
  UDC 控制器，并区分恢复成功与恢复失败，不误用首次安装原值作本次回滚。
- supervisor 用进程锁保证单实例，前端操作期间保持业务按钮互斥，失败日志分开记录
  原因与 DRM 恢复结果。
- 状态接口只读取一次 DRM 快照；启动及未稳定状态继续自动刷新，稳定后停止轮询。
- 保留既定会话关闭规则：隐藏页面、导航或冻结时关闭；可见页面仅短暂失焦不关闭。
- 当前设备 ADB 返回 `fork failed: Try again`，无法完成新包安装及重启后的复测。
  此错误原因尚未证实，不能归因于 WebUI 关闭；需手动重启恢复设备后继续验证。

## v1.0.0-alpha6 合并

- 合并开发者的 SoC 外围节点过滤、旧路径缓存迁移、UFS 辅助/回退通道和晚启动 Hook 重试。
  UFS 是存储序列号，不等同于处理器序列号；界面和验证来源分别标注。
- 保留已有顶层 `socX` 优先级，拒绝指向外围设备的 SoC 别名；扫描有条目预算，
  UFS 缺失时最多每 30 秒重新扫描一次。
- 合并 Binder 无关事务提前过滤、按需 Worker、无 HAL 等待及退出拆除 Hook、
  10/20/40 秒退避和 5 分钟冷却。只有正常运行的 Worker 能重置失败预算。
- 补齐等待期间的 DRM 配置重新载入和状态请求同步；保持 OAID 实时更换、单实例保护、
  generation 递增回滚及 UI 刷新等 alpha4/alpha5 修复，不导入附件中的旧实现。
- 附件的发热验证文档是测量方案，不是实测温度结论；本次合并不安装模块或操作手机。

## v1.0.1

- 版本号统一为 `1.0.1`，当前发布版本不再使用 `-alpha` 后缀。功能与此前 alpha6 合并版本一致。
