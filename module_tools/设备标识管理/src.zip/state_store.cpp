#include "state_store.h"

#include "kernel_module_kit_umbrella.h"

namespace jiebiao {
namespace {

constexpr const char* kSchema = "config_schema";
constexpr const char* kMasterEnabled = "master_enabled";
constexpr const char* kActionSequence = "action_sequence";
constexpr const char* kActionType = "action_type";
constexpr const char* kActionPayload = "action_payload";
constexpr const char* kActionResultSequence = "action_result_sequence";
constexpr const char* kActionResult = "action_result";
constexpr const char* kDaemonPid = "daemon_pid";
constexpr const char* kDaemonBoot = "daemon_boot_id";
constexpr const char* kLegacyConflictId = "legacy_conflict_id";
constexpr const char* kLegacyConflictVersion = "legacy_conflict_version";

}  // namespace

bool storage_read_string(const char* key, std::string& value) {
    value.clear();
    return is_ok(kernel_module::read_string_disk_storage(key, value));
}

bool storage_write_string(const char* key, const std::string& value) {
    return is_ok(kernel_module::write_string_disk_storage(key, value.c_str()));
}

bool storage_read_bool(const char* key, bool& value) {
    return is_ok(kernel_module::read_bool_disk_storage(key, value));
}

bool storage_write_bool(const char* key, bool value) {
    return is_ok(kernel_module::write_bool_disk_storage(key, value));
}

bool storage_read_u32(const char* key, uint32_t& value) {
    return is_ok(kernel_module::read_uint32_disk_storage(key, value));
}

bool storage_write_u32(const char* key, uint32_t value) {
    return is_ok(kernel_module::write_uint32_disk_storage(key, value));
}

bool storage_read_i32(const char* key, int32_t& value) {
    return is_ok(kernel_module::read_int32_disk_storage(key, value));
}

bool storage_write_i32(const char* key, int32_t value) {
    return is_ok(kernel_module::write_int32_disk_storage(key, value));
}

ModuleConfig load_config() {
    ModuleConfig config;
    config.schema_version = kConfigSchemaVersion;
    storage_read_bool(kMasterEnabled, config.master_enabled);
    return config;
}

bool save_config(const ModuleConfig& config) {
    bool ok = true;
    ok = storage_write_bool(kMasterEnabled, config.master_enabled) && ok;
    // Retire the former patch-date setting so upgrades do not retain a
    // configuration surface that is no longer supported.
    ok = storage_write_string("security_patch", "") && ok;
    ok = storage_write_u32(kSchema, kConfigSchemaVersion) && ok;
    return ok;
}

bool clear_removed_model_config() {
    bool ok = true;
    ok = storage_write_bool("device_names_enabled", false) && ok;
    ok = storage_write_string("selected_template", "") && ok;
    ok = storage_write_bool("media_enabled", false) && ok;
    ok = storage_write_string("media_packages", "") && ok;
    ok = storage_write_string("media_roots", "") && ok;
    ok = storage_write_string("media_suffixes", "") && ok;
    ok = storage_write_string("media_keywords", "") && ok;
    return ok;
}

uint32_t enqueue_action(const std::string& type, const std::string& payload) {
    uint32_t sequence = 0;
    storage_read_u32(kActionSequence, sequence);
    sequence = sequence == UINT32_MAX ? 1 : sequence + 1;
    if (!storage_write_string(kActionType, type) ||
        !storage_write_string(kActionPayload, payload) ||
        !storage_write_u32(kActionSequence, sequence)) {
        return 0;
    }
    return sequence;
}

bool read_action_after(uint32_t last_sequence, PendingAction& action) {
    uint32_t sequence = 0;
    if (!storage_read_u32(kActionSequence, sequence) || sequence == 0 || sequence == last_sequence) {
        return false;
    }
    std::string type;
    std::string payload;
    if (!storage_read_string(kActionType, type) || type.empty()) return false;
    storage_read_string(kActionPayload, payload);
    action.sequence = sequence;
    action.type = std::move(type);
    action.payload = std::move(payload);
    return true;
}

bool write_action_result(uint32_t sequence, const std::string& result_json) {
    return storage_write_string(kActionResult, result_json) &&
           storage_write_u32(kActionResultSequence, sequence);
}

std::string read_action_result(uint32_t* sequence) {
    uint32_t stored_sequence = 0;
    storage_read_u32(kActionResultSequence, stored_sequence);
    if (sequence) *sequence = stored_sequence;
    std::string result;
    storage_read_string(kActionResult, result);
    return result;
}

bool store_daemon_identity(int32_t pid, const std::string& current_boot_id) {
    return storage_write_string(kDaemonBoot, current_boot_id) &&
           storage_write_i32(kDaemonPid, pid);
}

bool read_daemon_identity(int32_t& pid, std::string& current_boot_id) {
    pid = 0;
    current_boot_id.clear();
    return storage_read_i32(kDaemonPid, pid) &&
           storage_read_string(kDaemonBoot, current_boot_id);
}

bool set_legacy_conflict(const std::string& module_id,
                         const std::string& version) {
    return storage_write_string(kLegacyConflictVersion, version) &&
           storage_write_string(kLegacyConflictId, module_id);
}

void clear_legacy_conflict() {
    storage_write_string(kLegacyConflictId, "");
    storage_write_string(kLegacyConflictVersion, "");
}

bool read_legacy_conflict(std::string& module_id, std::string& version) {
    module_id.clear();
    version.clear();
    storage_read_string(kLegacyConflictVersion, version);
    return storage_read_string(kLegacyConflictId, module_id) &&
           !module_id.empty();
}

}  // namespace jiebiao
