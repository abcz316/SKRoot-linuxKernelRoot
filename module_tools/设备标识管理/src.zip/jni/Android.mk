LOCAL_PATH := $(call my-dir)
KERNEL_MODULE_KIT := $(LOCAL_PATH)/../.sdk-cache/kernel_module_kit

include $(CLEAR_VARS)
LOCAL_MODULE := kernel_module_kit_static_prebuilt
LOCAL_SRC_FILES := ../.sdk-cache/kernel_module_kit/lib/libkernel_module_kit_static.a
include $(PREBUILT_STATIC_LIBRARY)

# Single SKP module entry: Jiebiao supervisor + DRM worker management.
include $(CLEAR_VARS)
LOCAL_MODULE := module_device_identity_manager
LOCAL_SRC_FILES := \
    ../module_main.cpp \
    ../common.cpp \
    ../state_store.cpp \
    ../property_engine.cpp \
    ../identity_engine.cpp \
    ../usb_serial_engine.cpp \
    ../oaid_engine.cpp \
    ../ssaid_engine.cpp \
    ../reset_transaction.cpp \
    ../patch_base.cpp \
    ../patch_soc_info_show.cpp \
    ../patch_msm_get_serial_number.cpp \
    ../soc_serial_adapter.cpp \
    ../operations.cpp \
    ../daemon.cpp \
    ../web_ui.cpp \
    ../drmid_worker.cpp \
    ../drmid_backend.cpp \
    ../hal_identity.cpp \
    ../startup_readiness.cpp \
    ../runtime_control.cpp \
    ../runtime_profile.cpp \
    ../device_id_fingerprint.cpp \
    ../file_lifecycle.cpp \
    ../control_ipc.cpp \
    ../binder_ioctl_resolver.cpp \
    ../binder_hook_builder.cpp
LOCAL_C_INCLUDES += $(KERNEL_MODULE_KIT)/include $(LOCAL_PATH)/..
LOCAL_STATIC_LIBRARIES := kernel_module_kit_static_prebuilt
LOCAL_LDLIBS += -landroid -lmediandk -lz
include $(LOCAL_PATH)/build_macros.mk
include $(BUILD_SHARED_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := device_identity_drm_worker
LOCAL_SRC_FILES := \
    ../device_identity_drm_worker_main.cpp \
    ../drmid_worker.cpp \
    ../drmid_backend.cpp \
    ../hal_identity.cpp \
    ../startup_readiness.cpp \
    ../runtime_control.cpp \
    ../runtime_profile.cpp \
    ../device_id_fingerprint.cpp \
    ../file_lifecycle.cpp \
    ../control_ipc.cpp \
    ../binder_ioctl_resolver.cpp \
    ../binder_hook_builder.cpp
LOCAL_C_INCLUDES += $(KERNEL_MODULE_KIT)/include $(LOCAL_PATH)/..
LOCAL_STATIC_LIBRARIES := kernel_module_kit_static_prebuilt
LOCAL_LDLIBS += -landroid -lmediandk -lz
include $(LOCAL_PATH)/build_macros.mk
include $(BUILD_EXECUTABLE)
