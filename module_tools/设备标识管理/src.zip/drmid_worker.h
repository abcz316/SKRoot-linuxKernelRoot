#pragma once

#include <sys/types.h>

#include <cstdint>
#include <string>

#include "binder_hook_builder.h"
#include "control_ipc.h"

namespace device_identity::drm {

inline constexpr const char* kLegacyJiebiaoModuleId =
    "jiebiaoSkpDeviceIdentity20260814";
inline constexpr const char* kLegacyDrmidModuleId =
    "drmidKern612Probe20260728Alpha01";

enum class WorkerState : uint32_t {
    kDisabled = 0,
    kStarting = 1,
    kRunning = 2,
    kStopped = 3,
    kFailed = 4,
    kWaitingHal = 5,
};

struct ConflictStatus {
    bool detected = false;
    std::string module_id;
    std::string module_version;
};

struct Status {
    WorkerState state = WorkerState::kStopped;
    pid_t pid = 0;
    int32_t last_result = 0;
    bool control_connected = false;
    // The worker is alive but has not connected its Binder control endpoint
    // yet. During boot this is the intentional stability gate, not a dead
    // backend; the WebUI uses it to show the full-page re-entry notice.
    bool startup_waiting = false;
    drmid::ControlIpcResponse control{};
    std::string kernel_release;
    std::string binder_backend;
    std::string resolution_source;
    std::string file_offset_source;
    std::string ioctl_offset_source;
    std::string capabilities;
    std::string entry_fingerprint;
    uint32_t entry_semantics = 0;
    uint32_t symbol_validations = 0;
    std::string device_fingerprint;
};

bool detect_legacy_module_conflict(const char* root_key,
                                   ConflictStatus& status);

std::string worker_path(const std::string& private_dir);
bool start_worker(const std::string& private_dir,
                  bool resolve_only,
                  std::string& detail,
                  const std::string& root_key = {});
bool stop_worker(const std::string& private_dir, std::string& detail);
bool worker_alive(const std::string& private_dir, pid_t* pid = nullptr);
bool mark_startup_waiting(const std::string& private_dir, bool waiting);
bool mark_waiting_hal(const std::string& private_dir, bool waiting);
Status read_status(const std::string& private_dir);

bool initialize_runtime(const std::string& private_dir,
                        drmid::ReplacementConfig& config,
                        bool& created,
                        std::string& detail);
bool read_runtime(const std::string& private_dir,
                  drmid::ReplacementConfig& config,
                  std::string& detail);
bool write_runtime(const std::string& private_dir,
                   const drmid::ReplacementConfig& config,
                   std::string& detail);
bool publish_runtime(const std::string& private_dir,
                     const drmid::ReplacementConfig& config,
                     drmid::ControlIpcResponse* response,
                     std::string& detail);
// Compatibility entry point for older callers.  The identity master switch
// controls both the published replacement mode and whether the Binder worker
// is resident; disabled is a hook-free, worker-free state.
bool set_runtime_mode(const std::string& private_dir,
                      drmid::ReplacementMode mode,
                      bool publish,
                      drmid::ControlIpcResponse* response,
                      std::string& detail);
bool set_enabled(const std::string& private_dir,
                 bool enabled,
                 std::string& detail,
                 const std::string& root_key = {});
// Produces the next generation entirely in memory.  Callers decide when the
// control record is committed/published so multi-surface transactions never
// expose a temporary DRM generation during preflight.
bool build_randomized_runtime(const drmid::ReplacementConfig& previous,
                              drmid::ReplacementConfig& next,
                              std::string& detail);
bool randomize_runtime(const std::string& private_dir,
                       drmid::ReplacementConfig& previous,
                       drmid::ReplacementConfig& next,
                       std::string& detail);
bool restore_runtime(const std::string& private_dir,
                     const drmid::ReplacementConfig& previous,
                     std::string& detail);
std::string serialize_runtime(const drmid::ReplacementConfig& config);
bool parse_runtime(const std::string& text,
                   drmid::ReplacementConfig& config);

std::string status_json(const Status& status);

// Standalone worker entry used by webroot/device_identity_drm_worker.
int worker_main(const char* module_private_dir);

}  // namespace device_identity::drm
