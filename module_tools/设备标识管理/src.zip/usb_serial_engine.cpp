#include "usb_serial_engine.h"

#include "common.h"
#include "state_store.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <filesystem>
#include <map>
#include <sstream>
#include <system_error>
#include <vector>

namespace jiebiao {
namespace {

namespace fs = std::filesystem;

constexpr const char* kUsbSerialOriginalsV1 = "usb_gadget_serial_originals_v1";
constexpr const char* kUsbSerialBoundTargetV1 = "usb_gadget_serial_bound_target_v1";
constexpr const char* kConfigfsRoots[] = {
    "/config/usb_gadget",
    "/sys/kernel/config/usb_gadget",
};
constexpr size_t kMaxUsbNodes = 64;
constexpr size_t kMaxUsbSerialLength = 126;

using OriginalMap = std::map<std::string, std::string>;

bool safe_component(const std::string& value) {
    if (value.empty() || value.size() > 64) return false;
    return std::all_of(value.begin(), value.end(), [](unsigned char ch) {
        return std::isalnum(ch) || ch == '.' || ch == '_' || ch == '-';
    });
}

bool valid_usb_serial(const std::string& value) {
    if (value.empty() || value.size() > kMaxUsbSerialLength) return false;
    return std::all_of(value.begin(), value.end(), [](unsigned char ch) {
        return ch >= 0x20 && ch <= 0x7e && ch != '\t';
    });
}

bool safe_usb_serial_path(const std::string& path) {
    for (const char* root : kConfigfsRoots) {
        const std::string prefix = std::string(root) + '/';
        if (!path.starts_with(prefix)) continue;
        const std::string relative = path.substr(prefix.size());
        std::vector<std::string> parts;
        size_t cursor = 0;
        while (cursor <= relative.size()) {
            const size_t slash = relative.find('/', cursor);
            parts.push_back(relative.substr(cursor, slash == std::string::npos
                                                        ? std::string::npos
                                                        : slash - cursor));
            if (slash == std::string::npos) break;
            cursor = slash + 1;
        }
        return parts.size() == 4 && safe_component(parts[0]) && parts[1] == "strings" &&
               safe_component(parts[2]) && parts[3] == "serialnumber";
    }
    return false;
}

bool safe_usb_udc_path(const std::string& path) {
    for (const char* root : kConfigfsRoots) {
        const std::string prefix = std::string(root) + '/';
        if (!path.starts_with(prefix)) continue;
        const std::string relative = path.substr(prefix.size());
        const size_t slash = relative.find('/');
        return slash != std::string::npos && relative.find('/', slash + 1) == std::string::npos &&
               safe_component(relative.substr(0, slash)) && relative.substr(slash + 1) == "UDC";
    }
    return false;
}

bool real_directory(const fs::directory_entry& entry) {
    std::error_code error;
    const fs::file_status status = entry.symlink_status(error);
    return !error && fs::is_directory(status) && !fs::is_symlink(status);
}

bool real_regular_file(const fs::path& path) {
    struct stat st{};
    return lstat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode) && !S_ISLNK(st.st_mode);
}

std::vector<std::string> discover_usb_serial_nodes() {
    for (const char* root_value : kConfigfsRoots) {
        std::vector<std::string> nodes;
        const fs::path root(root_value);
        std::error_code error;
        for (fs::directory_iterator gadget_it(root, fs::directory_options::skip_permission_denied, error), end;
             gadget_it != end && !error && nodes.size() < kMaxUsbNodes; gadget_it.increment(error)) {
            if (!real_directory(*gadget_it) || !safe_component(gadget_it->path().filename().string())) continue;
            const fs::path strings = gadget_it->path() / "strings";
            std::error_code strings_error;
            for (fs::directory_iterator language_it(
                     strings, fs::directory_options::skip_permission_denied, strings_error), language_end;
                 language_it != language_end && !strings_error && nodes.size() < kMaxUsbNodes;
                 language_it.increment(strings_error)) {
                if (!real_directory(*language_it) ||
                    !safe_component(language_it->path().filename().string())) continue;
                const fs::path candidate = language_it->path() / "serialnumber";
                const std::string path = candidate.string();
                if (safe_usb_serial_path(path) && real_regular_file(candidate)) nodes.push_back(path);
            }
        }
        if (!nodes.empty()) {
            std::sort(nodes.begin(), nodes.end());
            nodes.erase(std::unique(nodes.begin(), nodes.end()), nodes.end());
            return nodes;
        }
    }
    return {};
}

bool read_usb_serial(const std::string& path, std::string& value) {
    if (!safe_usb_serial_path(path) || !read_stream_file(path, value, 256)) return false;
    value = trim(std::move(value));
    return valid_usb_serial(value);
}

bool write_usb_serial(const std::string& path, const std::string& value) {
    if (!safe_usb_serial_path(path) || !valid_usb_serial(value)) return false;
    const int fd = open(path.c_str(), O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return false;
    struct stat st{};
    bool ok = fstat(fd, &st) == 0 && S_ISREG(st.st_mode);
    size_t done = 0;
    while (ok && done < value.size()) {
        const ssize_t count = write(fd, value.data() + done, value.size() - done);
        if (count > 0) done += static_cast<size_t>(count);
        else if (count < 0 && errno == EINTR) continue;
        else ok = false;
    }
    close(fd);
    std::string readback;
    return ok && read_usb_serial(path, readback) && readback == value;
}

bool write_configfs_control(const std::string& path, const std::string& value) {
    if (!safe_usb_udc_path(path) || value.empty() || value.size() > 128 || !real_regular_file(path)) {
        return false;
    }
    const int fd = open(path.c_str(), O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return false;
    size_t done = 0;
    bool ok = true;
    while (done < value.size()) {
        const ssize_t count = write(fd, value.data() + done, value.size() - done);
        if (count > 0) done += static_cast<size_t>(count);
        else if (count < 0 && errno == EINTR) continue;
        else { ok = false; break; }
    }
    close(fd);
    return ok;
}

struct BoundUdc {
    std::string path;
    std::string controller;
};

std::vector<BoundUdc> discover_bound_udcs() {
    for (const char* root_value : kConfigfsRoots) {
        std::vector<BoundUdc> result;
        const fs::path root(root_value);
        std::error_code error;
        for (fs::directory_iterator it(root, fs::directory_options::skip_permission_denied, error), end;
             it != end && !error && result.size() < kMaxUsbNodes; it.increment(error)) {
            if (!real_directory(*it) || !safe_component(it->path().filename().string())) continue;
            const std::string path = (it->path() / "UDC").string();
            if (!safe_usb_udc_path(path) || !real_regular_file(path)) continue;
            std::string controller;
            if (!read_stream_file(path, controller, 256)) continue;
            controller = trim(std::move(controller));
            if (!controller.empty() && safe_component(controller)) result.push_back({path, controller});
        }
        if (!result.empty()) return result;
    }
    return {};
}

bool rebind_udc(const BoundUdc& udc) {
    if (!write_configfs_control(udc.path, "\n")) return false;
    usleep(50000);
    for (int attempt = 0; attempt < 8; ++attempt) {
        std::string current;
        // Android's USB service can restore the same UDC first. EBUSY from
        // our write then is not a failure if the controller is already bound.
        if (read_stream_file(udc.path, current, 256)) {
            current = trim(std::move(current));
            if (current == udc.controller) return true;
            if (!current.empty()) return false;  // Never replace another owner.
        }
        write_configfs_control(udc.path, udc.controller);
        if (read_stream_file(udc.path, current, 256) && trim(std::move(current)) == udc.controller) return true;
        usleep(100000);
    }
    return false;
}

bool rebind_active_gadgets(size_t& rebound, size_t& failed) {
    rebound = 0;
    failed = 0;
    const auto udcs = discover_bound_udcs();
    for (const auto& udc : udcs) {
        if (rebind_udc(udc)) ++rebound;
        else ++failed;
    }
    return failed == 0;
}

std::string serialize_originals(const OriginalMap& originals) {
    std::string output;
    for (const auto& [path, value] : originals) output += path + '\t' + value + '\n';
    return output;
}

bool parse_originals(const std::string& text, OriginalMap& originals) {
    originals.clear();
    for (const auto& line : split_lines(text)) {
        if (line.empty()) continue;
        const size_t tab = line.find('\t');
        if (tab == std::string::npos) return false;
        const std::string path = line.substr(0, tab);
        const std::string value = line.substr(tab + 1);
        if (!safe_usb_serial_path(path) || !valid_usb_serial(value)) return false;
        originals[path] = value;
    }
    return true;
}

std::string result_detail(const UsbGadgetSerialResult& result, const char* stage) {
    return std::string(stage) + ",nodes=" + std::to_string(result.detected) +
           ",applied=" + std::to_string(result.applied) +
           ",failed=" + std::to_string(result.failed) +
           ",rebound=" + std::to_string(result.rebound);
}

}  // namespace

UsbGadgetSerialResult apply_usb_gadget_serial(const std::string& serial) {
    UsbGadgetSerialResult result;
    if (!valid_usb_serial(serial)) {
        result.failed = 1;
        result.detail = "invalid-target";
        return result;
    }
    const std::vector<std::string> nodes = discover_usb_serial_nodes();
    result.detected = nodes.size();
    if (nodes.empty()) {
        result.detail = "absent";
        return result;
    }

    std::string stored;
    storage_read_string(kUsbSerialOriginalsV1, stored);
    OriginalMap originals;
    if (!parse_originals(stored, originals)) {
        result.failed = nodes.size();
        result.detail = "originals-corrupt";
        return result;
    }
    for (const auto& path : nodes) {
        if (originals.contains(path)) continue;
        std::string original;
        if (!read_usb_serial(path, original)) {
            ++result.failed;
            continue;
        }
        originals[path] = original;
    }
    if (result.failed != 0) {
        result.detail = result_detail(result, "capture-failed");
        return result;
    }
    if (!storage_write_string(kUsbSerialOriginalsV1, serialize_originals(originals))) {
        result.failed = nodes.size();
        result.detail = result_detail(result, "save-originals-failed");
        return result;
    }
    OriginalMap previous;
    for (const auto& path : nodes) {
        if (!read_usb_serial(path, previous[path])) ++result.failed;
    }
    if (result.failed != 0) {
        result.detail = result_detail(result, "snapshot-failed");
        return result;
    }
    const auto previous_udcs = discover_bound_udcs();
    std::string bound_target;
    storage_read_string(kUsbSerialBoundTargetV1, bound_target);
    bool changed = false;
    for (const auto& path : nodes) {
        std::string current;
        if (read_usb_serial(path, current) && current == serial) {
            ++result.applied;
        } else if (write_usb_serial(path, serial)) {
            ++result.applied;
            changed = true;
        } else {
            ++result.failed;
        }
    }
    const bool needs_rebind = result.failed == 0 && (changed || bound_target != serial);
    if (needs_rebind) {
        size_t rebind_failed = 0;
        rebind_active_gadgets(result.rebound, rebind_failed);
        result.failed += rebind_failed;
        if (result.rebound != 0 && rebind_failed == 0) {
            if (!storage_write_string(kUsbSerialBoundTargetV1, serial)) ++result.failed;
        }
    }
    if (result.failed != 0) {
        // Do not leave a subset of gadget language nodes on the new target.
        // A failed UDC rebind or one write must be an atomic failure from the
        // identity transaction's perspective.
        bool restored = true;
        for (const auto& [path, value] : previous) {
            restored = write_usb_serial(path, value) && restored;
        }
        for (const auto& udc : previous_udcs) restored = rebind_udc(udc) && restored;
        const bool marker_ok = storage_write_string(kUsbSerialBoundTargetV1, restored ? bound_target : "");
        restored = restored && marker_ok;
        result.detail = result_detail(result, restored ? "partial-rolled-back" : "partial-rollback-failed");
        return result;
    }
    result.detail = result_detail(result, "ok");
    return result;
}

UsbGadgetSerialResult restore_usb_gadget_serial() {
    UsbGadgetSerialResult result;
    std::string stored;
    storage_read_string(kUsbSerialOriginalsV1, stored);
    if (stored.empty()) {
        result.detail = "not-captured";
        return result;
    }
    OriginalMap originals;
    if (!parse_originals(stored, originals)) {
        result.failed = 1;
        result.detail = "originals-corrupt";
        return result;
    }
    result.detected = originals.size();
    OriginalMap remaining;
    for (const auto& [path, original] : originals) {
        if (access(path.c_str(), F_OK) != 0) {
            ++result.applied;
        } else if (write_usb_serial(path, original)) {
            ++result.applied;
        } else {
            ++result.failed;
            remaining[path] = original;
        }
    }
    if (result.failed == 0 && result.applied != 0) {
        size_t rebind_failed = 0;
        rebind_active_gadgets(result.rebound, rebind_failed);
        result.failed += rebind_failed;
    }
    if (result.failed != 0) remaining = originals;
    if (!storage_write_string(kUsbSerialOriginalsV1, serialize_originals(remaining))) {
        ++result.failed;
    }
    if (result.failed == 0) storage_write_string(kUsbSerialBoundTargetV1, "");
    result.detail = result_detail(result, result.failed == 0 ? "restored" : "restore-partial");
    return result;
}

UsbGadgetSerialReadback verify_usb_gadget_serial(const std::string& expected) {
    UsbGadgetSerialReadback result;
    result.source = "USB configfs gadget";
    if (!valid_usb_serial(expected)) {
        result.state = "error";
        result.detail = "invalid-target";
        return result;
    }
    const std::vector<std::string> nodes = discover_usb_serial_nodes();
    result.detected = nodes.size();
    if (nodes.empty()) {
        result.state = "absent";
        result.detail = "no-configfs-node";
        return result;
    }
    size_t passed = 0;
    size_t unreadable = 0;
    for (const auto& path : nodes) {
        std::string value;
        if (!read_usb_serial(path, value)) ++unreadable;
        else if (value == expected) ++passed;
    }
    if (unreadable != 0) result.state = "error";
    else if (passed == nodes.size()) result.state = "passed";
    else result.state = "mismatch";
    result.detail = "nodes=" + std::to_string(nodes.size()) +
                    ",passed=" + std::to_string(passed) +
                    ",unreadable=" + std::to_string(unreadable);
    return result;
}

}  // namespace jiebiao
