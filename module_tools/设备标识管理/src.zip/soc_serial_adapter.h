#pragma once

#include <string>

namespace jiebiao::soc_serial {

// A readback describes the concrete kernel surface used for SoC serials.
// `hookable` only means the surface is a sysfs show file; the caller still
// needs to discover a compatible kernel show symbol before installing a hook.
struct Readback {
    std::string value;
    std::string path;
    std::string source;
    std::string detail;
    bool readable = false;
    bool hookable = false;
};

// Probe the first usable serial surface from the ordered adapter list.  The
// UFS entry is intentionally available as an explicit fallback for kernels
// which do not expose an SoC serial node; it is labeled separately so the UI
// and verifier do not confuse it with the application-processor serial.
Readback probe_ufs_serial();

// Probe the last successful path first, then discover standard SoC/bus and
// device-tree surfaces. The selected path is persisted for diagnostics and is
// re-discovered automatically when a kernel update removes it.
Readback probe();

// Read a specific candidate path, normalising NUL-terminated device-tree data.
Readback read_path(const std::string& path);

}  // namespace jiebiao::soc_serial
