#include "operations.h"

#include "common.h"
#include "reset_transaction.h"
#include "ssaid_engine.h"
#include "state_store.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <filesystem>
#include <sstream>

namespace fs = std::filesystem;

namespace jiebiao {
namespace {

constexpr const char* kPendingSsaidPackagesV1 = "pending_ssaid_packages";
constexpr const char* kPendingSsaidRequestsV2 = "pending_ssaid_requests_v2";
constexpr const char* kPostBootClearPackages = "post_boot_clear_packages";
constexpr const char* kLastEarlyOperation = "last_early_operation";

struct SsaidRequest {
    std::string user_selector;
    std::string package_name;
};

std::string private_backup_dir(const std::string& private_dir) {
    std::string path = private_dir;
    if (!path.empty() && path.back() != '/') path.push_back('/');
    path += "backups";
    mkdir(path.c_str(), 0700);
    chmod(path.c_str(), 0700);
    return path;
}

std::vector<SsaidRequest> parse_requests(const std::string& text) {
    std::vector<SsaidRequest> requests;
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        const size_t tab = line.find('\t');
        if (tab == std::string::npos) continue;
        SsaidRequest request{line.substr(0, tab), line.substr(tab + 1)};
        bool all = false;
        uint32_t user = 0;
        if (!valid_package_name(request.package_name) ||
            !parse_user_selector(request.user_selector, all, user)) continue;
        const bool duplicate = std::any_of(requests.begin(), requests.end(), [&](const auto& item) {
            return item.user_selector == request.user_selector && item.package_name == request.package_name;
        });
        if (!duplicate) requests.push_back(std::move(request));
    }
    return requests;
}

std::string serialize_requests(const std::vector<SsaidRequest>& requests) {
    std::string text;
    for (const auto& request : requests) text += request.user_selector + "\t" + request.package_name + "\n";
    return text;
}

bool apply_single_request(const std::string& private_dir,
                          const AndroidUserInfo& user,
                          const std::string& package_name,
                          std::string& detail) {
    const std::string replacement = random_hex(16);
    SsaidDocument document;
    if (!load_ssaid_document(private_dir, user, "single-u" + std::to_string(user.id), document, detail)) return false;
    size_t changed = 0;
    if (!reset_package_ssaid_xml(document.xml, package_name, replacement, changed, detail)) return false;
    std::string encoded;
    if (!encode_ssaid_document(private_dir, document, document.xml,
                               "single-u" + std::to_string(user.id), encoded, detail)) return false;

    const std::string fallback_path = user.path + ".fallback";
    AndroidUserInfo fallback_user;
    SsaidDocument fallback_document;
    std::string fallback_encoded;
    std::string fallback_detail;
    const bool has_fallback = inspect_ssaid_file(user.id, fallback_path, fallback_user, fallback_detail);
    if (!has_fallback && fallback_detail != "absent") {
        detail = "fallback-" + fallback_detail;
        return false;
    }
    if (has_fallback) {
        if (!fallback_user.ready ||
            !load_ssaid_document(private_dir, fallback_user,
                                 "single-fallback-u" + std::to_string(user.id),
                                 fallback_document, fallback_detail)) {
            detail = "fallback-" + fallback_detail;
            return false;
        }
        size_t fallback_changed = 0;
        if (!reset_package_ssaid_xml(fallback_document.xml, package_name, replacement,
                                     fallback_changed, fallback_detail) ||
            !encode_ssaid_document(private_dir, fallback_document, fallback_document.xml,
                                   "single-fallback-u" + std::to_string(user.id),
                                   fallback_encoded, fallback_detail)) {
            detail = "fallback-" + fallback_detail;
            return false;
        }
    }

    const std::string backup = private_backup_dir(private_dir) + "/ssaid-u" + std::to_string(user.id) + "-before-single.bak";
    if (!write_file_atomic(backup, document.original, 0600, false)) { detail = "backup-failed"; return false; }
    const std::string fallback_backup = backup + ".fallback";
    if (has_fallback && !write_file_atomic(fallback_backup, fallback_document.original, 0600, false)) {
        detail = "fallback-backup-failed";
        return false;
    }
    auto write_document = [](const std::string& path, const std::string& data) {
        return write_file_atomic(path, data, 0600, true) &&
               run_process({"/system/bin/restorecon", path}) == 0;
    };
    if (!write_document(user.path, encoded)) {
        const bool restored = write_document(user.path, document.original);
        detail = std::string("write-failed,") + (restored ? "rolled-back" : "rollback-failed");
        return false;
    }
    if (has_fallback && !write_document(fallback_path, fallback_encoded)) {
        const bool main_restored = write_document(user.path, document.original);
        const bool fallback_restored = write_document(fallback_path, fallback_document.original);
        detail = std::string("fallback-write-failed,") +
                 (main_restored && fallback_restored ? "rolled-back" : "rollback-failed");
        return false;
    }
    detail = "changed=" + std::to_string(changed) + ",format=" +
             (user.format == SsaidFormat::Abx ? "abx" : "xml") +
             ",fallback=" + (has_fallback ? "updated" : "absent");
    return true;
}

}  // namespace

bool schedule_ssaid_reset(const std::string& package_name,
                          const std::string& user_selector,
                          std::string& message) {
    if (global_reset_pending()) {
        message = "global-reset-pending";
        return false;
    }
    bool all_users = false;
    uint32_t user_id = 0;
    if (!valid_package_name(package_name) ||
        !parse_user_selector(user_selector, all_users, user_id)) {
        message = "invalid-package";
        return false;
    }
    std::string text;
    storage_read_string(kPendingSsaidRequestsV2, text);
    auto requests = parse_requests(text);
    const bool exists = std::any_of(requests.begin(), requests.end(), [&](const auto& request) {
        return request.user_selector == user_selector && request.package_name == package_name;
    });
    if (!exists) {
        requests.push_back({user_selector, package_name});
    }
    if (!storage_write_string(kPendingSsaidRequestsV2, serialize_requests(requests))) {
        message = "storage-write-failed";
        return false;
    }
    message = "scheduled-for-next-boot";
    return true;
}

std::string perform_early_pending_operations(const std::string& private_dir) {
    std::ostringstream report;
    std::vector<SsaidRequest> clear_after_boot;
    const std::string global_result = execute_early_global_reset(private_dir);
    if (!global_result.empty()) {
        report << global_result << '\n';
        storage_write_string(kPendingSsaidRequestsV2, "");
        storage_write_string(kPendingSsaidPackagesV1, "");
    } else {
        std::string pending_v2;
        storage_read_string(kPendingSsaidRequestsV2, pending_v2);
        std::string pending_v1;
        storage_read_string(kPendingSsaidPackagesV1, pending_v1);
        auto requests = parse_requests(pending_v2);
        for (const auto& package_name : split_lines(pending_v1)) {
            if (valid_package_name(package_name)) requests.push_back({"0", package_name});
        }
        const auto users = discover_android_users();
        for (const auto& request : requests) {
            bool all = false;
            uint32_t selected_user = 0;
            parse_user_selector(request.user_selector, all, selected_user);
            bool matched_user = false;
            for (const auto& user : users) {
                if (!all && user.id != selected_user) continue;
                matched_user = true;
                if (!user.ready) {
                    report << "ssaid u" << user.id << ' ' << request.package_name << "=skip(format-unsupported)\n";
                    continue;
                }
                std::string detail;
                const bool ok = apply_single_request(private_dir, user, request.package_name, detail);
                report << "ssaid u" << user.id << ' ' << request.package_name << '='
                       << (ok ? "ok" : "failed") << '(' << detail << ")\n";
                if (ok) clear_after_boot.push_back({std::to_string(user.id), request.package_name});
            }
            if (!matched_user) report << "ssaid " << request.package_name << "=failed(user-not-found)\n";
        }
        storage_write_string(kPendingSsaidRequestsV2, "");
        storage_write_string(kPendingSsaidPackagesV1, "");
    }
    if (!clear_after_boot.empty()) {
        storage_write_string(kPostBootClearPackages, serialize_requests(clear_after_boot));
    }
    const std::string result = report.str();
    if (!result.empty()) storage_write_string(kLastEarlyOperation, result);
    return result;
}

std::string perform_post_boot_operations(const std::string& private_dir) {
    std::string pending;
    storage_read_string(kPostBootClearPackages, pending);
    std::ostringstream report;
    const std::string transaction_result = finalize_global_reset(private_dir);
    if (!transaction_result.empty()) report << transaction_result << '\n';
    for (const auto& request : parse_requests(pending)) {
        bool all = false;
        uint32_t user = 0;
        if (!parse_user_selector(request.user_selector, all, user) || all) continue;
        const int result = run_process({"/system/bin/pm", "clear", "--user", std::to_string(user), request.package_name});
        report << "pm-clear u" << user << ' ' << request.package_name << '=' << result << "\n";
    }
    if (!pending.empty()) storage_write_string(kPostBootClearPackages, "");
    return report.str();
}

std::string recover_post_boot_global_reset(const std::string& private_dir) {
    std::ostringstream report;
    std::string state;
    storage_read_string("global_reset_state_v2", state);
    // A boot path that missed the native early entry can still recover a
    // prepared transaction once system services are available. Runtime
    // polling deliberately only finalizes early-applied transactions so a
    // freshly scheduled reset is never applied in the current boot.
    if (state == "prepared") {
        const std::string early = execute_early_global_reset(private_dir);
        if (!early.empty()) report << early << '\n';
    }
    const std::string post_boot = perform_post_boot_operations(private_dir);
    if (!post_boot.empty()) report << post_boot;
    return report.str();
}

}  // namespace jiebiao
