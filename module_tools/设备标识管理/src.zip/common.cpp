#include "common.h"

#include <android/log.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>

namespace jiebiao {
namespace {

bool fill_random(void* data, size_t size) {
    int fd = open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    size_t done = 0;
    while (done < size) {
        const ssize_t count = read(fd, static_cast<char*>(data) + done, size - done);
        if (count > 0) {
            done += static_cast<size_t>(count);
        } else if (count < 0 && errno == EINTR) {
            continue;
        } else {
            close(fd);
            return false;
        }
    }
    close(fd);
    return true;
}

bool starts_with(std::string_view value, std::string_view prefix) {
    return value.size() >= prefix.size() && value.substr(0, prefix.size()) == prefix;
}

int run_process_internal(const std::vector<std::string>& argv,
                         std::string* output,
                         size_t max_output,
                         bool switch_credentials,
                         uid_t uid,
                         gid_t gid) {
    if (argv.empty() || argv[0].empty()) return -1;
    int pipe_fd[2] = {-1, -1};
    if (output && pipe2(pipe_fd, O_CLOEXEC) != 0) return -1;
    const pid_t child = fork();
    if (child < 0) {
        if (output) { close(pipe_fd[0]); close(pipe_fd[1]); }
        return -1;
    }
    if (child == 0) {
        if (output) {
            close(pipe_fd[0]);
            dup2(pipe_fd[1], STDOUT_FILENO);
            dup2(pipe_fd[1], STDERR_FILENO);
            close(pipe_fd[1]);
        }
        if (switch_credentials && (setgid(gid) != 0 || setuid(uid) != 0)) _exit(126);
        std::vector<char*> args;
        args.reserve(argv.size() + 1);
        for (const auto& item : argv) args.push_back(const_cast<char*>(item.c_str()));
        args.push_back(nullptr);
        execv(args[0], args.data());
        _exit(127);
    }
    if (output) {
        close(pipe_fd[1]);
        output->clear();
        std::array<char, 4096> buffer{};
        while (true) {
            const ssize_t count = read(pipe_fd[0], buffer.data(), buffer.size());
            if (count > 0) {
                const size_t available = output->size() < max_output ? max_output - output->size() : 0;
                output->append(buffer.data(), std::min(available, static_cast<size_t>(count)));
            }
            else if (count < 0 && errno == EINTR) continue;
            else break;
        }
        close(pipe_fd[0]);
    }
    int status = 0;
    while (waitpid(child, &status, 0) < 0) {
        if (errno != EINTR) return -1;
    }
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return -1;
}

}  // namespace

std::string trim(std::string value) {
    auto visible = [](unsigned char ch) { return !std::isspace(ch); };
    value.erase(value.begin(), std::find_if(value.begin(), value.end(), visible));
    value.erase(std::find_if(value.rbegin(), value.rend(), visible).base(), value.end());
    return value;
}

std::vector<std::string> split_lines(const std::string& text) {
    std::vector<std::string> result;
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        line = trim(std::move(line));
        if (!line.empty()) result.push_back(std::move(line));
    }
    return result;
}

std::string join_lines(const std::vector<std::string>& values) {
    std::string output;
    for (const auto& value : values) {
        if (value.empty()) continue;
        output += value;
        output.push_back('\n');
    }
    return output;
}

std::string json_escape(std::string_view value) {
    std::string output;
    output.reserve(value.size() + 8);
    static constexpr char kHex[] = "0123456789abcdef";
    for (unsigned char ch : value) {
        switch (ch) {
            case '"': output += "\\\""; break;
            case '\\': output += "\\\\"; break;
            case '\b': output += "\\b"; break;
            case '\f': output += "\\f"; break;
            case '\n': output += "\\n"; break;
            case '\r': output += "\\r"; break;
            case '\t': output += "\\t"; break;
            default:
                if (ch < 0x20) {
                    output += "\\u00";
                    output.push_back(kHex[(ch >> 4) & 0xf]);
                    output.push_back(kHex[ch & 0xf]);
                } else {
                    output.push_back(static_cast<char>(ch));
                }
        }
    }
    return output;
}

std::string json_string(std::string_view value) {
    return "\"" + json_escape(value) + "\"";
}

std::string url_decode(std::string_view value) {
    std::string output;
    output.reserve(value.size());
    auto hex_value = [](char ch) -> int {
        if (ch >= '0' && ch <= '9') return ch - '0';
        if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
        if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
        return -1;
    };
    for (size_t i = 0; i < value.size(); ++i) {
        if (value[i] == '+') {
            output.push_back(' ');
        } else if (value[i] == '%' && i + 2 < value.size()) {
            const int high = hex_value(value[i + 1]);
            const int low = hex_value(value[i + 2]);
            if (high >= 0 && low >= 0) {
                output.push_back(static_cast<char>((high << 4) | low));
                i += 2;
            } else {
                output.push_back(value[i]);
            }
        } else {
            output.push_back(value[i]);
        }
    }
    return output;
}

std::map<std::string, std::string> parse_form(const std::string& body) {
    std::map<std::string, std::string> output;
    size_t offset = 0;
    while (offset <= body.size()) {
        const size_t end = body.find('&', offset);
        const std::string_view part(body.data() + offset,
                                    (end == std::string::npos ? body.size() : end) - offset);
        const size_t equals = part.find('=');
        const std::string key = url_decode(part.substr(0, equals));
        const std::string value = equals == std::string_view::npos
                                      ? std::string()
                                      : url_decode(part.substr(equals + 1));
        if (!key.empty() && key.size() <= 64 && value.size() <= 256 * 1024) {
            output[key] = value;
        }
        if (end == std::string::npos) break;
        offset = end + 1;
    }
    return output;
}

bool valid_package_name(std::string_view value) {
    if (value.empty() || value.size() > 255 || value.front() == '.' || value.back() == '.') return false;
    bool has_dot = false;
    for (char ch : value) {
        if (ch == '.') {
            has_dot = true;
        } else if (!(std::isalnum(static_cast<unsigned char>(ch)) || ch == '_')) {
            return false;
        }
    }
    return has_dot && value.find("..") == std::string_view::npos;
}

bool safe_property_key(std::string_view key) {
    if (key.empty() || key.size() > 127 || forbidden_property_key(key)) return false;
    if (!(starts_with(key, "ro.") || starts_with(key, "persist.") ||
          starts_with(key, "sys.") || starts_with(key, "vendor.") ||
          starts_with(key, "net.") || starts_with(key, "ril.") ||
          starts_with(key, "gsm."))) {
        return false;
    }
    for (char ch : key) {
        if (!(std::isalnum(static_cast<unsigned char>(ch)) || ch == '.' || ch == '_' || ch == '-')) {
            return false;
        }
    }
    return true;
}

bool forbidden_property_key(std::string_view key) {
    static constexpr std::string_view kExact[] = {
        "ro.boot.flash.locked",
        "ro.boot.verifiedbootstate",
        "ro.boot.veritymode",
        "ro.boot.vbmeta.device_state",
        "ro.boot.vbmeta.digest",
        "ro.boot.vbmeta.hash",
        "ro.boot.warranty_bit",
        "ro.warranty_bit",
        "ro.secureboot.lockstate",
        "ro.boot.secureboot",
        "ro.oem_unlock_supported",
        "sys.oem_unlock_allowed",
        "ro.boot.realme.lockstate",
        "vendor.boot.verifiedbootstate",
        "ro.bootimage.build.sha1",
        "ro.adb.secure",
        "ro.debuggable",
        "ro.force.debuggable",
        "ro.secure",
        "persist.sys.usb.config",
        "sys.usb.config",
    };
    for (const auto blocked : kExact) {
        if (key == blocked) return true;
    }
    return key.find("baseband") != std::string_view::npos ||
           key.find("radio") != std::string_view::npos ||
           starts_with(key, "gsm.version.");
}

std::string get_property(const char* key) {
    char value[PROP_VALUE_MAX]{};
    const int size = __system_property_get(key, value);
    return size > 0 ? std::string(value, static_cast<size_t>(size)) : std::string();
}

bool property_exists(const char* key) {
    return key && *key && __system_property_find(key) != nullptr;
}

int run_process(const std::vector<std::string>& argv, std::string* output, size_t max_output) {
    return run_process_internal(argv, output, max_output, false, 0, 0);
}

int run_process_as(uid_t uid,
                   gid_t gid,
                   const std::vector<std::string>& argv,
                   std::string* output,
                   size_t max_output) {
    return run_process_internal(argv, output, max_output, true, uid, gid);
}

bool read_file(const std::string& path, std::string& output, size_t max_bytes) {
    output.clear();
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return false;
    struct stat st{};
    if (fstat(fd, &st) != 0 || !S_ISREG(st.st_mode) || static_cast<uint64_t>(st.st_size) > max_bytes) {
        close(fd);
        return false;
    }
    output.resize(static_cast<size_t>(st.st_size));
    size_t done = 0;
    while (done < output.size()) {
        const ssize_t count = read(fd, output.data() + done, output.size() - done);
        if (count > 0) done += static_cast<size_t>(count);
        else if (count < 0 && errno == EINTR) continue;
        else { close(fd); output.clear(); return false; }
    }
    close(fd);
    return true;
}

bool read_stream_file(const std::string& path, std::string& output, size_t max_bytes) {
    output.clear();
    if (max_bytes == 0) return false;
    const int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return false;
    std::array<char, 4096> buffer{};
    bool ok = true;
    while (output.size() < max_bytes) {
        const size_t request = std::min(buffer.size(), max_bytes - output.size());
        const ssize_t count = read(fd, buffer.data(), request);
        if (count > 0) output.append(buffer.data(), static_cast<size_t>(count));
        else if (count == 0) break;
        else if (errno == EINTR) continue;
        else { ok = false; break; }
    }
    close(fd);
    if (!ok) output.clear();
    return ok;
}

bool write_file_atomic(const std::string& path,
                       const std::string& content,
                       uint32_t mode,
                       bool preserve_owner) {
    struct stat old_stat{};
    const bool old_exists = preserve_owner && lstat(path.c_str(), &old_stat) == 0 && S_ISREG(old_stat.st_mode);
    const std::string temp = path + ".tmp." + std::to_string(getpid());
    int fd = open(temp.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, mode);
    if (fd < 0) return false;
    size_t done = 0;
    bool ok = true;
    while (done < content.size()) {
        const ssize_t count = write(fd, content.data() + done, content.size() - done);
        if (count > 0) done += static_cast<size_t>(count);
        else if (count < 0 && errno == EINTR) continue;
        else { ok = false; break; }
    }
    if (ok && fsync(fd) != 0) ok = false;
    if (old_exists) {
        fchmod(fd, old_stat.st_mode & 07777);
        fchown(fd, old_stat.st_uid, old_stat.st_gid);
    }
    close(fd);
    if (ok && rename(temp.c_str(), path.c_str()) == 0) return true;
    unlink(temp.c_str());
    return false;
}

bool append_log(const std::string& private_dir, const std::string& line) {
    std::string path = private_dir;
    if (!path.empty() && path.back() != '/') path.push_back('/');
    path += "jiebiao.log";
    int fd = open(path.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return false;
    const std::string record = std::to_string(monotonic_millis()) + " " + line + "\n";
    const ssize_t count = write(fd, record.data(), record.size());
    close(fd);
    return count == static_cast<ssize_t>(record.size());
}

std::string random_from(std::string_view alphabet, size_t size) {
    if (alphabet.empty() || size == 0 || size > 4096) return {};
    std::vector<uint8_t> random(size * 2);
    if (!fill_random(random.data(), random.size())) {
        const uint64_t fallback = monotonic_millis() ^ static_cast<uint64_t>(getpid());
        for (size_t i = 0; i < random.size(); ++i) random[i] = static_cast<uint8_t>((fallback >> (i % 8)) + i * 31);
    }
    std::string output;
    output.reserve(size);
    for (uint8_t byte : random) {
        if (output.size() == size) break;
        const size_t limit = 256 - (256 % alphabet.size());
        if (static_cast<size_t>(byte) < limit) output.push_back(alphabet[byte % alphabet.size()]);
    }
    while (output.size() < size) output.push_back(alphabet[random[output.size() % random.size()] % alphabet.size()]);
    return output;
}

std::string random_hex(size_t size, bool upper) {
    return random_from(upper ? "0123456789ABCDEF" : "0123456789abcdef", size);
}

std::string random_digits(size_t size) {
    return random_from("0123456789", size);
}

std::string random_uuid_v4() {
    const std::string hex = random_hex(32);
    if (hex.size() != 32) return {};
    return hex.substr(0, 8) + "-" + hex.substr(8, 4) + "-4" + hex.substr(13, 3) +
           "-a" + hex.substr(17, 3) + "-" + hex.substr(20, 12);
}

uint64_t monotonic_millis() {
    return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count());
}

std::string boot_id() {
    std::string value;
    if (!read_stream_file("/proc/sys/kernel/random/boot_id", value, 128)) return {};
    return trim(std::move(value));
}

std::string shell_quote(std::string_view value) {
    std::string output("'");
    for (char ch : value) {
        if (ch == '\'') output += "'\\''";
        else output.push_back(ch);
    }
    output.push_back('\'');
    return output;
}

}  // namespace jiebiao
