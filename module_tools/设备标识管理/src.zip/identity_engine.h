#pragma once

#include <cstddef>
#include <string>

namespace jiebiao {

struct IdentityValues {
    std::string serial;
    std::string soc_serial;
    std::string android_id;
    std::string ufs_serial;
};

struct IdentityApplyResult {
    size_t applied = 0;
    size_t failed = 0;
    bool kernel_serial_hooked = false;
    std::string message;
};

IdentityValues load_or_create_identity(bool force_regenerate = false);
IdentityValues generate_identity_values();
bool randomize_oaids_now(const std::string& private_dir, std::string& detail);
bool queue_oaid_rotation(const std::string& private_dir, std::string& detail);
bool apply_pending_oaids(const std::string& private_dir, std::string& detail);
bool save_identity_values(const IdentityValues& values);
std::string serialize_identity_values(const IdentityValues& values);
bool parse_identity_values(const std::string& text, IdentityValues& values);
std::string identity_values_json(const IdentityValues& values);
bool ensure_identity_baseline_properties();
bool ensure_identity_baseline_settings();
bool ensure_identity_baseline_oaid();
bool set_identity_application_state(const std::string& state);
std::string identity_application_state();
std::string identity_comparison_json(const IdentityValues& target, bool master_enabled);
std::string identity_verification_json(const IdentityValues& target, bool master_enabled);

IdentityApplyResult apply_identity_properties(const std::string& private_dir,
                                              const IdentityValues& values,
                                              bool install_kernel_serial_hook);
IdentityApplyResult restore_identity_properties(const std::string& private_dir);

bool apply_identity_settings(const IdentityValues& values,
                             std::string& detail);
// 一键更换时让 Android ID 一次生效：改写全部用户 settings_ssaid.xml 的全局
// android_id/userkey，并延迟软重启 system_server 使 SettingsProvider 重新加载。
bool force_global_android_id_now(const std::string& private_dir,
                                 const std::string& android_id,
                                 std::string& detail);
// 保存/读取当前使用的 SSAID userkey（用于后续新用户自动同步）
bool save_ssaid_userkey(const std::string& userkey);
bool load_ssaid_userkey(std::string& userkey);
// 扫描所有用户，把 userkey 不匹配的用户自动同步成当前值（含 .fallback）
bool sync_new_users_ssaid(const std::string& private_dir, std::string& detail);
bool capture_managed_settings(std::string& snapshot,
                              std::string& detail);
bool restore_managed_settings_snapshot(const std::string& snapshot,
                                       std::string& detail);
bool restore_legacy_device_name_settings(std::string& detail);
bool restore_retired_identity_settings(std::string& detail);
bool restore_identity_settings(std::string& detail);

}  // namespace jiebiao
