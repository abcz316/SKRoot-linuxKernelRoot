#include "reset_transaction.h"

#include "common.h"
#include "drmid_worker.h"
#include "identity_engine.h"
#include "oaid_engine.h"
#include "property_engine.h"
#include "ssaid_engine.h"
#include "state_store.h"
#include "usb_serial_engine.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <iomanip>
#include <sstream>
#include <system_error>
#include <vector>

namespace fs = std::filesystem;

namespace jiebiao {
namespace {

constexpr const char* kTxnState = "global_reset_state_v2";
constexpr const char* kTxnDirectory = "global_reset_directory_v2";
constexpr const char* kTxnDetail = "global_reset_detail_v2";
constexpr const char* kTxnHasOplusOaid = "global_reset_has_oplus_oaid_v1";
constexpr const char* kIdentityOaidTarget = "identity_oaid_target_v1";
constexpr const char* kIdentityOaidPreviousTarget = "identity_oaid_target_previous_v1";
constexpr size_t kMaxSnapshotFile = 32 * 1024 * 1024;
constexpr size_t kMaxSnapshotFiles = 4096;
constexpr uint64_t kMaxSnapshotBytes = 64ULL * 1024 * 1024;

struct TxnEntry {
    std::string kind;
    uint32_t user_id = 0;
    std::string target;
    std::string backup;
    std::string hash;
    std::string payload;
};

struct Surface {
    std::string id;
    std::string state;
    std::string detail;
};

class Fnv64 {
public:
    void update(const void* bytes, size_t size) {
        const auto* data = static_cast<const unsigned char*>(bytes);
        for (size_t i = 0; i < size; ++i) {
            value_ ^= data[i];
            value_ *= 1099511628211ULL;
        }
    }
    void update(const std::string& value) { update(value.data(), value.size()); }
    std::string hex() const {
        std::ostringstream output;
        output << std::hex << std::setfill('0') << std::setw(16) << value_;
        return output.str();
    }
private:
    uint64_t value_ = 1469598103934665603ULL;
};

std::string storage_value(const char* key) {
    std::string value;
    storage_read_string(key, value);
    return value;
}

bool ensure_directory(const fs::path& path, mode_t mode = 0700) {
    std::error_code error;
    if (!fs::create_directories(path, error) && error && !fs::is_directory(path, error)) return false;
    return chmod(path.c_str(), mode) == 0 || errno == EPERM;
}

bool path_hash(const std::string& path, std::string& output) {
    output.clear();
    struct stat root_stat{};
    if (lstat(path.c_str(), &root_stat) != 0 || S_ISLNK(root_stat.st_mode)) return false;
    Fnv64 hash;
    uint64_t total = 0;
    size_t count = 0;
    auto add_file = [&](const fs::path& file, const std::string& relative, const struct stat& st) {
        if (!S_ISREG(st.st_mode) || st.st_size < 0 || static_cast<uint64_t>(st.st_size) > kMaxSnapshotFile ||
            total + static_cast<uint64_t>(st.st_size) > kMaxSnapshotBytes || ++count > kMaxSnapshotFiles) return false;
        std::string data;
        if (!read_file(file.string(), data, kMaxSnapshotFile)) return false;
        hash.update("F\t" + relative + "\t" + std::to_string(st.st_mode & 07777) + "\t");
        hash.update(data);
        total += data.size();
        return true;
    };
    if (S_ISREG(root_stat.st_mode)) {
        if (!add_file(path, ".", root_stat)) return false;
    } else if (S_ISDIR(root_stat.st_mode)) {
        std::vector<fs::path> paths;
        std::error_code error;
        for (fs::recursive_directory_iterator it(path, fs::directory_options::skip_permission_denied, error), end;
             it != end && !error; it.increment(error)) paths.push_back(it->path());
        if (error) return false;
        std::sort(paths.begin(), paths.end());
        for (const auto& item : paths) {
            struct stat st{};
            if (lstat(item.c_str(), &st) != 0 || S_ISLNK(st.st_mode)) return false;
            const std::string relative = fs::relative(item, path).generic_string();
            if (S_ISDIR(st.st_mode)) {
                hash.update("D\t" + relative + "\t" + std::to_string(st.st_mode & 07777) + "\n");
            } else if (!add_file(item, relative, st)) {
                return false;
            }
        }
    } else {
        return false;
    }
    output = hash.hex();
    return true;
}

bool copy_regular_snapshot(const fs::path& source, const fs::path& destination, const struct stat& st) {
    std::string data;
    if (!read_file(source.string(), data, kMaxSnapshotFile)) return false;
    if (!ensure_directory(destination.parent_path())) return false;
    if (!write_file_atomic(destination.string(), data, st.st_mode & 07777, false)) return false;
    chown(destination.c_str(), st.st_uid, st.st_gid);
    chmod(destination.c_str(), st.st_mode & 07777);
    return true;
}

bool copy_snapshot(const std::string& source, const std::string& destination) {
    struct stat root_stat{};
    if (lstat(source.c_str(), &root_stat) != 0 || S_ISLNK(root_stat.st_mode)) return false;
    if (S_ISREG(root_stat.st_mode)) return copy_regular_snapshot(source, destination, root_stat);
    if (!S_ISDIR(root_stat.st_mode) || !ensure_directory(destination, root_stat.st_mode & 07777)) return false;
    chown(destination.c_str(), root_stat.st_uid, root_stat.st_gid);
    size_t count = 0;
    uint64_t total = 0;
    std::error_code error;
    for (fs::recursive_directory_iterator it(source, fs::directory_options::skip_permission_denied, error), end;
         it != end && !error; it.increment(error)) {
        if (++count > kMaxSnapshotFiles) return false;
        struct stat st{};
        if (lstat(it->path().c_str(), &st) != 0 || S_ISLNK(st.st_mode)) return false;
        const fs::path relative = fs::relative(it->path(), source, error);
        if (error || relative.empty() || relative.string().find("..") != std::string::npos) return false;
        const fs::path target = fs::path(destination) / relative;
        if (S_ISDIR(st.st_mode)) {
            if (!ensure_directory(target, st.st_mode & 07777)) return false;
            chown(target.c_str(), st.st_uid, st.st_gid);
        } else if (S_ISREG(st.st_mode)) {
            if (st.st_size < 0 || total + static_cast<uint64_t>(st.st_size) > kMaxSnapshotBytes) return false;
            if (!copy_regular_snapshot(it->path(), target, st)) return false;
            total += static_cast<uint64_t>(st.st_size);
        } else {
            return false;
        }
    }
    return !error;
}

bool allowed_target(const TxnEntry& entry) {
    if (entry.kind == "oaid") return entry.target == "/data/system/oaid_persistence_0";
    if (entry.kind == "oplus-oaid") return entry.target == "/data/system/openid_config.xml";
    if (entry.kind == "appset") {
        if (entry.target == "/data/system/appsetids" || entry.target == "/data/system/app_set_ids.xml") return true;
        const std::string prefix = "/data/system/users/";
        const std::string suffix = "/app_set_ids.xml";
        if (!entry.target.starts_with(prefix) || !entry.target.ends_with(suffix)) return false;
        const std::string id = entry.target.substr(prefix.size(), entry.target.size() - prefix.size() - suffix.size());
        bool all = false;
        uint32_t parsed = 0;
        return parse_user_selector(id, all, parsed) && !all;
    }
    if (entry.kind == "ssaid" || entry.kind == "ssaid-fallback") {
        const std::string suffix = entry.kind == "ssaid-fallback" ? ".fallback" : "";
        return entry.target == "/data/system/users/" + std::to_string(entry.user_id) +
                               "/settings_ssaid.xml" + suffix;
    }
    return false;
}

bool remove_target(const TxnEntry& entry) {
    if (!allowed_target(entry)) return false;
    struct stat st{};
    if (lstat(entry.target.c_str(), &st) == 0 && S_ISLNK(st.st_mode)) return false;
    std::error_code error;
    if (!fs::exists(entry.target, error)) return true;
    if (fs::is_directory(entry.target, error)) fs::remove_all(entry.target, error);
    else fs::remove(entry.target, error);
    return !error;
}

bool restore_entry(const TxnEntry& entry) {
    if (!remove_target(entry) || !copy_snapshot(entry.backup, entry.target)) return false;
    return run_process({"/system/bin/restorecon", "-RF", entry.target}) == 0;
}

bool known_oaid(const std::string& data) {
    return data.size() == 20 && data[0] == '\0' && data[1] == '\x10' &&
           std::all_of(data.begin() + 2, data.end(), [](unsigned char ch) { return std::isxdigit(ch); });
}

std::string serialize_entries(const std::vector<TxnEntry>& entries) {
    std::string text = "version\t3\n";
    for (const auto& entry : entries) {
        text += "entry\t" + entry.kind + "\t" + std::to_string(entry.user_id) + "\t" + entry.target +
                "\t" + entry.backup + "\t" + entry.hash + "\t" + entry.payload + "\n";
    }
    return text;
}

bool parse_entries(const std::string& text, std::vector<TxnEntry>& entries) {
    entries.clear();
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        if (!line.starts_with("entry\t")) continue;
        std::vector<std::string> fields;
        size_t cursor = 0;
        while (fields.size() < 6) {
            const size_t tab = line.find('\t', cursor);
            if (tab == std::string::npos) break;
            fields.push_back(line.substr(cursor, tab - cursor));
            cursor = tab + 1;
        }
        if (fields.size() != 6) return false;
        char* end = nullptr;
        const unsigned long user = std::strtoul(fields[2].c_str(), &end, 10);
        if (!end || *end != '\0' || user > 99999) return false;
        TxnEntry entry{fields[1], static_cast<uint32_t>(user), fields[3], fields[4], fields[5], line.substr(cursor)};
        if (!allowed_target(entry)) return false;
        entries.push_back(std::move(entry));
    }
    return text.starts_with("version\t3\n");
}

std::string transaction_root(const std::string& private_dir) {
    return fs::path(private_dir).append("backups/transactions").string();
}

bool valid_transaction_dir(const std::string& private_dir, const std::string& path) {
    const std::string root = transaction_root(private_dir) + "/txn-";
    return path.starts_with(root) && path.find("..") == std::string::npos;
}

void prune_transaction_directories(const std::string& private_dir, const std::string& keep) {
    const fs::path root(transaction_root(private_dir));
    std::error_code error;
    for (fs::directory_iterator it(root, fs::directory_options::skip_permission_denied, error), end;
         it != end && !error; it.increment(error)) {
        const std::string path = it->path().string();
        if (path == keep || !it->path().filename().string().starts_with("txn-") ||
            !valid_transaction_dir(private_dir, path)) continue;
        struct stat st{};
        if (lstat(path.c_str(), &st) != 0 || !S_ISDIR(st.st_mode) || S_ISLNK(st.st_mode)) continue;
        fs::remove_all(it->path(), error);
        if (error) error.clear();
    }
}

bool load_transaction(const std::string& private_dir,
                      std::string& directory,
                      std::vector<TxnEntry>& entries,
                      IdentityValues& old_values,
                      IdentityValues& new_values,
                      std::string& settings_snapshot) {
    if (!storage_read_string(kTxnDirectory, directory) || !valid_transaction_dir(private_dir, directory)) return false;
    std::string manifest;
    std::string old_text;
    std::string new_text;
    if (!read_file(directory + "/manifest.tsv", manifest, 1024 * 1024) ||
        !read_file(directory + "/identity.old", old_text, 64 * 1024) ||
        !read_file(directory + "/identity.new", new_text, 64 * 1024) ||
        !read_file(directory + "/settings.snapshot", settings_snapshot, 256 * 1024)) return false;
    return parse_entries(manifest, entries) && parse_identity_values(old_text, old_values) &&
           parse_identity_values(new_text, new_values);
}

bool load_transaction_drm(const std::string& directory,
                          drmid::ReplacementConfig& old_config,
                          drmid::ReplacementConfig& new_config) {
    std::string old_text;
    std::string new_text;
    return read_file(directory + "/drm.old", old_text, 4096) &&
           read_file(directory + "/drm.new", new_text, 4096) &&
           device_identity::drm::parse_runtime(old_text, old_config) &&
           device_identity::drm::parse_runtime(new_text, new_config);
}

void set_state(const std::string& state, const std::string& detail) {
    storage_write_string(kTxnDetail, detail);
    storage_write_string(kTxnState, state);
}

bool backup_entry(const std::string& directory,
                  size_t index,
                  TxnEntry& entry,
                  std::string& detail) {
    entry.backup = directory + "/entry-" + std::to_string(index);
    if (!path_hash(entry.target, entry.hash)) { detail = entry.kind + ":hash-failed"; return false; }
    if (!copy_snapshot(entry.target, entry.backup)) { detail = entry.kind + ":backup-failed"; return false; }
    std::string copied_hash;
    if (!path_hash(entry.backup, copied_hash) || copied_hash != entry.hash) {
        detail = entry.kind + ":backup-verify-failed";
        return false;
    }
    return true;
}

bool apply_entry(const std::string& private_dir,
                 const TxnEntry& entry,
                 const IdentityValues& new_values,
                 std::string& detail) {
    if (entry.kind == "appset") {
        const bool ok = remove_target(entry);
        detail = ok ? "appset-removed" : "appset-remove-failed";
        return ok;
    }
    if (entry.kind == "oaid") {
        const std::string value = std::string("\0\x10", 2) + entry.payload;
        const bool ok = known_oaid(value) && write_file_atomic(entry.target, value, 0600, true);
        if (ok) run_process({"/system/bin/restorecon", entry.target});
        detail = ok ? "oaid-updated" : "oaid-write-failed";
        return ok;
    }
    if (entry.kind == "oplus-oaid") {
        std::string xml;
        if (!read_file(entry.target, xml, 1024 * 1024)) {
            detail = "oplus-oaid-read-failed";
            return false;
        }
        size_t changed = 0;
        if (!rewrite_oplus_openid_xml(xml, entry.payload, changed, detail)) {
            detail = "oplus-oaid-" + detail;
            return false;
        }
        const bool ok = write_file_atomic(entry.target, xml, 0600, true);
        if (ok) run_process({"/system/bin/restorecon", entry.target});
        detail = ok ? "oplus-oaid-updated-users=" + std::to_string(changed)
                    : "oplus-oaid-write-failed";
        return ok;
    }
    if (entry.kind == "ssaid" || entry.kind == "ssaid-fallback") {
        std::string original;
        if (!read_file(entry.target, original, 16 * 1024 * 1024)) { detail = "ssaid-read-failed"; return false; }
        const SsaidFormat format = original.size() >= 3 && original.compare(0, 3, "ABX") == 0
            ? SsaidFormat::Abx : SsaidFormat::Xml;
        AndroidUserInfo user{entry.user_id, "", entry.target, format,
            format == SsaidFormat::Xml || (access("/system/bin/abx2xml", X_OK) == 0 && access("/system/bin/xml2abx", X_OK) == 0)};
        SsaidDocument document;
        if (!load_ssaid_document(private_dir, user, "txn-apply-" + std::to_string(entry.user_id), document, detail)) return false;
        size_t changed = 0;
        if (!reset_all_ssaid_xml(document.xml, new_values.android_id, entry.payload, changed, detail)) return false;
        std::string encoded;
        if (!encode_ssaid_document(private_dir, document, document.xml,
                                   "txn-apply-" + std::to_string(entry.user_id), encoded, detail)) return false;
        if (!write_file_atomic(entry.target, encoded, 0600, true)) { detail = "ssaid-write-failed"; return false; }
        run_process({"/system/bin/restorecon", entry.target});
        detail = entry.kind + "-updated-" + std::to_string(changed);
        return true;
    }
    detail = "unknown-entry";
    return false;
}

std::vector<Surface> probe_surfaces() {
    std::vector<Surface> result;
    const auto users = discover_android_users();
    size_t ready_users = 0;
    size_t blocked_users = 0;
    for (const auto& user : users) user.ready ? ++ready_users : ++blocked_users;
    size_t fallback_ready = 0;
    size_t fallback_blocked = 0;
    for (const auto& user : users) {
        AndroidUserInfo fallback;
        std::string fallback_detail;
        if (inspect_ssaid_file(user.id, user.path + ".fallback", fallback, fallback_detail)) {
            fallback.ready ? ++fallback_ready : ++fallback_blocked;
        } else if (fallback_detail != "absent") {
            ++fallback_blocked;
        }
    }
    const bool ssaid_ready = ready_users != 0 && blocked_users == 0 && fallback_blocked == 0;
    result.push_back({"ssaid", ssaid_ready ? "ready" : (users.empty() ? "absent" : "unsupported"),
                      "ready=" + std::to_string(ready_users) +
                      ",unsupported=" + std::to_string(blocked_users) +
                      ",fallback=" + std::to_string(fallback_ready) +
                      ",fallback_unsupported=" + std::to_string(fallback_blocked)});

    bool appset = access("/data/system/appsetids", F_OK) == 0 ||
                  access("/data/system/app_set_ids.xml", F_OK) == 0;
    for (const auto& user : users) {
        if (access(("/data/system/users/" + std::to_string(user.id) + "/app_set_ids.xml").c_str(), F_OK) == 0) appset = true;
    }
    result.push_back({"appset", appset ? "ready" : "absent", appset ? "target-detected" : "no-known-path"});

    std::string oaid;
    if (!read_file("/data/system/oaid_persistence_0", oaid, 1024 * 1024)) {
        result.push_back({"system_oaid", "absent", "no-known-path"});
    } else {
        result.push_back({"system_oaid", known_oaid(oaid) ? "ready" : "unsupported",
                          known_oaid(oaid) ? "format-v1" : "unknown-format"});
    }

    const std::string oplus_path = "/data/system/openid_config.xml";
    std::string oplus_xml;
    std::vector<OplusOaidValue> oplus_values;
    std::string oplus_detail;
    if (read_file(oplus_path, oplus_xml, 1024 * 1024)) {
        if (inspect_oplus_openid_xml(oplus_xml, oplus_values, oplus_detail)) {
            std::string provider_value;
            std::string provider_detail;
            const bool provider_read = read_oplus_oaid_provider(provider_value, provider_detail);
            const auto primary = std::find_if(oplus_values.begin(), oplus_values.end(),
                [](const auto& item) { return item.user == "0"; });
            const bool provider_matches = provider_read && primary != oplus_values.end() &&
                                          primary->value == provider_value;
            result.push_back({"oplus_oaid", provider_matches ? "ready" : "unsupported",
                              oplus_detail + ',' + (provider_matches ? "provider-match" :
                                  (provider_read ? "provider-mismatch" : provider_detail))});
        } else {
            result.push_back({"oplus_oaid", "unsupported", oplus_detail});
        }
    } else {
        result.push_back({"oplus_oaid",
                          access("/data/data/com.heytap.openid", F_OK) == 0 ? "unsupported" : "absent",
                          access("/data/data/com.heytap.openid", F_OK) == 0
                              ? "provider-detected-config-unavailable" : "provider-not-detected"});
    }

    const char* oem_paths[] = {
        "/data/data/com.android.oaid",
        "/data/data/com.oplus.oaid", "/data/data/com.xiaomi.xmsf",
        "/data/data/com.huawei.hwid", "/data/data/com.samsung.android.deviceidservice",
    };
    size_t oem_detected = 0;
    for (const char* path : oem_paths) if (access(path, F_OK) == 0) ++oem_detected;
    result.push_back({"oem_oaid", oem_detected ? "unsupported" : "absent",
                      oem_detected ? "provider-detected-probe-only" : "provider-not-detected"});

    const bool google = access("/data/data/com.google.android.gsf", F_OK) == 0 ||
                        access("/data/data/com.google.android.gms", F_OK) == 0;
    result.push_back({"gsf_gms", google ? "unsupported" : "absent",
                      google ? "provider-detected-probe-only" : "provider-not-detected"});
    result.push_back({"module_identity", "ready", "existing-properties-and-kernel-layer"});

    std::string transaction_state;
    storage_read_string(kTxnState, transaction_state);
    std::string overlay;
    if (transaction_state == "prepared" || transaction_state == "early-applied") overlay = "pending";
    else if (transaction_state == "applied") overlay = "applied";
    else if (transaction_state == "rolled-back") overlay = "rolled-back";
    if (!overlay.empty()) {
        bool transaction_has_oplus_oaid = false;
        storage_read_bool(kTxnHasOplusOaid, transaction_has_oplus_oaid);
        for (auto& surface : result) {
            if (surface.state == "ready" &&
                (surface.id != "oplus_oaid" || transaction_has_oplus_oaid)) {
                surface.state = overlay;
            }
        }
    }
    return result;
}

std::string surface_json(const Surface& surface) {
    return "{\"id\":" + json_string(surface.id) + ",\"state\":" + json_string(surface.state) +
           ",\"detail\":" + json_string(surface.detail) + "}";
}

}  // namespace

bool prepare_global_reset(const std::string& private_dir, std::string& detail) {
    std::string current_state;
    storage_read_string(kTxnState, current_state);
    if (current_state == "prepared" || current_state == "early-applied") {
        detail = "transaction-already-pending";
        return false;
    }

    const std::string root = transaction_root(private_dir);
    if (!ensure_directory(root)) {
        detail = "transaction-root-failed";
        set_state("preflight-failed", detail);
        return false;
    }
    const std::string directory = root + "/txn-" + random_hex(16);
    if (!ensure_directory(directory)) {
        detail = "transaction-directory-failed";
        set_state("preflight-failed", detail);
        return false;
    }
    const std::string previous_oaid_target = storage_value(kIdentityOaidTarget);
    const std::string previous_oaid_pending = storage_value("identity_oaid_pending_payload_v1");
    const std::string previous_system_oaid_pending = storage_value("identity_system_oaid_pending_v1");
    const std::string previous_oaid_runtime = storage_value("identity_oaid_runtime_state_v1");
    const std::string previous_oaid_runtime_detail = storage_value("identity_oaid_runtime_detail_v1");
    auto preflight_failed = [&](const std::string& reason) {
        detail = reason;
        fs::remove_all(directory);
        storage_write_bool(kTxnHasOplusOaid, false);
        storage_write_string(kIdentityOaidTarget, previous_oaid_target);
        storage_write_string("identity_oaid_pending_payload_v1", previous_oaid_pending);
        storage_write_string("identity_system_oaid_pending_v1", previous_system_oaid_pending);
        storage_write_string("identity_oaid_runtime_state_v1", previous_oaid_runtime);
        storage_write_string("identity_oaid_runtime_detail_v1", previous_oaid_runtime_detail);
        storage_write_string(kIdentityOaidPreviousTarget, "");
        set_state("preflight-failed", detail);
        return false;
    };

    const IdentityValues old_values = load_or_create_identity(false);
    const IdentityValues new_values = generate_identity_values();
    drmid::ReplacementConfig old_drm{};
    drmid::ReplacementConfig new_drm{};
    std::string drm_detail;
    if (!device_identity::drm::read_runtime(private_dir, old_drm, drm_detail) ||
        !device_identity::drm::build_randomized_runtime(
            old_drm, new_drm, drm_detail)) {
        return preflight_failed("drm-preflight-" + drm_detail);
    }
    std::string settings_snapshot;
    std::string settings_detail;
    if (!capture_managed_settings(settings_snapshot, settings_detail)) {
        return preflight_failed("settings-preflight-" + settings_detail);
    }
    if (!write_file_atomic(directory + "/identity.old", serialize_identity_values(old_values), 0600, false) ||
        !write_file_atomic(directory + "/identity.new", serialize_identity_values(new_values), 0600, false) ||
        !write_file_atomic(directory + "/settings.snapshot", settings_snapshot, 0600, false) ||
        !write_file_atomic(directory + "/drm.old", device_identity::drm::serialize_runtime(old_drm), 0600, false) ||
        !write_file_atomic(directory + "/drm.new", device_identity::drm::serialize_runtime(new_drm), 0600, false)) {
        return preflight_failed("transaction-metadata-failed");
    }

    std::vector<TxnEntry> entries;
    for (const auto& user : discover_android_users()) {
        if (!user.ready) continue;
        SsaidDocument document;
        std::string operation_detail;
        if (!load_ssaid_document(private_dir, user, "txn-preflight-" + std::to_string(user.id), document, operation_detail)) {
            return preflight_failed("ssaid-u" + std::to_string(user.id) + '-' + operation_detail);
        }
        const std::string userkey = random_hex(64);
        size_t changed = 0;
        if (!reset_all_ssaid_xml(document.xml, new_values.android_id, userkey, changed, operation_detail)) {
            return preflight_failed("ssaid-u" + std::to_string(user.id) + '-' + operation_detail);
        }
        std::string encoded;
        if (!encode_ssaid_document(private_dir, document, document.xml,
                                   "txn-preflight-" + std::to_string(user.id), encoded, operation_detail)) {
            return preflight_failed("ssaid-u" + std::to_string(user.id) + '-' + operation_detail);
        }
        TxnEntry entry{"ssaid", user.id, user.path, "", "", userkey};
        if (!backup_entry(directory, entries.size(), entry, detail)) return preflight_failed(detail);
        entries.push_back(std::move(entry));

        const std::string fallback_path = user.path + ".fallback";
        AndroidUserInfo fallback_user;
        std::string fallback_detail;
        const bool has_fallback = inspect_ssaid_file(user.id, fallback_path, fallback_user, fallback_detail);
        if (!has_fallback && fallback_detail != "absent") {
            return preflight_failed("ssaid-fallback-u" + std::to_string(user.id) + '-' + fallback_detail);
        }
        if (has_fallback) {
            if (!fallback_user.ready) {
                return preflight_failed("ssaid-fallback-u" + std::to_string(user.id) + '-' + fallback_detail);
            }
            SsaidDocument fallback_document;
            if (!load_ssaid_document(private_dir, fallback_user,
                                     "txn-preflight-fallback-" + std::to_string(user.id),
                                     fallback_document, fallback_detail)) {
                return preflight_failed("ssaid-fallback-u" + std::to_string(user.id) + '-' + fallback_detail);
            }
            size_t fallback_changed = 0;
            if (!reset_all_ssaid_xml(fallback_document.xml, new_values.android_id, userkey,
                                     fallback_changed, fallback_detail)) {
                return preflight_failed("ssaid-fallback-u" + std::to_string(user.id) + '-' + fallback_detail);
            }
            std::string fallback_encoded;
            if (!encode_ssaid_document(private_dir, fallback_document, fallback_document.xml,
                                       "txn-preflight-fallback-" + std::to_string(user.id),
                                       fallback_encoded, fallback_detail)) {
                return preflight_failed("ssaid-fallback-u" + std::to_string(user.id) + '-' + fallback_detail);
            }
            TxnEntry fallback_entry{"ssaid-fallback", user.id, fallback_path, "", "", userkey};
            if (!backup_entry(directory, entries.size(), fallback_entry, detail)) return preflight_failed(detail);
            entries.push_back(std::move(fallback_entry));
        }
    }

    std::vector<std::string> appset_paths = {"/data/system/appsetids", "/data/system/app_set_ids.xml"};
    for (const auto& user : discover_android_users()) {
        appset_paths.push_back("/data/system/users/" + std::to_string(user.id) + "/app_set_ids.xml");
    }
    for (const auto& path : appset_paths) {
        if (access(path.c_str(), F_OK) != 0) continue;
        TxnEntry entry{"appset", 0, path, "", "", ""};
        if (!backup_entry(directory, entries.size(), entry, detail)) return preflight_failed(detail);
        entries.push_back(std::move(entry));
    }

    std::string oaid;
    if (read_file("/data/system/oaid_persistence_0", oaid, 1024 * 1024) && known_oaid(oaid)) {
        TxnEntry entry{"oaid", 0, "/data/system/oaid_persistence_0", "", "", random_hex(18)};
        if (!backup_entry(directory, entries.size(), entry, detail)) return preflight_failed(detail);
        entries.push_back(std::move(entry));
    }

    bool has_oplus_oaid = false;
    std::string oplus_primary_target;
    const std::string oplus_path = "/data/system/openid_config.xml";
    if (access(oplus_path.c_str(), F_OK) == 0) {
        std::string xml;
        std::string payload;
        if (!read_file(oplus_path, xml, 1024 * 1024)) {
            return preflight_failed("oplus-oaid-read-failed");
        }
        std::string oplus_detail;
        if (!build_oplus_oaid_payload(xml, payload, oplus_detail)) {
            return preflight_failed("oplus-oaid-" + oplus_detail);
        }
        if (!oplus_oaid_payload_value(payload, "0", oplus_primary_target)) {
            return preflight_failed("oplus-oaid-primary-user-missing");
        }
        TxnEntry entry{"oplus-oaid", 0, oplus_path, "", "", payload};
        if (!backup_entry(directory, entries.size(), entry, detail)) return preflight_failed(detail);
        entries.push_back(std::move(entry));
        has_oplus_oaid = true;
    }

    if (!write_file_atomic(directory + "/manifest.tsv", serialize_entries(entries), 0600, false) ||
        !storage_write_string(kTxnDirectory, directory) ||
        !storage_write_bool(kTxnHasOplusOaid, has_oplus_oaid) ||
        (has_oplus_oaid &&
         (!storage_write_string(kIdentityOaidPreviousTarget, storage_value(kIdentityOaidTarget)) ||
          !storage_write_string(kIdentityOaidTarget, oplus_primary_target)))) {
        return preflight_failed("manifest-write-failed");
    }
    if (!storage_write_string("identity_oaid_pending_payload_v1", "") ||
        !storage_write_string("identity_system_oaid_pending_v1", "") ||
        !storage_write_string("identity_oaid_runtime_state_v1", "") ||
        !storage_write_string("identity_oaid_runtime_detail_v1", "")) {
        return preflight_failed("oaid-state-clear-failed");
    }
    detail = "prepared entries=" + std::to_string(entries.size()) + ",restart-required";
    set_state("prepared", detail);
    return true;
}

std::string execute_early_global_reset(const std::string& private_dir) {
    std::string state;
    storage_read_string(kTxnState, state);
    if (state != "prepared") return {};
    std::string directory;
    std::vector<TxnEntry> entries;
    IdentityValues old_values;
    IdentityValues new_values;
    std::string settings_snapshot;
    drmid::ReplacementConfig old_drm{};
    drmid::ReplacementConfig new_drm{};
    if (!load_transaction(private_dir, directory, entries, old_values, new_values, settings_snapshot)) {
        storage_write_string(kIdentityOaidTarget, storage_value(kIdentityOaidPreviousTarget));
        storage_write_string(kIdentityOaidPreviousTarget, "");
        set_state("preflight-failed", "transaction-load-failed");
        return "global-reset preflight-failed(transaction-load-failed)";
    }
    if (!load_transaction_drm(directory, old_drm, new_drm)) {
        set_state("preflight-failed", "drm-transaction-load-failed");
        return "global-reset preflight-failed(drm-transaction-load-failed)";
    }
    for (const auto& entry : entries) {
        std::string hash;
        if (!path_hash(entry.target, hash) || hash != entry.hash) {
            storage_write_string(kIdentityOaidTarget, storage_value(kIdentityOaidPreviousTarget));
            storage_write_string(kIdentityOaidPreviousTarget, "");
            set_state("preflight-failed", entry.kind + ":hash-changed");
            prune_transaction_directories(private_dir, directory);
            return "global-reset preflight-failed(" + entry.kind + ":hash-changed)";
        }
    }

    std::vector<const TxnEntry*> applied;
    std::string detail;
    for (const auto& entry : entries) {
        if (!apply_entry(private_dir, entry, new_values, detail)) {
            bool restored = restore_entry(entry);
            for (auto it = applied.rbegin(); it != applied.rend(); ++it) restored = restore_entry(**it) && restored;
            save_identity_values(old_values);
            storage_write_string(kIdentityOaidTarget, storage_value(kIdentityOaidPreviousTarget));
            storage_write_string(kIdentityOaidPreviousTarget, "");
            set_identity_application_state(load_config().master_enabled ? "applied" : "pending");
            set_state("rolled-back", entry.kind + ':' + detail + (restored ? "" : ",restore-failed"));
            prune_transaction_directories(private_dir, directory);
            return "global-reset rolled-back(" + entry.kind + ':' + detail + ')';
        }
        applied.push_back(&entry);
    }
    std::string drm_detail;
    if (!device_identity::drm::write_runtime(private_dir, new_drm, drm_detail) ||
        !save_identity_values(new_values)) {
        for (auto it = applied.rbegin(); it != applied.rend(); ++it) restore_entry(**it);
        save_identity_values(old_values);
        device_identity::drm::restore_runtime(private_dir, old_drm, drm_detail);
        storage_write_string(kIdentityOaidTarget, storage_value(kIdentityOaidPreviousTarget));
        storage_write_string(kIdentityOaidPreviousTarget, "");
        set_identity_application_state(load_config().master_enabled ? "applied" : "pending");
        set_state("rolled-back", "identity-save-failed");
        prune_transaction_directories(private_dir, directory);
        return "global-reset rolled-back(identity-save-failed)";
    }
    set_state("early-applied", "files-applied=" + std::to_string(applied.size()));
    return "global-reset early-applied(files=" + std::to_string(applied.size()) + ")";
}

std::string finalize_global_reset(const std::string& private_dir) {
    std::string state;
    storage_read_string(kTxnState, state);
    if (state != "early-applied") return {};
    std::string directory;
    std::vector<TxnEntry> entries;
    IdentityValues old_values;
    IdentityValues new_values;
    std::string settings_snapshot;
    drmid::ReplacementConfig old_drm{};
    drmid::ReplacementConfig new_drm{};
    if (!load_transaction(private_dir, directory, entries, old_values, new_values, settings_snapshot)) {
        storage_write_string(kIdentityOaidTarget, storage_value(kIdentityOaidPreviousTarget));
        storage_write_string(kIdentityOaidPreviousTarget, "");
        set_state("rolled-back", "finalize-load-failed");
        return "global-reset rolled-back(finalize-load-failed)";
    }
    if (!load_transaction_drm(directory, old_drm, new_drm)) {
        set_state("rolled-back", "drm-finalize-load-failed");
        return "global-reset rolled-back(drm-finalize-load-failed)";
    }
    const ModuleConfig config = load_config();
    // A global reset always includes the DRM random ID, regardless of the
    // identity master switch.  When the resident worker is available publish
    // immediately; after an explicit DRM exit the persisted runtime is
    // picked up on the next worker start.
    if (device_identity::drm::worker_alive(private_dir)) {
        const auto drm_status = device_identity::drm::read_status(private_dir);
        if (!drm_status.control_connected) {
            // The DRM worker deliberately enters only after the Android/DRM
            // readiness gate.  Keep the transaction pending while it starts;
            // the supervisor loop retries this finalize phase.
            return "global-reset finalize-deferred(drm-worker-starting)";
        }
        std::string drm_detail;
        drmid::ControlIpcResponse drm_response{};
        if (!device_identity::drm::publish_runtime(
                private_dir, new_drm, &drm_response, drm_detail)) {
            for (auto it = entries.rbegin(); it != entries.rend(); ++it) restore_entry(*it);
            save_identity_values(old_values);
            device_identity::drm::restore_runtime(private_dir, old_drm, drm_detail);
            set_state("rolled-back", "drm-publish-failed,reboot-required");
            prune_transaction_directories(private_dir, directory);
            return "global-reset rolled-back(drm-publish-failed,reboot-required)";
        }
    }
    if (config.master_enabled) {
        std::string settings_detail;
        if (!apply_identity_settings(new_values, settings_detail)) {
            bool restored = restore_managed_settings_snapshot(settings_snapshot, settings_detail);
            for (auto it = entries.rbegin(); it != entries.rend(); ++it) restored = restore_entry(*it) && restored;
            save_identity_values(old_values);
            std::string drm_detail;
            device_identity::drm::restore_runtime(private_dir, old_drm, drm_detail);
            storage_write_string(kIdentityOaidTarget, storage_value(kIdentityOaidPreviousTarget));
            storage_write_string(kIdentityOaidPreviousTarget, "");
            apply_identity_properties(private_dir, old_values, false);
            apply_usb_gadget_serial(old_values.serial);
            set_identity_application_state(config.master_enabled ? "applied" : "pending");
            set_state("rolled-back", std::string("settings-failed,") + (restored ? "restored" : "restore-failed") +
                                      ",reboot-required");
            prune_transaction_directories(private_dir, directory);
            return "global-reset rolled-back(settings-failed,reboot-required)";
        }
    }
    set_identity_application_state(config.master_enabled ? "applied" : "pending");
    storage_write_string(kIdentityOaidPreviousTarget, "");
    set_state("applied", "complete entries=" + std::to_string(entries.size()));
    prune_transaction_directories(private_dir, directory);
    return "global-reset applied(entries=" + std::to_string(entries.size()) + ")";
}

std::string identity_surfaces_json() {
    const auto surfaces = probe_surfaces();
    std::string json = "[";
    for (size_t i = 0; i < surfaces.size(); ++i) {
        if (i) json.push_back(',');
        json += surface_json(surfaces[i]);
    }
    json.push_back(']');
    return json;
}

std::string global_reset_status_json() {
    std::string state;
    std::string detail;
    storage_read_string(kTxnState, state);
    storage_read_string(kTxnDetail, detail);
    if (state.empty()) state = "idle";
    const bool reboot = state == "prepared" ||
                        (state == "rolled-back" && detail.find("reboot-required") != std::string::npos);
    return "{\"state\":" + json_string(state) + ",\"detail\":" + json_string(detail) +
           ",\"reboot_required\":" + (reboot ? "true" : "false") + "}";
}

bool global_reset_pending() {
    std::string state;
    storage_read_string(kTxnState, state);
    return state == "prepared" || state == "early-applied";
}

}  // namespace jiebiao
