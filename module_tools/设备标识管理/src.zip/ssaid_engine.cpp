#include "ssaid_engine.h"

#include "common.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <sstream>

namespace fs = std::filesystem;

namespace jiebiao {
namespace {

constexpr size_t kMaxSsaidBytes = 16 * 1024 * 1024;
constexpr size_t kMaxSsaidXmlBytes = 32 * 1024 * 1024;
constexpr size_t kMaxUsers = 64;

bool numeric_user_id(const std::string& value, uint32_t& user_id) {
    if (value.empty() || value.size() > 5 ||
        !std::all_of(value.begin(), value.end(), [](unsigned char ch) { return std::isdigit(ch); })) {
        return false;
    }
    char* end = nullptr;
    const unsigned long parsed = std::strtoul(value.c_str(), &end, 10);
    if (!end || *end != '\0' || parsed > 99999) return false;
    user_id = static_cast<uint32_t>(parsed);
    return true;
}

bool is_hex(std::string_view value, size_t length) {
    return value.size() == length &&
           std::all_of(value.begin(), value.end(), [](unsigned char ch) { return std::isxdigit(ch); });
}

size_t tag_end(const std::string& xml, size_t start) {
    char quote = '\0';
    for (size_t i = start; i < xml.size(); ++i) {
        const char ch = xml[i];
        if (quote) {
            if (ch == quote) quote = '\0';
        } else if (ch == '\'' || ch == '"') {
            quote = ch;
        } else if (ch == '>') {
            return i;
        }
        if (i - start > 8192) break;
    }
    return std::string::npos;
}

bool attribute_range(const std::string& tag,
                     const std::string& name,
                     size_t& value_start,
                     size_t& value_length) {
    size_t cursor = 0;
    while ((cursor = tag.find(name, cursor)) != std::string::npos) {
        const bool left_ok = cursor == 0 || std::isspace(static_cast<unsigned char>(tag[cursor - 1])) ||
                             tag[cursor - 1] == '<';
        size_t equals = cursor + name.size();
        while (equals < tag.size() && std::isspace(static_cast<unsigned char>(tag[equals]))) ++equals;
        if (!left_ok || equals >= tag.size() || tag[equals] != '=') {
            cursor += name.size();
            continue;
        }
        ++equals;
        while (equals < tag.size() && std::isspace(static_cast<unsigned char>(tag[equals]))) ++equals;
        if (equals >= tag.size() || (tag[equals] != '\'' && tag[equals] != '"')) return false;
        const char quote = tag[equals++];
        const size_t end = tag.find(quote, equals);
        if (end == std::string::npos) return false;
        value_start = equals;
        value_length = end - equals;
        return true;
    }
    return false;
}

std::string attribute_value(const std::string& tag, const std::string& name) {
    size_t start = 0;
    size_t length = 0;
    return attribute_range(tag, name, start, length) ? tag.substr(start, length) : std::string();
}

bool replace_attribute(std::string& tag, const std::string& name, const std::string& value) {
    size_t start = 0;
    size_t length = 0;
    if (!attribute_range(tag, name, start, length)) return false;
    tag.replace(start, length, value);
    return true;
}

std::string work_path(const std::string& private_dir, const std::string& tag, const char* suffix) {
    std::string directory = private_dir;
    if (!directory.empty() && directory.back() != '/') directory.push_back('/');
    directory += "backups";
    mkdir(directory.c_str(), 0700);
    chmod(directory.c_str(), 0700);
    return directory + "/." + tag + "." + std::to_string(getpid()) + suffix;
}

const char* format_name(SsaidFormat format) {
    switch (format) {
        case SsaidFormat::Xml: return "xml";
        case SsaidFormat::Abx: return "abx";
        default: return "unknown";
    }
}

}  // namespace

bool inspect_ssaid_file(uint32_t user_id,
                        const std::string& path,
                        AndroidUserInfo& user,
                        std::string& detail) {
    user = {};
    struct stat st{};
    if (lstat(path.c_str(), &st) != 0) {
        detail = errno == ENOENT ? "absent" : "stat-failed";
        return false;
    }
    if (!S_ISREG(st.st_mode) || S_ISLNK(st.st_mode) || st.st_size < 3 ||
        static_cast<uint64_t>(st.st_size) > kMaxSsaidBytes) {
        detail = "invalid-file";
        return false;
    }
    std::string data;
    if (!read_file(path, data, kMaxSsaidBytes)) {
        detail = "read-failed";
        return false;
    }
    SsaidFormat format = SsaidFormat::Unknown;
    if (data.size() >= 3 && data.compare(0, 3, "ABX") == 0) format = SsaidFormat::Abx;
    else if (data.find('<') != std::string::npos) format = SsaidFormat::Xml;
    const bool converters = access("/system/bin/abx2xml", X_OK) == 0 &&
                            access("/system/bin/xml2abx", X_OK) == 0;
    const bool ready = format == SsaidFormat::Xml || (format == SsaidFormat::Abx && converters);
    user = AndroidUserInfo{user_id,
        user_id == 0 ? "主用户 (0)" : "用户 " + std::to_string(user_id),
        path, format, ready};
    detail = ready ? "ok" : (format == SsaidFormat::Abx ? "abx-tools-unavailable" : "unknown-format");
    return true;
}

std::vector<AndroidUserInfo> discover_android_users() {
    std::vector<AndroidUserInfo> users;
    std::error_code error;
    const fs::path root("/data/system/users");
    for (fs::directory_iterator it(root, fs::directory_options::skip_permission_denied, error), end;
         it != end && !error && users.size() < kMaxUsers; it.increment(error)) {
        if (error) { error.clear(); continue; }
        uint32_t user_id = 0;
        if (!numeric_user_id(it->path().filename().string(), user_id)) continue;
        const fs::path path = it->path() / "settings_ssaid.xml";
        AndroidUserInfo user;
        std::string detail;
        if (inspect_ssaid_file(user_id, path.string(), user, detail)) users.push_back(std::move(user));
    }
    std::sort(users.begin(), users.end(), [](const auto& left, const auto& right) { return left.id < right.id; });
    return users;
}

std::string android_users_json(const std::vector<AndroidUserInfo>& users) {
    std::string json = "[";
    for (size_t i = 0; i < users.size(); ++i) {
        if (i) json.push_back(',');
        const auto& user = users[i];
        json += "{\"id\":" + std::to_string(user.id) +
                ",\"label\":" + json_string(user.label) +
                ",\"format\":" + json_string(format_name(user.format)) +
                ",\"ready\":" + (user.ready ? "true" : "false") + "}";
    }
    json.push_back(']');
    return json;
}

bool parse_user_selector(const std::string& selector, bool& all_users, uint32_t& user_id) {
    all_users = selector == "all";
    user_id = 0;
    return all_users || numeric_user_id(selector, user_id);
}

bool reset_package_ssaid_xml(std::string& xml,
                             const std::string& package_name,
                             const std::string& replacement,
                             size_t& changed,
                             std::string& detail) {
    changed = 0;
    if (!valid_package_name(package_name) || !is_hex(replacement, 16)) {
        detail = "invalid-input";
        return false;
    }
    size_t cursor = 0;
    while ((cursor = xml.find("<setting", cursor)) != std::string::npos) {
        const size_t end = tag_end(xml, cursor);
        if (end == std::string::npos) { detail = "malformed-xml"; return false; }
        std::string tag = xml.substr(cursor, end - cursor + 1);
        if (attribute_value(tag, "package") == package_name) {
            const std::string value = attribute_value(tag, "value");
            if (is_hex(value, 16) && replace_attribute(tag, "value", replacement)) {
                xml.replace(cursor, end - cursor + 1, tag);
                ++changed;
                cursor += tag.size();
                continue;
            }
        }
        cursor = end + 1;
    }
    detail = changed ? "ok" : "package-entry-not-found";
    return changed != 0;
}

bool reset_all_ssaid_xml(std::string& xml,
                         const std::string& android_id,
                         const std::string& userkey,
                         size_t& changed,
                         std::string& detail) {
    changed = 0;
    if (!is_hex(android_id, 16) || !is_hex(userkey, 64)) {
        detail = "invalid-input";
        return false;
    }
    bool userkey_found = false;
    size_t cursor = 0;
    while ((cursor = xml.find("<setting", cursor)) != std::string::npos) {
        const size_t end = tag_end(xml, cursor);
        if (end == std::string::npos) { detail = "malformed-xml"; return false; }
        std::string tag = xml.substr(cursor, end - cursor + 1);
        const std::string name = attribute_value(tag, "name");
        const std::string* replacement = nullptr;
        if (name == "android_id") {
            const std::string old_value = attribute_value(tag, "value");
            if (!old_value.empty() && !is_hex(old_value, 16)) { detail = "invalid-android-id"; return false; }
            replacement = &android_id;
        } else if (name == "userkey") {
            const std::string old_value = attribute_value(tag, "value");
            if (!is_hex(old_value, 64)) { detail = "invalid-userkey"; return false; }
            replacement = &userkey;
            userkey_found = true;
        }
        if (replacement && replace_attribute(tag, "value", *replacement)) {
            xml.replace(cursor, end - cursor + 1, tag);
            ++changed;
            cursor += tag.size();
        } else {
            cursor = end + 1;
        }
    }
    if (!userkey_found) {
        cursor = 0;
        while ((cursor = xml.find("<setting", cursor)) != std::string::npos) {
            const size_t end = tag_end(xml, cursor);
            if (end == std::string::npos) { detail = "malformed-xml"; return false; }
            std::string tag = xml.substr(cursor, end - cursor + 1);
            const std::string package_name = attribute_value(tag, "package");
            const std::string value = attribute_value(tag, "value");
            if (!package_name.empty() && is_hex(value, 16) &&
                replace_attribute(tag, "value", random_hex(16))) {
                xml.replace(cursor, end - cursor + 1, tag);
                ++changed;
                cursor += tag.size();
            } else {
                cursor = end + 1;
            }
        }
    }
    detail = changed ? (userkey_found ? "ok-userkey" : "ok-legacy") : "recognized-values-not-found";
    return changed != 0;
}

bool load_ssaid_document(const std::string& private_dir,
                         const AndroidUserInfo& user,
                         const std::string& work_tag,
                         SsaidDocument& document,
                         std::string& detail) {
    document = {};
    if (!user.ready || !read_file(user.path, document.original, kMaxSsaidBytes)) {
        detail = user.format == SsaidFormat::Abx ? "abx-tools-unavailable" : "read-failed";
        return false;
    }
    document.user = user;
    if (user.format == SsaidFormat::Xml) {
        document.xml = document.original;
    } else if (user.format == SsaidFormat::Abx) {
        if (run_process({"/system/bin/abx2xml", user.path, "-"},
                        &document.xml, kMaxSsaidXmlBytes) != 0 ||
            document.xml.empty() || document.xml.find('<') == std::string::npos) {
            detail = "abx2xml-failed";
            return false;
        }
    } else {
        detail = "unknown-format";
        return false;
    }
    (void)private_dir;
    (void)work_tag;
    detail = "ok";
    return true;
}

bool encode_ssaid_document(const std::string& private_dir,
                           const SsaidDocument& document,
                           const std::string& xml,
                           const std::string& work_tag,
                           std::string& encoded,
                           std::string& detail) {
    encoded.clear();
    if (document.user.format == SsaidFormat::Xml) {
        encoded = xml;
        detail = "ok";
        return true;
    }
    if (document.user.format != SsaidFormat::Abx) {
        detail = "unknown-format";
        return false;
    }
    const std::string xml_path = work_path(private_dir, work_tag, ".xml");
    const std::string abx_path = work_path(private_dir, work_tag, ".abx");
    unlink(xml_path.c_str());
    unlink(abx_path.c_str());
    bool ok = write_file_atomic(xml_path, xml, 0600, false) &&
              run_process({"/system/bin/xml2abx", xml_path, abx_path}) == 0 &&
              read_file(abx_path, encoded, kMaxSsaidBytes) && encoded.size() >= 3 &&
              encoded.compare(0, 3, "ABX") == 0;
    std::string roundtrip;
    if (ok) {
        ok = run_process({"/system/bin/abx2xml", abx_path, "-"},
                         &roundtrip, kMaxSsaidXmlBytes) == 0 &&
             !roundtrip.empty() && roundtrip.find('<') != std::string::npos;
    }
    unlink(xml_path.c_str());
    unlink(abx_path.c_str());
    detail = ok ? "ok" : "xml2abx-failed";
    return ok;
}

}  // namespace jiebiao
