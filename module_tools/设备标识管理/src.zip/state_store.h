#pragma once

#include <cstdint>
#include <string>

namespace jiebiao {

inline constexpr uint32_t kConfigSchemaVersion = 5;

struct ModuleConfig {
    uint32_t schema_version = kConfigSchemaVersion;
    bool master_enabled = false;
};

struct PendingAction {
    uint32_t sequence = 0;
    std::string type;
    std::string payload;
};

ModuleConfig load_config();
bool save_config(const ModuleConfig& config);
bool clear_removed_model_config();

bool storage_read_string(const char* key, std::string& value);
bool storage_write_string(const char* key, const std::string& value);
bool storage_read_bool(const char* key, bool& value);
bool storage_write_bool(const char* key, bool value);
bool storage_read_u32(const char* key, uint32_t& value);
bool storage_write_u32(const char* key, uint32_t value);
bool storage_read_i32(const char* key, int32_t& value);
bool storage_write_i32(const char* key, int32_t value);

uint32_t enqueue_action(const std::string& type, const std::string& payload);
bool read_action_after(uint32_t last_sequence, PendingAction& action);
bool write_action_result(uint32_t sequence, const std::string& result_json);
std::string read_action_result(uint32_t* sequence = nullptr);

bool store_daemon_identity(int32_t pid, const std::string& current_boot_id);
bool read_daemon_identity(int32_t& pid, std::string& current_boot_id);

bool set_legacy_conflict(const std::string& module_id,
                         const std::string& version);
void clear_legacy_conflict();
bool read_legacy_conflict(std::string& module_id, std::string& version);

}  // namespace jiebiao
