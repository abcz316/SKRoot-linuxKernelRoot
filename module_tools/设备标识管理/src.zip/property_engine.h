#pragma once

#include <cstddef>
#include <string>
#include <utility>

namespace jiebiao {

struct PropertyApplyResult {
    size_t applied = 0;
    size_t skipped = 0;
    size_t failed = 0;
    std::string message;
};

std::string resetprop_path(const std::string& private_dir);
bool set_property(const std::string& private_dir,
                  const std::string& key,
                  const std::string& value);

PropertyApplyResult restore_legacy_template_properties(const std::string& private_dir);

// One-way upgrade cleanup for builds that previously exposed patch-date
// spoofing.  No current configuration or application path writes it.
PropertyApplyResult restore_retired_security_patch(const std::string& private_dir);

}  // namespace jiebiao
