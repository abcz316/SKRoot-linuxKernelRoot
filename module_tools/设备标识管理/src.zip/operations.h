#pragma once

#include <string>

namespace jiebiao {

bool schedule_ssaid_reset(const std::string& package_name,
                          const std::string& user_selector,
                          std::string& message);

// Called from skroot_module_main before zygote64 starts.
std::string perform_early_pending_operations(const std::string& private_dir);

// Called by the root daemon after Android boot completion.
std::string recover_post_boot_global_reset(const std::string& private_dir);
std::string perform_post_boot_operations(const std::string& private_dir);

}  // namespace jiebiao
