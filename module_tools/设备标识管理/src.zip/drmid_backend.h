#pragma once

#include "module_err_def.h"

namespace device_identity::drm {
KModErr run_backend(const char* root_key, const char* module_private_dir);
}
