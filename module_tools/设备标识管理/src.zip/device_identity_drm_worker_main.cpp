#include "drmid_worker.h"
#include <cstdlib>

int main() {
    const char* private_dir = std::getenv("DEVICE_IDENTITY_PRIVATE_DIR");
    return device_identity::drm::worker_main(
        private_dir && *private_dir ? private_dir : "/data/adb/.drmid_private");
}
