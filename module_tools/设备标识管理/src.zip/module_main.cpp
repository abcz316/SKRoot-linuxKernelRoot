#include "common.h"
#include "daemon.h"
#include "drmid_worker.h"
#include "identity_engine.h"
#include "operations.h"
#include "property_engine.h"
#include "state_store.h"
#include "usb_serial_engine.h"

#include "file_lifecycle.h"
#include "kernel_module_kit_umbrella.h"

#include <sys/stat.h>
#include <unistd.h>

#include <string>

#if defined(__aarch64__)
constexpr bool kArm64Build = true;
#else
constexpr bool kArm64Build = false;
#endif

namespace {

std::string normalize_private_dir(const char* value) {
    std::string path = value ? value : "";
    while (path.size() > 1 && path.back() == '/') path.pop_back();
    return path;
}

}  // namespace

int skroot_module_main(const char* root_key, const char* module_private_dir) {
    (void)kArm64Build;  // Resolver performs the live ABI gate in the worker.
    if (!kArm64Build || sizeof(void*) != 8) {
        kernel_module::set_current_module_run_state(
            skroot_env::ModuleRunState::Abnormal);
        return static_cast<int>(to_num(KModErr::ERR_MODULE_FUNC_NOT_STANDARD));
    }
    const std::string private_dir = normalize_private_dir(module_private_dir);
    if (!root_key || !*root_key || private_dir.empty()) {
        return static_cast<int>(to_num(KModErr::ERR_MODULE_PARAM));
    }
    drmid::cleanup_legacy_public_artifacts();
    drmid::cleanup_seed_temp_orphans(module_private_dir);

    device_identity::drm::ConflictStatus conflict;
    if (!device_identity::drm::detect_legacy_module_conflict(root_key, conflict)) {
        kernel_module::set_current_module_run_state(
            skroot_env::ModuleRunState::Abnormal);
        kernel_module::set_current_module_description(
            "旧模块冲突检查失败；设备标识管理保持停用");
        return static_cast<int>(to_num(KModErr::ERR_MODULE_TEST_CHANNEL));
    }
    if (conflict.detected) {
        jiebiao::set_legacy_conflict(conflict.module_id, conflict.module_version);
        kernel_module::set_current_module_run_state(
            skroot_env::ModuleRunState::Abnormal);
        kernel_module::set_current_module_description(
            "检测到旧版设备标识模块；设备标识管理保持停用");
        return static_cast<int>(to_num(KModErr::ERR_MODULE_TEST_CHANNEL));
    }
    jiebiao::clear_legacy_conflict();

    chmod(jiebiao::resetprop_path(private_dir).c_str(), 0700);
    chmod(device_identity::drm::worker_path(private_dir).c_str(), 0700);
    const auto retired_patch = jiebiao::restore_retired_security_patch(private_dir);
    jiebiao::storage_write_string("security_patch", "");
    jiebiao::append_log(private_dir,
        "retired-security-patch-restore=" + retired_patch.message + ':' +
        std::to_string(retired_patch.applied) + '/' +
        std::to_string(retired_patch.failed));
    jiebiao::ensure_identity_baseline_properties();

    const std::string pending_result =
        jiebiao::perform_early_pending_operations(private_dir);
    if (!pending_result.empty()) jiebiao::append_log(private_dir, pending_result);

    const jiebiao::ModuleConfig config = jiebiao::load_config();
    const std::string apply_result =
        jiebiao::apply_early_config(private_dir, config, true);
    jiebiao::append_log(private_dir, "early=" + apply_result);

    if (!jiebiao::start_background_daemon(root_key, private_dir)) {
        kernel_module::set_current_module_run_state(
            skroot_env::ModuleRunState::Abnormal);
        kernel_module::set_current_module_description(
            "设备标识管理后台启动失败，请查看模块日志");
        return static_cast<int>(to_num(KModErr::ERR_MODULE_TEST_CHANNEL));
    }
    kernel_module::set_current_module_run_state(
        skroot_env::ModuleRunState::Running);
    kernel_module::set_current_module_description(
        "设备标识、SSAID、OAID 与 Widevine DRM ID 统一管理");
    return 0;
}

std::string module_on_install(const char*, const char* module_private_dir) {
    const std::string private_dir = normalize_private_dir(module_private_dir);
    if (private_dir.empty()) return "模块私有目录为空";

    // An upgrade can run while the previous supervisor/worker is still
    // resident. Stop both before migrating state or replacing the payload;
    // otherwise the old Binder hook may survive until the next reboot and
    // make the installation appear to cause a long-running thermal event.
    jiebiao::stop_background_daemon();
    std::string stale_worker_detail;
    device_identity::drm::stop_worker(private_dir, stale_worker_detail);
    jiebiao::append_log(
        private_dir, "module-install stale-runtime-stop=" + stale_worker_detail);

    jiebiao::storage_write_string("id_imsi", "");
    jiebiao::storage_write_string("id_iccid", "");
    chmod(jiebiao::resetprop_path(private_dir).c_str(), 0700);
    chmod(device_identity::drm::worker_path(private_dir).c_str(), 0700);

    const auto retired_patch = jiebiao::restore_retired_security_patch(private_dir);
    if (retired_patch.failed != 0 ||
        !jiebiao::storage_write_string("security_patch", "")) {
        return "旧安全补丁配置恢复失败，请查看模块日志";
    }

    std::string retired_identity_cleanup;
    if (!jiebiao::restore_retired_identity_settings(retired_identity_cleanup)) {
        return "旧标识设置恢复失败，请查看模块日志";
    }
    jiebiao::append_log(
        private_dir, "retired-identity-cleanup=" + retired_identity_cleanup);

    uint32_t schema = 0;
    if (!jiebiao::storage_read_u32("config_schema", schema) ||
        schema != jiebiao::kConfigSchemaVersion) {
        const auto template_cleanup =
            jiebiao::restore_legacy_template_properties(private_dir);
        std::string device_name_cleanup;
        const bool names_cleaned =
            jiebiao::restore_legacy_device_name_settings(device_name_cleanup);
        if (template_cleanup.failed != 0 || !names_cleaned) {
            return "旧机型配置恢复失败，请查看模块日志";
        }
        jiebiao::ModuleConfig fresh;
        fresh.master_enabled = false;
        if (!jiebiao::save_config(fresh) ||
            !jiebiao::clear_removed_model_config()) {
            return "初始化设备标识管理配置失败";
        }
        jiebiao::storage_write_bool("pending_identity_reset", false);
    }

    drmid::ReplacementConfig drm_config{};
    bool created = false;
    std::string drm_detail;
    if (!device_identity::drm::initialize_runtime(
            private_dir, drm_config, created, drm_detail)) {
        return "初始化 DRM ID 私有配置失败";
    }
    jiebiao::append_log(private_dir,
        "module-install schema=" +
            std::to_string(jiebiao::kConfigSchemaVersion) +
            ";drm=" + drm_detail +
            ";created=" + (created ? "1" : "0"));
    return "";
}

void module_on_uninstall(const char*, const char* module_private_dir) {
    const std::string private_dir = normalize_private_dir(module_private_dir);
    jiebiao::stop_background_daemon();
    std::string drm_detail;
    device_identity::drm::stop_worker(private_dir, drm_detail);
    jiebiao::restore_legacy_template_properties(private_dir);
    jiebiao::restore_retired_security_patch(private_dir);
    jiebiao::restore_identity_properties(private_dir);
    const auto usb_result = jiebiao::restore_usb_gadget_serial();
    std::string settings_detail;
    jiebiao::restore_identity_settings(settings_detail);
    drmid::cleanup_module_state_files(private_dir.c_str());
    jiebiao::append_log(private_dir,
        "module-uninstall drm=" + drm_detail + ",usb=" + usb_result.detail +
        ",settings=" + settings_detail);
}

SKROOT_MODULE_NAME("设备标识管理")
SKROOT_MODULE_VERSION("1.0.5")
SKROOT_MODULE_DESC("统一管理设备标识、SSAID、OAID 与 Widevine DRM ID")
SKROOT_MODULE_AUTHOR("斓梦语、蜃、榆爱")
SKROOT_MODULE_ID32("deviceIdentityManagerSKP20260904")
SKROOT_MODULE_ON_INSTALL(module_on_install)
SKROOT_MODULE_ON_UNINSTALL(module_on_uninstall)
