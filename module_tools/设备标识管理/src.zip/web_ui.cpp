#include "common.h"
#include "daemon.h"
#include "drmid_worker.h"
#include "identity_engine.h"
#include "operations.h"
#include "reset_transaction.h"
#include "ssaid_engine.h"
#include "state_store.h"

#include "kernel_module_kit_umbrella.h"

#include <signal.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cinttypes>
#include <mutex>
#include <sstream>
#include <thread>
#include <vector>

namespace jiebiao {
namespace {

constexpr auto kWebUiOpenGrace = std::chrono::seconds(20);
constexpr auto kWebUiIdleTimeout = std::chrono::seconds(12);
constexpr auto kWebUiCloseDelay = std::chrono::milliseconds(120);

bool bool_from_form(const std::map<std::string, std::string>& form, const char* key) {
    const auto it = form.find(key);
    return it != form.end() && (it->second == "1" || it->second == "true" || it->second == "on");
}

std::string config_json(const ModuleConfig& config) {
    return "{" +
           std::string("\"schema\":") + std::to_string(config.schema_version) +
           ",\"master_enabled\":" + (config.master_enabled ? "true" : "false") + "}";
}

std::string drm_fingerprint(uint64_t value) {
    if (value == 0) return {};
    char text[17];
    std::snprintf(text, sizeof(text), "%016" PRIx64, value);
    return text;
}

// The regular identity engine owns the serial/SSAID/OAID fields.  DRM is a
// resident Binder subsystem, so add its read-only fingerprints at the WebUI
// boundary rather than coupling the two persistence layers.  Raw Widevine
// bytes never leave the worker; only the original and configured fingerprints
// are displayed.
std::string append_drm_identity(std::string json,
                                const device_identity::drm::Status& status,
                                bool verification) {
    if (json.empty() || json.back() != '}') return json;
    const std::string original = status.device_fingerprint;
    const std::string current = drm_fingerprint(status.control.profile_fingerprint);
    const bool running = status.state == device_identity::drm::WorkerState::kRunning &&
                         status.control_connected;
    const bool write_mode = status.control.replacement_mode ==
                            static_cast<uint32_t>(drmid::ReplacementMode::kWriteTest);
    const std::string state = verification
        ? (running && write_mode && !current.empty() ? "passed" :
           running && !current.empty() ? "pending" : "unsupported")
        : (!original.empty() && running && write_mode && !current.empty() ? "applied" :
           !original.empty() && !current.empty() ? "pending" : "unknown");
    const std::string display_current = verification
        ? (state == "passed" ? "Binder 等长替换链路已验证" :
           state == "pending" ? "Dry-run：等待启用替换" : "等待 Binder 后端")
        : (state == "applied" ? current : state == "pending" ? "待应用" : "未捕获");
    const std::string field = "\"drmid\":{\"original\":" + json_string(original) +
        ",\"current\":" + json_string(display_current) +
        ",\"state\":" + json_string(state) +
        ",\"detail\":" + json_string("Binder profile fingerprint") + "}";
    json.insert(json.size() - 1, (json.size() > 2 ? "," : "") + field);
    return json;
}

}  // namespace

class JiebiaoWebHandler final : public kernel_module::WebUIHttpHandler {
public:
    void onPrepareCreate(const char* root_key,
                         const char* module_private_dir,
                         uint32_t port) override {
        std::lock_guard<std::mutex> guard(lock_);
        root_key_ = root_key ? root_key : "";
        private_dir_ = module_private_dir ? module_private_dir : "";
        session_token_.clear();
        session_open_ = false;
        shutdown_requested_ = false;
        server_exiting_ = false;
        session_last_activity_ = std::chrono::steady_clock::now();
        printf("[jiebiao] WebUI ready port=%u private=%s\n", port, private_dir_.c_str());
    }

    void onServerCreated(CivetServer* server) override {
        {
            std::lock_guard<std::mutex> guard(lock_);
            server_ = server;
            session_last_activity_ = std::chrono::steady_clock::now();
        }
        if (!watchdog_started_.exchange(true)) {
            std::thread([this] { session_watchdog(); }).detach();
        }
    }

    ServerExitAction onBeforeServerExit() override {
        std::lock_guard<std::mutex> guard(lock_);
        session_open_ = false;
        session_token_.clear();
        server_exiting_ = true;
        std::fill(root_key_.begin(), root_key_.end(), '\0');
        root_key_.clear();
        return ServerExitAction::Exit;
    }

    bool handlePost(CivetServer*,
                    mg_connection* connection,
                    const std::string& path,
                    const std::string& body) override {
        const auto form = parse_form(body);
        if (path == "/api/session") return handle_session_open(connection);
        if (path == "/api/session/ping") return handle_session_ping(connection, form);
        if (path == "/api/session/close") return handle_session_close(connection, form);
        if (!authenticated(form)) {
            kernel_module::webui::send_json(connection, 401, "{\"ok\":false,\"error\":\"session\"}");
            return true;
        }
        std::string conflict_id;
        std::string conflict_version;
        const bool conflict = read_legacy_conflict(conflict_id, conflict_version);
        const bool read_only_route = path == "/api/status" || path == "/api/log" ||
                                     path == "/api/action-result";
        if (conflict && !read_only_route) {
            kernel_module::webui::send_json(connection, 409,
                "{\"ok\":false,\"error\":\"legacy-module-conflict\",\"id\":" +
                json_string(conflict_id) + "}");
            return true;
        }
        if (path == "/api/status") return handle_status(connection);
        if (path == "/api/config") return handle_config(connection, form);
        if (path == "/api/randomize") return handle_randomize(connection);
        if (path == "/api/reset-ssaid") return handle_reset_ssaid(connection, form);
        if (path == "/api/local-reset") return handle_local_reset(connection, form);
        if (path == "/api/drm-stop") return handle_drm_stop(connection);
        if (path == "/api/action-result") return handle_action_result(connection);
        if (path == "/api/log") return handle_log(connection);
        kernel_module::webui::send_json(connection, 404, "{\"ok\":false,\"error\":\"route\"}");
        return true;
    }

private:
    bool authenticated(const std::map<std::string, std::string>& form) {
        const auto it = form.find("token");
        if (it == form.end()) return false;
        std::lock_guard<std::mutex> guard(lock_);
        if (!session_open_ || server_exiting_ || it->second.size() != session_token_.size()) return false;
        unsigned char difference = 0;
        for (size_t i = 0; i < session_token_.size(); ++i) {
            difference |= static_cast<unsigned char>(session_token_[i] ^ it->second[i]);
        }
        if (difference != 0) return false;
        session_last_activity_ = std::chrono::steady_clock::now();
        return true;
    }

    bool handle_session_open(mg_connection* connection) {
        std::lock_guard<std::mutex> guard(lock_);
        if (server_exiting_ || server_ == nullptr) {
            kernel_module::webui::send_json(connection, 503,
                "{\"ok\":false,\"error\":\"webui-exited\"}");
            return true;
        }
        session_token_ = random_hex(32);
        session_open_ = !session_token_.empty();
        session_last_activity_ = std::chrono::steady_clock::now();
        shutdown_requested_ = false;
        kernel_module::webui::send_json(connection, 200,
            "{\"ok\":true,\"token\":" + json_string(session_token_) +
            ",\"heartbeat_ms\":4000}");
        return true;
    }

    bool handle_session_ping(mg_connection* connection,
                             const std::map<std::string, std::string>& form) {
        if (!authenticated(form)) {
            kernel_module::webui::send_json(connection, 401,
                "{\"ok\":false,\"error\":\"session\"}");
            return true;
        }
        kernel_module::webui::send_json(connection, 200,
            "{\"ok\":true,\"heartbeat_ms\":4000}");
        return true;
    }

    bool handle_session_close(mg_connection* connection,
                              const std::map<std::string, std::string>& form) {
        if (!authenticated(form)) {
            kernel_module::webui::send_json(connection, 401,
                "{\"ok\":false,\"error\":\"session\"}");
            return true;
        }
        {
            std::lock_guard<std::mutex> guard(lock_);
            session_open_ = false;
            session_token_.clear();
            request_server_close_locked();
        }
        kernel_module::webui::send_json(connection, 200,
            "{\"ok\":true,\"closed\":true}");
        return true;
    }

    void request_server_close_locked() {
        if (shutdown_requested_ || server_ == nullptr || server_exiting_) return;
        shutdown_requested_ = true;
        CivetServer* server = server_;
        std::thread([server] {
            std::this_thread::sleep_for(kWebUiCloseDelay);
            if (server != nullptr) server->close();
        }).detach();
    }

    void session_watchdog() {
        for (;;) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            std::lock_guard<std::mutex> guard(lock_);
            if (server_ == nullptr || server_exiting_ || shutdown_requested_) continue;
            const auto idle = std::chrono::steady_clock::now() - session_last_activity_;
            const auto limit = session_open_ ? kWebUiIdleTimeout : kWebUiOpenGrace;
            if (idle >= limit) request_server_close_locked();
        }
    }

    bool handle_status(mg_connection* connection) {
        bool daemon_alive = background_daemon_alive(private_dir_);
        std::string transaction_state;
        storage_read_string("global_reset_state_v2", transaction_state);
        if (transaction_state == "early-applied" && !daemon_alive) {
            const std::string recovery = perform_post_boot_operations(private_dir_);
            if (!recovery.empty()) append_log(private_dir_, "webui-recovery " + recovery);
            transaction_state.clear();
            storage_read_string("global_reset_state_v2", transaction_state);
        }
        if (!daemon_alive) {
            std::string conflict_id;
            std::string conflict_version;
            const bool conflict = read_legacy_conflict(conflict_id, conflict_version);
            std::string root_key;
            std::string private_dir;
            {
                std::lock_guard<std::mutex> guard(lock_);
                root_key = root_key_;
                private_dir = private_dir_;
            }
            if (!conflict && !root_key.empty() && !private_dir.empty()) {
                start_background_daemon(root_key.c_str(), private_dir);
                std::fill(root_key.begin(), root_key.end(), '\0');
                daemon_alive = background_daemon_alive(private_dir_);
            }
        }
        int32_t daemon_pid = 0;
        std::string daemon_boot;
        read_daemon_identity(daemon_pid, daemon_boot);
        const ModuleConfig config = load_config();
        const IdentityValues identities = load_or_create_identity(false);
        uint32_t result_sequence = 0;
        const std::string action_result = read_action_result(&result_sequence);
        std::string users_json;
        std::string surfaces_json;
        if (!storage_read_string("android_users_cache_v2", users_json) || users_json.empty()) users_json = "[]";
        if (!storage_read_string("identity_surfaces_cache_v2", surfaces_json) || surfaces_json.empty()) surfaces_json = "[]";
        ensure_identity_baseline_properties();
        ensure_identity_baseline_settings();
        ensure_identity_baseline_oaid();

        const auto drm_status = device_identity::drm::read_status(private_dir_);
        std::string identity_json = append_drm_identity(
            identity_comparison_json(identities, config.master_enabled), drm_status, false);
        std::string verification_json = append_drm_identity(
            identity_verification_json(identities, config.master_enabled), drm_status, true);
        std::string json = "{\"ok\":true,\"config\":" + config_json(config) +
            ",\"identity\":" + identity_values_json(identities) +
            ",\"identity_comparison\":" + identity_json +
            ",\"identity_verification\":" + verification_json +
            ",\"device\":{\"brand\":" + json_string(get_property("ro.product.brand")) +
            ",\"model\":" + json_string(get_property("ro.product.model")) +
            ",\"device\":" + json_string(get_property("ro.product.device")) +
            ",\"fingerprint\":" + json_string(get_property("ro.build.fingerprint")) +
            ",\"serial\":" + json_string(get_property("ro.serialno")) + "}" +
            ",\"daemon\":{\"alive\":" + (daemon_alive ? "true" : "false") +
            ",\"pid\":" + std::to_string(daemon_pid) + "}" +
            ",\"drm\":" + device_identity::drm::status_json(drm_status) +
            ",\"legacy_conflict\":" + [&] { std::string id, version; const bool found = read_legacy_conflict(id, version); return std::string("{\"detected\":") + (found ? "true" : "false") + ",\"id\":" + json_string(id) + ",\"version\":" + json_string(version) + "}"; }() +
            ",\"users\":" + users_json +
            ",\"identity_surfaces\":" + surfaces_json +
            ",\"global_reset\":" + global_reset_status_json() +
            ",\"last_action\":{\"sequence\":" + std::to_string(result_sequence) +
            ",\"result\":" + (action_result.empty() ? "null" : action_result) + "}}";
        kernel_module::webui::send_json(connection, 200, json);
        return true;
    }

    bool handle_config(mg_connection* connection,
                       const std::map<std::string, std::string>& form) {
        if (global_reset_pending()) {
            kernel_module::webui::send_json(connection, 409, "{\"ok\":false,\"error\":\"global-reset-pending\"}");
            return true;
        }
        ModuleConfig config = load_config();
        const ModuleConfig previous = config;
        config.master_enabled = bool_from_form(form, "master_enabled");
        if (!save_config(config)) {
            kernel_module::webui::send_json(connection, 500, "{\"ok\":false,\"error\":\"storage\"}");
            return true;
        }
        const uint32_t sequence = enqueue_action("apply-config", "");
        if (sequence == 0) save_config(previous);
        kernel_module::webui::send_json(connection, sequence ? 202 : 500,
            std::string("{\"ok\":") + (sequence ? "true" : "false") +
            ",\"sequence\":" + std::to_string(sequence) + "}");
        return true;
    }

    bool handle_randomize(mg_connection* connection) {
        if (global_reset_pending()) {
            kernel_module::webui::send_json(connection, 409, "{\"ok\":false,\"error\":\"global-reset-pending\"}");
            return true;
        }
        const uint32_t sequence = enqueue_action("randomize-identities", "");
        kernel_module::webui::send_json(connection, sequence ? 202 : 500,
            std::string("{\"ok\":") + (sequence ? "true" : "false") +
            ",\"sequence\":" + std::to_string(sequence) + "}");
        return true;
    }

    bool handle_reset_ssaid(mg_connection* connection,
                            const std::map<std::string, std::string>& form) {
        const auto it = form.find("package");
        const auto user_it = form.find("user");
        const std::string user = user_it == form.end() ? "0" : user_it->second;
        std::string message;
        const bool ok = it != form.end() && schedule_ssaid_reset(it->second, user, message);
        kernel_module::webui::send_json(connection, ok ? 202 : 422,
            std::string("{\"ok\":") + (ok ? "true" : "false") +
            ",\"message\":" + json_string(message) + ",\"reboot_required\":true}");
        return true;
    }

    bool handle_local_reset(mg_connection* connection,
                            const std::map<std::string, std::string>& form) {
        const auto it = form.find("confirm");
        if (it == form.end() || it->second != "RESET_IDENTIFIERS") {
            kernel_module::webui::send_json(connection, 422, "{\"ok\":false,\"error\":\"confirmation\"}");
            return true;
        }
        const uint32_t sequence = enqueue_action("prepare-global-reset", "");
        kernel_module::webui::send_json(connection, sequence ? 202 : 500,
            std::string("{\"ok\":") + (sequence ? "true" : "false") +
            ",\"sequence\":" + std::to_string(sequence) +
            ",\"message\":\"preflight-queued\",\"reboot_required\":false}");
        return true;
    }

    bool handle_drm_stop(mg_connection* connection) {
        if (global_reset_pending()) {
            kernel_module::webui::send_json(connection, 409,
                "{\"ok\":false,\"error\":\"global-reset-pending\"}");
            return true;
        }
        const uint32_t sequence = enqueue_action("stop-drm-worker", "");
        kernel_module::webui::send_json(connection, sequence ? 202 : 500,
            std::string("{\"ok\":") + (sequence ? "true" : "false") +
            ",\"sequence\":" + std::to_string(sequence) + "}");
        return true;
    }

    bool handle_action_result(mg_connection* connection) {
        uint32_t sequence = 0;
        const std::string result = read_action_result(&sequence);
        kernel_module::webui::send_json(connection, 200,
            "{\"ok\":true,\"sequence\":" + std::to_string(sequence) +
            ",\"result\":" + (result.empty() ? "null" : result) + "}");
        return true;
    }

    bool handle_log(mg_connection* connection) {
        std::string path = private_dir_;
        if (!path.empty() && path.back() != '/') path.push_back('/');
        path += "jiebiao.log";
        std::string log;
        read_file(path, log, 512 * 1024);
        if (log.size() > 128 * 1024) log.erase(0, log.size() - 128 * 1024);
        kernel_module::webui::send_json(connection, 200,
            "{\"ok\":true,\"log\":" + json_string(log) + "}");
        return true;
    }

    std::mutex lock_;
    std::string root_key_;
    std::string private_dir_;
    std::string session_token_;
    CivetServer* server_ = nullptr;
    bool session_open_ = false;
    bool shutdown_requested_ = false;
    bool server_exiting_ = false;
    std::chrono::steady_clock::time_point session_last_activity_{};
    std::atomic_bool watchdog_started_{false};
};

}  // namespace jiebiao

SKROOT_MODULE_WEB_UI(jiebiao::JiebiaoWebHandler)
