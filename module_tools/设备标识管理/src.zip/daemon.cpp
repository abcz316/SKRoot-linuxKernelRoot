#include "daemon.h"

#include "common.h"
#include "drmid_worker.h"
#include "identity_engine.h"
#include "operations.h"
#include "property_engine.h"
#include "reset_transaction.h"
#include "ssaid_engine.h"
#include "usb_serial_engine.h"
#include "supervisor_lease.h"

#include "kernel_module_kit_umbrella.h"

#include <fcntl.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <sstream>
#include <vector>

namespace jiebiao {
namespace {

std::atomic_bool g_stop{false};
constexpr const char* kModuleId = "deviceIdentityManagerSKP20260904";
constexpr uint32_t kWorkerRestartBurstLimit = 3;
constexpr uint32_t kWorkerRestartInitialDelayMs = 10000;
constexpr uint32_t kWorkerRestartMaximumDelayMs = 300000;
constexpr uint32_t kWorkerHealthyWindowMs = 30000;

uint32_t worker_restart_delay_ms(uint32_t attempt) {
    if (attempt == 0) return kWorkerRestartInitialDelayMs;
    uint64_t delay = kWorkerRestartInitialDelayMs;
    for (uint32_t index = 1; index < attempt && delay < kWorkerRestartMaximumDelayMs;
         ++index) {
        delay = std::min<uint64_t>(delay * 2U, kWorkerRestartMaximumDelayMs);
    }
    return static_cast<uint32_t>(delay);
}

class ActionLock {
public:
    explicit ActionLock(const std::string& private_dir) {
        const std::string path = private_dir + "/identity_action_v1.lock";
        fd_ = open(path.c_str(), O_CREAT | O_RDWR | O_CLOEXEC | O_NOFOLLOW, 0600);
        if (fd_ >= 0 && flock(fd_, LOCK_EX | LOCK_NB) != 0) { close(fd_); fd_ = -1; }
    }
    ~ActionLock() { if (fd_ >= 0) { flock(fd_, LOCK_UN); close(fd_); } }
    bool ok() const { return fd_ >= 0; }
private:
    int fd_ = -1;
};

void on_stop_signal(int) {
    g_stop.store(true);
}

bool process_alive(int32_t pid) {
    return pid > 1 && kill(pid, 0) == 0;
}

bool read_proc_command_line(int32_t pid, std::string& command_line) {
    const std::string path = "/proc/" + std::to_string(pid) + "/cmdline";
    return read_stream_file(path, command_line, 4096) && !command_line.empty();
}

// Use procfs btime and init's monotonic start tick as the daemon's boot-cycle token;
// this remains independent of any module-managed identity values.
std::string boot_session_id() {
    std::string proc_stat;
    std::string btime;
    if (read_stream_file("/proc/stat", proc_stat, 64 * 1024)) {
        for (const auto& line : split_lines(proc_stat)) {
            if (line.starts_with("btime ")) {
                btime = trim(line.substr(6));
                break;
            }
        }
    }
    std::string init_stat;
    std::string init_start;
    if (read_stream_file("/proc/1/stat", init_stat, 4096)) {
        const size_t close = init_stat.rfind(") ");
        if (close != std::string::npos && close + 2 < init_stat.size()) {
            std::istringstream fields(init_stat.substr(close + 2));
            std::vector<std::string> values;
            std::string value;
            while (fields >> value) values.push_back(value);
            // After the comm field, values[0] is state (field 3), so
            // starttime (field 22) is values[19].
            if (values.size() > 19) init_start = values[19];
        }
    }
    if (!btime.empty() || !init_start.empty()) return "btime=" + btime + ";init=" + init_start;
    // Only a read failure reaches this fallback for unusual procfs implementations.
    return "bootid=" + boot_id();
}

bool daemon_process_alive(int32_t pid) {
    if (!process_alive(pid)) return false;
    std::string command_line;
    if (!read_proc_command_line(pid, command_line)) return false;
    return command_line.find(kModuleId) != std::string::npos;
}

void redirect_daemon_output(const std::string& private_dir) {
    std::string path = private_dir;
    if (!path.empty() && path.back() != '/') path.push_back('/');
    path += "daemon.log";
    const int fd = open(path.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd >= 0) {
        dup2(fd, STDOUT_FILENO);
        dup2(fd, STDERR_FILENO);
        if (fd > STDERR_FILENO) close(fd);
    }
}

bool wait_for_boot_completed() {
    while (!g_stop.load()) {
        if (get_property("sys.boot_completed") == "1") return true;
        sleep(2);
    }
    return false;
}

std::string result_json(bool ok, const std::string& stage, const std::string& detail) {
    return std::string("{\"ok\":") + (ok ? "true" : "false") +
           ",\"stage\":" + json_string(stage) +
           ",\"detail\":" + json_string(detail) + "}";
}

void refresh_runtime_inventory() {
    storage_write_string("android_users_cache_v2", android_users_json(discover_android_users()));
    storage_write_string("identity_surfaces_cache_v2", identity_surfaces_json());
}

std::string restore_identity_for_supervisor_stop(const std::string& private_dir) {
    const auto properties = restore_identity_properties(private_dir);
    const auto usb = restore_usb_gadget_serial();
    std::string settings;
    const bool settings_ok = restore_identity_settings(settings);
    set_identity_application_state("pending");
    return "props=" + std::to_string(properties.applied) + "/" +
           std::to_string(properties.failed) + ",usb=" + usb.detail +
           ",settings=" + settings + ",ok=" +
           (properties.failed == 0 && usb.failed == 0 && settings_ok ? "1" : "0");
}

std::string apply_runtime_config(const std::string& private_dir,
                                 const ModuleConfig& config,
                                 bool install_kernel_serial_hook,
                                 bool apply_settings,
                                 bool* operation_ok = nullptr) {
    std::ostringstream report;
    bool ok = true;
    const auto legacy_template = restore_legacy_template_properties(private_dir);
    ok = legacy_template.failed == 0 && ok;
    report << "legacy-template-restore=" << legacy_template.message << ':'
           << legacy_template.applied << '/' << legacy_template.failed << ';';

    std::string settings_detail;
    if (config.master_enabled) {
        const IdentityValues values = load_or_create_identity(false);
        const auto result = apply_identity_properties(private_dir, values, install_kernel_serial_hook);
        ok = result.failed == 0 && ok;
        report << "identity=" << result.message << ':' << result.applied << '/' << result.failed
               << ",soc-hook=" << (result.kernel_serial_hooked ? 1 : 0) << ';';
        const auto usb_result = apply_usb_gadget_serial(values.serial);
        ok = usb_result.failed == 0 && ok;
        report << "usb-serial=" << usb_result.detail << ';';
        if (apply_settings) {
            const bool settings_ok = apply_identity_settings(values, settings_detail);
            ok = settings_ok && ok;
            report << "settings=" << settings_detail << ';';
            // 真正改 SSAID：改写 settings_ssaid.xml 并软重启 framework
            std::string force_detail;
            const bool force_ok = force_global_android_id_now(private_dir, values.android_id, force_detail);
            ok = force_ok && ok;
            report << "androidid=" << force_detail << ';';
            set_identity_application_state(result.failed == 0 && usb_result.failed == 0 && settings_ok
                                               ? "applied" : "pending");
        } else {
            set_identity_application_state(result.failed == 0 && usb_result.failed == 0
                                               ? "properties-ready" : "pending");
        }
        std::string pending_oaid_detail;
        const bool pending_oaid_ok = !apply_settings || apply_pending_oaids(private_dir, pending_oaid_detail);
        ok = pending_oaid_ok && ok;
        report << "oaid=" << pending_oaid_detail << ';';
    } else {
        const auto result = restore_identity_properties(private_dir);
        ok = result.failed == 0 && ok;
        report << "identity-restore=" << result.message << ':' << result.applied << '/' << result.failed << ';';
        const auto usb_result = restore_usb_gadget_serial();
        ok = usb_result.failed == 0 && ok;
        report << "usb-serial-restore=" << usb_result.detail << ';';
        if (apply_settings) {
            const bool settings_ok = restore_identity_settings(settings_detail);
            ok = settings_ok && ok;
            report << "settings-restore=" << settings_detail << ';';
        }
        set_identity_application_state("pending");
    }
    append_log(private_dir, std::string("apply-config ok=") + (ok ? "1 " : "0 ") + report.str());
    if (operation_ok) *operation_ok = ok;
    return result_json(ok, "apply-config", report.str());
}

std::string execute_action(const std::string& private_dir,
                           const std::string& root_key,
                           const PendingAction& action) {
    ActionLock action_lock(private_dir);
    if (!action_lock.ok()) return result_json(false, action.type, "action-lock-failed");
    if (action.type == "apply-config") {
        const ModuleConfig config = load_config();
        std::string drm_detail;
        const auto desired_mode = config.master_enabled
            ? drmid::ReplacementMode::kWriteTest
            : drmid::ReplacementMode::kDryRun;
        drmid::ControlIpcResponse drm_response{};
        bool drm_ok = true;
        if (config.master_enabled) {
            // Persist the desired mode before starting a cold worker; the
            // worker loads it after its readiness gate.  If it is already
            // starting, do not turn a transiently unavailable control socket
            // into a failed user action—the persisted generation is picked up
            // by the worker before the socket becomes ready.
            std::string mode_detail;
            drm_ok = device_identity::drm::set_runtime_mode(
                private_dir, desired_mode, false, nullptr, mode_detail);
            if (drm_ok && !device_identity::drm::worker_alive(private_dir)) {
                std::string start_detail;
                drm_ok = device_identity::drm::start_worker(
                    private_dir, false, start_detail, root_key);
                drm_detail = "mode=" + mode_detail + ",start=" + start_detail;
            }
            if (drm_ok && device_identity::drm::worker_alive(private_dir)) {
                const auto worker_status = device_identity::drm::read_status(private_dir);
                if (!worker_status.startup_waiting && worker_status.control_connected) {
                    drm_ok = device_identity::drm::set_runtime_mode(
                        private_dir, desired_mode, true, &drm_response, drm_detail);
                } else {
                    drm_detail = "mode=" + mode_detail + ",worker-starting";
                }
            }
        } else {
            // Dry-run still installs a global Binder hook and therefore is not
            // a low-power state.  Stop the worker and leave the persisted
            // runtime in dry-run so a later enable starts from a known policy.
            std::string stop_detail;
            const bool stop_ok = device_identity::drm::stop_worker(
                private_dir, stop_detail);
            std::string mode_detail;
            const bool mode_ok = device_identity::drm::set_runtime_mode(
                private_dir, desired_mode, false, nullptr, mode_detail);
            drm_ok = stop_ok && mode_ok;
            drm_detail = "stop=" + stop_detail + ",mode=" + mode_detail;
        }
        bool identity_ok = false;
        const std::string identity = drm_ok
            ? apply_runtime_config(private_dir, config, true, true, &identity_ok)
            : result_json(false, "apply-config", "drm-precondition-failed");
        return result_json(identity_ok && drm_ok, action.type,
                           "identity=" + identity + ",drm=" + drm_detail);
    }
    if (action.type == "randomize-identities") {
        if (global_reset_pending()) return result_json(false, action.type, "global-reset-pending");
        const ModuleConfig config = load_config();
        const IdentityValues previous_values = load_or_create_identity(false);
        const IdentityValues values = generate_identity_values();
        drmid::ReplacementConfig previous_drm{};
        drmid::ReplacementConfig next_drm{};
        std::string drm_detail;
        if (!device_identity::drm::randomize_runtime(
                private_dir, previous_drm, next_drm, drm_detail)) {
            return result_json(false, action.type, "drm=" + drm_detail);
        }
        const std::string previous_state = identity_application_state();
        auto rollback = [&](const std::string& cause, bool restore_surfaces) {
            bool restored = save_identity_values(previous_values);
            std::string rollback_detail;
            if (restore_surfaces) {
                const auto props = apply_identity_properties(private_dir, previous_values, true);
                const auto usb = apply_usb_gadget_serial(previous_values.serial);
                std::string settings;
                const bool settings_ok = apply_identity_settings(previous_values, settings);
                restored = props.failed == 0 && usb.failed == 0 && settings_ok && restored;
                rollback_detail += ",usb=" + usb.detail;
            }
            std::string restore_drm_detail;
            const bool drm_restored = device_identity::drm::restore_runtime(
                private_dir, previous_drm, restore_drm_detail);
            restored = drm_restored && restored;
            set_identity_application_state(restored ? previous_state : "pending");
            return result_json(false, action.type, cause + ",rollback=" +
                (restored ? "completed" : "failed") + rollback_detail + ",drm-restore=" + restore_drm_detail);
        };
        if (!save_identity_values(values)) {
            return rollback("identity-storage-failed", false);
        }
        if (!device_identity::drm::write_runtime(private_dir, next_drm, drm_detail)) {
            return rollback("drm-write=" + drm_detail, false);
        }
        // Publish the newly generated virtual ID when the worker endpoint is
        // ready.  During the post-boot readiness gate the worker is alive but
        // has no control socket yet; the durable runtime record is enough and
        // is loaded when the hook is installed.  Treating that state as an
        // IPC failure would make a valid rotation fail during the first boot.
        drmid::ControlIpcResponse drm_response{};
        const bool worker_running = device_identity::drm::worker_alive(private_dir);
        bool drm_ok = true;
        if (worker_running) {
            const auto worker_status = device_identity::drm::read_status(private_dir);
            if (worker_status.control_connected) {
                drm_ok = device_identity::drm::publish_runtime(
                    private_dir, next_drm, &drm_response, drm_detail);
            } else {
                drm_detail = worker_status.startup_waiting
                    ? "persisted-worker-starting"
                    : "persisted-worker-not-ready";
            }
        } else {
            drm_detail = "persisted-worker-offline";
        }
        if (!drm_ok) {
            return rollback("drm-publish=" + drm_detail, false);
        }
        if (!config.master_enabled) {
            std::string oaid_detail;
            const bool oaid_ok = queue_oaid_rotation(private_dir, oaid_detail);
            if (!oaid_ok) return rollback("oaid-queue=" + oaid_detail, false);
            set_identity_application_state("pending");
            return result_json(oaid_ok, action.type, "saved-master-disabled,oaid=" + oaid_detail);
        }
        const auto property_result = apply_identity_properties(private_dir, values, true);
        const auto usb_result = apply_usb_gadget_serial(values.serial);
        std::string settings_detail;
        const bool settings_ok = apply_identity_settings(values, settings_detail);
        std::string oaid_detail;
        const bool base_ok = property_result.failed == 0 && usb_result.failed == 0 && settings_ok;
        const bool oaid_ok = base_ok ? randomize_oaids_now(private_dir, oaid_detail) : true;
        if (!base_ok) oaid_detail = "skipped-base-failure";
        const bool ok = property_result.failed == 0 && usb_result.failed == 0 &&
                        settings_ok && oaid_ok;
        if (!base_ok) {
            return rollback("base-failed,usb=" + usb_result.detail + ",settings=" +
                            settings_detail + ",oaid=" + oaid_detail, true);
        }
        // Android ID 一次生效：改写全部用户 settings_ssaid.xml 并软重启 framework。
        // 放在所有 apply 之后，避免软重启打断 OAID 等其它写入；失败不回滚已生效属性。
        std::string force_android_detail;
        const bool force_android_ok =
            force_global_android_id_now(private_dir, values.android_id, force_android_detail);
        set_identity_application_state("applied");
        return result_json(ok && force_android_ok, action.type,
                           "props=" + std::to_string(property_result.applied) + "/" +
                           std::to_string(property_result.failed) + ",usb=" + usb_result.detail +
                           "," + settings_detail + ",oaid=" + oaid_detail +
                           ",androidid=" + force_android_detail +
                           ",drm=" + drm_detail);
    }
    if (action.type == "prepare-global-reset") {
        std::string detail;
        const bool ok = prepare_global_reset(private_dir, detail);
        return result_json(ok, action.type, detail);
    }
    if (action.type == "stop-drm-worker") {
        std::string drm_detail;
        const bool ok = device_identity::drm::stop_worker(private_dir, drm_detail);
        append_log(private_dir, "drm-worker-manual-stop=" + drm_detail);
        return result_json(ok, action.type, drm_detail);
    }
    if (action.type == "stop") {
        std::string drm_detail;
        device_identity::drm::stop_worker(private_dir, drm_detail);
        g_stop.store(true);
        return result_json(true, action.type, "stopping,drm=" + drm_detail);
    }
    return result_json(false, action.type, "unknown-action");
}

void daemon_main(std::string root_key, std::string private_dir) {
    SupervisorLease lease(private_dir);
    if (!lease.acquire()) _exit(0);
    g_stop.store(false);
    setsid();
    umask(0077);
    prctl(PR_SET_NAME, "jiebiao_skp", 0, 0, 0);
    redirect_daemon_output(private_dir);
    signal(SIGTERM, on_stop_signal);
    signal(SIGINT, on_stop_signal);
    signal(SIGHUP, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);

    const KModErr root_result = skroot_env::get_root(root_key.c_str());
    if (is_failed(root_result)) {
        append_log(private_dir, "daemon-root-failed=" + to_string(root_result));
        _exit(1);
    }
    store_daemon_identity(static_cast<int32_t>(getpid()), boot_session_id());
    kernel_module::set_current_module_run_state(skroot_env::ModuleRunState::Running);
    append_log(private_dir, "daemon-start pid=" + std::to_string(getpid()));

    device_identity::drm::mark_startup_waiting(private_dir, true);
    if (!wait_for_boot_completed()) {
        device_identity::drm::mark_startup_waiting(private_dir, false);
        _exit(0);
    }
    ensure_identity_baseline_properties();
    ensure_identity_baseline_settings();
    ensure_identity_baseline_oaid();
    refresh_runtime_inventory();
    const ModuleConfig first_config = load_config();
    std::string drm_detail;
    // The DRM Binder backend is demand-driven.  Dry-run still hooks the global
    // Binder ioctl path, so keeping it resident while the identity feature is
    // disabled defeats the low-power default and can keep a busy DRM HAL hot.
    const auto boot_mode = first_config.master_enabled
        ? drmid::ReplacementMode::kWriteTest
        : drmid::ReplacementMode::kDryRun;
    uint32_t drm_restart_attempts = 0;
    auto drm_next_restart = std::chrono::steady_clock::time_point::min();
    auto drm_healthy_since = std::chrono::steady_clock::time_point::min();
    if (first_config.master_enabled) {
        if (!device_identity::drm::set_runtime_mode(
                private_dir, boot_mode, false, nullptr, drm_detail)) {
            append_log(private_dir, "drm-runtime-mode-failed=" + drm_detail);
        }
        const bool started = device_identity::drm::start_worker(
            private_dir, false, drm_detail, root_key);
        append_log(private_dir, "drm-worker-start=" + drm_detail +
                                ",mode=" + std::to_string(static_cast<uint32_t>(boot_mode)));
        (void)started;
        drm_restart_attempts = 1;
        drm_next_restart = std::chrono::steady_clock::now() +
            std::chrono::milliseconds(worker_restart_delay_ms(1));
    } else {
        std::string stop_detail;
        const bool stopped = device_identity::drm::stop_worker(private_dir, stop_detail);
        if (!stopped) append_log(private_dir, "drm-worker-policy-stop-failed=" + stop_detail);
        if (!device_identity::drm::set_runtime_mode(
                private_dir, boot_mode, false, nullptr, drm_detail)) {
            append_log(private_dir, "drm-runtime-mode-failed=" + drm_detail);
        }
        append_log(private_dir, "drm-worker-start=disabled-by-policy,stop=" +
                                stop_detail + ",mode=" +
                                std::to_string(static_cast<uint32_t>(boot_mode)));
    }
    const std::string post_boot = recover_post_boot_global_reset(private_dir);
    if (!post_boot.empty()) append_log(private_dir, post_boot);
    refresh_runtime_inventory();
    if (first_config.master_enabled) {
        const IdentityValues values = load_or_create_identity(false);
        // Retry the SoC hook after boot.  Some vendor/MediaTek kernels create
        // the serial_number sysfs node only after the early module entry; the
        // readback guard in apply_identity_properties makes this idempotent
        // when the early hook already succeeded.
        const auto late_result = apply_identity_properties(private_dir, values, true);
        const auto usb_result = apply_usb_gadget_serial(values.serial);
        std::string settings_detail;
        const bool settings_ok = apply_identity_settings(values, settings_detail);
        // 双开/分身用户的安卓 ID：apply_identity_settings 只改 user 0，
        // 必须额外调用 force_global_android_id_now 改写所有用户的 SSAID XML。
        // early 阶段可能因 system_server 未就绪而失败，late 阶段重试确保生效。
        std::string force_android_detail;
        bool force_android_ok = true;
        if (settings_ok && values.android_id.size() == 16) {
            force_android_ok = force_global_android_id_now(private_dir, values.android_id, force_android_detail);
        } else {
            force_android_detail = "skipped";
        }
        const std::string property_state = identity_application_state();
        const bool properties_ready = property_state == "properties-ready" || property_state == "applied";
        set_identity_application_state(settings_ok && force_android_ok && properties_ready && late_result.failed == 0 &&
                                           usb_result.failed == 0
                                           ? "applied" : "pending");
        append_log(private_dir, "late-identity props=" + std::to_string(late_result.applied) + "/" +
                                std::to_string(late_result.failed) +
                                ";usb=" + usb_result.detail + ";settings=" + settings_detail +
                                ";androidid=" + force_android_detail);
        std::string pending_oaid_detail;
        const bool pending_oaid_ok = apply_pending_oaids(private_dir, pending_oaid_detail);
        append_log(private_dir, "late-oaid ok=" + std::to_string(pending_oaid_ok) + "," + pending_oaid_detail);
    } else {
        const auto usb_result = restore_usb_gadget_serial();
        std::string settings_detail;
        restore_identity_settings(settings_detail);
        append_log(private_dir, "late-usb-serial-restore=" + usb_result.detail);
        set_identity_application_state("pending");
    }
    uint32_t last_action = 0;
    PendingAction current;
    if (read_action_after(0, current)) last_action = current.sequence;
    uint32_t serial_guard_ticks = 0;
    uint32_t ssaid_sync_ticks = 0;
    bool post_boot_finalized = false;
    const auto daemon_started = std::chrono::steady_clock::now();

    while (!g_stop.load()) {
        // Retry only the post-boot finalize phase. A transaction newly
        // prepared while the device is running remains reboot-gated.
        const std::string retry = perform_post_boot_operations(private_dir);
        if (!retry.empty()) append_log(private_dir, retry);

        PendingAction action;
        if (read_action_after(last_action, action)) {
            const std::string result = execute_action(private_dir, root_key, action);
            append_log(private_dir, "action=" + action.type + ",result=" + result);
            write_action_result(action.sequence, result);
            last_action = action.sequence;
            refresh_runtime_inventory();
        }

        const ModuleConfig config = load_config();
        const auto now = std::chrono::steady_clock::now();
        // 开机 late apply 在 sys.boot_completed=1 瞬间立即执行，此时 system_server /
        // OAID 服务往往尚未完全就绪，SoC/Android ID/OAID 可能没落上。系统稳定约 60 秒后
        // 自动补做一次完整应用，确保无需手动打开 WebUI 也能真正生效。
        if (!post_boot_finalized && config.master_enabled &&
            now - daemon_started >= std::chrono::seconds(60)) {
            const IdentityValues values = load_or_create_identity(false);
            const auto rp = apply_identity_properties(private_dir, values, true);
            const auto ur = apply_usb_gadget_serial(values.serial);
            std::string sd;
            const bool sok = apply_identity_settings(values, sd);
            std::string od;
            const bool ook = apply_pending_oaids(private_dir, od);
            set_identity_application_state(
                (rp.failed == 0 && ur.failed == 0 && sok && ook) ? "applied" : "pending");
            append_log(private_dir, "post-boot-finalize props=" +
                std::to_string(rp.applied) + "/" + std::to_string(rp.failed) +
                ";usb=" + ur.detail + ";settings=" + sd + ";oaid=" + od);
            post_boot_finalized = true;
        }
        const bool drm_alive = device_identity::drm::worker_alive(private_dir);
        if (!config.master_enabled) {
            // The disabled policy is deliberately hook-free.  This also
            // cleans up a worker left behind by an interrupted config action.
            drm_healthy_since = std::chrono::steady_clock::time_point::min();
            if (drm_alive) {
                std::string policy_stop_detail;
                device_identity::drm::stop_worker(private_dir, policy_stop_detail);
                append_log(private_dir, "drm-worker-policy-stop=" + policy_stop_detail);
            }
        } else if (drm_alive) {
            // A worker must remain healthy for a short window before failures
            // are forgiven.  This prevents a child that exits immediately from
            // resetting the retry budget and creating a hot restart storm.
            // A process merely waiting for HAL is not a healthy Hook session.
            uint32_t worker_state = 0;
            std::string worker_state_bytes;
            if (read_file(private_dir + "/drm_worker_state", worker_state_bytes, sizeof(worker_state)) &&
                worker_state_bytes.size() == sizeof(worker_state)) {
                std::memcpy(&worker_state, worker_state_bytes.data(), sizeof(worker_state));
            }
            if (worker_state != static_cast<uint32_t>(device_identity::drm::WorkerState::kRunning)) {
                drm_healthy_since = std::chrono::steady_clock::time_point::min();
            } else if (drm_healthy_since == std::chrono::steady_clock::time_point::min()) {
                drm_healthy_since = now;
            } else if (now - drm_healthy_since >=
                       std::chrono::milliseconds(kWorkerHealthyWindowMs)) {
                drm_restart_attempts = 0;
                drm_next_restart = std::chrono::steady_clock::time_point::min();
            }
        } else {
            drm_healthy_since = std::chrono::steady_clock::time_point::min();
            const auto worker_status = device_identity::drm::read_status(private_dir);
            // Retry only a backend that returned through its cleanup path.
            // Backoff and a per-supervisor burst budget make unsupported or
            // repeatedly failing kernels fail quiet instead of respawning a
            // resolver/hook cycle every few seconds for hours.
            if (worker_status.state == device_identity::drm::WorkerState::kFailed &&
                now >= drm_next_restart) {
                const bool within_burst = drm_restart_attempts < kWorkerRestartBurstLimit;
                if (within_burst) ++drm_restart_attempts;
                const uint32_t delay_ms = within_burst
                    ? worker_restart_delay_ms(drm_restart_attempts)
                    : kWorkerRestartMaximumDelayMs;
                std::string restart_detail;
                const bool restarted = device_identity::drm::start_worker(
                    private_dir, false, restart_detail, root_key);
                append_log(private_dir,
                           "drm-worker-retry=" + restart_detail +
                           ",attempt=" + std::to_string(drm_restart_attempts) +
                           ",budget=" + (within_burst ? "burst" : "cooldown") +
                           ",result=" + (restarted ? "1" : "0") +
                           ",next-delay-ms=" + std::to_string(delay_ms));
                drm_next_restart = now + std::chrono::milliseconds(delay_ms);
            }
        }
        if (config.master_enabled && ++serial_guard_ticks >= 15) {
            serial_guard_ticks = 0;
            const IdentityValues values = load_or_create_identity(false);
            const bool serial_mismatch = !values.serial.empty() &&
                                         get_property("ro.serialno") != values.serial;
            const auto usb_readback = verify_usb_gadget_serial(values.serial);
            const bool usb_mismatch = usb_readback.state == "mismatch" ||
                                      usb_readback.state == "error";
            if (serial_mismatch || usb_mismatch) {
                const auto result = apply_identity_properties(private_dir, values, false);
                const auto usb_result = apply_usb_gadget_serial(values.serial);
                append_log(private_dir, "identity-guard reapplied=" + std::to_string(result.applied) +
                                        ",usb=" + usb_result.detail);
            }
        }
        // 双开/分身新用户自动同步：每 60 秒扫描一次，发现新用户的 SSAID
        // userkey 不匹配就自动改写成当前值，确保主应用和双开应用安卓 ID 一致。
        if (config.master_enabled && ++ssaid_sync_ticks >= 30) {
            ssaid_sync_ticks = 0;
            std::string sync_detail;
            if (sync_new_users_ssaid(private_dir, sync_detail)) {
                if (sync_detail.find("synced=0") != 0) {
                    append_log(private_dir, "ssaid-user-sync " + sync_detail);
                }
            }
        }
        sleep(2);
    }
    // The DRM worker is a child of the supervisor. stop_worker() also reaps
    // it when it exits normally, so shutdown does not leave a zombie or a
    // second resident worker behind.
    std::string stop_detail;
    device_identity::drm::stop_worker(private_dir, stop_detail);
    const std::string restore_detail =
        restore_identity_for_supervisor_stop(private_dir);
    std::fill(root_key.begin(), root_key.end(), '\0');
    store_daemon_identity(0, boot_session_id());
    append_log(private_dir, "daemon-stop drm=" + stop_detail +
                            ",identity=" + restore_detail);
    _exit(0);
}

}  // namespace

std::string apply_early_config(const std::string& private_dir,
                               const ModuleConfig& config,
                               bool install_kernel_serial_hook) {
    return apply_runtime_config(private_dir, config, install_kernel_serial_hook, false);
}

bool start_background_daemon(const char* root_key, const std::string& private_dir) {
    if (!root_key || !*root_key || private_dir.empty()) return false;
    int32_t stored_pid = 0;
    std::string stored_boot;
    if (read_daemon_identity(stored_pid, stored_boot) && stored_boot == boot_session_id() &&
        daemon_process_alive(stored_pid)) {
        return true;
    }
    SupervisorLease lease(private_dir);
    const pid_t owner = lease.owner();
    if (owner > 1) {
        store_daemon_identity(owner, boot_session_id());
        return true;
    }
    if (owner < 0) return false;
    const pid_t child = fork();
    if (child < 0) return false;
    if (child == 0) daemon_main(root_key, private_dir);
    for (int attempt = 0; attempt < 20; ++attempt) {
        int status = 0;
        waitpid(child, &status, WNOHANG);
        if (lease.owner() > 1) return true;
        usleep(50000);
    }
    return false;
}

bool background_daemon_alive(const std::string& private_dir) {
    SupervisorLease lease(private_dir);
    if (lease.owner() > 1) return true;
    int32_t pid = 0;
    std::string stored_boot;
    return read_daemon_identity(pid, stored_boot) && stored_boot == boot_session_id() &&
           daemon_process_alive(pid);
}

void stop_background_daemon() {
    int32_t pid = 0;
    std::string stored_boot;
    if (!read_daemon_identity(pid, stored_boot) || stored_boot != boot_session_id() || !daemon_process_alive(pid)) return;
    enqueue_action("stop", "");
    for (int i = 0; i < 20 && process_alive(pid); ++i) usleep(100000);
    if (process_alive(pid)) kill(pid, SIGTERM);
}

}  // namespace jiebiao
