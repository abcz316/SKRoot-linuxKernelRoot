import java.lang.reflect.Method;

// Fixed OUID-only bridge to the OEM's typed Binder API. No transaction numbers
// or arbitrary method/package/user arguments are accepted.
public final class OplusOaidRuntime {
    static String checked(Object value) {
        if (!(value instanceof String) || !((String) value).matches("[0-9A-Fa-f]{64}")) {
            throw new IllegalStateException("invalid-ouid");
        }
        return (String) value;
    }

    public static void main(String[] args) {
        Thread watchdog = new Thread(() -> {
            try { Thread.sleep(8000); } catch (InterruptedException ignored) { return; }
            System.err.println("OAID_ERROR=timeout");
            System.exit(3);
        });
        watchdog.setDaemon(true);
        watchdog.start();
        int status = 0;
        try {
            if (args.length != 1 || !(args[0].equals("probe") || args[0].equals("rotate"))) {
                throw new IllegalArgumentException("probe-or-rotate-required");
            }
            Class<?> type = Class.forName("android.app.OplusNotificationManager");
            Object manager = type.getConstructor().newInstance();
            Method get = type.getMethod("getStdid", String.class, int.class, String.class);
            Method clear = type.getMethod("clearStdid", String.class, int.class, String.class);
            String before = checked(get.invoke(manager, "com.android.shell", 2000, "OUID"));
            if (args[0].equals("probe")) {
                System.out.println("OAID_RUNTIME=ready");
            } else {
                clear.invoke(manager, "com.android.shell", 2000, "OUID");
                String after = checked(get.invoke(manager, "com.android.shell", 2000, "OUID"));
                if (before.equalsIgnoreCase(after)) throw new IllegalStateException("ouid-unchanged");
                System.out.println("OUID=" + after);
            }
        } catch (Throwable error) {
            Throwable reason = error.getCause() == null ? error : error.getCause();
            System.err.println("OAID_ERROR=" + reason.getClass().getSimpleName());
            status = 2;
        }
        System.exit(status);
    }
}
