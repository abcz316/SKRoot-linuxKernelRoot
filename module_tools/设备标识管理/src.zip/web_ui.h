#pragma once

// The SKP WebUI handler is registered from web_ui.cpp via SKROOT_MODULE_WEB_UI.

