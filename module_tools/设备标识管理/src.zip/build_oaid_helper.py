"""Build the small OEM OUID bridge into a deterministic private DEX archive."""
from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "java/OplusOaidRuntime.java"
OUTPUT = ROOT / "resources/oaid-runtime.jar"
STAMP = ROOT / "resources/oaid-runtime.source.sha256"


def main():
    source_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    if OUTPUT.is_file() and STAMP.is_file() and STAMP.read_text().strip() == source_hash:
        with zipfile.ZipFile(OUTPUT) as archive:
            if archive.testzip() is None and archive.namelist() == ["classes.dex"]:
                return
    java = shutil.which("java")
    javac = shutil.which("javac") or (str(Path(java).resolve().with_name("javac")) if java else None)
    default_sdk = str(Path(os.environ["LOCALAPPDATA"]) / "Android/Sdk") if os.name == "nt" else "/mnt/c/Users/Administrator/AppData/Local/Android/Sdk"
    sdk = Path(os.environ.get("ANDROID_SDK_ROOT", default_sdk))
    tools = sorted(sdk.glob("build-tools/*/lib/d8.jar"))
    d8 = os.environ.get("D8_JAR") or (str(tools[-1]) if tools else None)
    if not java or not javac or not d8:
        raise SystemExit("Set JAVA_HOME/PATH and ANDROID_SDK_ROOT or D8_JAR to build OAID helper")
    with tempfile.TemporaryDirectory() as directory:
        build = Path(directory)
        subprocess.run([javac, "--release", "8", "-d", str(build), str(SOURCE)], check=True)
        subprocess.run([java, "-cp", d8, "com.android.tools.r8.D8", "--min-api", "34",
                        "--output", str(build), str(build / "OplusOaidRuntime.class")], check=True)
        with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED) as archive:
            info = zipfile.ZipInfo("classes.dex", (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100600 << 16
            archive.writestr(info, (build / "classes.dex").read_bytes())
    STAMP.write_text(hashlib.sha256(SOURCE.read_bytes()).hexdigest() + "\n", encoding="ascii")
    print(OUTPUT)


if __name__ == "__main__":
    main()
