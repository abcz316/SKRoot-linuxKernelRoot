#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/build_oaid_helper.py"
DEFAULT_NDK_BUILD="/mnt/c/Users/Administrator/AppData/Local/Android/Sdk/ndk/26.3.11579264/build/ndk-build"
NDK_BUILD="${NDK_BUILD:-$DEFAULT_NDK_BUILD}"

if [[ -x "$NDK_BUILD" && -x "$(dirname "$(dirname "$NDK_BUILD")")/toolchains/llvm/prebuilt/linux-x86_64/bin/clang++" ]]; then
  exec "$NDK_BUILD" -C "$ROOT" NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk "$@"
fi

if command -v cmd.exe >/dev/null 2>&1 && [[ -f "$ROOT/build_windows.cmd" ]]; then
  cd "$ROOT"
  exec cmd.exe /d /c build_windows.cmd "$@"
fi

echo "No runnable Android NDK host toolchain was found." >&2
echo "Set NDK_BUILD to a Linux ndk-build path or run build_windows.cmd on Windows." >&2
exit 2
