#pragma once

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string>

namespace jiebiao {

// POSIX process locks are not inherited by forked helper processes. The
// kernel releases ownership on supervisor exit, including abnormal exit.
class SupervisorLease {
public:
    explicit SupervisorLease(const std::string& directory) {
        fd_ = open((directory + "/identity_supervisor_v1.lock").c_str(),
                   O_CREAT | O_RDWR | O_CLOEXEC | O_NOFOLLOW, 0600);
        struct stat st{};
        if (fd_ >= 0 && (fstat(fd_, &st) != 0 || !S_ISREG(st.st_mode))) {
            close(fd_);
            fd_ = -1;
        }
    }
    ~SupervisorLease() { if (fd_ >= 0) close(fd_); }
    SupervisorLease(const SupervisorLease&) = delete;
    SupervisorLease& operator=(const SupervisorLease&) = delete;
    bool acquire() {
        struct flock lock{};
        lock.l_type = F_WRLCK;
        lock.l_whence = SEEK_SET;
        return fd_ >= 0 && fcntl(fd_, F_SETLK, &lock) == 0;
    }
    pid_t owner() const {
        struct flock lock{};
        lock.l_type = F_WRLCK;
        lock.l_whence = SEEK_SET;
        if (fd_ < 0 || fcntl(fd_, F_GETLK, &lock) < 0) return -1;
        return lock.l_type == F_UNLCK ? 0 : lock.l_pid;
    }
private:
    int fd_ = -1;
};

}  // namespace jiebiao
