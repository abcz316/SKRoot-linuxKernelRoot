from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]


def run_probe(candidate=ROOT, scenario=None):
    compiler = shutil.which("g++") or shutil.which("clang++")
    if compiler is None:
        raise unittest.SkipTest("host C++ compiler is unavailable")
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        # Redirect only absolute fixture path literals, executing the actual
        # adapter implementation with the production discovery/cache logic.
        source = (candidate / "soc_serial_adapter.cpp").read_text(encoding="utf-8")
        source = re.sub(r'"(/(?:sys|proc)/[^"\n]*)"',
                        lambda match: '"' + directory + match[1] + '"', source)
        translated = root / "adapter.cpp"
        translated.write_text(source, encoding="utf-8")
        binary = root / "probe"
        flags = ['-DHAS_UFS'] if 'probe_ufs_serial' in (candidate / 'soc_serial_adapter.h').read_text() else []
        subprocess.run([compiler, "-std=c++20", "-O2", *flags, "-I", str(candidate),
                        str(ROOT / "tests/soc_serial_probe_harness.cpp"),
                        str(translated), "-o", str(binary)], check=True,
                       capture_output=True, text=True)
        return subprocess.run([str(binary), directory] + ([scenario] if scenario else []), check=True,
                              capture_output=True, text=True).stdout


class SocSerialBehaviorTest(unittest.TestCase):
    def test_peripheral_cached_node_and_disguised_alias_rejected(self):
        for scenario in ('peripheral', 'peripheral-alias'):
            with self.subTest(scenario=scenario):
                self.assertIn('=none,value=,readable=0,hookable=0', run_probe(ROOT, scenario))

    def test_ufs_cached_as_auxiliary_and_soc_takes_priority(self):
        output=run_probe(ROOT, 'ufs-cache')
        self.assertIn('ufs-cache=/sys/devices/soc0/serial_number,value=SOC_ORIGINAL', output)
        self.assertIn('auxiliary=ufs-sysfs,value=UFS_ORIGINAL', output)

    def test_ufs_only_is_available_as_explicit_fallback(self):
        self.assertIn('value=UFS_ORIGINAL,readable=1,hookable=1',run_probe(ROOT,'ufs-only'))

    def test_top_level_soc_wins_over_bus_alias(self):
        self.assertIn('alias-priority=/sys/devices/soc0/serial_number',run_probe(ROOT,'alias-priority'))

    def test_real_adapter_discovery_and_cache(self):
        output = run_probe()
        expected = {
            "priority": "/sys/devices/soc0/serial_number,value=1111111111,readable=1,hookable=1",
            "system-soc": "/sys/devices/system/soc/soc0/serial_number,value=12345678,readable=1,hookable=1",
            "nested-mtk": "/sys/devices/platform/soc/mtk-deviceid/serial_number,value=12345678,readable=1,hookable=1",
            "class-soc": "/sys/class/soc/soc0/serial_number,value=12345678,readable=1,hookable=1",
            "bus-alias": "/sys/bus/soc/devices/soc0/serial_number,value=12345678,readable=1,hookable=1",
            "dt-chosen": "/sys/firmware/devicetree/base/chosen/serial-number,value=DT123456,readable=1,hookable=0",
            "late-sysfs": "/sys/devices/platform/soc/serial_number,value=12345678,readable=1,hookable=1",
            "stale-cache": "/sys/firmware/devicetree/base/chosen/serial-number,value=DT123456,readable=1,hookable=0",
            "absent": "none,value=,readable=0,hookable=0",
            "unrelated": "none,value=,readable=0,hookable=0",
        }
        self.assertEqual(dict(line.split("=", 1) for line in output.splitlines()), expected)


if __name__ == "__main__":
    import sys
    if len(sys.argv) in (3,4) and sys.argv[1] == "--probe":
        print(run_probe(Path(sys.argv[2]),sys.argv[3] if len(sys.argv)==4 else None), end="")
    else:
        unittest.main()
