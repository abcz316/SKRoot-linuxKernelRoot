#include "ssaid_engine.h"
#include "common.h"

#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

namespace jiebiao {

std::vector<std::vector<std::string>> process_calls;

bool valid_package_name(std::string_view value) {
    return value == "com.example.app" || value == "com.example.other";
}

std::string random_hex(size_t size, bool) {
    return std::string(size, 'c');
}

bool read_file(const std::string& path, std::string& output, size_t max_bytes) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return false;
    output.assign(std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());
    if (output.size() > max_bytes) {
        output.clear();
        return false;
    }
    return true;
}
bool write_file_atomic(const std::string&, const std::string&, uint32_t, bool) { return true; }
int run_process(const std::vector<std::string>& args, std::string* output, size_t) {
    process_calls.push_back(args);
    if (args.size() == 3 && args[0] == "/system/bin/abx2xml" && args[2] == "-") {
        if (output) {
            *output = "<settings><setting name=\"userkey\" value=\"" +
                      std::string(64, 'a') + "\"/></settings>";
        }
        return 0;
    }
    if (args.size() == 3 && args[0] == "/system/bin/xml2abx") {
        std::ofstream encoded(args[2], std::ios::binary);
        static constexpr char kAbx[] = {'A', 'B', 'X', '\0', 'f', 'i', 'x', 't', 'u', 'r', 'e'};
        encoded.write(kAbx, sizeof(kAbx));
        return encoded ? 0 : 1;
    }
    return 1;
}

}  // namespace jiebiao

int main() {
    using namespace jiebiao;
    namespace fs = std::filesystem;
    const std::string old_android = "0123456789abcdef";
    const std::string new_android = "fedcba9876543210";
    const std::string old_userkey(64, 'a');
    const std::string new_userkey(64, 'b');

    std::string modern = "<settings>"
        "<setting name=\"android_id\" value=\"" + old_android + "\"/>"
        "<setting name=\"userkey\" value=\"" + old_userkey + "\"/>"
        "<setting package=\"com.example.app\" value=\"1111111111111111\"/>"
        "</settings>";
    size_t changed = 0;
    std::string detail;
    assert(reset_all_ssaid_xml(modern, new_android, new_userkey, changed, detail));
    assert(changed == 2);
    assert(modern.find(new_android) != std::string::npos);
    assert(modern.find(new_userkey) != std::string::npos);
    assert(modern.find("1111111111111111") != std::string::npos);
    assert(detail == "ok-userkey");

    std::string legacy = "<settings>"
        "<setting name='android_id' value='" + old_android + "'/>"
        "<setting package='com.example.app' value='1111111111111111'/>"
        "<setting package='com.example.other' value='2222222222222222'/>"
        "</settings>";
    assert(reset_all_ssaid_xml(legacy, new_android, new_userkey, changed, detail));
    assert(changed == 3);
    assert(legacy.find(std::string(16, 'c')) != std::string::npos);
    assert(detail == "ok-legacy");

    std::string package_xml = "<settings>"
        "<setting package=\"com.example.app\" value=\"1111111111111111\"/>"
        "<setting package=\"com.example.other\" value=\"2222222222222222\"/>"
        "</settings>";
    assert(reset_package_ssaid_xml(package_xml, "com.example.app", "3333333333333333", changed, detail));
    assert(changed == 1);
    assert(package_xml.find("3333333333333333") != std::string::npos);
    assert(package_xml.find("2222222222222222") != std::string::npos);

    std::string malformed = "<settings><setting package=\"com.example.app\" value=\"1111111111111111\"";
    assert(!reset_package_ssaid_xml(malformed, "com.example.app", "3333333333333333", changed, detail));
    assert(detail == "malformed-xml");

    std::string bad_key = "<settings><setting name=\"userkey\" value=\"short\"/></settings>";
    assert(!reset_all_ssaid_xml(bad_key, new_android, new_userkey, changed, detail));
    assert(detail == "invalid-userkey");

    const fs::path fixture = fs::temp_directory_path() /
        ("jiebiao-ssaid-inspect-" + std::to_string(static_cast<long long>(getpid())));
    fs::create_directories(fixture);
    const fs::path xml_path = fixture / "settings_ssaid.xml";
    {
        std::ofstream output(xml_path, std::ios::binary);
        output << "<settings><setting name=\"userkey\" value=\"" << old_userkey
               << "\"/></settings>";
    }
    AndroidUserInfo inspected;
    assert(inspect_ssaid_file(0, xml_path.string(), inspected, detail));
    assert(inspected.format == SsaidFormat::Xml);
    assert(inspected.ready);
    assert(detail == "ok");

    const fs::path abx_path = fixture / "settings_ssaid.xml.fallback";
    {
        std::ofstream output(abx_path, std::ios::binary);
        output.write("ABX\0fixture", 11);
    }
    assert(inspect_ssaid_file(0, abx_path.string(), inspected, detail));
    assert(inspected.format == SsaidFormat::Abx);
    const bool converters = access("/system/bin/abx2xml", X_OK) == 0 &&
                            access("/system/bin/xml2abx", X_OK) == 0;
    assert(inspected.ready == converters);

    assert(!inspect_ssaid_file(0, (fixture / "missing").string(), inspected, detail));
    assert(detail == "absent");
    const fs::path symlink_path = fixture / "symlink";
    fs::create_symlink(xml_path, symlink_path);
    assert(!inspect_ssaid_file(0, symlink_path.string(), inspected, detail));
    assert(detail == "invalid-file");
    AndroidUserInfo unavailable{10, "用户 10", "/tmp/missing.abx", SsaidFormat::Abx, false};
    SsaidDocument document;
    assert(!load_ssaid_document("/tmp", unavailable, "test", document, detail));
    assert(detail == "abx-tools-unavailable");

    SsaidDocument abx;
    const AndroidUserInfo abx_user{0, "", abx_path.string(), SsaidFormat::Abx, true};
    assert(load_ssaid_document(fixture.string(), abx_user, "decode", abx, detail));
    assert(detail == "ok");
    assert(!process_calls.empty());
    assert(process_calls.back() == std::vector<std::string>({
        "/system/bin/abx2xml", abx_path.string(), "-"}));

    std::string encoded;
    assert(encode_ssaid_document(fixture.string(), abx, abx.xml,
                                 "encode-roundtrip", encoded, detail));
    assert(detail == "ok");
    assert(encoded.size() >= 3 && encoded.compare(0, 3, "ABX") == 0);
    assert(process_calls.back().size() == 3);
    assert(process_calls.back()[0] == "/system/bin/abx2xml");
    assert(process_calls.back()[2] == "-");

    fs::remove_all(fixture);

    std::cout << "ssaid-transform: ok\n";
    return 0;
}
