from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
STUB = '''package android.app;
public class OplusNotificationManager {
  private boolean cleared;
  public String getStdid(String pkg, int uid, String type) {
    if (!pkg.equals("com.android.shell") || uid != 2000 || !type.equals("OUID"))
      throw new AssertionError("scope");
    String mode = System.getProperty("fixture", "matching");
    if (mode.equals("invalid")) return "";
    return (cleared && !mode.equals("unchanged") ? "B" : "A").repeat(64);
  }
  public void clearStdid(String pkg, int uid, String type) {
    if (System.getProperty("fixture", "").equals("probe")) throw new AssertionError("probe-mutated");
    if (!type.equals("OUID") || cleared) throw new AssertionError("scope-or-repeat");
    cleared = true;
  }
}'''


class OaidJavaBridgeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.java = shutil.which("java")
        compiler = shutil.which("javac") or (str(Path(cls.java).resolve().with_name("javac")) if cls.java else None)
        if not cls.java or not compiler:
            raise unittest.SkipTest("JDK required")
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        stub = Path(cls.temp.name) / "OplusNotificationManager.java"
        stub.write_text(STUB, encoding="utf-8")
        subprocess.run([compiler, "-d", cls.temp.name, str(stub),
                        str(ROOT / "java/OplusOaidRuntime.java")], check=True, capture_output=True)

    def call(self, mode, operation):
        return subprocess.run([self.java, "-Dfixture=" + mode, "-cp", self.temp.name,
                               "OplusOaidRuntime", operation], capture_output=True, text=True)

    def test_probe_does_not_clear(self):
        result = self.call("probe", "probe")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "OAID_RUNTIME=ready")

    def test_rotation_returns_system_generated_value(self):
        result = self.call("matching", "rotate")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), "OUID=" + "B" * 64)

    def test_unchanged_value_and_invalid_baseline_fail(self):
        for mode in ("unchanged", "invalid"):
            with self.subTest(mode=mode):
                self.assertEqual(self.call(mode, "rotate").returncode, 2)

    def test_unknown_operation_is_rejected(self):
        self.assertEqual(self.call("probe", "clear-all").returncode, 2)


if __name__ == "__main__":
    unittest.main()
