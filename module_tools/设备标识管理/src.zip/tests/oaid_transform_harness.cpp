#include "oaid_engine.h"
#include "common.h"

#include <cassert>
#include <iostream>
#include <vector>

namespace jiebiao {

std::string random_hex(size_t size, bool) {
    return std::string(size, 'A');
}

int run_process(const std::vector<std::string>&, std::string*, size_t) {
    return 1;
}

int run_process_as(uid_t, gid_t, const std::vector<std::string>&, std::string*, size_t) {
    return 1;
}

}  // namespace jiebiao

int main() {
    using namespace jiebiao;
    const std::string original0(64, '1');
    const std::string original10(64, '2');
    const std::string replacement0(64, 'B');
    const std::string replacement10(64, 'C');
    std::string xml = "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>"
        "<openid_config version=\"1\">"
        "<guid value=\"GUID-UNCHANGED\"></guid>"
        "<ouid name=\"0\" value=\"" + original0 + "\"></ouid>"
        "<ouid value='" + original10 + "' name='10'></ouid>"
        "<duid sign=\"SIGN\" value=\"DUID-UNCHANGED\"></duid>"
        "</openid_config>";

    std::vector<OplusOaidValue> values;
    std::string detail;
    assert(inspect_oplus_openid_xml(xml, values, detail));
    assert(values.size() == 2);
    assert(values[0].user == "0" && values[0].value == original0);
    assert(values[1].user == "10" && values[1].value == original10);
    assert(detail == "format-v1,users=2");

    std::string generated;
    assert(build_oplus_oaid_payload(xml, generated, detail));
    assert(generated == "0=" + std::string(64, 'A') + ";10=" + std::string(64, 'A'));

    size_t changed = 0;
    const std::string payload = "0=" + replacement0 + ";10=" + replacement10;
    assert(rewrite_oplus_openid_xml(xml, payload, changed, detail));
    assert(changed == 2);
    assert(xml.find(replacement0) != std::string::npos);
    assert(xml.find(replacement10) != std::string::npos);
    assert(xml.find("GUID-UNCHANGED") != std::string::npos);
    assert(xml.find("DUID-UNCHANGED") != std::string::npos);
    std::string selected;
    assert(oplus_oaid_payload_value(payload, "0", selected));
    assert(selected == replacement0);
    assert(!oplus_oaid_payload_value(payload, "999", selected));

    const std::string provider_value =
        "A86C142EF51B4AD9A33AAE3AB246B6871634a75e972fd008ac6dfcff3b68ef53";
    assert(parse_oplus_oaid_provider_output(
        "Result: Bundle[{OUID=" + provider_value + "}]\n", selected, detail));
    assert(selected == provider_value);
    assert(detail == "provider-read");
    assert(!parse_oplus_oaid_provider_output(
        "Result: Bundle[{OUID=}]\n", selected, detail));
    assert(detail == "provider-value-invalid");

    std::string malformed = "<openid_config version=\"1\"><ouid name=\"0\" value=\"short\"/></openid_config>";
    assert(!inspect_oplus_openid_xml(malformed, values, detail));
    assert(detail == "invalid-ouid-entry");
    std::string wrong_version = "<openid_config version=\"2\"><ouid name=\"0\" value=\"" +
        original0 + "\"/></openid_config>";
    assert(!inspect_oplus_openid_xml(wrong_version, values, detail));
    assert(detail == "unsupported-version");
    std::string duplicate = "<openid_config version=\"1\"><ouid name=\"0\" value=\"" +
        original0 + "\"/><ouid name=\"0\" value=\"" + original10 + "\"/></openid_config>";
    assert(!inspect_oplus_openid_xml(duplicate, values, detail));
    assert(detail == "duplicate-or-too-many-users");
    std::string missing = "<openid_config version=\"1\"><guid value=\"x\"/></openid_config>";
    assert(!inspect_oplus_openid_xml(missing, values, detail));
    assert(detail == "ouid-not-found");

    std::string mismatch = "<openid_config version=\"1\"><ouid name=\"0\" value=\"" +
        original0 + "\"/></openid_config>";
    assert(!rewrite_oplus_openid_xml(mismatch, "10=" + replacement10, changed, detail));
    assert(detail == "payload-user-mismatch");

    std::cout << "oaid-transform: ok\n";
    return 0;
}
