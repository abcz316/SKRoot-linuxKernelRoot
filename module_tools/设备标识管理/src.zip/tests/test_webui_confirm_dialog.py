from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
CSS = (ROOT / "webroot" / "style.css").read_text(encoding="utf-8")


class WebUiConfirmDialogTest(unittest.TestCase):
    def test_custom_confirm_dialog_is_present_and_browser_confirm_is_removed(self):
        for marker in (
            'id="confirmLayer"', 'id="confirmDialog"',
            'id="confirmCancel"', 'id="confirmAccept"',
            'id="confirmBackdrop"', 'role="dialog"', 'aria-modal="true"',
        ):
            self.assertIn(marker, HTML)
        self.assertNotIn("window.confirm", JS)
        self.assertIn("function showConfirm", JS)
        self.assertIn("function closeConfirm", JS)
        self.assertIn('event.key === "Escape" && confirmOpen', JS)
        self.assertIn('$("#confirmAccept").addEventListener', JS)
        self.assertIn(".confirm-layer.is-open", CSS)
        self.assertIn(".confirm-dialog", CSS)

    def test_all_destructive_confirm_flows_use_the_custom_dialog(self):
        self.assertGreaterEqual(JS.count("showConfirm({"), 3)
        self.assertIn("立即更换设备标识？", JS)
        self.assertIn("安排彻底重置？", JS)
        self.assertIn("退出 DRM 后端？", JS)
        self.assertIn("立即应用", JS)
        self.assertIn("检查并安排", JS)
        self.assertIn("退出后端", JS)


if __name__ == "__main__":
    unittest.main()
