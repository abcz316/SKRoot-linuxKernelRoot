from __future__ import annotations

import hashlib
from pathlib import Path
import re
import subprocess
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]
MODULE = (ROOT / "module_main.cpp").read_text(encoding="utf-8")
WEB = (ROOT / "web_ui.cpp").read_text(encoding="utf-8")
DAEMON = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
HOOK = (ROOT / "binder_hook_builder.cpp").read_text(encoding="utf-8")
WORKER = (ROOT / "drmid_worker.cpp").read_text(encoding="utf-8")
WORKER_HEADER = (ROOT / "drmid_worker.h").read_text(encoding="utf-8")
TRANSACTION = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
HTML = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
PACKAGE = (ROOT / "package.py").read_text(encoding="utf-8")
VERSION = "1.0.9"
MODULE_ID = "deviceIdentityManagerSKP20260904"
ZIP = ROOT / "dist" / f"设备标识管理-{VERSION}-arm64-run-once.zip"
SDK_SHA256 = "5b304a9d7e1c2d5d8aa2e7d2a95710d37b1f261e1a92ffe640737d747ed93f91"


class MergeReleaseTest(unittest.TestCase):
    def test_single_skp_entry_and_webui_registration(self):
        production = "\n".join(
            path.read_text(encoding="utf-8")
            for pattern in ("*.cpp", "*.h")
            for path in ROOT.glob(pattern)
        )
        self.assertEqual(production.count("SKROOT_MODULE_NAME("), 1)
        self.assertEqual(production.count("SKROOT_MODULE_WEB_UI("), 1)
        self.assertEqual(production.count("SKROOT_MODULE_ID32("), 1)
        self.assertIn(f'SKROOT_MODULE_ID32("{MODULE_ID}")', MODULE)
        self.assertEqual(len(MODULE_ID.encode("ascii")), 32)

    def test_install_and_uninstall_clear_stale_runtime_processes(self):
        install_start = MODULE.index("std::string module_on_install")
        install_end = MODULE.index("void module_on_uninstall", install_start)
        install_block = MODULE[install_start:install_end]
        uninstall_block = MODULE[install_end:]
        for block in (install_block, uninstall_block):
            self.assertIn("stop_background_daemon", block)
            self.assertIn("stop_worker", block)
        self.assertIn("stale-runtime-stop", install_block)

    def test_sdk_461_and_native_abi_are_frozen(self):
        sdk = ROOT / ".sdk-cache/kernel_module_kit/lib/libkernel_module_kit_static.a"
        self.assertEqual(hashlib.sha256(sdk.read_bytes()).hexdigest(), SDK_SHA256)
        self.assertIn("kCounterContextAbi = 20", (ROOT / "kernel_context.h").read_text(encoding="utf-8"))
        self.assertIn("kControlIpcVersion = 5", (ROOT / "control_ipc.h").read_text(encoding="utf-8"))
        self.assertIn("kRuntimeControlVersion = 3", (ROOT / "runtime_control.h").read_text(encoding="utf-8"))
        self.assertIn(SDK_SHA256, PACKAGE)

    def test_supervisor_worker_lifecycle_and_private_key_channel(self):
        for marker in (
            "start_worker", "stop_worker", "worker_alive", "drm-worker-retry",
            'pipe(root_pipe)', 'DEVICE_IDENTITY_ROOT_FD', "std::fill(root_key.begin()",
            "restore_identity_for_supervisor_stop",
        ):
            self.assertIn(marker, DAEMON + WORKER)
        self.assertNotRegex(WORKER, r"setenv\([^\n]*ROOT_KEY")
        self.assertNotIn("root_key.c_str(), path.c_str()", WORKER)

    def test_resident_process_set_is_bounded_and_worker_is_reaped(self):
        self.assertEqual(DAEMON.count("fork()"), 1)
        self.assertEqual(WORKER.count("fork()"), 1)
        self.assertIn("PR_SET_PDEATHSIG", WORKER)
        self.assertIn("getppid() != supervisor_pid", WORKER)
        self.assertIn("bool reap_worker(pid_t pid)", WORKER)
        stop_start = WORKER.index("bool stop_worker(")
        stop_end = WORKER.index("bool start_worker(", stop_start)
        self.assertIn("reap_worker(pid)", WORKER[stop_start:stop_end])
        self.assertNotIn("while (true)", DAEMON)

    def test_master_switch_uses_a_hook_free_disabled_state(self):
        apply_start = DAEMON.index('if (action.type == "apply-config")')
        apply_end = DAEMON.index('if (action.type == "randomize-identities")')
        apply_block = DAEMON[apply_start:apply_end]
        self.assertIn("ReplacementMode::kWriteTest", apply_block)
        self.assertIn("ReplacementMode::kDryRun", apply_block)
        self.assertIn("set_runtime_mode", apply_block)
        self.assertIn("stop_worker", apply_block)
        self.assertIn("worker-starting", apply_block)
        self.assertIn("disabled-by-policy", DAEMON)
        self.assertRegex(DAEMON, r"start_worker\(\s*private_dir,\s*false")

    def test_compatibility_switch_does_not_restart_disabled_worker(self):
        start = WORKER.index("bool set_enabled(")
        end = WORKER.index("bool build_randomized_runtime", start)
        block = WORKER[start:end]
        disabled_start = block.index("if (!enabled)")
        disabled_end = block.index("if (worker_alive", disabled_start)
        disabled_path = block[disabled_start:disabled_end]
        self.assertIn("stop_worker", disabled_path)
        self.assertIn("set_runtime_mode", disabled_path)
        self.assertNotIn("start_worker", disabled_path)

    def test_rotation_persists_while_worker_readiness_gate_is_active(self):
        action_start = DAEMON.index('if (action.type == "randomize-identities")')
        action_end = DAEMON.index('if (action.type == "prepare-global-reset")')
        action_block = DAEMON[action_start:action_end]
        self.assertIn("worker_running", action_block)
        self.assertIn("worker_status.control_connected", action_block)
        self.assertIn('"persisted-worker-starting"', action_block)
        self.assertNotIn(
            "!device_identity::drm::worker_alive(private_dir) ||\n            device_identity::drm::publish_runtime",
            action_block,
        )

    def test_restart_backoff_and_budget_bound_failed_workers(self):
        for marker in (
            "kWorkerRestartBurstLimit",
            "kWorkerRestartInitialDelayMs",
            "kWorkerRestartMaximumDelayMs",
            "kWorkerHealthyWindowMs",
            "worker_restart_delay_ms",
            "next-delay-ms",
            "budget=",
        ):
            self.assertIn(marker, DAEMON)
        self.assertIn("worker_status.state == device_identity::drm::WorkerState::kFailed", DAEMON)
        self.assertIn("now >= drm_next_restart", DAEMON)

    def test_binder_hot_path_filters_unrelated_transactions(self):
        for marker in (
            "Only transaction code 11 can be a deviceUniqueId query",
            "avoid the 256-byte user copy",
            "correlation path only consumes replies sent by the HAL",
            "before the user copy",
            "BC_REPLY_SG",
            "BR_TRANSACTION_SEC_CTX",
        ):
            self.assertIn(marker, HOOK)

    def test_drm_configuration_controls_are_removed_but_diagnostics_remain(self):
        for marker in (
            "/api/drm-config", "/api/drm-exit", "handle_drm_config",
            "handle_drm_exit", 'id="drmIdAction"',
            'id="drmMode"', 'id="drmCustomId"', "Widevine DRM ID",
        ):
            self.assertNotIn(marker, WEB + JS + HTML)
        self.assertIn("DRM Binder 诊断", HTML)
        self.assertIn('data-identity-original="drmid"', HTML)
        self.assertIn('data-verification-state="drmid"', HTML)
        self.assertIn("/api/drm-stop", WEB + JS)

    def test_schema_master_switch_and_conflict_gate(self):
        state = (ROOT / "state_store.h").read_text(encoding="utf-8")
        self.assertIn("kConfigSchemaVersion = 5", state)
        self.assertIn("bool master_enabled", state)
        for old_id in (
            "jiebiaoSkpDeviceIdentity20260814",
            "drmidKern612Probe20260728Alpha01",
        ):
            self.assertIn(old_id, MODULE + WORKER + WORKER_HEADER)
        self.assertIn("legacy-module-conflict", WEB)
        self.assertIn("config.master_enabled", DAEMON + WEB)

    def test_drm_randomization_preflight_is_pure_and_transactional(self):
        self.assertIn("build_randomized_runtime", WORKER + TRANSACTION)
        prepare = TRANSACTION[TRANSACTION.index("bool prepare_global_reset"):TRANSACTION.index("std::string execute_early_global_reset")]
        self.assertIn("build_randomized_runtime", prepare)
        self.assertNotIn("randomize_runtime(", prepare)
        for marker in ('"/drm.old"', '"/drm.new"', "restore_runtime", "publish_runtime"):
            self.assertIn(marker, TRANSACTION)

    def test_drm_id_is_random_at_first_init_and_every_rotation(self):
        init_start = WORKER.index("bool initialize_runtime")
        init_end = WORKER.index("bool read_runtime", init_start)
        init_block = WORKER[init_start:init_end]
        self.assertIn('open("/dev/urandom"', init_block)
        self.assertIn("config.virtual_id.data()", init_block)
        self.assertNotIn("config.virtual_id = profile.virtual_stream", init_block)

        rotate_start = WORKER.index("bool build_randomized_runtime")
        rotate_end = WORKER.index("bool randomize_runtime", rotate_start)
        rotate_block = WORKER[rotate_start:rotate_end]
        self.assertIn('open("/dev/urandom"', rotate_block)
        self.assertIn("next.config_generation++", rotate_block)

        action_start = DAEMON.index('if (action.type == "randomize-identities")')
        action_end = DAEMON.index('if (action.type == "prepare-global-reset")')
        action_block = DAEMON[action_start:action_end]
        self.assertIn("publish_runtime", action_block)
        self.assertLess(action_block.index("publish_runtime"),
                        action_block.index("if (!config.master_enabled)"))

    def test_identity_switch_posts_and_waits_immediately(self):
        self.assertIn('$("#markEnabled").addEventListener("change"', JS)
        self.assertIn('post("/api/config"', JS)
        self.assertIn("await waitForAction(result.sequence)", JS)
        self.assertNotIn('$("#configForm").addEventListener("submit"', JS)
        self.assertNotIn("保存并应用", HTML)

    def test_beginner_friendly_rotate_and_full_reset_copy(self):
        for marker in (
            "快速更换设备标识", "核心标识", "立即应用", "保存为待应用",
            "彻底重置全部标识", "全部支持的标识", "重启后生效",
            "检查并安排完整重置", "写入失败时会使用备份回滚",
        ):
            self.assertIn(marker, HTML + JS + (ROOT / "README.md").read_text(encoding="utf-8"))
        for marker in ("仅轮换模块标识", "统一全局标识重置", "预检并安排重置"):
            self.assertNotIn(marker, HTML)
        for marker in ("尚未安排", "准备完成，等待重启", "完整重置已完成", "操作异常，已恢复原值"):
            self.assertIn(marker, JS)
        self.assertIn('showConfirm({', JS)
        self.assertIn("OAID", JS[JS.index('$(\"#randomizeButton\")'):])
        self.assertIn("randomize_oaids_now", DAEMON + (ROOT / "identity_engine.cpp").read_text(encoding="utf-8"))

    def test_quick_rotation_includes_immediate_oaid_paths(self):
        identity = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        for marker in (
            "randomize_oaids_now",
            "queue_oaid_rotation",
            '"/data/system/openid_config.xml"',
            '"/data/system/oaid_persistence_0"',
            "apply_oaid_targets",
        ):
            self.assertIn(marker, identity)
        self.assertIn("apply_pending_oaids", DAEMON)
        self.assertIn("无需重启", JS)

    def test_drm_identity_and_diagnostic_status_are_read_only_and_visible(self):
        self.assertIn('data-identity-original="drmid"', HTML)
        self.assertIn('data-identity-current="drmid"', HTML)
        self.assertIn('data-verification-state="drmid"', HTML)
        self.assertIn("DRM Binder 诊断", HTML)
        for marker in (
            'data-drm-field="kernel_release"',
            'data-drm-field="capabilities"',
            'data-drm-field="entry_fingerprint"',
            'data-drm-field="original_fingerprint"',
            'data-drm-field="virtual_fingerprint"',
            'data-drm-field="counters"',
        ):
            self.assertIn(marker, HTML)
        self.assertIn("append_drm_identity", WEB)
        self.assertIn("/api/drm-stop", WEB + JS)

    def test_unified_webui_and_background_disconnect(self):
        for marker in (
            "设备标识管理",
            "后台已退出", "请重新从管理器打开",
        ):
            self.assertIn(marker, HTML)
        for marker in (
            "visibilitychange",
            'document.addEventListener("freeze"', "pagehide", "beforeunload", "sendBeacon",
        ):
            self.assertIn(marker, JS)
        self.assertIn("request_server_close_locked", WEB)
        self.assertIn("kWebUiIdleTimeout", WEB)
        self.assertNotIn("/api/drm-config", WEB + JS + HTML)
        self.assertNotIn("drmIdAction", WEB + JS + HTML)
        self.assertNotIn("securityPatch", WEB + JS + HTML)
        self.assertIn('id="markEnabled"', HTML)
        self.assertNotIn('id="drmIdAction"', HTML)

    def test_tee_backend_and_public_id_exports_are_absent(self):
        production = "\n".join(
            path.read_text(encoding="utf-8")
            for pattern in ("*.cpp", "*.h")
            for path in ROOT.glob(pattern)
        )
        for marker in (
            "si_object_do_invoke", "free_si_object", "TeeFirmwareIdentity",
            "tee_backend_state", "widevine.mbn", "DRMID_EXPORT_EXPECTED",
            "DRMID_EXPORT_EXPECTED_READABLE", "fchmod(fd, 0644)",
        ):
            self.assertNotIn(marker, production)

    def test_archive_is_exact_private_and_reproducible(self):
        first = subprocess.run(
            ["python3", "package.py"], cwd=ROOT, check=True,
            capture_output=True, text=True,
        ).stdout.splitlines()[-1]
        second = subprocess.run(
            ["python3", "package.py"], cwd=ROOT, check=True,
            capture_output=True, text=True,
        ).stdout.splitlines()[-1]
        self.assertEqual(first, second)
        self.assertEqual(first, hashlib.sha256(ZIP.read_bytes()).hexdigest())
        with zipfile.ZipFile(ZIP) as archive:
            self.assertEqual(
                set(archive.namelist()),
                {
                    "libmodule_device_identity_manager.so",
                    "resources/resetprop",
                    "resources/oaid-runtime.jar",
                    "webroot/device_identity_drm_worker",
                    "webroot/index.html",
                    "webroot/app.js",
                    "webroot/style.css",
                },
            )
            self.assertTrue(all(item.date_time == (1980, 1, 1, 0, 0, 0) for item in archive.infolist()))


if __name__ == "__main__":
    unittest.main()
