from pathlib import Path
import re
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]
MODULE_SOURCE = (ROOT / "module_main.cpp").read_text(encoding="utf-8")
WEB_SOURCE = (ROOT / "web_ui.cpp").read_text(encoding="utf-8")
PRODUCTION_SOURCE = "\n".join(
    path.read_text(encoding="utf-8")
    for suffix in ("*.cpp", "*.h")
    for path in sorted(ROOT.glob(suffix))
)
MODULE_ID = "deviceIdentityManagerSKP20260904"
VERSION = "1.0.9"
ZIP = ROOT / "dist" / f"设备标识管理-{VERSION}-arm64-run-once.zip"


class ReleaseScopeTest(unittest.TestCase):
    def test_module_id_is_exactly_32_ascii_bytes(self):
        match = re.search(r'SKROOT_MODULE_ID32\("([^"]+)"\)', MODULE_SOURCE)
        self.assertIsNotNone(match)
        self.assertEqual(match.group(1), MODULE_ID)
        self.assertEqual(len(match.group(1).encode("ascii")), 32)

    def test_skp_metadata_and_native_entry_are_present(self):
        self.assertIn('SKROOT_MODULE_NAME("设备标识管理")', MODULE_SOURCE)
        self.assertIn('SKROOT_MODULE_AUTHOR("斓梦语、蜃、榆爱")', MODULE_SOURCE)
        self.assertIn(f'SKROOT_MODULE_VERSION("{VERSION}")', MODULE_SOURCE)
        self.assertIn("int skroot_module_main(", MODULE_SOURCE)
        self.assertIn("SKROOT_MODULE_WEB_UI", WEB_SOURCE)

    def test_production_has_no_removed_subsystems(self):
        lowered = PRODUCTION_SOURCE.lower()
        forbidden = (
            "tricky_store",
            "persistent_keys",
            "com.helper.bootinfo",
            "binder_ctl",
            "libbinder_aux.so",
            "/data/adb/modules/ksu32402_model_switcher",
            "kernelsu.js",
            "adb_enabled",
            "development_settings_enabled",
            "kminstallkeybox",
            "/data/vendor/tzstorage",
            "/data/mediadrm",
            "/data/vendor/mediadrm",
            "/data/system/usagestats",
            "wificonfigstore.xml",
            "setenforce",
        )
        for marker in forbidden:
            with self.subTest(marker=marker):
                self.assertNotIn(marker, lowered)

    def test_model_spoof_features_are_removed(self):
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        package = (ROOT / "package.py").read_text(encoding="utf-8")
        daemon = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
        self.assertNotIn("templateSelect", html + js)
        self.assertNotIn("deviceNamesEnabled", html + js)
        self.assertNotIn("/api/templates", WEB_SOURCE)
        self.assertNotIn("apply_template", daemon)
        self.assertNotIn("prop_templates", package)

    def test_property_filter_rejects_removed_property_families(self):
        common = (ROOT / "common.cpp").read_text(encoding="utf-8")
        for marker in (
            '"ro.boot.verifiedbootstate"',
            '"ro.boot.vbmeta.digest"',
            '"ro.adb.secure"',
            '"persist.sys.usb.config"',
        ):
            self.assertIn(marker, common)
        self.assertIn("forbidden_property_key(key)", common)

    def test_webui_has_only_fixed_routes(self):
        routes = set(re.findall(r'path == "(/api/[a-z/-]+)"', WEB_SOURCE))
        self.assertEqual(
            routes,
            {
                "/api/session",
                "/api/session/ping",
                "/api/session/close",
                "/api/status",
                "/api/config",
                "/api/randomize",
                "/api/reset-ssaid",
                "/api/local-reset",
                "/api/drm-stop",
                "/api/action-result",
                "/api/log",
            },
        )
        lowered = WEB_SOURCE.lower()
        self.assertNotIn("/api/shell", lowered)
        self.assertNotIn("/api/command", lowered)
        self.assertNotIn("system(", lowered)

    def test_webui_uses_skp_api_and_local_assets(self):
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        self.assertIn('href="style.css"', html)
        self.assertIn('src="app.js"', html)
        self.assertNotRegex(html, r'https?://')
        self.assertIn('post("/api/session"', js)
        self.assertNotIn("exec", js.lower())
        self.assertIn('user: $("#ssaidUser").value', js)
        self.assertNotIn("device_names_enabled", js)
        self.assertIn("identity_surfaces", js)

    def test_release_name_and_webui_identity_icons_match_product(self):
        package = (ROOT / "package.py").read_text(encoding="utf-8")
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        style = (ROOT / "webroot" / "style.css").read_text(encoding="utf-8")
        self.assertIn('PACKAGE_BASENAME = "设备标识管理"', package)
        self.assertIn('f"{PACKAGE_BASENAME}-{VERSION}-arm64-run-once.zip"', package)
        self.assertNotIn('class="brand-mark" aria-hidden="true">解</span>', html)
        self.assertIn('class="brand-mark"', html)
        self.assertIn('class="status-icon"', html)
        self.assertIn('.brand-mark svg', style)
        self.assertIn('.status-icon', style)

    def test_webui_closes_session_on_page_leave_and_shows_reopen_screen(self):
        web = (ROOT / "web_ui.cpp").read_text(encoding="utf-8")
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        for marker in (
            "onServerCreated",
            "session_watchdog",
            "request_server_close_locked",
            '"/api/session/ping"',
            '"/api/session/close"',
            "kWebUiIdleTimeout",
        ):
            self.assertIn(marker, web)
        for marker in (
            "visibilitychange",
            "pagehide",
            "sendBeacon",
            "startHeartbeat",
            "showDisconnectedPage",
            "/api/session/close",
        ):
            self.assertIn(marker, js)
        self.assertIn('id="screenGate"', html)
        self.assertIn("后台已退出", html)
        self.assertIn("请重新从管理器打开", html)

    def test_webui_uses_realtime_identity_toggle_without_patch_controls(self):
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        self.assertIn("设备标识修改", html)
        self.assertNotIn("securityPatch", html)
        self.assertNotIn("saveConfig", html)
        self.assertNotIn("保存并应用", html)
        self.assertIn('id="markEnabled"', html)

    def test_identity_comparison_preserves_flat_api_and_adds_baseline_state(self):
        identity = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        header = (ROOT / "identity_engine.h").read_text(encoding="utf-8")
        web = (ROOT / "web_ui.cpp").read_text(encoding="utf-8")
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        for marker in (
            '"identity_baseline_v1"',
            '"identity_apply_state_v1"',
            '"pending"',
            '"unknown"',
            "identity_comparison_json",
            "ensure_identity_baseline_properties",
            "ensure_identity_baseline_settings",
            "ensure_identity_baseline_oaid",
            '"identity_oaid_baseline_v1"',
            '"identity_oaid_target_v1"',
            "oaid",
            "read_current_oplus_oaid",
        ):
            self.assertIn(marker, identity + header)
        self.assertIn("identity_comparison_json(identities, config.master_enabled)", web)
        self.assertIn('data-identity-original="serial"', html)
        self.assertIn('data-identity-current="serial"', html)
        self.assertIn('data-identity-state="serial"', html)
        self.assertIn('data-identity-original="oaid"', html)
        self.assertIn('data-identity-current="oaid"', html)
        self.assertIn("stateLabels", js)
        self.assertIn("待应用", js)

    def test_identity_verification_is_exposed_and_rendered_separately(self):
        identity = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        header = (ROOT / "identity_engine.h").read_text(encoding="utf-8")
        web = (ROOT / "web_ui.cpp").read_text(encoding="utf-8")
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        self.assertIn("identity_verification_json", identity + header)
        self.assertIn("verify_setting_value", identity)
        self.assertIn("verify_file_value", identity)
        self.assertIn("identity_verification", web)
        self.assertIn("实际读取验证", html)
        self.assertIn('data-verification-state="serial"', html)
        self.assertIn('data-verification-state="oaid"', html)
        self.assertIn('class="identity-grid verification-grid"', html)
        style = (ROOT / "webroot" / "style.css").read_text(encoding="utf-8")
        self.assertIn('.verification-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }', style)
        self.assertIn("OPLUS/OUID provider", identity)
        self.assertIn("verificationLabels", js)
        self.assertIn("验证通过", js)

    def test_usb_gadget_serial_follows_serial_lifecycle(self):
        engine = (ROOT / "usb_serial_engine.cpp").read_text(encoding="utf-8")
        header = (ROOT / "usb_serial_engine.h").read_text(encoding="utf-8")
        identity = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        daemon = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
        module = (ROOT / "module_main.cpp").read_text(encoding="utf-8")
        transaction = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
        makefile = (ROOT / "jni" / "Android.mk").read_text(encoding="utf-8")
        for marker in (
            '"/config/usb_gadget"',
            '"/sys/kernel/config/usb_gadget"',
            '"usb_gadget_serial_originals_v1"',
            '"usb_gadget_serial_bound_target_v1"',
            "safe_usb_serial_path",
            "safe_usb_udc_path",
            "O_NOFOLLOW",
            "apply_usb_gadget_serial",
            "restore_usb_gadget_serial",
            "verify_usb_gadget_serial",
            "rebind_active_gadgets",
            "write_configfs_control",
        ):
            self.assertIn(marker, engine + header)
        self.assertIn("verify_serial_surfaces", identity)
        self.assertIn("system property + USB configfs", identity)
        self.assertGreaterEqual(daemon.count("apply_usb_gadget_serial"), 3)
        self.assertGreaterEqual(daemon.count("restore_usb_gadget_serial"), 2)
        self.assertIn("restore_usb_gadget_serial", module)
        self.assertIn("apply_usb_gadget_serial(old_values.serial)", transaction)
        self.assertIn("../usb_serial_engine.cpp", makefile)
        for marker in ("sys.usb.config", "persist.sys.usb.config", "adb_enabled"):
            self.assertNotIn(marker, engine.lower())

    def test_alpha19_removes_telephony_identity_surfaces(self):
        identity = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        header = (ROOT / "identity_engine.h").read_text(encoding="utf-8")
        daemon = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
        transaction = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        for marker in (
            '"call", "iphonesubinfo"',
            'read_phone_identifier("8")',
            'read_phone_identifier("13")',
            'verify_telephony_value',
            'data-identity-original="imsi"',
            'data-identity-original="iccid"',
            'data-verification-state="imsi"',
            'data-verification-state="iccid"',
        ):
            self.assertNotIn(marker, identity + header + daemon + html + js)
        for removed in (
            "boot_id_value", "cpu_id", "hostname",
            "sethostname(", "kBootIdProperties", "kCpuIdProperties",
            "kHostnameProperties", "kAdvertisingProperties",
        ):
            self.assertNotIn(removed, identity + header + daemon)
        self.assertNotIn("std::string advertising_id;", header)
        self.assertNotIn('add("global", 0, "advertising_id"', identity)
        self.assertNotIn('add("secure", 0, "advertising_id"', identity)
        self.assertNotIn('"adid"', identity)
        for removed_label in ("Boot ID", "CPU ID", "Hostname", "Advertising ID"):
            self.assertNotIn(removed_label, html)
        self.assertIn('boot_session_id()', daemon)
        self.assertNotIn('stored_boot == boot_id()', daemon)
        self.assertNotIn('write_kernel_boot_id(', identity)
        self.assertNotIn('../patch_boot_id.cpp', (ROOT / 'jni' / 'Android.mk').read_text(encoding='utf-8'))
        self.assertNotIn('"advertising_id"', transaction)
        self.assertIn('unsupported: "暂不支持"', js)

    def test_config_v5_removes_model_fields_and_clears_legacy_values(self):
        header = (ROOT / "state_store.h").read_text(encoding="utf-8")
        source = (ROOT / "state_store.cpp").read_text(encoding="utf-8")
        self.assertIn("kConfigSchemaVersion = 5", header)
        self.assertIn("bool master_enabled", header)
        self.assertNotIn("device_names_enabled", header)
        self.assertNotIn("selected_template", header)
        self.assertIn('storage_write_bool("device_names_enabled", false)', source)
        self.assertIn('storage_write_string("selected_template", "")', source)

    def test_alpha21_removes_media_guard(self):
        production = (ROOT / "package.py").read_text(encoding="utf-8")
        header = (ROOT / "state_store.h").read_text(encoding="utf-8")
        source = (ROOT / "state_store.cpp").read_text(encoding="utf-8")
        daemon = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
        makefile = (ROOT / "jni" / "Android.mk").read_text(encoding="utf-8")
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        runtime = daemon + makefile + html + js + header
        for marker in ("MediaGuard", "media_guard", "媒体会话守护", "media_enabled",
                       "media_packages", "media_roots", "media_suffixes", "media_keywords",
                       "mediaEnabled", "mediaPackages", "mediaRoots", "mediaSuffixes", "mediaKeywords"):
            self.assertNotIn(marker, runtime)
        self.assertNotIn("media_guard.cpp", makefile)
        self.assertIn('storage_write_bool("media_enabled", false)', source)

    def test_ssaid_never_deletes_settings_table(self):
        operations = (ROOT / "operations.cpp").read_text(encoding="utf-8")
        transaction = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
        combined = operations + transaction
        self.assertNotRegex(combined, r'unlink\([^\n]*settings_ssaid')
        self.assertIn('"/system/bin/abx2xml"', (ROOT / "ssaid_engine.cpp").read_text(encoding="utf-8"))
        self.assertIn('"/system/bin/xml2abx"', (ROOT / "ssaid_engine.cpp").read_text(encoding="utf-8"))
        self.assertIn('"clear", "--user"', operations)

    def test_ssaid_fallback_is_transactional(self):
        operations = (ROOT / "operations.cpp").read_text(encoding="utf-8")
        transaction = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
        engine = (ROOT / "ssaid_engine.cpp").read_text(encoding="utf-8")
        self.assertIn("inspect_ssaid_file", engine)
        self.assertIn('entry.kind == "ssaid-fallback"', transaction)
        self.assertIn('"ssaid-fallback"', transaction)
        self.assertIn('user.path + ".fallback"', transaction)
        self.assertIn("restore_entry(entry)", transaction)
        self.assertIn('backup + ".fallback"', operations)
        self.assertIn('fallback-write-failed', operations)

    def test_global_reset_is_preflighted_and_fail_closed(self):
        source = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
        operations = (ROOT / "operations.cpp").read_text(encoding="utf-8")
        daemon = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
        for marker in (
            "backup_entry(",
            "backup-verify-failed",
            "hash-changed",
            'set_state("prepared"',
            'set_state("rolled-back"',
            "restore_managed_settings_snapshot",
            "save_identity_values(old_values)",
        ):
            self.assertIn(marker, source)
        self.assertIn("recover_post_boot_global_reset", operations)
        self.assertIn('if (state == "prepared")', operations)
        self.assertIn("recover_post_boot_global_reset(private_dir)", daemon)
        self.assertIn("perform_post_boot_operations(private_dir)", daemon)

    def test_webui_retries_early_applied_transaction_status(self):
        js = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
        self.assertIn('reset.state === "early-applied"', js)
        self.assertIn("transactionPollTimer", js)
        self.assertIn("setTimeout", js)

    def test_runtime_recovery_rejects_reused_daemon_pid(self):
        daemon = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
        common = (ROOT / "common.cpp").read_text(encoding="utf-8")
        web = (ROOT / "web_ui.cpp").read_text(encoding="utf-8")
        self.assertIn("daemon_process_alive", daemon)
        self.assertIn("read_proc_command_line", daemon)
        self.assertIn("read_stream_file", daemon + common)
        self.assertIn("/proc/", daemon)
        self.assertIn("background_daemon_alive", daemon + web)
        self.assertIn('transaction_state == "early-applied"', web)
        self.assertIn("perform_post_boot_operations(private_dir_)", web)

    def test_provider_adapters_are_probe_only_when_unknown(self):
        source = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
        self.assertIn("provider-detected-probe-only", source)
        self.assertIn('overlay = "pending"', source)
        self.assertIn('overlay = "applied"', source)
        self.assertIn('overlay = "rolled-back"', source)
        self.assertIn('entry.kind == "oaid"', source)
        self.assertNotIn('TxnEntry entry{"gsf"', source)
        self.assertNotIn('TxnEntry entry{"oem_oaid"', source)

    def test_oplus_oaid_adapter_is_transactional_and_readback_verified(self):
        engine = (ROOT / "oaid_engine.cpp").read_text(encoding="utf-8")
        header = (ROOT / "oaid_engine.h").read_text(encoding="utf-8")
        transaction = (ROOT / "reset_transaction.cpp").read_text(encoding="utf-8")
        makefile = (ROOT / "jni" / "Android.mk").read_text(encoding="utf-8")
        for marker in (
            "inspect_oplus_openid_xml",
            "build_oplus_oaid_payload",
            "rewrite_oplus_openid_xml",
            "read_oplus_oaid_provider",
            "run_process_as(2000, 2000",
            "parse_oplus_oaid_provider_output",
            "content://com.oplus.omes.oaid_status_provider",
            '"--method", "OUID"',
        ):
            self.assertIn(marker, engine + header)
        for marker in (
            'entry.kind == "oplus-oaid"',
            'entry.target == "/data/system/openid_config.xml"',
            'TxnEntry entry{"oplus-oaid"',
            "backup_entry(",
            "restore_entry(",
            '"oplus_oaid"',
            '"provider-match"',
        ):
            self.assertIn(marker, transaction)
        self.assertIn("../oaid_engine.cpp", makefile)
        self.assertNotIn('"clear", "com.heytap.openid"', transaction)

    def test_added_identity_surfaces_are_present(self):
        identity = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        self.assertIn('"ro.vendor.oem.serialno"', identity)
        self.assertIn("restore_retired_identity_settings", identity)
        self.assertNotIn('get_property("ro.product.marketname")', identity)

    def test_identity_properties_are_existing_only_and_build_ids_are_untouched(self):
        identity = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        header = (ROOT / "identity_engine.h").read_text(encoding="utf-8")
        html = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
        self.assertIn("property_exists(key.c_str())", identity)
        self.assertIn("restore_original_property", identity)
        self.assertIn("originally absent key as a tombstone", identity)
        self.assertIn("A retired field is restored once", identity)
        self.assertNotIn('"ro.product.build.id"', identity)
        self.assertNotIn('"ro.build.unique_id"', identity)
        self.assertNotIn("unique_id", header)
        self.assertNotIn("Build Unique ID", html)

    def test_security_patch_feature_is_removed(self):
        source = (ROOT / "property_engine.cpp").read_text(encoding="utf-8")
        header = (ROOT / "property_engine.h").read_text(encoding="utf-8")
        self.assertNotIn("apply_security_patch", source + header)
        self.assertNotIn("build_date_for_patch", source)
        self.assertIn("restore_retired_security_patch", source + header)

    def test_archive_members_are_private_and_complete(self):
        if not ZIP.is_file():
            self.skipTest("package has not been generated")
        with zipfile.ZipFile(ZIP) as archive:
            names = archive.namelist()
            self.assertEqual(len(names), len(set(names)))
            self.assertIn("libmodule_device_identity_manager.so", names)
            self.assertIn("webroot/device_identity_drm_worker", names)
            self.assertIn("resources/resetprop", names)
            self.assertIn("webroot/index.html", names)
            self.assertIn("webroot/app.js", names)
            self.assertIn("webroot/style.css", names)
            self.assertFalse(any(name.startswith("resources/prop_templates/") for name in names))
            for name in names:
                self.assertFalse(name.startswith("/"))
                self.assertNotIn("..", Path(name).parts)
                self.assertFalse(name.startswith("data/"))


if __name__ == "__main__":
    unittest.main()
