from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
CSS = (ROOT / "webroot" / "style.css").read_text(encoding="utf-8")


class WebUiStartupWaitingTest(unittest.TestCase):
    def test_waiting_state_uses_a_full_page_blocker(self):
        for marker in (
            'id="screenGate"',
            'id="screenGateTitle"',
            'id="screenGateMessage"',
            "模块暂未完全启用",
            "请等待系统稳定后重新进入（约1-2分钟）",
            "正在等待稳定切入",
        ):
            self.assertIn(marker, HTML)
        self.assertIn('data-screen-state="connecting"', HTML)
        self.assertIn(".screen-gate", CSS)
        self.assertIn('.screen-gate[aria-hidden="true"]', CSS)

    def test_starting_backend_blocks_all_controls_and_closes_the_session(self):
        for marker in (
            "function drmWaitingForStableCutIn",
            "startup_waiting",
            '"waiting-stable"',
            "function setScreenState",
            '$$("button, input, select, textarea")',
            'setText("#statusText", "正在等待稳定切入")',
            '$("#refreshStatus").dataset.state = "waiting"',
            'setScreenState("waiting-stable")',
            'document.visibilityState === "hidden"',
            "pagehide",
            "beforeunload",
        ):
            self.assertIn(marker, JS)
        self.assertLess(
            JS.index("if (drmWaitingForStableCutIn(drm))"),
            JS.index('$("#refreshStatus").dataset.state = daemonAlive'),
        )

    def test_backend_exposes_supervisor_boot_wait(self):
        worker = (ROOT / "drmid_worker.cpp").read_text(encoding="utf-8")
        daemon = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
        self.assertIn("startup_waiting", worker)
        self.assertIn("mark_startup_waiting(private_dir, true)", daemon)
        self.assertIn("mark_startup_waiting(private_dir, false)", daemon)

    def test_waiting_overlay_is_distinct_from_disconnect_overlay(self):
        self.assertIn('id="screenGate"', HTML)
        self.assertIn("后台已退出", HTML)
        self.assertIn('setScreenState("disconnected")', JS)
        self.assertIn("if (PREVIEW_MODE || disconnectStarted) return", JS)

    def test_focus_loss_does_not_close_webui_session(self):
        self.assertIn('window.addEventListener("blur", handleWindowBlur)', JS)
        start = JS.index('function handleWindowBlur')
        end = JS.index('function handleWindowFocus', start)
        self.assertIn('if (document.visibilityState === "hidden") closeWebUiSession()', JS[start:end])
        self.assertIn('document.addEventListener("visibilitychange"', JS)
        self.assertIn('window.addEventListener("pagehide", closeWebUiSession', JS)


if __name__ == "__main__":
    unittest.main()
