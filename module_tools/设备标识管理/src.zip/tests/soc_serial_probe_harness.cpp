#include "soc_serial_adapter.h"
#include "common.h"
#include "state_store.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <map>
#include <string>

namespace fs = std::filesystem;
namespace jiebiao {
std::map<std::string, std::string> cached_paths;
std::string trim(std::string value) {
    const auto start = value.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return {};
    return value.substr(start, value.find_last_not_of(" \t\r\n") - start + 1);
}
bool read_stream_file(const std::string& path, std::string& output, size_t maximum) {
    if (fs::is_symlink(fs::symlink_status(path))) return false;
    std::ifstream input(path, std::ios::binary);
    if (!input) return false;
    output.assign(std::istreambuf_iterator<char>(input), {});
    return output.size() <= maximum;
}
bool storage_read_string(const char* key, std::string& value) {
    value = cached_paths[key];
    return true;
}
bool storage_write_string(const char* key, const std::string& value) {
    cached_paths[key] = value;
    return true;
}
}  // namespace jiebiao

int main(int argc, char** argv) {
    if (argc < 2 || argc > 3) return 2;
    const std::string root = argv[1];
    auto reset = [&] {
        fs::remove_all(root + "/sys");
        fs::remove_all(root + "/proc");
        jiebiao::cached_paths.clear();
    };
    auto put = [&](const std::string& path, const std::string& value) {
        fs::create_directories(fs::path(root + path).parent_path());
        std::ofstream(root + path, std::ios::binary) << value;
    };
    auto show = [&](const char* test) {
        const auto result = jiebiao::soc_serial::probe();
        const std::string path = result.path.empty() ? "none" : result.path.substr(root.size());
        std::cout << test << "=" << path << ",value=" << result.value
                  << ",readable=" << result.readable << ",hookable=" << result.hookable << '\n';
    };

    if (argc == 3) {
        const std::string scenario = argv[2];
        reset();
        const std::string ufs = "/sys/devices/platform/soc/1d84000.ufshc/string_descriptors/serial_number";
        if (scenario == "ufs-cache") {
            put(ufs, "UFS_ORIGINAL");
            put("/sys/devices/soc0/serial_number", "SOC_ORIGINAL");
            jiebiao::cached_paths["soc_serial_adapter_v1"] = root + ufs;
        } else if (scenario == "peripheral") {
            put("/sys/devices/platform/soc/pcie/mhi/serial_number", "MODEM");
            jiebiao::cached_paths["soc_serial_adapter_v1"] = root + "/sys/devices/platform/soc/pcie/mhi/serial_number";
        } else if (scenario == "ufs-only") {
            put(ufs, "UFS_ORIGINAL");
        } else if (scenario == "alias-priority") {
            put("/sys/devices/soc0/serial_number", "SOC_ORIGINAL");
            fs::create_directories(root + "/sys/bus/soc/devices");
            fs::create_directory_symlink(root + "/sys/devices/soc0", root + "/sys/bus/soc/devices/soc0");
        } else if (scenario == "peripheral-alias") {
            put("/sys/devices/platform/soc/ufs/serial_number", "STORAGE");
            fs::create_directories(root + "/sys/class/soc");
            fs::create_directory_symlink(root + "/sys/devices/platform/soc/ufs", root + "/sys/class/soc/soc0");
        } else return 2;
        show(scenario.c_str());
#ifdef HAS_UFS
        if (scenario == "ufs-cache") {
            const auto auxiliary = jiebiao::soc_serial::probe_ufs_serial();
            std::cout << "auxiliary=" << auxiliary.source << ",value=" << auxiliary.value << '\n';
        }
#endif
        reset();
        return 0;
    }

    reset();
    show("absent");
    put("/sys/devices/platform/soc/serial_number", "2222222222\n");
    put("/sys/devices/soc0/serial_number", "1111111111\n");
    show("priority");
    reset();
    put("/sys/devices/system/soc/soc0/serial_number", "12345678\n");
    show("system-soc");
    reset();
    put("/sys/devices/platform/soc/mtk-deviceid/serial_number", "12345678\n");
    show("nested-mtk");
    reset();
    put("/sys/class/soc/soc0/serial_number", "12345678\n");
    show("class-soc");
    reset();
    put("/sys/devices/fixture/serial_number", "12345678\n");
    fs::create_directories(root + "/sys/bus/soc/devices");
    fs::create_directory_symlink(root + "/sys/devices/fixture", root + "/sys/bus/soc/devices/soc0");
    show("bus-alias");
    reset();
    put("/sys/firmware/devicetree/base/chosen/serial-number", std::string("DT123456\0", 9));
    show("dt-chosen");
    put("/sys/devices/platform/soc/serial_number", "12345678\n");
    show("late-sysfs");
    fs::remove(root + "/sys/devices/platform/soc/serial_number");
    show("stale-cache");
    reset();
    put("/sys/devices/other/serial_number", "NOT_SOC");
    show("unrelated");
    reset();
    return 0;
}
