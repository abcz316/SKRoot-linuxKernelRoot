from pathlib import Path
import shutil
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT / "webroot/app.js").read_text(encoding="utf-8")


class ActionStatusRefreshTest(unittest.TestCase):
    def run_js(self, code):
        node = shutil.which("node")
        if not node:
            self.skipTest("node required")
        subprocess.run([node, "-e", code], check=True, capture_output=True, text=True)

    def test_forced_refresh_waits_and_fetches_after_old_request(self):
        function = JS[JS.index("function loadStatus("):JS.index("async function fetchStatus(")]
        self.run_js('const assert = require("node:assert/strict"); let statusRequestInFlight = null;'
                    'let requests = []; function fetchStatus() { return new Promise(r => requests.push(r)); }' + function + '''
            (async () => {
                const first = loadStatus();
                assert.equal(loadStatus(), first);
                const fresh = loadStatus(false, true);
                let completed = false; fresh.then(() => completed = true);
                requests[0]({generation: 1});
                await first; await Promise.resolve();
                assert.equal(requests.length, 2);
                assert.equal(completed, false);
                requests[1]({generation: 2});
                assert.deepEqual(await fresh, {generation: 2});
            })().catch(e => { console.error(e); process.exit(1); });
        ''')

    def test_action_failure_refreshes_status_before_reporting(self):
        function = JS[JS.index("async function waitForAction("):JS.index("async function copyIdentityValue(")]
        self.run_js('const assert = require("node:assert/strict"); const window={setTimeout:f=>f()};'
                    'let refreshed=false; async function loadStatus(show, force) { assert.equal(force,true); refreshed=true; }'
                    'async function loadLog() {} async function post() { return {sequence:7,result:{ok:false,detail:"OAID failed"}}; }'
                    + function + '''
            (async () => {
                await assert.rejects(waitForAction(7), /OAID failed/);
                assert.equal(refreshed, true);
            })().catch(e => { console.error(e); process.exit(1); });
        ''')

    def test_starting_drm_state_schedules_status_retry(self):
        start = JS.index('function renderStatus(data)')
        end = JS.index('function loadStatus(', start)
        block = JS[start:end]
        self.assertIn('drmNeedsStatusRetry(data)', block)
        self.assertIn('scheduleStatusRetry(1500)', block)

    def test_drm_startup_polling_stops_at_stable_or_terminal_states(self):
        fn = JS[JS.index('function drmNeedsStatusRetry'):JS.index('function renderStatus')]
        self.run_js('const assert=require("node:assert/strict"); let PREVIEW_MODE=false, sessionClosed=false;' + fn + '''
          const data={daemon:{alive:true}, config:{master_enabled:true},
            drm:{state:"starting",connected:false}, identity_verification:{drmid:{state:"pending"}}};
          assert.equal(drmNeedsStatusRetry(data),true);
          data.drm={state:"running",connected:true};
          assert.equal(drmNeedsStatusRetry(data),true);
          data.identity_verification.drmid.state="passed";
          assert.equal(drmNeedsStatusRetry(data),false);
          for (const state of ["failed","disabled","stopped"]) {
            data.drm={state,connected:false}; assert.equal(drmNeedsStatusRetry(data),false);
          }
          data.drm={state:"running",connected:true}; data.config.master_enabled=false;
          data.identity_verification.drmid.state="pending";
          assert.equal(drmNeedsStatusRetry(data),false);
          data.config.master_enabled=true;
          data.drm={state:"waiting-hal",connected:false};
          assert.equal(drmNeedsStatusRetry(data),true);
          sessionClosed=true; data.drm.state="starting";
          assert.equal(drmNeedsStatusRetry(data),false);
        ''')

    def test_backend_uses_one_drm_snapshot_for_every_field(self):
        source=(ROOT / 'web_ui.cpp').read_text()
        self.assertEqual(source.count('device_identity::drm::read_status(private_dir_)'),1)
        self.assertIn('device_identity::drm::status_json(drm_status)',source)


if __name__ == "__main__":
    unittest.main()
