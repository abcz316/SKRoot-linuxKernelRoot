#include "kernel_module_kit_umbrella.h"

#include <unistd.h>

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

namespace {

constexpr const char* kModuleId = "deviceIdentityManagerSKP20260904";

std::string read_root_key() {
    std::string root_key;
    std::getline(std::cin, root_key);
    return root_key;
}

int finish(std::string& root_key, KModErr result) {
    std::fill(root_key.begin(), root_key.end(), '\0');
    std::cout << "result=" << to_string(result) << '\n';
    return is_ok(result) ? 0 : 1;
}

}  // namespace

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);
    if (argc < 2) {
        std::cerr << "usage: jiebiao_sdk_control env|list|webui|install|install-once|uninstall|rootcmd|provider [argument]\n";
        return 2;
    }
    std::string root_key = read_root_key();
    if (root_key.empty()) {
        std::cerr << "missing root key on stdin\n";
        return 2;
    }

    const std::string action(argv[1]);
    if (action == "env") {
        const auto state = skroot_env::get_skroot_environment_state(root_key.c_str());
        skroot_env::SkrootSdkVersion installed{};
        const KModErr version_result = skroot_env::get_installed_skroot_environment_version(root_key.c_str(), installed);
        std::cout << "state=" << static_cast<uint32_t>(state) << " installed="
                  << installed.major << "." << installed.minor << "." << installed.patch
                  << " version_result=" << to_string(version_result) << "\n";
        return finish(root_key, KModErr::OK);
    }
    if ((action == "install" || action == "install-once") && argc >= 3) {
        std::string reason;
        const KModErr result = action == "install"
            ? skroot_env::install_module(root_key.c_str(), argv[2], reason)
            : skroot_env::install_module_dev_run_once(root_key.c_str(), argv[2], reason);
        if (!reason.empty()) std::cout << "reason=" << reason << '\n';
        return finish(root_key, result);
    }
    if (action == "uninstall" && argc >= 3) {
        const KModErr result = skroot_env::uninstall_module(root_key.c_str(), argv[2]);
        return finish(root_key, result);
    }
    if (action == "list") {
        std::vector<skroot_env::module_record> modules;
        const KModErr result = skroot_env::get_all_modules_list(root_key.c_str(), modules);
        if (is_ok(result)) {
            for (const auto& module : modules) {
                std::cout << module.desc.id32 << '\t' << module.desc.version << '\t'
                          << static_cast<uint32_t>(module.state) << '\t'
                          << (module.desc.web_ui ? "webui" : "-") << '\n';
            }
        }
        return finish(root_key, result);
    }
    if (action == "webui") {
        int port = 0;
        const KModErr result =
            skroot_env::features::web_ui::start_module_web_ui_server_async(
                root_key.c_str(), kModuleId, port);
        std::cout << "port=" << port << '\n';
        std::fill(root_key.begin(), root_key.end(), '\0');
        if (is_failed(result)) {
            std::cout << "result=" << to_string(result) << '\n';
            return 1;
        }
        const unsigned long hold_seconds = argc >= 3 ? std::strtoul(argv[2], nullptr, 10) : 600;
        sleep(std::min(hold_seconds, 600UL));
        return 0;
    }
    if (action == "rootcmd" && argc >= 3) {
        std::string command;
        for (int index = 2; index < argc; ++index) {
            if (!command.empty()) command.push_back(' ');
            command += argv[index];
        }
        std::string output;
        const KModErr result = skroot_env::run_root_cmd(root_key.c_str(), command.c_str(), output);
        std::cout << output;
        if (!output.empty() && output.back() != '\n') std::cout << '\n';
        return finish(root_key, result);
    }
    if (action == "provider") {
        const KModErr result = skroot_env::get_root(root_key.c_str());
        std::fill(root_key.begin(), root_key.end(), '\0');
        std::cerr << "before-drop uid=" << getuid() << " gid=" << getgid()
                  << " result=" << to_string(result) << '\n';
        if (is_failed(result)) return 1;
        if (setgid(2000) != 0 || setuid(2000) != 0) {
            perror("drop-to-shell");
            return 1;
        }
        std::cerr << "after-drop uid=" << getuid() << " gid=" << getgid() << '\n';
        execl("/system/bin/content", "content", "call", "--uri",
              "content://com.oplus.omes.oaid_status_provider", "--method", "OUID",
              static_cast<char*>(nullptr));
        perror("exec-content");
        return 1;
    }

    std::fill(root_key.begin(), root_key.end(), '\0');
    std::cerr << "invalid action\n";
    return 2;
}
