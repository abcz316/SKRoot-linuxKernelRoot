@echo off
setlocal
pushd "%~dp0"
call "C:\Users\Administrator\AppData\Local\Android\Sdk\ndk\26.3.11579264\ndk-build.cmd" NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk %*
set "BUILD_STATUS=%ERRORLEVEL%"
popd
exit /b %BUILD_STATUS%
