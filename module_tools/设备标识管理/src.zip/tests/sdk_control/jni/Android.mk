LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := kernel_module_kit_static_prebuilt
LOCAL_SRC_FILES := ../../../.sdk-cache/kernel_module_kit/lib/libkernel_module_kit_static.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := jiebiao_sdk_control
LOCAL_SRC_FILES := ../sdk_control_main.cpp
KERNEL_MODULE_KIT := $(LOCAL_PATH)/../../../.sdk-cache/kernel_module_kit
LOCAL_C_INCLUDES += $(KERNEL_MODULE_KIT)/include
LOCAL_STATIC_LIBRARIES := kernel_module_kit_static_prebuilt
LOCAL_CPPFLAGS += -std=c++20 -fPIC -fvisibility=hidden -fno-stack-protector
LOCAL_LDLIBS += -lz
include $(BUILD_EXECUTABLE)
