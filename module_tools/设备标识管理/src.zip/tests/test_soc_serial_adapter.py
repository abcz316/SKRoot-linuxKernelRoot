from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
ADAPTER = (ROOT / "soc_serial_adapter.cpp").read_text(encoding="utf-8")
HEADER = (ROOT / "soc_serial_adapter.h").read_text(encoding="utf-8")
IDENTITY = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
DAEMON = (ROOT / "daemon.cpp").read_text(encoding="utf-8")
ANDROID_MK = (ROOT / "jni/Android.mk").read_text(encoding="utf-8")


class SocSerialAdapterTest(unittest.TestCase):
    def test_probe_order_and_device_tree_fallback(self):
        self.assertIn('"/sys/devices"', ADAPTER)
        self.assertIn('"/sys/bus/soc/devices"', ADAPTER)
        self.assertIn('recursive_directory_iterator', ADAPTER)
        self.assertIn('"/sys/class/soc"', ADAPTER)
        self.assertIn('current_name == "system"', ADAPTER)
        self.assertIn('name.find("apmixed")', ADAPTER)
        self.assertIn('name.find("deviceid")', ADAPTER)
        self.assertIn('/sys/firmware/devicetree/base/serial-number', ADAPTER)
        self.assertIn('/proc/device-tree/serial-number', ADAPTER)
        self.assertIn('/sys/firmware/devicetree/base/chosen/serial-number', ADAPTER)
        self.assertIn('/proc/device-tree/chosen/serial-number', ADAPTER)
        self.assertLess(ADAPTER.index('"/sys/devices"'), ADAPTER.index('"/sys/bus/soc/devices"'))
        self.assertLess(ADAPTER.index('"/sys/bus/soc/devices"'),
                        ADAPTER.index('/sys/firmware/devicetree/base/serial-number'))

    def test_device_tree_is_read_only_and_nul_normalised(self):
        self.assertIn('result.hookable = !is_device_tree_path(path)', ADAPTER)
        self.assertIn("value.erase(std::remove(value.begin(), value.end(), '\\0')", ADAPTER)
        self.assertIn('no-readable-serial-number-surface', ADAPTER)

    def test_device_tree_cache_does_not_hide_late_sysfs_surface(self):
        self.assertIn('bool have_cached_result = false', ADAPTER)
        self.assertIn('if (cached_result.hookable) return cached_result', ADAPTER)
        self.assertIn('if (have_cached_result) return cached_result', ADAPTER)

    def test_cache_and_recursive_scan_reject_peripheral_serial_nodes(self):
        self.assertIn('is_valid_soc_sysfs_path', ADAPTER)
        self.assertIn('is_peripheral_component', ADAPTER)
        for marker in ('"ufs"', '"ufshc"', '"mhi"', '"pcie"', '"pci"', '"usb"'):
            with self.subTest(marker=marker):
                self.assertIn(marker, ADAPTER)
        self.assertIn('rejected-non-soc-surface', ADAPTER)
        self.assertIn('storage_write_string(kCachedPath, "")', ADAPTER)
        self.assertIn('std::stable_sort(paths.begin(), paths.end()', ADAPTER)

    def test_ufs_serial_remains_an_explicit_secondary_surface(self):
        self.assertIn('probe_ufs_serial()', HEADER)
        self.assertIn('kUfsSerialPath', ADAPTER)
        self.assertIn('discover_ufs_serial_paths', ADAPTER)
        self.assertIn('"ufs-sysfs"', ADAPTER)
        self.assertIn('kUfsCachedPath', ADAPTER)
        self.assertIn('storage_write_string(kUfsCachedPath, cached)', ADAPTER)
        self.assertIn('lowered.find("ufs")', IDENTITY)
        self.assertIn('lowered.find("ufshc")', IDENTITY)

    def test_identity_uses_adapter_instead_of_soc0_hardcode(self):
        self.assertIn('#include "soc_serial_adapter.h"', IDENTITY)
        self.assertIn('soc_serial::probe()', IDENTITY)
        self.assertIn('verify_soc_serial_surface', IDENTITY)
        self.assertNotIn('/sys/devices/soc0/serial_number', IDENTITY)
        self.assertIn('soc_serial_adapter.cpp', ANDROID_MK)

    def test_serial_generation_preserves_observed_length(self):
        start = IDENTITY.index('std::string generate_serial()')
        end = IDENTITY.index('std::string random_like', start)
        block = IDENTITY[start:end]
        self.assertIn('first_property_value(kSerialProperties', block)
        self.assertIn('return random_like(current)', block)

    def test_mtk_symbol_filter_and_deduplication(self):
        self.assertIn('kallsyms_lookup_name_array("serial_number_show"', IDENTITY)
        self.assertIn('SymbolMatchMode::Suffix', IDENTITY)
        self.assertIn('lowered.find("mtk")', IDENTITY)
        self.assertIn('lowered.find("mediatek")', IDENTITY)
        self.assertIn('std::unordered_set<uint64_t> patched', IDENTITY)
        self.assertIn('lowered != "serial_number_show"', IDENTITY)

    def test_mtk_numeric_serial_rotation_preserves_u32_shape(self):
        self.assertIn('std::string random_numeric_like', IDENTITY)
        self.assertIn('const bool ten_digit_u32 = original.size() == 10', IDENTITY)
        self.assertIn('"123"', IDENTITY)
        self.assertIn('return numeric ? random_numeric_like(current) : random_like(current)', IDENTITY)

    def test_missing_soc_surface_does_not_create_unapplied_target(self):
        # 重构后统一走 randomize_soc_serial：空输入必须返回空串，
        # 等价于旧的 current_soc_serial.empty() ? std::string()，
        # 保证探测不到 SoC surface 时不会制造一个无法应用的目标值。
        self.assertIn('std::string randomize_soc_serial(const std::string& current)', IDENTITY)
        self.assertIn('if (current.empty()) return {};', IDENTITY)
        self.assertIn('randomize_soc_serial(current_soc_serial)', IDENTITY)

    def test_empty_legacy_soc_target_is_backfilled_after_adapter_probe(self):
        self.assertIn('else if (values.soc_serial.empty())', IDENTITY)
        self.assertIn('const std::string current_soc_serial = read_soc_serial()', IDENTITY)
        self.assertIn('save_identity_values(values)', IDENTITY)

    def test_late_boot_retries_soc_hook_after_early_sysfs_probe(self):
        self.assertIn('const auto late_result = apply_identity_properties(private_dir, values, true)', DAEMON)
        self.assertIn('soc_readback.state == "passed"', IDENTITY)

    def test_mtk_socinfo_cells_are_not_used_as_serial(self):
        self.assertNotIn("socinfo-data1", ADAPTER + IDENTITY)
        self.assertNotIn("socinfo-data2", ADAPTER + IDENTITY)

    def test_fixture_selection_prefers_soc_sysfs(self):
        fixture = {
            "/sys/devices/soc0/serial_number": "SOC0",
            "/sys/devices/soc1/serial_number": "SOC1",
            "/sys/bus/soc/devices/soc0/serial_number": "BUS",
        }
        selected = sorted(path for path in fixture if path.startswith("/sys/devices/soc"))[0]
        self.assertEqual(selected, "/sys/devices/soc0/serial_number")
        self.assertNotEqual(fixture[selected], "0x10000001")


if __name__ == "__main__":
    unittest.main()
