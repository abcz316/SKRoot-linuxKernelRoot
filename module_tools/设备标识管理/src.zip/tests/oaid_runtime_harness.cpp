#include "oaid_engine.h"
#include "common.h"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <sstream>
#include <unistd.h>

std::string scenario;
bool dispatched = false;
unsigned queries = 0;
unsigned xml_writes = 0;
const std::string before(64, 'A');
const std::string after(64, 'B');
extern "C" int usleep(useconds_t) { return 0; }

namespace jiebiao {
std::string random_hex(size_t size, bool) { return std::string(size, 'B'); }
std::vector<std::string> split_lines(const std::string& text) {
    std::istringstream input(text);
    std::vector<std::string> lines;
    std::string line;
    while (std::getline(input, line)) lines.push_back(line);
    return lines;
}
std::string actual_value() {
    ++queries;
    return dispatched && (scenario == "matching" || (scenario == "delayed" && queries >= 4))
        ? after : before;
}
int run_process_as(uid_t uid, gid_t gid, const std::vector<std::string>& args,
                    std::string* output, size_t) {
    assert(uid == 2000 && gid == 2000);
    assert(std::find(args.begin(), args.end(), "--user") != args.end());
    if (scenario == "unavailable") return 1;
    *output = "Result: Bundle[{OUID=" + actual_value() + "}]\n";
    return 0;
}
int run_process(const std::vector<std::string>& args, std::string* output, size_t) {
    if (args.front() == "/system/bin/restorecon") return 0;
    assert(args.front() == "/system/bin/env");
    assert(args[3] == "/system/bin" && args[4] == "OplusOaidRuntime");
    if (args.back() == "probe") {
        *output = "OAID_RUNTIME=ready\n";
        return 0;
    }
    assert(args.back() == "rotate" && !dispatched);
    dispatched = true;
    if (scenario == "helper-failed") return 2;
    *output = scenario == "malformed" ? "OUID=short\n" :
              "OUID=" + (scenario == "unchanged" ? before : after) + "\n";
    return 0;
}
// These three I/O stubs exercise the original alpha3 writer unchanged in the
// baseline/rollback comparison. New runtime rotation never calls them.
bool read_file(const std::string&, std::string& xml, size_t) {
    xml = "<openid_config version=\"1\"><ouid name=\"0\" value=\"" + before + "\"/></openid_config>";
    return true;
}
bool write_file_atomic(const std::string&, const std::string&, uint32_t, bool) {
    ++xml_writes;
    dispatched = true;
    return true;
}
bool read_current_oplus_oaid(std::string& value, std::string&) {
    value = actual_value();
    return scenario != "unavailable";
}
#ifdef LEGACY_WRITER
#include "legacy.inc"
#endif
}

int main(int argc, char** argv) {
    if (argc != 3) return 2;
    scenario = argv[2];
    std::string target, detail;
#ifdef LEGACY_WRITER
    const bool ok = jiebiao::write_oplus_oaid_payload("0=" + after, detail);
#else
    const bool ok = jiebiao::rotate_oplus_oaid_runtime(argv[1], target, detail);
#endif
    const bool provider_matches = jiebiao::actual_value() == after;
    std::cout << "accepted=" << ok << ",provider_matches=" << provider_matches
              << ",xml_writes=" << xml_writes << ",detail=" << detail << '\n';
}
