from pathlib import Path
import unittest
from test_rotation_stability import compile_run, function

ROOT = Path(__file__).resolve().parents[1]


def policy_probe(candidate=ROOT):
    source=(candidate/'drmid_worker.cpp').read_text()
    body=function(source,'bool set_enabled(', 'bool build_randomized_runtime(')
    return compile_run(r'''
      #include <cstdint>
      #include <string>
      #include <iostream>
      namespace drmid { enum class ReplacementMode {kDryRun,kWriteTest}; }
      const char* kEnabledName="enabled";
      bool alive=true,connected=true;
      std::string events;
      struct Status {bool control_connected;};
      Status read_status(const std::string&) {return {connected};}
      bool write_u32(const std::string&,const char*,uint32_t) {return true;}
      bool worker_alive(const std::string&) {return alive;}
      bool stop_worker(const std::string&, std::string& d) {events+="stop;";alive=false;d="stopped";return true;}
      bool start_worker(const std::string&,bool,std::string& d,const std::string&) {events+="start;";alive=true;d="spawned";return true;}
      bool set_runtime_mode(const std::string&,drmid::ReplacementMode mode,bool publish,void*,std::string& d) {
        events+=mode==drmid::ReplacementMode::kWriteTest?"write":"dry";
        events+=publish?"-publish;":"-persist;";d="mode";return true;
      }
    '''+body+r'''
      int main() {
        std::string detail;
        bool ok=set_enabled("private",false,detail,"fixture");
        std::cout<<"disabled_ok="<<ok<<",worker="<<alive<<",events="<<events<<'\n';
        events.clear();alive=false;connected=false;
        ok=set_enabled("private",true,detail,"fixture");
        std::cout<<"enabled_ok="<<ok<<",worker="<<alive<<",events="<<events<<'\n';
        events.clear();alive=true;connected=false;
        ok=set_enabled("private",true,detail,"fixture");
        std::cout<<"starting_ok="<<ok<<",events="<<events<<'\n';
      }
    ''')


class Alpha6BehaviorTest(unittest.TestCase):
    def test_disabled_worker_is_stopped_and_cold_enable_persists_before_start(self):
        output=policy_probe()
        self.assertIn('disabled_ok=1,worker=0,events=stop;dry-persist;',output)
        self.assertIn('enabled_ok=1,worker=1,events=write-persist;start;',output)
        self.assertIn('starting_ok=1,events=write-persist;',output)

    def test_restart_delay_has_bounded_growth(self):
        source=(ROOT/'daemon.cpp').read_text()
        constants=function(source,'constexpr uint32_t kWorkerRestartBurstLimit','class ActionLock')
        output=compile_run('#include <algorithm>\n#include <cstdint>\n#include <iostream>\n'+constants+'''
          int main() {for(unsigned n: {1U,2U,3U,30U,UINT32_MAX}) std::cout<<worker_restart_delay_ms(n)<<' ';}
        ''')
        self.assertEqual(output.strip(),'10000 20000 40000 300000 300000')

    def test_hook_wait_reloads_runtime_and_exposes_nonblocking_ui_state(self):
        backend=(ROOT/'drmid_backend.cpp').read_text()
        start=backend.index('if (daemon_mode && hal_identities.count == 0)')
        end=backend.index('err = drmid::install_readonly_parser_hook(',start)
        body=backend[start:end]
        self.assertIn('mark_waiting_hal(module_private_dir, true)',body)
        self.assertLess(body.index('wait_for_daemon_widevine_hal'),body.index('read_runtime_control_file'))
        ipc=(ROOT/'control_ipc.cpp').read_text()
        self.assertIn('if (!hook_has_hal)',ipc)
        self.assertIn('pending.config_generation >',ipc)

    def test_hot_path_filter_precedes_copy(self):
        hook=(ROOT/'binder_hook_builder.cpp').read_text()
        start=hook.index('a->bind(is_transaction);')
        dispatch=hook.index('a->bind(record_transaction);',start)
        copy=hook.index('a->add(x13, x23, kTransactionScratchOffset);',start)
        self.assertLess(dispatch,copy)
        for command in ('BC_REPLY','BC_REPLY_SG','BR_TRANSACTION','BR_TRANSACTION_SEC_CTX'):
            self.assertIn(command,hook[start:dispatch])
        request=hook.index('a->bind(request);')
        self.assertLess(hook.index('kGetPropertyByteArrayTransactionCode',request),
                        hook.index('a->ldr(x17, ptr(x23, kTransactionScratchOffset + 32))',request))

    def test_previous_fixes_remain(self):
        identity=(ROOT/'identity_engine.cpp').read_text()
        worker=(ROOT/'drmid_worker.cpp').read_text()
        daemon=(ROOT/'daemon.cpp').read_text()
        self.assertIn('rotate_oplus_oaid_runtime',identity)
        self.assertIn('restored.config_generation = newest + 1',worker)
        self.assertIn('SupervisorLease lease(private_dir)',daemon)
        self.assertIn('active-config-mismatch',worker)


if __name__=='__main__':
    import sys
    if len(sys.argv)==3 and sys.argv[1]=='--probe':print(policy_probe(Path(sys.argv[2])),end='')
    else:unittest.main()
