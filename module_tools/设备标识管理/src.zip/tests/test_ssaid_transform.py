from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]


class SsaidTransformTest(unittest.TestCase):
    def test_host_transform_harness(self):
        compiler = shutil.which("g++") or shutil.which("clang++")
        if compiler is None:
            self.skipTest("host C++ compiler is unavailable")
        with tempfile.TemporaryDirectory() as directory:
            binary = Path(directory) / "ssaid_transform"
            command = [
                compiler,
                "-std=c++20",
                "-O2",
                "-ffunction-sections",
                "-fdata-sections",
                "-I",
                str(ROOT),
                str(ROOT / "tests" / "ssaid_transform_harness.cpp"),
                str(ROOT / "ssaid_engine.cpp"),
                "-Wl,--gc-sections",
                "-o",
                str(binary),
            ]
            subprocess.run(command, check=True, capture_output=True, text=True)
            result = subprocess.run([str(binary)], check=True, capture_output=True, text=True)
            self.assertIn("ssaid-transform: ok", result.stdout)


if __name__ == "__main__":
    unittest.main()
