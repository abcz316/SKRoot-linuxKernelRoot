from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def probe(candidate, scenario):
    compiler = shutil.which("g++") or shutil.which("clang++")
    if not compiler:
        raise unittest.SkipTest("C++ compiler required")
    with tempfile.TemporaryDirectory() as directory:
        build = Path(directory)
        (build / "resources").mkdir()
        (build / "resources/oaid-runtime.jar").touch()
        flags = []
        source = (candidate / "identity_engine.cpp").read_text(encoding="utf-8")
        if "bool write_oplus_oaid_payload(" in source:
            start = source.index("bool write_oplus_oaid_payload(")
            end = source.index("bool write_system_oaid(", start)
            (build / "legacy.inc").write_text(source[start:end], encoding="utf-8")
            flags.append("-DLEGACY_WRITER")
        binary = build / "runtime"
        subprocess.run([compiler, "-std=c++20", "-O2", "-ffunction-sections", "-fdata-sections",
                        *flags, "-I", str(candidate), "-I", directory,
                        str(ROOT / "tests/oaid_runtime_harness.cpp"), str(candidate / "oaid_engine.cpp"),
                        "-Wl,--gc-sections", "-o", str(binary)], check=True, capture_output=True, text=True)
        return subprocess.run([str(binary), directory, scenario], check=True,
                              capture_output=True, text=True).stdout.strip()


class OaidRuntimeTest(unittest.TestCase):
    def test_cached_provider_is_not_success(self):
        self.assertIn("accepted=0,provider_matches=0,xml_writes=0", probe(ROOT, "cached"))

    def test_matching_provider_is_success(self):
        self.assertIn("accepted=1,provider_matches=1,xml_writes=0", probe(ROOT, "matching"))

    def test_delayed_provider_is_verified_without_second_reset(self):
        self.assertIn("accepted=1,provider_matches=1", probe(ROOT, "delayed"))

    def test_helper_errors_invalid_id_and_unavailable_provider_fail(self):
        for scenario in ("helper-failed", "malformed", "unchanged", "unavailable"):
            with self.subTest(scenario=scenario):
                self.assertIn("accepted=0", probe(ROOT, scenario))

    def test_live_rotation_does_not_write_oplus_xml(self):
        source = (ROOT / "identity_engine.cpp").read_text(encoding="utf-8")
        self.assertNotIn("write_oplus_oaid_payload", source)
        # 旧实现固定写 18 位 hex，在小米（16 位载荷）上必校验失败；
        # 现改为跟随原值长度/字符集生成，避免破坏厂商 OAID 格式。
        self.assertIn('system_value = random_oaid_payload_like(payload, payload.size())', source)
        self.assertIn('runtime_state == "failed"', source)
        self.assertIn('oaid_display = oaid_current', source)


if __name__ == "__main__":
    import sys
    if len(sys.argv) == 4 and sys.argv[1] == "--probe":
        print(probe(Path(sys.argv[2]), sys.argv[3]))
    else:
        unittest.main()
