from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / "webroot" / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "webroot" / "app.js").read_text(encoding="utf-8")
CSS = (ROOT / "webroot" / "style.css").read_text(encoding="utf-8")


class WebUiRedesignTest(unittest.TestCase):
    def test_mobile_status_first_structure_and_master_switch(self):
        for marker in (
            'class="overview-grid"', 'id="metricMark"', 'id="metricDaemon"',
            'id="metricDrm"', 'id="metricAction"', 'id="markEnabled"',
            "DRM Binder 后端按需运行", "当前标识", "实际读取验证",
        ):
            self.assertIn(marker, HTML)
        self.assertLess(HTML.index('id="metricMark"'), HTML.index('id="identityGrid"'))
        self.assertNotIn("保存并应用", HTML)

    def test_overview_cards_show_verification_count_and_drm_write_state(self):
        self.assertIn("<span>标识统计</span>", HTML)
        self.assertIn("验证通过的标识项", HTML)
        self.assertIn("<span>DRM状态</span>", HTML)
        self.assertIn("当前替换写入状态", HTML)
        self.assertIn("function verificationCount", JS)
        self.assertIn('`${keys.filter((key) => verification[key]?.state === "passed").length}/${keys.length}`', JS)
        self.assertIn('if (drm.connected && Number(drm.mode) === 1)', JS)
        self.assertIn('return "已写入"', JS)
        self.assertIn('return "未写入"', JS)
        self.assertNotIn("最近任务", HTML)

    def test_each_identity_shows_values_state_verification_and_copy(self):
        for key in ("serial", "soc_serial", "androidid", "oaid", "drmid"):
            with self.subTest(identity=key):
                for marker in (
                    f'data-identity-original="{key}"',
                    f'data-identity-current="{key}"',
                    f'data-identity-state="{key}"',
                    f'data-verification-inline="{key}"',
                    f'data-verification-state="{key}"',
                ):
                    self.assertIn(marker, HTML)
        self.assertGreaterEqual(HTML.count('class="copy-button"'), 10)
        self.assertIn("navigator.clipboard?.writeText", JS)
        self.assertIn("已复制到剪贴板", JS)

    def test_verification_is_inline_and_old_standalone_section_is_removed(self):
        self.assertIn("每项右侧同时显示实际读取验证结果", HTML)
        self.assertIn('data-verification-inline="drmid"', HTML)
        self.assertNotIn('aria-labelledby="verificationHeading"', HTML)
        self.assertNotIn('<h2 id="verificationHeading">实际读取验证</h2>', HTML)
        self.assertNotIn('class="card verification-card"', HTML)

    def test_low_frequency_surfaces_are_inside_bottom_drawer(self):
        drawer_start = HTML.index('id="advancedDrawer"')
        drawer_end = HTML.index('id="toast"')
        drawer = HTML[drawer_start:drawer_end]
        for marker in (
            'data-drawer-panel="device"', 'data-drawer-panel="drm"',
            'data-drawer-panel="coverage"', 'data-drawer-panel="logs"',
            'id="deviceFingerprint"', 'id="drmDiagnosticGrid"',
            'id="surfaceGrid"', 'id="logOutput"', 'id="refreshLog"',
        ):
            self.assertIn(marker, drawer)
        self.assertIn('role="dialog"', drawer)
        self.assertIn('aria-modal="true"', drawer)

    def test_drawer_interactions_and_abnormal_drm_expansion(self):
        for marker in (
            "openDrawer", "requestCloseDrawer", "selectDrawerTab",
            'history.pushState', 'window.addEventListener("popstate"',
            'event.key === "Escape"', '$("#drawerBackdrop").addEventListener',
            '$("#closeAdvancedDrawer").addEventListener',
            '$("#drmDiagnosticDetails").open = drmIssue', "drmHasIssue",
        ):
            self.assertIn(marker, JS)
        self.assertIn(".bottom-drawer", CSS)
        self.assertIn("env(safe-area-inset-bottom)", CSS)

    def test_local_shadcn_inspired_theme_and_dark_system_variant(self):
        self.assertIn("--surface: #ffffff", CSS)
        self.assertIn("--primary: #2563eb", CSS)
        self.assertIn("@media (prefers-color-scheme: dark)", CSS)
        self.assertIn("border: 1px solid var(--line)", CSS)
        self.assertIn("box-shadow: var(--shadow-sm)", CSS)
        self.assertNotRegex(HTML, r'https?://')
        self.assertNotIn("@import", CSS)

    def test_existing_api_and_session_contract_remain_frontend_compatible(self):
        for route in (
            "/api/session", "/api/session/ping", "/api/session/close",
            "/api/status", "/api/config", "/api/randomize",
            "/api/reset-ssaid", "/api/local-reset", "/api/drm-stop",
            "/api/action-result", "/api/log",
        ):
            self.assertIn(route, JS)
        for marker in (
            "visibilitychange", "freeze",
            "pagehide", "beforeunload", "sendBeacon", "PREVIEW_MODE",
            'id="screenGate"', "后台已退出", "请重新从管理器打开",
        ):
            self.assertIn(marker, JS + HTML)


if __name__ == "__main__":
    unittest.main()
