from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def function(source, start, end):
    return source[source.index(start):source.index(end, source.index(start))]


def compile_run(source):
    compiler = shutil.which('g++') or shutil.which('clang++')
    if not compiler:
        raise unittest.SkipTest('C++ compiler unavailable')
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        cpp = root / 'test.cpp'
        cpp.write_text(source)
        subprocess.run([compiler, '-std=c++20', '-I', str(ROOT), str(cpp), '-o', str(root/'test')],
                       check=True, capture_output=True, text=True)
        return subprocess.run([str(root/'test'), directory], check=True, capture_output=True, text=True).stdout


def drm_probe(candidate=ROOT):
    worker = (candidate/'drmid_worker.cpp').read_text()
    publish = function(worker, 'bool publish_runtime(', 'bool set_runtime_mode(')
    restore = function(worker, 'bool restore_runtime(', 'std::string serialize_runtime(')
    return compile_run(r'''
      #include <algorithm>
      #include <array>
      #include <cassert>
      #include <cstdint>
      #include <iostream>
      #include <limits>
      #include <string>
      enum class KModErr { OK=0, ERR_MODULE_PARAM=-20000, ERR_MODULE_SOCKET=-20001 };
      bool is_failed(KModErr e) {return e!=KModErr::OK;}
      std::string to_string(KModErr e) {return std::to_string(int(e));}
      namespace drmid {
        enum class ReplacementMode {kDryRun=0,kWriteTest=1};
        struct ReplacementConfig {uint64_t config_generation=0,seed_generation=1,profile_fingerprint=0;
          ReplacementMode mode=ReplacementMode::kWriteTest; uint32_t virtual_id_length=32; std::array<uint8_t,32> virtual_id{};};
        struct ControlIpcResponse {int result=0; uint64_t config_generation=0,seed_generation=1,profile_fingerprint=0;
          uint32_t replacement_mode=1,virtual_id_length=32;};
        enum class ControlIpcOperation {kApply,kStatus};
        std::string default_control_socket_path(const char*) {return "socket";}
      }
      drmid::ReplacementConfig disk,active;
      bool lose_response=false, status_error=false;
      unsigned writes=0;
      namespace drmid {
        KModErr send_control_ipc_request(const char*,ControlIpcOperation op,ControlIpcResponse& out) {
          if (status_error && op==ControlIpcOperation::kStatus) return KModErr::ERR_MODULE_SOCKET;
          out={};
          if(op==ControlIpcOperation::kApply) {
            if(disk.config_generation<active.config_generation) out.result=-20000;
            else if(disk.config_generation>active.config_generation) active=disk;
          }
          out.config_generation=active.config_generation; out.profile_fingerprint=active.profile_fingerprint;
          out.seed_generation=active.seed_generation; out.replacement_mode=uint32_t(active.mode);
          out.virtual_id_length=active.virtual_id_length;
          if(lose_response && op==ControlIpcOperation::kApply) return KModErr::ERR_MODULE_SOCKET;
          return KModErr::OK;
        }
      }
      bool worker_alive(const std::string&) {return true;}
      bool read_runtime(const std::string&,drmid::ReplacementConfig& value,std::string&) {value=disk; return true;}
      bool write_runtime(const std::string&,const drmid::ReplacementConfig& value,std::string&) {disk=value; ++writes; return true;}
    ''' + publish + restore + r'''
      int main() {
        drmid::ReplacementConfig previous; previous.config_generation=10; previous.profile_fingerprint=111;
        disk=active=previous; disk.config_generation=active.config_generation=11; disk.profile_fingerprint=active.profile_fingerprint=222;
        std::string detail;
        bool restored=restore_runtime("dir",previous,detail);
        std::cout<<"rollback_ok="<<restored<<",disk_generation="<<disk.config_generation<<",active_generation="<<active.config_generation
          <<",disk_fp="<<disk.profile_fingerprint<<",active_fp="<<active.profile_fingerprint<<'\n';
        disk.config_generation=active.config_generation; disk.profile_fingerprint=999;
        std::cout<<"same_generation_collision_accepted="<<publish_runtime("dir",disk,nullptr,detail)<<'\n';
        disk=active; ++disk.config_generation; lose_response=true;
        std::cout<<"lost_ack_reconciled="<<publish_runtime("dir",disk,nullptr,detail)<<'\n';
        lose_response=false; disk=active; active.config_generation=UINT64_MAX;
        const unsigned count=writes;
        std::cout<<"overflow_rejected="<<!restore_runtime("dir",previous,detail)<<",no_write="<<(count==writes)<<'\n';
      }
    ''')


def usb_probe(candidate=ROOT):
    source = (candidate/'usb_serial_engine.cpp').read_text()
    body = function(source, 'bool rebind_udc(', 'bool rebind_active_gadgets(')
    return compile_run(r'''
      #include <string>
      #include <iostream>
      struct BoundUdc {std::string path,controller;};
      std::string current;
      bool takeover=false; int writes=0;
      int usleep(unsigned) {return 0;}
      std::string trim(std::string s) {return s;}
      bool read_stream_file(const std::string&,std::string& out,size_t) {out=current; return true;}
      bool write_configfs_control(const std::string&,const std::string& value) {
        ++writes;
        if(value=="\n") {current=takeover?"other-controller":"controller";return true;}
        return false;
      }
    ''' + body + r'''
      int main() {
        BoundUdc udc{"UDC","controller"};
        bool ok=rebind_udc(udc);
        std::cout<<"system_rebound_accepted="<<ok<<",writes="<<writes<<'\n';
        writes=0;takeover=true;ok=rebind_udc(udc);
        std::cout<<"other_controller_rejected="<<!ok<<",writes="<<writes<<'\n';
      }
    ''')


class RotationStabilityTest(unittest.TestCase):
    def test_real_drm_restore_monotonic_and_reconciled(self):
        output = drm_probe()
        self.assertIn('rollback_ok=1,disk_generation=12,active_generation=12,disk_fp=111,active_fp=111',output)
        self.assertIn('same_generation_collision_accepted=0',output)
        self.assertIn('lost_ack_reconciled=1',output)
        self.assertIn('overflow_rejected=1,no_write=1',output)

    def test_udc_already_rebound_and_changed_owner(self):
        output = usb_probe()
        self.assertIn('system_rebound_accepted=1,writes=1',output)
        self.assertIn('other_controller_rejected=1,writes=1',output)

    def test_supervisor_lease_excludes_children_and_releases_after_exit(self):
        output = compile_run(r'''
          #include "supervisor_lease.h"
          #include <cassert>
          #include <sys/wait.h>
          #include <iostream>
          int main(int argc,char** argv) {
            jiebiao::SupervisorLease first(argv[1]); assert(first.acquire());
            pid_t child=fork();
            if(child==0) {jiebiao::SupervisorLease second(argv[1]); _exit(!second.acquire() && second.owner()==getppid()?0:1);}
            int status; waitpid(child,&status,0); assert(WIFEXITED(status)&&WEXITSTATUS(status)==0);
            std::cout<<"supervisor-single-owner: ok\n";
          }
        ''')
        self.assertIn('supervisor-single-owner: ok', output)

    def test_rollback_reports_real_outcome_and_uses_previous_values(self):
        source=(ROOT/'usb_serial_engine.cpp').read_text()
        apply=function(source,'UsbGadgetSerialResult apply_usb_gadget_serial(', 'UsbGadgetSerialResult restore_usb_gadget_serial(')
        self.assertIn('OriginalMap previous;',apply)
        self.assertIn('partial-rollback-failed',apply)
        self.assertIn('restored = write_usb_serial(path, value) && restored',apply)
        daemon=(ROOT/'daemon.cpp').read_text()
        self.assertIn('drm-restore=',daemon)
        self.assertIn('SupervisorLease lease(private_dir)',daemon)


if __name__ == '__main__':
    import sys
    if len(sys.argv)==3 and sys.argv[1]=='--probe':
        print(drm_probe(Path(sys.argv[2]))+usb_probe(Path(sys.argv[2])),end='')
    else:
        unittest.main()
