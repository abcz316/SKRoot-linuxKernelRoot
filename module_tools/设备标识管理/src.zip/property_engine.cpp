#include "property_engine.h"

#include "common.h"
#include "state_store.h"

#include <unistd.h>

#include <map>
#include <sstream>
#include <vector>

namespace jiebiao {
namespace {

constexpr const char* kTemplateOriginals = "template_original_props";
constexpr const char* kPatchOriginals = "patch_original_props";

struct OriginalValue {
    bool existed = false;
    std::string value;
};

using OriginalMap = std::map<std::string, OriginalValue>;

std::string private_path(const std::string& private_dir, std::string_view relative) {
    std::string path = private_dir;
    if (!path.empty() && path.back() != '/') path.push_back('/');
    path.append(relative);
    return path;
}

std::string serialize_originals(const OriginalMap& values) {
    std::string output;
    for (const auto& [key, original] : values) {
        output += key;
        output.push_back('\t');
        output += original.existed ? "1" : "0";
        output.push_back('\t');
        output += original.value;
        output.push_back('\n');
    }
    return output;
}

OriginalMap parse_originals(const std::string& text) {
    OriginalMap values;
    std::istringstream input(text);
    std::string line;
    while (std::getline(input, line)) {
        const size_t first = line.find('\t');
        const size_t second = first == std::string::npos ? first : line.find('\t', first + 1);
        if (first == std::string::npos || second == std::string::npos) continue;
        const std::string key = line.substr(0, first);
        if (!safe_property_key(key)) continue;
        values[key] = OriginalValue{line.substr(first + 1, second - first - 1) == "1",
                                    line.substr(second + 1)};
    }
    return values;
}

OriginalMap load_originals(const char* storage_key) {
    std::string text;
    storage_read_string(storage_key, text);
    return parse_originals(text);
}

bool save_originals(const char* storage_key, const OriginalMap& values) {
    return storage_write_string(storage_key, serialize_originals(values));
}

void capture_if_missing(OriginalMap& originals, const std::string& key) {
    if (originals.contains(key)) return;
    const std::string value = get_property(key.c_str());
    originals[key] = OriginalValue{!value.empty(), value};
}

PropertyApplyResult apply_pairs(const std::string& private_dir,
                                const std::vector<std::pair<std::string, std::string>>& values,
                                const char* originals_key,
                                size_t pre_skipped = 0) {
    PropertyApplyResult result;
    result.skipped = pre_skipped;
    OriginalMap originals = load_originals(originals_key);
    for (const auto& [key, value] : values) capture_if_missing(originals, key);
    if (!save_originals(originals_key, originals)) {
        result.failed = values.size();
        result.message = "save-originals-failed";
        return result;
    }
    for (const auto& [key, value] : values) {
        if (set_property(private_dir, key, value)) ++result.applied;
        else ++result.failed;
    }
    result.message = result.failed == 0 ? "ok" : "partial";
    return result;
}

PropertyApplyResult restore_pairs(const std::string& private_dir, const char* originals_key) {
    PropertyApplyResult result;
    const OriginalMap originals = load_originals(originals_key);
    const std::string resetprop = resetprop_path(private_dir);
    for (const auto& [key, original] : originals) {
        std::vector<std::string> args{resetprop};
        if (original.existed) {
            args.insert(args.end(), {"-n", key, original.value});
        } else {
            args.insert(args.end(), {"-n", "-d", key});
        }
        if (run_process(args) == 0) ++result.applied;
        else ++result.failed;
    }
    if (result.failed == 0) storage_write_string(originals_key, "");
    result.message = result.failed == 0 ? "ok" : "partial";
    return result;
}

}  // namespace

std::string resetprop_path(const std::string& private_dir) {
    return private_path(private_dir, "resources/resetprop");
}

bool set_property(const std::string& private_dir,
                  const std::string& key,
                  const std::string& value) {
    if (!safe_property_key(key) || value.size() > 512) return false;
    const std::string resetprop = resetprop_path(private_dir);
    return access(resetprop.c_str(), X_OK) == 0 &&
           run_process({resetprop, "-n", key, value}) == 0;
}

PropertyApplyResult restore_legacy_template_properties(const std::string& private_dir) {
    return restore_pairs(private_dir, kTemplateOriginals);
}

PropertyApplyResult restore_retired_security_patch(const std::string& private_dir) {
    return restore_pairs(private_dir, kPatchOriginals);
}

}  // namespace jiebiao
