#include "soc_serial_adapter.h"

#include "common.h"
#include "state_store.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <mutex>
#include <filesystem>
#include <iterator>
#include <string_view>
#include <system_error>
#include <unordered_set>
#include <vector>

namespace jiebiao::soc_serial {
namespace {

constexpr const char* kCachedPath = "soc_serial_adapter_v1";
constexpr const char* kUfsCachedPath = "ufs_serial_adapter_v1";
constexpr const char* kUfsSerialPath =
    "/sys/devices/platform/soc/1d84000.ufshc/string_descriptors/serial_number";
constexpr size_t kMaxScanEntries = 2048;

bool is_soc_directory(const std::filesystem::path& path) {
    const std::string name = path.filename().string();
    if (name == "soc") return true;
    if (name.rfind("soc", 0) != 0 || name.size() == 3) return false;
    return std::all_of(name.begin() + 3, name.end(), [](unsigned char ch) {
        return std::isdigit(ch) != 0;
    });
}

std::string lower_ascii(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char ch) {
        return static_cast<char>(std::tolower(ch));
    });
    return value;
}

bool is_peripheral_component(const std::string& lowered) {
    // A number of vendor kernels expose a `serial_number` attribute below
    // storage/modem/bus devices.  Those values are valid device serials, but
    // they are not the application processor's SoC serial.  In particular,
    // UFS is commonly nested below /sys/devices/platform/soc and used to win
    // the old recursive scan after the cache had been populated once.
    static constexpr const char* kPeripheralMarkers[] = {
        "ufs", "ufshc", "mhi", "pcie", "pci", "usb", "sdhci", "mmc",
        "modem", "baseband", "wlan", "wifi", "bluetooth", "camera",
        "gpu", "display", "audio", "thermal", "battery", "charger",
        "sensor", "i2c", "spi",
    };
    return std::any_of(std::begin(kPeripheralMarkers), std::end(kPeripheralMarkers),
                       [&lowered](const char* marker) {
                           return lowered.find(marker) != std::string::npos;
                       });
}

bool has_peripheral_component(const std::filesystem::path& path) {
    for (const auto& component : path) {
        if (is_peripheral_component(lower_ascii(component.string()))) return true;
    }
    return false;
}

bool has_prefix(const std::string& value, const char* prefix) {
    const std::string_view prefix_view(prefix);
    return value.size() >= prefix_view.size() &&
           std::string_view(value).substr(0, prefix_view.size()) == prefix_view;
}

bool is_direct_soc_sysfs_path(const std::filesystem::path& path) {
    if (path.filename() != "serial_number") return false;
    const std::string parent = path.parent_path().filename().string();
    if (parent != "soc" && !is_soc_directory(path.parent_path())) return false;

    const std::string value = path.string();
    return has_prefix(value, "/sys/devices/soc") ||
           has_prefix(value, "/sys/devices/system/soc/") ||
           has_prefix(value, "/sys/devices/platform/soc/") ||
           has_prefix(value, "/sys/bus/soc/devices/") ||
           has_prefix(value, "/sys/class/soc/");
}

// Only accept serial_number files from an explicitly SoC-labelled sysfs
// surface.  This predicate is deliberately shared by discovery and cache
// validation: a path which was acceptable on an earlier build must not be
// trusted merely because it is still readable after an upgrade.
bool is_valid_soc_sysfs_path(const std::string& value) {
    if (value.empty() || value.back() == '/' ||
        std::filesystem::path(value).filename() != "serial_number") {
        return false;
    }
    if (!has_prefix(value, "/sys/") || has_peripheral_component(value)) return false;
    const std::filesystem::path normalized(value);
    if (normalized.lexically_normal() != normalized) return false;
    std::error_code error;
    const auto real = std::filesystem::canonical(normalized, error);
    if (!error && has_peripheral_component(real)) return false;

    const std::filesystem::path path(value);
    if (is_direct_soc_sysfs_path(path)) return true;

    // Some MediaTek trees put the attribute directly below a SoC platform
    // node rather than naming that node soc0.  Keep this fallback scoped to
    // known SoC roots and reject all peripheral subtrees above.
    const std::string lowered = lower_ascii(value);
    return has_prefix(lowered, "/sys/devices/platform/soc/") ||
           has_prefix(lowered, "/sys/devices/system/soc/") ||
           has_prefix(lowered, "/sys/devices/platform/mediatek/") ||
           has_prefix(lowered, "/sys/devices/platform/mtk/");
}

bool is_ufs_serial_path(const std::string& value) {
    const std::string lowered = lower_ascii(value);
    if (lowered.empty() || lowered.back() == '/' ||
        std::filesystem::path(lowered).filename() != "serial_number" ||
        lowered.find("/sys/devices/") != 0) {
        return false;
    }
    const bool ufs_device = lowered.find("ufs") != std::string::npos ||
                            lowered.find("ufshc") != std::string::npos;
    if (!ufs_device) return false;
    // Keep the UFS adapter on the serial-descriptor attribute rather than
    // accepting an unrelated file named serial_number in another UFS child.
    return lowered.find("/string_descriptors/serial_number") != std::string::npos;
}

std::vector<std::string> discover_ufs_serial_paths() {
    std::vector<std::string> paths;
    std::unordered_set<std::string> seen;
    std::error_code error;

    // 直接 glob：找所有 */string_descriptors/serial_number，不依赖深度递归
    for (const auto& entry : std::filesystem::directory_iterator(
             "/sys/devices/platform/soc", error)) {
        if (error) { error.clear(); continue; }
        const auto candidate = entry.path() / "string_descriptors" / "serial_number";
        if (std::filesystem::is_regular_file(candidate, error)) {
            std::string s = candidate.string();
            if (is_ufs_serial_path(s) && seen.insert(s).second) paths.push_back(s);
        }
        error.clear();
    }

    // 递归扫描作为补充
    size_t visited = 0;
    for (const std::filesystem::path root : {
             std::filesystem::path("/sys/devices/platform/soc"),
             std::filesystem::path("/sys/devices/platform/mediatek"),
             std::filesystem::path("/sys/devices/platform/mtk")}) {
        for (std::filesystem::recursive_directory_iterator it(
                 root, std::filesystem::directory_options::skip_permission_denied, error),
             end;
             it != end && !error && visited++ < kMaxScanEntries; it.increment(error)) {
            const auto current = it->path();
            if (it.depth() >= 8) it.disable_recursion_pending();
            if (current.filename() != "serial_number" ||
                !is_ufs_serial_path(current.string())) {
                error.clear();
                continue;
            }
            if (std::filesystem::is_regular_file(current, error) &&
                seen.insert(current.string()).second) {
                paths.push_back(current.string());
            }
            error.clear();
        }
        error.clear();
    }
    std::sort(paths.begin(), paths.end());
    return paths;
}

int sysfs_path_priority(const std::string& value) {
    if (has_prefix(value, "/sys/devices/soc") && is_direct_soc_sysfs_path(value)) return 0;
    if (is_direct_soc_sysfs_path(std::filesystem::path(value)) &&
        has_prefix(value, "/sys/devices/")) return 1;
    if (has_prefix(value, "/sys/bus/soc/devices/") ||
        has_prefix(value, "/sys/class/soc/")) return 2;
    return 3;
}

// MediaTek kernels do not consistently register a top-level socX device.
// Depending on the vendor tree, the same attribute is exposed below
// /sys/devices/platform/soc, a bus device, or a /sys/class/soc alias.  Keep
// discovery scoped to SoC-labelled roots and a small depth limit so probing
// remains deterministic and does not walk unrelated sysfs devices.
bool is_soc_context(const std::filesystem::path& path) {
    for (const auto& component : path) {
        const std::string name = lower_ascii(component.string());
        if (name == "soc" || name.rfind("soc", 0) == 0 ||
            name.find("mediatek") != std::string::npos ||
            name.find("mtk") != std::string::npos ||
            name.find("efuse") != std::string::npos ||
            name.find("chipid") != std::string::npos ||
            name.find("chip_id") != std::string::npos ||
            name.find("apmixed") != std::string::npos ||
            name.find("topckgen") != std::string::npos ||
            name.find("infracfg") != std::string::npos ||
            name.find("deviceid") != std::string::npos ||
            name.find("device_id") != std::string::npos ||
            name.find("serial") != std::string::npos) {
            return true;
        }
    }
    return false;
}

void append_unique(std::vector<std::string>& paths,
                   std::unordered_set<std::string>& seen,
                   const std::filesystem::path& candidate) {
    const std::string path = candidate.string();
    if (seen.insert(path).second) paths.push_back(path);
}

std::string normalise(std::string value) {
    value.erase(std::remove(value.begin(), value.end(), '\0'), value.end());
    return trim(std::move(value));
}

std::vector<std::string> discover_sysfs_paths() {
    std::vector<std::string> paths;
    std::unordered_set<std::string> seen;
    std::error_code error;
    size_t visited = 0;
    const std::filesystem::path devices("/sys/devices");
    // Keep the layouts used by Qualcomm and by several Dimensity vendor
    // kernels explicit.  The recursive pass below handles additional bus
    // nesting, while these candidates make the common paths deterministic.
    for (const auto& candidate : {
             std::filesystem::path("/sys/devices/soc0/serial_number"),
             std::filesystem::path("/sys/devices/system/soc/soc0/serial_number"),
             std::filesystem::path("/sys/devices/platform/soc/soc0/serial_number"),
             std::filesystem::path("/sys/devices/platform/soc/serial_number")}) {
        if (is_valid_soc_sysfs_path(candidate.string()) &&
            std::filesystem::is_regular_file(candidate, error)) {
            append_unique(paths, seen, candidate);
        }
        error.clear();
    }
    // Preserve the original fast path for Qualcomm's /sys/devices/socX
    // layout, then recurse only through SoC-context directories for MTK.
    for (std::filesystem::directory_iterator it(
             devices, std::filesystem::directory_options::skip_permission_denied, error),
         end;
         it != end && !error; it.increment(error)) {
        if (!is_soc_directory(it->path())) continue;
        const auto candidate = it->path() / "serial_number";
        if (is_valid_soc_sysfs_path(candidate.string()) &&
            std::filesystem::is_regular_file(candidate, error)) {
            append_unique(paths, seen, candidate);
        }
        error.clear();
    }

    error.clear();
    for (std::filesystem::recursive_directory_iterator it(
             devices, std::filesystem::directory_options::skip_permission_denied, error),
         end;
         it != end && !error && visited++ < kMaxScanEntries; it.increment(error)) {
        const auto current = it->path();
        if (it.depth() >= 6) it.disable_recursion_pending();
        if (it->is_directory(error)) {
            // Walk through the platform anchor and then only through
            // directories whose names identify a SoC/MTK subtree.  This
            // avoids a full /sys traversal on devices with large device
            // graphs while still covering /sys/devices/platform/soc/*.
            const std::string current_name = lower_ascii(current.filename().string());
            const bool platform_anchor = current_name == "platform" ||
                                          current_name == "devices" ||
                                          current_name == "system";
            if (has_peripheral_component(current) || (!is_soc_context(current) && !platform_anchor)) {
                it.disable_recursion_pending();
            }
            error.clear();
            continue;
        }
        if (current.filename() != "serial_number" ||
            !is_valid_soc_sysfs_path(current.string()) ||
            !is_soc_context(current.parent_path())) {
            error.clear();
            continue;
        }
        if (std::filesystem::is_regular_file(current, error)) {
            append_unique(paths, seen, current);
        }
        error.clear();
    }

    error.clear();
    const std::filesystem::path bus("/sys/bus/soc/devices");
    for (std::filesystem::directory_iterator it(
             bus, std::filesystem::directory_options::skip_permission_denied, error),
        end;
         it != end && !error; it.increment(error)) {
        const auto candidate = it->path() / "serial_number";
        if (is_valid_soc_sysfs_path(candidate.string()) &&
            std::filesystem::is_regular_file(candidate, error)) {
            append_unique(paths, seen, candidate);
        }
        error.clear();
    }

    // /sys/class/soc is a common vendor alias.  Parent symlinks are safe to
    // follow while read_stream_file still rejects a symlink at the leaf.
    error.clear();
    const std::filesystem::path soc_class("/sys/class/soc");
    for (std::filesystem::directory_iterator it(
             soc_class, std::filesystem::directory_options::skip_permission_denied, error),
        end;
         it != end && !error; it.increment(error)) {
        const auto candidate = it->path() / "serial_number";
        if (is_valid_soc_sysfs_path(candidate.string()) &&
            std::filesystem::is_regular_file(candidate, error)) {
            append_unique(paths, seen, candidate);
        }
        error.clear();
    }

    std::stable_sort(paths.begin(), paths.end(), [](const std::string& left,
                                                    const std::string& right) {
        const int left_priority = sysfs_path_priority(left);
        const int right_priority = sysfs_path_priority(right);
        if (left_priority != right_priority) return left_priority < right_priority;
        return left < right;
    });
    return paths;
}

std::vector<std::string> discover_device_tree_paths() {
    std::vector<std::string> paths;
    std::unordered_set<std::string> seen;
    std::error_code error;
    size_t visited = 0;
    for (const std::filesystem::path root : {
             std::filesystem::path("/sys/firmware/devicetree/base"),
             std::filesystem::path("/proc/device-tree")}) {
        for (std::filesystem::recursive_directory_iterator it(
                 root, std::filesystem::directory_options::skip_permission_denied, error),
             end;
             it != end && !error && visited++ < kMaxScanEntries; it.increment(error)) {
            const auto current = it->path();
            if (it.depth() >= 6) it.disable_recursion_pending();
            if (it->is_directory(error)) {
                if (it.depth() > 0 && !is_soc_context(current)) {
                    it.disable_recursion_pending();
                }
                error.clear();
                continue;
            }
            if (current.filename() != "serial-number") {
                error.clear();
                continue;
            }
            if (std::filesystem::is_regular_file(current, error)) {
                append_unique(paths, seen, current);
            }
            error.clear();
        }
        error.clear();
    }
    // Some bootloaders place the same property under /chosen instead of at
    // the DT root.  Keep these explicit fallbacks because /chosen is not a
    // SoC-labelled directory and is intentionally pruned by the bounded walk.
    for (const auto& candidate : {
             std::filesystem::path("/sys/firmware/devicetree/base/chosen/serial-number"),
             std::filesystem::path("/proc/device-tree/chosen/serial-number")}) {
        if (std::filesystem::is_regular_file(candidate, error)) {
            append_unique(paths, seen, candidate);
        }
        error.clear();
    }
    return paths;
}

bool is_device_tree_path(const std::string& path) {
    return path == "/sys/firmware/devicetree/base/serial-number" ||
           path == "/proc/device-tree/serial-number" ||
           path.rfind("/sys/firmware/devicetree/base/", 0) == 0 ||
           path.rfind("/proc/device-tree/", 0) == 0;
}

}  // namespace

Readback read_path(const std::string& path) {
    Readback result;
    result.path = path;
    result.source = is_device_tree_path(path) ? "device-tree" :
                    (is_ufs_serial_path(path) ? "ufs-sysfs" :
                    (path.rfind("/sys/bus/soc/devices/", 0) == 0 ? "soc-bus-sysfs" :
                                                                     "soc-sysfs"));
    if (!is_device_tree_path(path) &&
        !is_valid_soc_sysfs_path(path) && !is_ufs_serial_path(path)) {
        result.detail = "rejected-non-soc-surface";
        return result;
    }
    result.hookable = !is_device_tree_path(path);
    if (path.empty() || !read_stream_file(path, result.value, 256)) {
        result.detail = "unreadable";
        result.value.clear();
        return result;
    }
    result.value = normalise(std::move(result.value));
    result.readable = !result.value.empty();
    result.detail = result.readable ? "ok" : "empty";
    return result;
}

Readback probe_ufs_serial() {
    static std::mutex lock;
    const std::lock_guard<std::mutex> guard(lock);
    static auto next_scan = std::chrono::steady_clock::time_point::min();
    std::string cached;
    if (storage_read_string(kUfsCachedPath, cached) && !cached.empty()) {
        cached = normalise(std::move(cached));
        if (is_ufs_serial_path(cached)) {
            Readback result = read_path(cached);
            if (result.readable) {
                result.source = "ufs-sysfs";
                result.detail = "ok-ufs";
                return result;
            }
        } else {
            storage_write_string(kUfsCachedPath, "");
        }
    }
    // Missing UFS is normal. Avoid walking sysfs on every WebUI readback.
    if (std::chrono::steady_clock::now() < next_scan) {
        Readback missing;
        missing.source = "ufs-sysfs";
        missing.detail = "no-readable-ufs-serial-surface";
        return missing;
    }
    next_scan = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    for (const auto& path : discover_ufs_serial_paths()) {
        Readback result = read_path(path);
        if (!result.readable) continue;
        result.source = "ufs-sysfs";
        result.detail = "ok-ufs";
        storage_write_string(kUfsCachedPath, path);
        return result;
    }
    // Keep the known layout as an explicit last candidate in case a vendor
    // exposes the node while its parent directory is not enumerable yet.
    Readback result = read_path(kUfsSerialPath);
    if (result.readable) {
        result.source = "ufs-sysfs";
        result.detail = "ok-ufs";
        storage_write_string(kUfsCachedPath, kUfsSerialPath);
        return result;
    }
    result.source = "ufs-sysfs";
    result.detail = "no-readable-ufs-serial-surface";
    return result;
}

Readback probe() {
    std::string cached;
    Readback cached_result;
    bool have_cached_result = false;
    if (storage_read_string(kCachedPath, cached) && !cached.empty()) {
        cached = normalise(std::move(cached));
        if (is_ufs_serial_path(cached)) {
            // Preserve the original adapter selection as an auxiliary UFS
            // surface while moving the primary cache to a true SoC node.
            storage_write_string(kUfsCachedPath, cached);
            storage_write_string(kCachedPath, "");
            cached.clear();
        } else if (!is_device_tree_path(cached) && !is_valid_soc_sysfs_path(cached)) {
            // Alpha builds could cache a readable UFS/MHI/PCIe serial because
            // those nodes lived below /sys/devices/platform/soc.  Drop the
            // stale path before probing so it can never be returned again.
            storage_write_string(kCachedPath, "");
        } else {
            cached_result = read_path(cached);
        }
        if (cached_result.readable) {
            // A device-tree property is a useful read-only fallback, but it
            // cannot be hooked.  Keep probing for a sysfs surface on every
            // call so a late-created MediaTek attribute (or a kernel module
            // loaded after boot) is not hidden by the DT cache forever.
            if (cached_result.hookable) return cached_result;
            have_cached_result = true;
        }
    }

    for (const std::string& path : discover_sysfs_paths()) {
        Readback result = read_path(path);
        if (!result.readable) continue;
        storage_write_string(kCachedPath, path);
        return result;
    }
    if (have_cached_result) return cached_result;
    // Root DT properties remain the most conventional fallback.  If a
    // vendor places serial-number below its SoC node, the bounded DT walk
    // covers that layout as well (all DT surfaces are read-only).
    std::vector<std::string> device_tree_paths{
        "/sys/firmware/devicetree/base/serial-number",
        "/proc/device-tree/serial-number",
        "/sys/firmware/devicetree/base/chosen/serial-number",
        "/proc/device-tree/chosen/serial-number"};
    for (const auto& path : discover_device_tree_paths()) {
        if (std::find(device_tree_paths.begin(), device_tree_paths.end(), path) ==
            device_tree_paths.end()) {
            device_tree_paths.push_back(path);
        }
    }
    for (const auto& path : device_tree_paths) {
        Readback result = read_path(path);
        if (!result.readable) continue;
        storage_write_string(kCachedPath, path);
        return result;
    }

    // Keep the original UFS serial available as a clearly labeled fallback
    // for vendor kernels that have no SoC serial surface at all.  It is not
    // selected when /sys/devices/soc0/serial_number (or another verified SoC
    // node) is present.
    Readback ufs_result = probe_ufs_serial();
    if (ufs_result.readable) return ufs_result;
    ufs_result = {};
    ufs_result.source = "unsupported";
    ufs_result.detail = "no-readable-serial-number-surface";
    return ufs_result;
}

}  // namespace jiebiao::soc_serial
