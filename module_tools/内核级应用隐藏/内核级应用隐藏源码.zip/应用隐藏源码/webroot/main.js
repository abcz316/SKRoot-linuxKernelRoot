// main.js — 应用自动隐藏 WebUI
// 通过 SKRoot 官方 REST API 与 so 通信

let allApps = [];
let filteredApps = [];
let selectedApps = new Set();
let allGames = [];
let filteredGames = [];
let selectedGame = '';
let currentRules = [];
let editingOldGame = ''; // 非空表示正在编辑该触发应用的旧规则（保存时若换了触发应用需先删旧）

// ============ API ============
async function apiGet(path) {
  try {
    const resp = await fetch(new URL(path, window.location.href), { method: 'GET' });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    return await resp.text();
  } catch (e) { console.error('GET', path, e); return null; }
}

async function apiPost(path, body = '') {
  try {
    const resp = await fetch(new URL(path, window.location.href), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body
    });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const text = await resp.text();
    try { return JSON.parse(text); } catch (e) { return text; }
  } catch (e) { console.error('POST', path, e); return null; }
}

// ============ 状态轮询 ============
async function fetchStatus() {
  const raw = await apiGet('/api/status');
  if (!raw) return;
  try {
    const s = JSON.parse(raw);
    const dot = document.getElementById('statusDot');
    const text = document.getElementById('statusText');
    if (s.running) { dot.classList.add('online'); text.textContent = '运行中'; }
    else { dot.classList.remove('online'); text.textContent = '已停止'; }
    document.getElementById('daemonStatus').textContent = s.running ? '运行中' : '已停止';
    document.getElementById('daemonPid').textContent = s.pid || '--';
    document.getElementById('fgApp').textContent = s.foreground || '--';
    document.getElementById('hiddenCount').textContent = (s.hidden || []).length + ' 个';
  } catch (e) {}
}

async function fetchConfig() {
  const raw = await apiGet('/api/config');
  if (!raw) return;
  try {
    const c = JSON.parse(raw);
    document.getElementById('cfgDisabled').checked = c.disabled;
    document.getElementById('cfgFgOnly').checked = c.foreground_only;
    document.getElementById('cfgKeepBg').checked = c.keep_background;
    // 后端缺省(老配置无此字段)视为开启
    document.getElementById('cfgForceStop').checked = c.force_stop !== false;
  } catch (e) {}
}

async function saveConfig() {
  const body = JSON.stringify({
    disabled: document.getElementById('cfgDisabled').checked,
    foreground_only: document.getElementById('cfgFgOnly').checked,
    keep_background: document.getElementById('cfgKeepBg').checked,
    force_stop: document.getElementById('cfgForceStop').checked
  });
  const res = await apiPost('/api/config', body);
  if (res && res.ok) {
    showToast('配置已保存');
  } else {
    showToast('配置保存失败');
  }
}

// ============ 规则 ============
async function fetchRules() {
  const raw = await apiGet('/api/rules');
  if (!raw) return;
  try {
    const data = JSON.parse(raw);
    currentRules = data.games || [];
    renderRules();
  } catch (e) {}
}

function renderRules() {
  const list = document.getElementById('ruleList');
  if (!currentRules.length) {
    list.innerHTML = '<div class="empty-hint">暂无规则，点击右上角添加</div>';
    return;
  }
  let html = '';
  currentRules.forEach(r => {
    html += '<div class="rule-card">';
    html += '<div class="rule-game">' + avatarHtml(r.pkg, 'avatar-sm') + '<span class="rule-game-pkg">' + esc(r.pkg) + '</span></div>';
    html += '<div class="rule-apps">';
    (r.apps || []).forEach(a => {
      html += '<span class="rule-app-tag">' + esc(a) + '</span>';
    });
    if (!r.apps || !r.apps.length) html += '<span class="rule-empty">未配置隐藏应用</span>';
    html += '</div>';
    html += '<div class="rule-actions">';
    html += '<button class="btn-sm btn-edit" onclick="editRule(\'' + esc(r.pkg) + '\')">编辑</button>';
    html += '<button class="btn-sm btn-danger" onclick="deleteRule(\'' + esc(r.pkg) + '\')">删除</button>';
    html += '</div></div>';
  });
  list.innerHTML = html;
}

async function deleteRule(pkg) {
  if (!confirm('确定删除规则：' + pkg + '？')) return;
  const res = await apiPost('/api/rules/delete', JSON.stringify({ game: pkg }));
  if (res && res.ok) {
    showToast('已删除');
    fetchRules();
  } else {
    showToast(res && res.error ? '删除失败：' + res.error : '删除失败');
  }
}

// ============ 添加 / 编辑规则 ============
function openAddDialog() { return openRuleDialog(null); }
async function editRule(pkg) {
  const rule = currentRules.find(r => r.pkg === pkg);
  if (!rule) { showToast('规则不存在或已被删除'); return; }
  await openRuleDialog(rule);
}
async function openRuleDialog(rule) {
  // rule 为 null=新增；否则=编辑并回填原触发应用与隐藏应用
  editingOldGame = rule ? rule.pkg : '';
  selectedApps = new Set(rule ? (rule.apps || []) : []);
  selectedGame = rule ? rule.pkg : '';
  document.getElementById('appSearch').value = '';
  const gs = document.getElementById('gameSearch');
  if (gs) gs.value = '';
  document.getElementById('modalTitle').textContent = rule ? '编辑隐藏规则' : '添加隐藏规则';
  document.getElementById('saveBtn').textContent = rule ? '保存修改' : '保存';
  document.getElementById('addModal').classList.add('show');
  // 加载触发应用列表（手机内全部第三方应用）
  const gamesRaw = await apiGet('/api/games');
  try {
    const g = JSON.parse(gamesRaw);
    allGames = g.games || [];
    filteredGames = allGames;
    renderGameList();
  } catch (e) {
    document.getElementById('gameList').innerHTML = '<div class="loading">加载失败</div>';
  }
  // 加载应用列表
  const appsRaw = await apiGet('/api/apps');
  try {
    const a = JSON.parse(appsRaw);
    allApps = a.apps || [];
    filteredApps = allApps;
    renderAppList();
  } catch (e) {
    document.getElementById('appList').innerHTML = '<div class="loading">加载失败</div>';
  }
  renderSelectedBar(); // 回填编辑时已选（含可能已不在列表中的包）
}

function closeAddDialog() {
  document.getElementById('addModal').classList.remove('show');
  // 关闭即清空编辑态与选择，避免下次打开残留上一次内容
  editingOldGame = '';
  selectedGame = '';
  selectedApps.clear();
  renderSelectedBar();
}

function filterGames() {
  const kw = document.getElementById('gameSearch').value.toLowerCase();
  filteredGames = kw ? allGames.filter(a => a.pkg.toLowerCase().includes(kw) || (a.label || '').toLowerCase().includes(kw)) : allGames;
  renderGameList();
}
// 搜索输入防抖：应用数量可能上百，连续输入时只在停顿后重建一次列表，省 CPU/掉帧
const onGameSearch = debounce(filterGames, 120);
function renderGameList() {
  const list = document.getElementById('gameList');
  if (!filteredGames.length) { list.innerHTML = '<div class="empty-hint">无匹配应用</div>'; return; }
  let html = '';
  filteredGames.forEach(a => {
    const on = selectedGame === a.pkg ? 'selected' : '';
    html += '<div class="app-item app-item-single ' + on + '" onclick="selectGame(\'' + esc(a.pkg).replace(/'/g, "\\'") + '\')">';
    html += '<span class="radio-dot ' + on + '"></span>';
    html += avatarHtml(a.pkg);
    html += '<div class="app-info"><span class="app-label">' + esc(a.label || a.pkg) + '</span>';
    html += '<span class="app-pkg">' + esc(a.pkg) + '</span></div></div>';
  });
  list.innerHTML = html;
}
function selectGame(pkg) {
  selectedGame = (selectedGame === pkg) ? '' : pkg;
  // 触发应用不能作为自己的隐藏目标：切换时剔除并刷新右侧可选列表
  selectedApps.delete(pkg);
  renderGameList();
  renderAppList();
  renderSelectedBar();
}
function filterApps() {
  const kw = document.getElementById('appSearch').value.toLowerCase();
  filteredApps = kw ? allApps.filter(a => a.pkg.toLowerCase().includes(kw) || (a.label || '').toLowerCase().includes(kw)) : allApps;
  renderAppList();
}
const onAppSearch = debounce(filterApps, 120);

function renderAppList() {
  const list = document.getElementById('appList');
  if (!filteredApps.length) { list.innerHTML = '<div class="empty-hint">无匹配应用</div>'; return; }
  let html = '';
  filteredApps.forEach(a => {
    const isSelf = (a.pkg === selectedGame);
    const isProt = !!a.protected;
    const checked = (!isSelf && !isProt && selectedApps.has(a.pkg)) ? 'checked' : '';
    const dis = (isSelf || isProt) ? 'disabled' : '';
    let tag = '';
    if (isSelf) tag = ' <span class="self-tag">目标进程·无需隐藏</span>';
    else if (isProt) tag = ' <span class="prot-tag">系统核心·不可隐藏</span>';
    html += '<label class="app-item' + (isSelf ? ' is-self' : '') + (isProt ? ' is-prot' : '') + '">';
    html += '<input type="checkbox" value="' + esc(a.pkg) + '" ' + checked + ' ' + dis + ' onchange="toggleApp(this)">';
    html += avatarHtml(a.pkg);
    html += '<div class="app-info"><span class="app-label">' + esc(a.label || a.pkg) + tag + '</span>';
    html += '<span class="app-pkg">' + esc(a.pkg) + '</span></div></label>';
  });
  list.innerHTML = html;
}

function toggleApp(cb) {
  if (cb.checked) selectedApps.add(cb.value);
  else selectedApps.delete(cb.value);
  renderSelectedBar();
}
// 已选应用栏：始终展示当前选中的全部包名（搜索过滤、或包已卸载不在列表时也能看到/移除）
function renderSelectedBar() {
  const bar = document.getElementById('selectedBar');
  if (!bar) return;
  const pkgs = Array.from(selectedApps).filter(p => p !== selectedGame).sort();
  if (!pkgs.length) { bar.innerHTML = ''; bar.classList.remove('has'); return; }
  bar.classList.add('has');
  let html = '<span class="selected-title">已选 ' + pkgs.length + ' 个 · 点 × 移除</span>';
  pkgs.forEach(p => {
    const safe = esc(p).replace(/'/g, "\\'");
    html += '<span class="selected-chip">' + avatarHtml(p, 'avatar-xs')
      + '<span class="selected-chip-name">' + esc(p) + '</span>'
      + '<span class="selected-x" onclick="removeSelectedApp(\'' + safe + '\')" title="移除">×</span></span>';
  });
  bar.innerHTML = html;
}
function removeSelectedApp(pkg) {
  selectedApps.delete(pkg);
  renderSelectedBar();
  renderAppList(); // 同步取消下方列表里的勾选状态
}

async function saveRule() {
  const game = selectedGame;
  if (!game) { showToast('请选择目标进程'); return; }
  // 双保险：剔除目标进程自身（正常情况下它在列表里已被禁选）
  const apps = Array.from(selectedApps).filter(p => p !== game);
  if (!apps.length) { showToast('请选择要隐藏的应用（目标进程自身无需选择）'); return; }
  // 先存好新规则；若更换了触发应用，再删旧规则。顺序很重要：先存新再删旧，
  // 中间态是"新旧并存"(只多藏、不会错误露出)；若先删旧再存新，会有毫秒级空窗，
  // 守护恰好轮询到会把目标恢复一次又重新隐藏，出现一闪。
  const body = JSON.stringify({ game, apps });
  const res = await apiPost('/api/rules', body);
  if (res && res.ok) {
    if (editingOldGame && editingOldGame !== game) {
      await apiPost('/api/rules/delete', JSON.stringify({ game: editingOldGame }));
    }
    showToast(editingOldGame ? '规则已更新' : '规则已保存');
    editingOldGame = '';
    closeAddDialog();
    fetchRules();
  } else {
    showToast(res && res.error ? '保存失败：' + res.error : '保存失败');
  }
}

// ============ 守护进程控制 ============
async function daemonAction(action) {
  const res = await apiPost('/api/daemon', action);
  if (res && res.ok) {
    showToast(action === 'start' ? '已启动' : action === 'stop' ? '已停止' : '已重启');
  } else {
    showToast('操作失败');
  }
  setTimeout(fetchStatus, 500);
}

// 一键救回：解除所有被伪卸载(pm hide)/挂起(suspend)的应用。
// 用于"某个应用隐藏后没恢复回来、桌面图标消失"；不会启用你在系统里手动禁用的应用。
async function restoreAll() {
  if (!confirm('将解除所有被隐藏/挂起的应用并恢复图标（不会启用你在系统里手动禁用的应用）。确定继续？')) return;
  showToast('正在恢复，请稍候…', 6000);
  const res = await apiPost('/api/restore_all', '') || {};
  if (res.ok) {
    showToast('恢复完成，处理 ' + (res.restored || 0) + ' 项，若图标未刷新请重启桌面');
    fetchRules();
    setTimeout(fetchStatus, 800);
  } else {
    showToast('恢复失败，请查看运行日志');
  }
}

// ============ 工具 ============
// 应用"图标位"：纯 native 模块无法调用系统 PackageManager 取真实图标，
// 这里用包名末段首字符 + 由包名确定性取色的圆角头像替代（同一应用颜色恒定）。
const AVATAR_COLORS = ['#4a9eff', '#36c5a0', '#f59e4a', '#e8648a', '#5fb878',
  '#f2c14e', '#e07a5f', '#5aa9c4', '#8fb36b', '#d98cb3'];
function hashStr(s) { let h = 0; for (let i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) >>> 0; } return h; }
function avatarText(pkg) {
  const segs = String(pkg || '').split('.').filter(Boolean);
  const last = segs.length ? segs[segs.length - 1] : String(pkg || '');
  return last ? last[0].toUpperCase() : '?';
}
function avatarHtml(pkg, extra) {
  const color = AVATAR_COLORS[hashStr(pkg) % AVATAR_COLORS.length];
  return '<span class="avatar ' + (extra || '') + '" style="background:' + color + '">' + esc(avatarText(pkg)) + '</span>';
}
function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
function debounce(fn, ms) {
  let timer = null;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
}

function showToast(msg, duration = 2000) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), duration);
}

// ============ 初始化 ============
let statusTimer = null;
function startPolling() {
  if (statusTimer) return;
  fetchStatus();
  statusTimer = setInterval(fetchStatus, 5000);
}
function stopPolling() {
  if (statusTimer) { clearInterval(statusTimer); statusTimer = null; }
}
function init() {
  fetchStatus();
  fetchConfig();
  fetchRules();
  // 页面可见时轮询，切到后台时暂停以省电（移动端友好）
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopPolling();
    else startPolling();
  });
  startPolling();
}
init();
