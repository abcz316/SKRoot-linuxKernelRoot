#!/system/bin/sh
# AAH 独立守护进程（不依赖 libmodule.so，fork 后 execve 运行）
# 用法: aah_daemon.sh <data_dir>
DIR="$1"
LOG="$DIR/aah.log"
PIDFILE="$DIR/aah.pid"
RULESDIR="$DIR/rules"
HIDDEN="$DIR/aah.shidden"

echo "$$" > "$PIDFILE"
chmod 0644 "$PIDFILE" 2>/dev/null
echo "[$(date '+%H:%M:%S')] sh daemon started pid=$$" >> "$LOG"

# 等 PMS ready（最多 90 秒）
i=0
while [ $i -lt 90 ]; do
    pm list packages 2>/dev/null | grep -q . && break
    sleep 1
    i=$((i+1))
done
echo "[$(date '+%H:%M:%S')] sh daemon pms-ready after ${i}s" >> "$LOG"

# 读前台包名（从 mResumedActivity 提取）
get_fg() {
    dumpsys activity activities 2>/dev/null \
      | grep -m1 'mResumedActivity' \
      | sed -e 's/.* //' -e 's#/.*##'
}

hide_app() {
    pkg="$1"
    pm hide --user 0 "$pkg" >/dev/null 2>&1
    pm hide --user 999 "$pkg" >/dev/null 2>&1
    pm suspend --user 0 "$pkg" >/dev/null 2>&1
    pm suspend --user 999 "$pkg" >/dev/null 2>&1
    am force-stop --user 0 "$pkg" >/dev/null 2>&1
    am force-stop --user 999 "$pkg" >/dev/null 2>&1
}

restore_app() {
    pkg="$1"
    pm unsuspend --user 0 "$pkg" >/dev/null 2>&1
    pm unsuspend --user 999 "$pkg" >/dev/null 2>&1
    pm unhide --user 0 "$pkg" >/dev/null 2>&1
    pm unhide --user 999 "$pkg" >/dev/null 2>&1
    pm enable --user 0 "$pkg" >/dev/null 2>&1
    pm enable --user 999 "$pkg" >/dev/null 2>&1
    cmd package install-existing --user 0 "$pkg" >/dev/null 2>&1
}

# 主循环
while true; do
    [ -f "$DIR/.aah_disabled" ] && {
        [ -f "$HIDDEN" ] && while read -r p; do [ -n "$p" ] && restore_app "$p"; done < "$HIDDEN"
        > "$HIDDEN"
        echo "[$(date '+%H:%M:%S')] disabled, all restored, exit" >> "$LOG"
        exit 0
    }
    sleep 2

    fg=$(get_fg)
    [ -z "$fg" ] && continue

    # 计算应隐藏的包：遍历 rules/*.conf，文件名=触发包，每行=目标包
    should_hide=""
    if [ -d "$RULESDIR" ]; then
        for conf in "$RULESDIR"/*.conf; do
            [ -f "$conf" ] || continue
            game=$(basename "$conf" .conf)
            # 前台是触发包才隐藏它的目标
            [ "$fg" = "$game" ] || continue
            while IFS= read -r line; do
                line=$(echo "$line" | tr -d '\r' | sed 's/#.*//' | xargs)
                [ -z "$line" ] && continue
                [ "$line" = "$game" ] && continue
                should_hide="$should_hide $line"
            done < "$conf"
        done
    fi
    should_hide=$(echo $should_hide | tr ' ' '\n' | sort -u | tr '\n' ' ')

    # 隐藏新的
    for pkg in $should_hide; do
        if ! grep -qx "$pkg" "$HIDDEN" 2>/dev/null; then
            echo "[$(date '+%H:%M:%S')] hide-begin pkg=$pkg fg=$fg" >> "$LOG"
            hide_app "$pkg"
            echo "$pkg" >> "$HIDDEN"
            echo "[$(date '+%H:%M:%S')] hide-done pkg=$pkg" >> "$LOG"
        else
            am force-stop --user 0 "$pkg" >/dev/null 2>&1
        fi
    done

    # 恢复不需要的
    if [ -f "$HIDDEN" ]; then
        tmp=$(mktemp)
        while read -r pkg; do
            [ -z "$pkg" ] && continue
            if echo " $should_hide " | grep -q " $pkg "; then
                echo "$pkg" >> "$tmp"
            else
                echo "[$(date '+%H:%M:%S')] restore pkg=$pkg" >> "$LOG"
                restore_app "$pkg"
            fi
        done < "$HIDDEN"
        mv "$tmp" "$HIDDEN"
    fi
done
