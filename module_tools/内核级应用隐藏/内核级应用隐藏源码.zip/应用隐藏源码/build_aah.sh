#!/bin/bash
# module_app_auto_hider 一条龙构建（全流程在本地盘，根治网络盘写 so 变 0 字节）：
#   源码同步到 /tmp -> 本地盘 ndk-build -> 本地 so 校验 -> 带重试回拷持久 dist -> 基线校验
set -u
W=/home/user/.super_doubao/super-doubao-runtime/workspace
MOD="$W/module_app_auto_hider"
NDK="/tmp/lndk"
KIT="/tmp/lkit"
BIN="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
BUILD=/tmp/aah_build
log(){ echo "[$(date '+%H:%M:%S')] $*"; }

NDK_SRC="$W/ndk_extract/android-ndk-r26b"
KIT_SRC="$W/kernel_module_kit"
# /tmp 回合间会被回收，自动从持久源准备本地工具链（编译器必须在本地盘运行）
if [ ! -x "$NDK/ndk-build" ]; then
  log "0) 准备本地 NDK（tar 流式拷贝，约2-3分钟）"
  rm -rf "$NDK"; mkdir -p "$NDK"
  tar -C "$NDK_SRC" -cf - . | tar -C "$NDK" -xf - || { echo "NDK_COPY_FAILED"; exit 3; }
  chmod +x "$NDK/ndk-build" 2>/dev/null
  log "   NDK 就绪"
fi
if [ ! -f "$KIT/lib/libkernel_module_kit_static.a" ]; then
  log "0) 准备本地 kernel kit"
  rm -rf "$KIT"; mkdir -p "$KIT"
  tar -C "$KIT_SRC" -cf - . | tar -C "$KIT" -xf - || { echo "KIT_COPY_FAILED"; exit 3; }
  log "   kit 就绪"
fi

log "1) 同步源码到本地盘 $BUILD（源码很小）"
rm -rf "$BUILD"; mkdir -p "$BUILD"
cp -a "$MOD/jni" "$BUILD/jni"
mkdir -p "$BUILD/dist"

log "2) 本地盘干净 ndk-build（官方 NDK r26b + 官方静态 kit）"
cd "$BUILD/jni" || exit 4
rm -rf obj libs
KIT_PATH="$KIT" "$NDK/ndk-build" \
    NDK_PROJECT_PATH=. \
    APP_BUILD_SCRIPT=./Android.mk \
    NDK_APPLICATION_MK=./Application.mk \
    -j4 2>&1 | grep -vE 'non-system libraries|LOCAL_STATIC_LIBRARIES|LOCAL_SHARED_LIBRARIES|current module|^Android NDK: +(This is|instead|of the)'
RC=${PIPESTATUS[0]}
[ $RC -ne 0 ] && { log "BUILD_FAILED rc=$RC"; exit $RC; }

SO="$BUILD/jni/libs/arm64-v8a/libmodule_app_auto_hider.so"
[ -f "$SO" ] || { log "SO_MISSING"; exit 2; }
SZ=$(stat -c %s "$SO")
log "3) 本地产物校验 size=$SZ"
[ "$SZ" -gt 100000 ] || { log "LOCAL_SO_TOO_SMALL size=$SZ"; exit 5; }
sync
SZ=$(stat -c %s "$SO"); [ "$SZ" -gt 100000 ] || { log "LOCAL_SO_SHRANK_AFTER_SYNC size=$SZ"; exit 5; }
"$BIN/llvm-readelf" -h "$SO" | grep -E 'Class|Machine|Type'

log "4) 成品回拷持久 dist（大小一致 + 最多5次重试 + sync，根治网络盘 0 字节）"
mkdir -p "$MOD/dist"
DST="$MOD/dist/libmodule_app_auto_hider.so"
ok=0
for i in 1 2 3 4 5; do
    rm -f "$DST"
    cat "$SO" > "$DST" 2>/dev/null
    sync
    DSZ=$(stat -c %s "$DST" 2>/dev/null || echo 0)
    if [ "$DSZ" = "$SZ" ]; then
        # 再回读比对字节，确保不是假大小
        if cmp -s "$SO" "$DST"; then ok=1; break; fi
    fi
    log "   回拷不一致 local=$SZ dist=$DSZ try=$i，重试"
    sleep 1
done
[ "$ok" = 1 ] || { log "DIST_COPY_FAILED"; exit 6; }
chmod 0600 "$DST"
# 同时在本地 build 留一份 so 供打包直接用(避免再从网络盘读)
cp -f "$SO" "$BUILD/libmodule_app_auto_hider.so"
ls -la "$DST"

log "5) 二进制基线校验"
ST="$BIN/llvm-strings"
echo "--- NEEDED ---"; "$BIN/llvm-readelf" -d "$DST" | grep NEEDED || echo "  (无 NEEDED，纯静态)"
echo "--- 旧作者残留(应为0) ---"; "$ST" "$DST" | grep -c '斓梦语' || true
echo "--- 署名 榆爱(>=1) ---"; "$ST" "$DST" | grep -c '榆爱'
echo "--- 版本1.5名片 ---"; "$ST" "$DST" | grep -c '应用自动隐藏'
echo "--- 方案A force-stop ---"; "$ST" "$DST" | grep -c 'force-stop'
echo "--- 自身进程令牌 AAH_DAEMON=1 ---"; "$ST" "$DST" | grep -c 'AAH_DAEMON=1'
echo "--- install-existing 兜底 ---"; "$ST" "$DST" | grep -c 'install-existing'
log "ALL_STAGES_DONE local_so=$SO size=$SZ"
