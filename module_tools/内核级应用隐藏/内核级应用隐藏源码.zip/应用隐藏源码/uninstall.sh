#!/system/bin/sh
# 模块卸载时执行：恢复所有被隐藏的应用，清理运行数据
# 新配置根 = 模块私有目录(MODDIR，随模块整体删除)；同时兼容清理旧 /data/local/tmp 残留
MODDIR=${0%/*}
AAH_DATA_DIR="$MODDIR"
AAH_RULES_DIR="$AAH_DATA_DIR/rules"
AAH_STATE="$AAH_DATA_DIR/aah.state"
OLD_DATA_DIR=/data/local/tmp/app_auto_hider

# 停止守护进程（模块目录与旧 tmp 目录两处 PID 都处理）
for _pd in "$AAH_DATA_DIR/aah.pid" "$OLD_DATA_DIR/aah.pid"; do
    if [ -f "$_pd" ]; then
        _pid=$(cat "$_pd" 2>/dev/null | tr -d ' \r\n')
        [ -n "$_pid" ] && kill -9 "$_pid" 2>/dev/null
    fi
done
rm -f "$AAH_DATA_DIR/aah.pid" "$AAH_DATA_DIR/aah.lock/pid" 2>/dev/null
rmdir "$AAH_DATA_DIR/aah.lock" 2>/dev/null
pkill -f aah_launch.sh 2>/dev/null

# 获取所有用户
AAH_USERS=$(
    {
        am get-current-user 2>/dev/null
        cmd user list 2>/dev/null | sed -n 's/.*UserInfo{\([0-9][0-9]*\):.*/\1/p'
        echo 0
    } | sed '/^[[:space:]]*$/d' | sort -nu | tr '\n' ' '
)
[ -n "$AAH_USERS" ] || AAH_USERS=0
# 当前用户：仅对它补 install-existing（救回被"对用户卸载"的包），分身用户不碰
_CU=$(am get-current-user 2>/dev/null | tr -dc '0-9'); [ -z "$_CU" ] && _CU=0

# 收集所有被管理的包名（模块目录 + 旧 tmp 目录双读，不遗漏）
AAH_PKGS=$(
    {
        cat "$AAH_STATE" "$OLD_DATA_DIR/aah.state" 2>/dev/null
        for _r in "$AAH_RULES_DIR"/*.conf "$MODDIR/rules"/*.conf "$OLD_DATA_DIR/rules"/*.conf; do
            [ -f "$_r" ] && sed -e 's/\r$//' -e '/^[[:space:]]*#/d' -e '/^[[:space:]]*$/d' "$_r" 2>/dev/null
        done
    } | sort -u | grep -v '^$'
)

# 恢复所有应用
for _pkg in $AAH_PKGS; do
    for _u in $AAH_USERS; do
        pm unhide --user "$_u" "$_pkg" >/dev/null 2>&1 || cmd package unhide --user "$_u" "$_pkg" >/dev/null 2>&1 || true
        pm unsuspend --user "$_u" "$_pkg" >/dev/null 2>&1 || cmd package unsuspend --user "$_u" "$_pkg" >/dev/null 2>&1 || true
        pm enable --user "$_u" "$_pkg" >/dev/null 2>&1 || cmd package set-enabled-setting --user "$_u" "$_pkg" enabled >/dev/null 2>&1 || true
        [ "$_u" = "$_CU" ] && { cmd package install-existing --user "$_u" "$_pkg" >/dev/null 2>&1 || true; }
    done
done

# 兜底：即使规则/状态记录已丢失，也按"已安装(-u)但当前不可见"的差集，把所有用户下
# 被 hide/suspend（伪卸载/挂起）的应用一律救回，避免卸载后仍有应用图标回不来。
for _u in $AAH_USERS; do
    _k=/data/local/tmp/.aah_k.$_u
    _v=/data/local/tmp/.aah_v.$_u
    cmd package list packages -u --user "$_u" 2>/dev/null > "$_k"
    cmd package list packages --user "$_u" 2>/dev/null > "$_v"
    while IFS= read -r _l; do
        _p=${_l#package:}
        [ -n "$_p" ] || continue
        if ! grep -Fqx "package:$_p" "$_v"; then
            pm unhide --user "$_u" "$_p" >/dev/null 2>&1 || cmd package unhide --user "$_u" "$_p" >/dev/null 2>&1 || true
            pm unsuspend --user "$_u" "$_p" >/dev/null 2>&1 || cmd package unsuspend --user "$_u" "$_p" >/dev/null 2>&1 || true
            [ "$_u" = "$_CU" ] && { cmd package install-existing --user "$_u" "$_p" >/dev/null 2>&1 || true; }
        fi
    done < "$_k"
    rm -f "$_k" "$_v"
done

# 清理旧 /data/local/tmp 残留（模块目录本身由框架随卸载整体删除）
rm -rf "$OLD_DATA_DIR" 2>/dev/null

echo "[AAH] uninstall done: restored $(echo "$AAH_PKGS" | wc -l) apps"
