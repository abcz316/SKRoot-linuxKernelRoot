// ============================================================================
//  patch_mkdir.h — Hook vfs_mkdir，挡"写死 Android/data/<包名> 路径试探"型检测
//  Android 16 GKI 不导出 __arm64_sys_mkdirat，改 hook 导出的 vfs_mkdir。
//  检测器 mkdir .../Android/data/<包名>，最后一段名即包名；basename 命中且
//  非系统进程 → 返回 0（让它以为创建成功=没装）。
// ============================================================================
#pragma once
#include <set>
#include <string>
#include "patch_base.h"

class PatchMkdir : public PatchBase {
public:
    PatchMkdir(const PatchBase& patch_base, uint64_t vfs_mkdir_addr);
    ~PatchMkdir();

    // pkgs：要隐藏的目标包名集合（如 bin.mt.plus.canary）
    KModErr patch_vfs_mkdir(const std::set<std::string>& pkgs);

private:
    uint64_t m_vfs_mkdir = 0;
};
