// ============================================================================
//  patch_filldir64.cpp — Hook filldir64（严格沿用 SKRoot 官方汇编主体）
//  filldir64 入参：x1=目录名指针, w2=名字长度, x4=该目录项 inode
// ============================================================================
#include "patch_filldir64.h"
#include <vector>
using namespace asmjit;
using namespace asmjit::a64;
using namespace asmjit::a64::Predicate;

PatchFilldir64::PatchFilldir64(const PatchBase& patch_base, uint64_t filldir64)
    : PatchBase(patch_base), m_filldir64(filldir64) {}

PatchFilldir64::~PatchFilldir64() {}

KModErr PatchFilldir64::patch_filldir64(const std::set<std::string>& names,
                                        const std::set<uint64_t>& ino_set) {
    GpX x1_name = x1;
    GpW w2_namelen = w2;
    GpX x4_ino = x4;

    std::vector<std::string> hide_names(names.begin(), names.end());
    std::vector<uint64_t> hide_inos(ino_set.begin(), ino_set.end());

    aarch64_asm_ctx asm_ctx = init_aarch64_asm();
    auto a = asm_ctx.assembler();
    Label L_allow_visible = a->newLabel();

    kernel_module::arm64_before_hook_start(a);

    // 系统/root 进程放行；普通 App 继续匹配隐藏规则
    emit_check_current_allow_visible_to_x10(a);
    a->cbnz(x10, L_allow_visible);

    // 按目录名称隐藏（数据包名目录，如 /data/data/<pkg>）
    for (size_t i = 0; i < hide_names.size(); ++i) {
        Label L_next = a->newLabel();
        const auto& dir_name = hide_names[i];
        aarch64_asm_mov_w(a, w11, dir_name.length());
        a->cmp(w2_namelen, w11);
        a->b(CondCode::kNE, L_next);

        aarch64_asm_set_x_cstr_ptr(a, x12, dir_name);
        {
            RegProtectGuard g1(a, x0);
            kernel_module::string_ops::kmemcmp(a, x1_name, x12, x11);
            a->mov(x11, x0);
        }
        a->cbnz(x11, L_next);

        // 返回 0：上层 iterate_shared 认为填充成功，继续遍历下一个目录项；
        // 当前项因未执行原 filldir 而未被写入用户缓冲区，实现隐藏。
        // 切勿返回非0：filldir 回调非0会让上层停止遍历，导致目录列表在首个隐藏项处截断。
        a->mov(x0, xzr);
        kernel_module::arm64_before_hook_end(a, false); // 命中：直接返回，不填该目录项
        a->bind(L_next);
    }

    // 按 inode 隐藏（/data/app 下带随机后缀的 APK 目录）
    for (size_t i = 0; i < hide_inos.size(); ++i) {
        Label L_next = a->newLabel();
        aarch64_asm_mov_x(a, x11, hide_inos[i]);
        a->cmp(x4_ino, x11);
        a->b(CondCode::kNE, L_next);

        a->mov(x0, xzr);  // 返回0=上层继续遍历；非0会截断目录列表
        kernel_module::arm64_before_hook_end(a, false);
        a->bind(L_next);
    }

    a->bind(L_allow_visible);
    kernel_module::arm64_before_hook_end(a, true); // 未命中：正常执行原函数
    return patch_kernel_before_hook(m_filldir64, a);
}
