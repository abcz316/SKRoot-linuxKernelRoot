// ============================================================================
//  aah_daemon_manager.h — 守护进程管理
//  负责 aah_launch.sh 的启动、停止、重启、状态检测、升级版本感知
// ============================================================================
#pragma once
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include "aah_paths.h"

class AahDaemonManager {
public:
    AahDaemonManager() = default;

    // 检测守护进程是否在运行（PID 存活 + cmdline 身份校验）
    bool is_running() {
        int pid = read_pid();
        if (pid <= 1) return false;
        if (kill(pid, 0) != 0 && errno != EPERM) return false;
        // 进程名伪装后 cmdline 只剩中性 "sh"：身份改认 environ 里的 AAH_DAEMON 令牌
        // (environ 仅 root 可读，普通App/反作弊看不到，不会因此暴露)。
        std::string environ = read_file("/proc/" + std::to_string(pid) + "/environ");
        if (environ.find("AAH_DAEMON=1") != std::string::npos) return true;
        // 兼容旧版守护(以脚本路径启动、cmdline 含 aah_launch)
        std::string cmdline = read_file("/proc/" + std::to_string(pid) + "/cmdline");
        if (cmdline.empty()) return false;
        // /proc/pid/cmdline 参数以 '\0' 分隔，转空格后匹配脚本名
        for (char& c : cmdline) {
            if (c == '\0') c = ' ';
        }
        return cmdline.find("aah_launch") != std::string::npos;
    }

    // 读取正在运行的守护进程版本（由脚本写入 aah.version）
    std::string running_version() {
        std::ifstream f(aah_paths::version_file());
        if (!f.is_open()) return "";
        std::string v;
        std::getline(f, v);
        while (!v.empty() && (v.back()=='\r'||v.back()=='\n'||v.back()==' ')) v.pop_back();
        return v;
    }

    // 启动守护进程
    bool start(const std::string& module_dir) {
        if (is_running()) return true;

        std::string launch_script = module_dir + "/common/aah_launch.sh";
        std::string paths_script  = module_dir + "/common/aah_paths.sh";
        chmod(launch_script.c_str(), 0755);
        chmod(paths_script.c_str(), 0755);
        (void)mkdir(aah_paths::root().c_str(), 0755);
        (void)mkdir(aah_paths::rules_dir().c_str(), 0755);

        // MODPATH 经环境变量传入（守护进程是 sh，无法从 /proc/maps 推导 so 路径）；
        // setsid→nohup→子shell 三级回退；路径单引号包裹防截断。
        // 进程名伪装：用 stdin 重定向(sh < script)喂脚本，进程 argv 只剩中性 "sh"，
        // /proc/<pid>/cmdline 不暴露模块脚本路径/名字；脚本自身不从 stdin 读取(已核对)。
        // AAH_DAEMON=1 是仅 root 可读的身份令牌(environ 对普通App不可见)，供存活识别。
        std::ostringstream cmd;
        cmd << "mkdir -p '" << aah_paths::root() << "' '" << aah_paths::rules_dir() << "' 2>/dev/null; ";
        cmd << "if command -v setsid >/dev/null 2>&1; then ";
        cmd <<   "AAH_DAEMON=1 MODPATH='" << module_dir << "' setsid sh < '" << launch_script << "' >/dev/null 2>&1 & ";
        cmd << "elif command -v nohup >/dev/null 2>&1; then ";
        cmd <<   "AAH_DAEMON=1 MODPATH='" << module_dir << "' nohup sh < '" << launch_script << "' >/dev/null 2>&1 & ";
        cmd << "else ";
        cmd <<   "(AAH_DAEMON=1 MODPATH='" << module_dir << "' sh < '" << launch_script << "' >/dev/null 2>&1 &) ";
        cmd << "fi";

        (void)std::system(cmd.str().c_str());

        // 等待 PID 文件出现并通过身份校验（最多 4 秒）
        for (int i = 0; i < 40; ++i) {
            usleep(100000);
            if (is_running()) return true;
        }
        return is_running();
    }

    bool stop() {
        int pid = read_pid();
        if (pid > 1) {
            kill(pid, SIGTERM);
            for (int i = 0; i < 30; ++i) {
                usleep(100000);
                if (kill(pid, 0) != 0 && errno != EPERM) break;
            }
            if (kill(pid, 0) == 0 || errno == EPERM) {
                kill(pid, SIGKILL);
            }
        }
        // 兜底清理"旧版守护"(旧版 cmdline 含 aah_launch.sh)；新版 cmdline 已伪装为
        // 中性 sh，靠上面的 aah.pid 精确终止，不在此按名字 pkill，以免误杀其它 sh。
        std::system("pkill -f aah_launch.sh 2>/dev/null");
        unlink(aah_paths::pid_file().c_str());
        unlink(aah_paths::lock_pid_file().c_str());
        return true;
    }

    bool restart(const std::string& module_dir) {
        stop();
        usleep(300000);
        return start(module_dir);
    }

    // 确保"指定版本"的守护进程在运行：
    //  - 没跑 → 启动
    //  - 在跑但版本不同（覆盖安装后旧脚本残留）→ 替换重启
    //  - 在跑且版本一致 → 不动
    // 返回最终是否有守护进程在运行。
    bool ensure_version(const std::string& module_dir, const std::string& expect_version) {
        if (is_running()) {
            std::string cur = running_version();
            // 版本文件读不到时保守地不重启（避免无谓抖动）；版本明确不一致才替换
            if (!cur.empty() && !expect_version.empty() && cur != expect_version) {
                return restart(module_dir);
            }
            return true;
        }
        return start(module_dir);
    }

private:
    static int read_pid() {
        std::ifstream f(aah_paths::pid_file());
        if (!f.is_open()) return 0;
        int pid = 0;
        f >> pid;
        return pid;
    }
    static std::string read_file(const std::string& path) {
        std::ifstream f(path, std::ios::binary);
        if (!f.is_open()) return "";
        std::ostringstream ss;
        ss << f.rdbuf();
        return ss.str();
    }
};
