// ============================================================================
//  aah_config_manager.h — 配置管理
//  管理运行模式配置（禁用 / 仅前台 / 后台保持），持久化到 SDK 磁盘存储，
//  并把标记文件同时写到【模块目录】和【必定可写的数据目录】供 shell 读取
//  （双写双读：防止部分环境模块目录只读导致 WebUI 配置不生效）
// ============================================================================
#pragma once
#include <string>
#include <cstdio>
#include <cstring>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fstream>
#include <sstream>
#include "kernel_module_kit_umbrella.h"
#include "aah_paths.h"

class AahConfigManager {
public:
    AahConfigManager() = default;

    void init(const std::string& module_dir) {
        m_module_dir = module_dir;
        load();
    }

    std::string to_json() const {
        std::ostringstream oss;
        oss << "{\"disabled\":" << (m_disabled ? "true" : "false")
            << ",\"foreground_only\":" << (m_foreground_only ? "true" : "false")
            << ",\"keep_background\":" << (m_keep_background ? "true" : "false")
            << ",\"force_stop\":" << (m_force_stop ? "true" : "false")
            << "}";
        return oss.str();
    }

    void from_json(const std::string& json) {
        m_disabled = json_bool_value(json, "disabled");
        m_foreground_only = json_bool_value(json, "foreground_only");
        m_keep_background = json_bool_value(json, "keep_background");
        // 缺省(老配置无此字段)保持默认开启，仅显式给出时覆盖
        if (json.find("\"force_stop\"") != std::string::npos)
            m_force_stop = json_bool_value(json, "force_stop");
        save();
    }

    // 将开关标志写到模块私有目录（= aah_paths 配置根，受框架隐藏保护，供 shell 读取）
    void apply_flags(const std::string& module_dir) {
        mkdir(aah_paths::root().c_str(), 0755);
        // module_dir 与 aah_paths::root() 同为模块私有目录，双写为同点幂等写，保留结构
        write_flag_dual(module_dir + "/.aah_disabled",
                        aah_paths::flag_file(".aah_disabled"), m_disabled);
        write_flag_dual(module_dir + "/.aah_foreground_only",
                        aah_paths::flag_file(".aah_foreground_only"), m_foreground_only);
        // 后台保持：互斥双标记(true→.aah_keep_background；false→.aah_no_keep_background)
        write_flag_dual(module_dir + "/.aah_keep_background",
                        aah_paths::flag_file(".aah_keep_background"), m_keep_background);
        write_flag_dual(module_dir + "/.aah_no_keep_background",
                        aah_paths::flag_file(".aah_no_keep_background"), !m_keep_background);
        // 强停开关默认开：写互斥双标记(true→.aah_force_stop；false→.aah_no_force_stop)
        write_flag_dual(module_dir + "/.aah_force_stop",
                        aah_paths::flag_file(".aah_force_stop"), m_force_stop);
        write_flag_dual(module_dir + "/.aah_no_force_stop",
                        aah_paths::flag_file(".aah_no_force_stop"), !m_force_stop);
    }

    bool is_disabled() const { return m_disabled; }
    bool is_foreground_only() const { return m_foreground_only; }
    bool is_keep_background() const { return m_keep_background; }
    bool is_force_stop() const { return m_force_stop; }

private:
    std::string m_module_dir;
    bool m_disabled = false;
    bool m_foreground_only = false;
    bool m_keep_background = true; // 默认开启后台保持（与 shell 默认一致）
    bool m_force_stop = true;      // 默认强停风险App进程（方案A，与 shell 默认一致）
    static constexpr const char* KEY_CONFIG = "aah_config_json";

    void load() {
        std::string json;
        if (is_ok(kernel_module::read_string_disk_storage(KEY_CONFIG, json)) && !json.empty()) {
            from_json_internal(json);
        }
    }
    void save() {
        std::string json = to_json();
        kernel_module::write_string_disk_storage(KEY_CONFIG, json.c_str());
    }
    void from_json_internal(const std::string& json) {
        m_disabled = json_bool_value(json, "disabled");
        m_foreground_only = json_bool_value(json, "foreground_only");
        m_keep_background = json_bool_value(json, "keep_background");
        if (json.find("\"force_stop\"") != std::string::npos)
            m_force_stop = json_bool_value(json, "force_stop");
    }

    static size_t value_pos(const std::string& json, const std::string& key) {
        std::string pat = "\"" + key + "\"";
        size_t p = json.find(pat);
        if (p == std::string::npos) return std::string::npos;
        p += pat.size();
        while (p < json.size() &&
               (json[p]==' '||json[p]=='\t'||json[p]=='\n'||json[p]=='\r')) p++;
        if (p >= json.size() || json[p] != ':') return std::string::npos;
        p++;
        while (p < json.size() &&
               (json[p]==' '||json[p]=='\t'||json[p]=='\n'||json[p]=='\r')) p++;
        return p;
    }

    static bool json_bool_value(const std::string& json, const std::string& key) {
        size_t pos = value_pos(json, key);
        if (pos == std::string::npos) return false;
        return json.compare(pos, 4, "true") == 0;
    }

    static void write_one(const std::string& path, bool enabled) {
        if (enabled) {
            std::ofstream f(path);
            if (f.is_open()) { f << "1"; f.close(); chmod(path.c_str(), aah_paths::in_local_tmp() ? 0666 : 0644); }
        } else {
            unlink(path.c_str());
        }
    }
    // 双写：模块目录写失败不影响数据目录那份（shell 任一存在即生效）
    static void write_flag_dual(const std::string& mod_path,
                                const std::string& data_path, bool enabled) {
        write_one(mod_path, enabled);
        write_one(data_path, enabled);
    }
};
