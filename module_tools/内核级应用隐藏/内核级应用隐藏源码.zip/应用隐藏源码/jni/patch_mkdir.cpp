// ============================================================================
//  patch_mkdir.cpp — Hook vfs_mkdir，挡"写死 Android/data/<包名> 路径试探"型检测
//  Android 16 GKI 不导出 __arm64_sys_mkdirat，改 hook vfs_mkdir（导出符号）。
//  vfs_mkdir 参数：x0=idmap, x1=dir(inode), x2=dentry, x3=mode
//  dentry->d_name 即目标最后一段名字（检测器 mkdir .../Android/data/<包名>，
//  最后一段就是包名）。basename 命中且非系统进程 → 返回 0（假装创建成功=没装）。
// ============================================================================
#include "patch_mkdir.h"
#include "kernel_offsets/dentry.h"
#include <vector>
using namespace asmjit;
using namespace asmjit::a64;
using namespace asmjit::a64::Predicate;

PatchMkdir::PatchMkdir(const PatchBase& patch_base, uint64_t vfs_mkdir)
    : PatchBase(patch_base), m_vfs_mkdir(vfs_mkdir) {}

PatchMkdir::~PatchMkdir() {}

KModErr PatchMkdir::patch_vfs_mkdir(const std::set<std::string>& pkgs) {
    if (m_vfs_mkdir == 0) return KModErr::ERR_MODULE_PARAM;

    // dentry->d_name 偏移（qstr：+0 hash, +4 len, +8 name*）
    uint32_t d_name_off = 0;
    if (kernel_module::get_dentry_d_name_offset(d_name_off) != KModErr::OK) {
        return KModErr::ERR_MODULE_PARAM;
    }

    std::vector<std::string> hide_names(pkgs.begin(), pkgs.end());
    if (hide_names.empty()) return KModErr::OK;

    GpX x2_dentry = x2;

    aarch64_asm_ctx asm_ctx = init_aarch64_asm();
    auto a = asm_ctx.assembler();
    Label L_allow = a->newLabel();

    kernel_module::arm64_before_hook_start(a);

    // 注意：不能按 euid 放行——检测器正是用 su(root,euid=0) 跑 mkdir 探测的。
    // 只要目标最后一段名命中包名，无论谁调用都返回 0（让它以为创建成功）。
    // 包名是固定的（如 bin.mt.plus.canary），系统进程不会 mkdir 这种名字，安全。

    // x11 = &dentry->d_name
    a->mov(x11, x2_dentry);
    a->add(x11, x11, d_name_off);
    // w12 = d_name.len（qstr+4）；x13 = d_name.name（qstr+8，内核态指针）
    a->ldr(w12, ptr(x11, 4));
    a->ldr(x13, ptr(x11, 8));

    for (const auto& name : hide_names) {
        Label L_next = a->newLabel();
        aarch64_asm_mov_w(a, w14, (uint32_t)name.size());
        a->cmp(w12, w14);
        a->b(CondCode::kNE, L_next);
        {
            RegProtectGuard g(a, x0);
            aarch64_asm_set_x_cstr_ptr(a, x15, name);
            kernel_module::string_ops::kmemcmp(a, x13, x15, x14);
            a->mov(x16, x0);
        }
        a->cbnz(x16, L_next);
        // 命中：vfs_mkdir 返回 0（成功），检测器以为创建成功=目标不存在
        a->mov(x0, xzr);
        kernel_module::arm64_before_hook_end(a, false);
        a->bind(L_next);
    }

    a->bind(L_allow);
    kernel_module::arm64_before_hook_end(a, true);
    return patch_kernel_before_hook(m_vfs_mkdir, a);
}
