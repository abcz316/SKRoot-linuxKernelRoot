// ============================================================================
//  patch_base.h — 内核 filldir hook 的公共基座（改造自 SKRoot 官方示例）
//  进程可见性判定被改为：系统保留 uid(euid<10000，含 root/system/shell 等)
//  放行；普通应用 uid(euid>=10000，含多用户/isolated) 命中隐藏规则即隐藏。
// ============================================================================
#pragma once
#include <iostream>
#include <vector>
#include "kernel_module_kit_umbrella.h"

#ifndef MY_FIRST_APP_UID
#define MY_FIRST_APP_UID 10000  // Android FIRST_APPLICATION_UID
#endif

class PatchBase {
public:
    PatchBase(uint32_t task_struct_offset_cred, uint32_t cred_euid_offset);
    PatchBase(const PatchBase& other);
    ~PatchBase();

    // 取出本次安装得到的 hook 句柄（用于后续卸载/热更新）
    kernel_module::HookHandle take_handle() { return m_hook_handle; }
protected:
    uint32_t m_task_struct_offset_cred = 0;
    uint32_t m_cred_euid_offset = 0;
    kernel_module::HookHandle m_hook_handle = nullptr;

    // 生成"当前进程是否放行可见"判定，结果放 x10：
    //   x10=1 放行（系统/root 进程，能看到全部目录项）
    //   x10=0 不放行（普通 App，继续后面的 name/inode 隐藏匹配）
    void emit_check_current_allow_visible_to_x10(asmjit::a64::Assembler* a);

    KModErr patch_kernel_before_hook(uint64_t kaddr, const asmjit::a64::Assembler* a);
};
