// ============================================================================
//  aah_rule_manager.h — 隐藏规则管理
//  规则以 .conf 文件存储在 RULES_DIR 下，文件名 = 目标包名，内容 = 要隐藏的应用包名列表
//  同时提供 JSON 序列化用于 WebUI
// ============================================================================
#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cctype>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <filesystem>
#include "aah_paths.h"
namespace fs = std::filesystem;

struct AahRule {
    std::string game_pkg;
    std::vector<std::string> hide_apps;
};

class AahRuleManager {
public:
    AahRuleManager() = default;

    void init(const std::string& rules_dir) {
        m_rules_dir = rules_dir;
        fs::create_directories(rules_dir);
        // 模块私有目录(root)只需 0755；仅旧 /data/local/tmp 兜底位置才放开 0777 供跨进程读写
        chmod(rules_dir.c_str(), aah_paths::in_local_tmp() ? 0777 : 0755);
    }

    // 序列化为 JSON: {"games":[{"pkg":"xxx","apps":["a","b"]}, ...]}
    std::string to_json() {
        auto rules = load_all();
        std::ostringstream oss;
        oss << "{\"games\":[";
        for (size_t i = 0; i < rules.size(); ++i) {
            if (i) oss << ",";
            oss << "{\"pkg\":\"" << json_escape(rules[i].game_pkg) << "\",\"apps\":[";
            for (size_t j = 0; j < rules[i].hide_apps.size(); ++j) {
                if (j) oss << ",";
                oss << "\"" << json_escape(rules[i].hide_apps[j]) << "\"";
            }
            oss << "]}";
        }
        oss << "]}";
        return oss.str();
    }

    // 全量规则打包（= to_json），用于冗余到框架磁盘存储，防覆盖升级清空模块目录丢规则
    std::string bundle() { return to_json(); }

    // 从全量打包 {"games":[{"pkg":"g","apps":["a","b"]}, ...]} 重建 .conf 文件。
    // 仅在 rules 目录为空（如覆盖升级后）时由主模块调用；返回恢复的规则条数。
    int restore_bundle(const std::string& json) {
        size_t p = json_value_pos(json, "games");
        if (p == std::string::npos || p >= json.size() || json[p] != '[') return 0;
        int restored = 0;
        size_t i = p + 1;
        while (i < json.size()) {
            size_t ob = json.find('{', i);
            if (ob == std::string::npos) break;
            // 对象内 apps 是字符串数组、无嵌套花括号，按花括号深度 1 切出单个对象
            int depth = 0; size_t ce = std::string::npos;
            for (size_t k = ob; k < json.size(); ++k) {
                if (json[k] == '{') ++depth;
                else if (json[k] == '}') { --depth; if (depth == 0) { ce = k; break; } }
            }
            if (ce == std::string::npos) break;
            std::string obj = json.substr(ob, ce - ob + 1);
            std::string game = json_string_value(obj, "pkg");
            auto apps = json_string_array(obj, "apps");
            std::vector<std::string> clean;
            std::set<std::string> uniq;
            for (auto& a : apps) {
                if (a == game) continue;  // 同 save_rule 双保险：不隐藏触发应用自身
                if (is_valid_package(a) && uniq.insert(a).second) clean.push_back(a);
            }
            if (is_valid_package(game) && !clean.empty() && save_rule(game, clean)) ++restored;
            i = ce + 1;
        }
        return restored;
    }

    // 从 JSON 添加/更新规则: {"game":"pkg","apps":["a","b"]}
    bool add_from_json(const std::string& json) {
        std::string game = json_string_value(json, "game");
        if (!is_valid_package(game)) return false;
        auto raw = json_string_array(json, "apps");
        std::vector<std::string> apps;
        std::set<std::string> uniq;
        for (auto& a : raw) {
            // 绝不隐藏触发应用自身：否则它一进前台就被自己的规则 pm hide，目标会立刻退回桌面
            if (a == game) continue;
            if (is_valid_package(a) && uniq.insert(a).second) apps.push_back(a);
        }
        if (apps.empty()) return false;
        return save_rule(game, apps);
    }

    // 从 JSON 删除规则: {"game":"pkg"}
    bool delete_from_json(const std::string& json) {
        std::string game = json_string_value(json, "game");
        if (!is_valid_package(game)) return false;
        return delete_rule(game);
    }

    bool save_rule(const std::string& game_pkg, const std::vector<std::string>& apps) {
        if (!is_valid_package(game_pkg)) return false;
        fs::create_directories(m_rules_dir);
        std::string path = m_rules_dir + "/" + game_pkg + ".conf";
        // 原子写：先写 .tmp 再 rename，避免 shell 守护每轮热读时读到半写文件
        std::string tmp = path + ".tmp";
        {
            std::ofstream f(tmp, std::ios::trunc);
            if (!f.is_open()) return false;
            for (const auto& app : apps) {
                // 双保险：写盘时也排除触发应用自身
                if (is_valid_package(app) && app != game_pkg) f << app << "\n";
            }
            f.flush();
            f.close();
            if (!f) return false;
        }
        chmod(tmp.c_str(), aah_paths::in_local_tmp() ? 0666 : 0644);
        if (std::rename(tmp.c_str(), path.c_str()) != 0) {
            unlink(tmp.c_str());
            return false;
        }
        return true;
    }

    bool delete_rule(const std::string& game_pkg) {
        if (!is_valid_package(game_pkg)) return false;
        std::string path = m_rules_dir + "/" + game_pkg + ".conf";
        return unlink(path.c_str()) == 0;
    }

    std::vector<AahRule> load_all() {
        std::vector<AahRule> result;
        DIR* dir = opendir(m_rules_dir.c_str());
        if (!dir) return result;
        struct dirent* entry;
        while ((entry = readdir(dir)) != nullptr) {
            std::string name = entry->d_name;
            if (name == "." || name == "..") continue;
            if (name.size() < 6 || name.substr(name.size() - 5) != ".conf") continue;
            AahRule rule;
            rule.game_pkg = name.substr(0, name.size() - 5);
            if (!is_valid_package(rule.game_pkg)) continue;
            std::string path = m_rules_dir + "/" + name;
            std::ifstream f(path);
            if (f.is_open()) {
                std::string line;
                while (std::getline(f, line)) {
                    while (!line.empty() && (line.back() == '\r' || line.back() == '\n' ||
                                             line.back() == ' ' || line.back() == '\t')) {
                        line.pop_back();
                    }
                    if (line.empty() || line[0] == '#') continue;
                    if (is_valid_package(line)) rule.hide_apps.push_back(line);
                }
            }
            result.push_back(std::move(rule));
        }
        closedir(dir);
        std::sort(result.begin(), result.end(),
                  [](const AahRule& a, const AahRule& b) {
                      return a.game_pkg < b.game_pkg;
                  });
        return result;
    }

private:
    std::string m_rules_dir;

    // 严格校验 Android 包名，杜绝 '/' 与 '..' 路径穿越
    static bool is_valid_package(const std::string& pkg) {
        if (pkg.empty() || pkg.size() > 255) return false;
        bool has_dot = false, segment_empty = true;
        for (char c : pkg) {
            if (c == '.') {
                if (segment_empty) return false;
                has_dot = true; segment_empty = true;
            } else if (std::isalnum(static_cast<unsigned char>(c)) || c == '_') {
                segment_empty = false;
            } else {
                return false;
            }
        }
        return has_dot && !segment_empty;
    }

    static std::string json_escape(const std::string& s) {
        std::string out;
        out.reserve(s.size() + 8);
        for (char c : s) {
            switch (c) {
                case '"':  out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\n': out += "\\n";  break;
                case '\r': out += "\\r";  break;
                case '\t': out += "\\t";  break;
                default:
                    if (static_cast<unsigned char>(c) < 0x20) {
                        char buf[8];
                        snprintf(buf, sizeof(buf), "\\u%04x", c);
                        out += buf;
                    } else {
                        out += c;
                    }
            }
        }
        return out;
    }

    // 定位 "key" 后的值起始位置（兼容标准 JSON 中冒号前后的任意空白）
    static size_t json_value_pos(const std::string& json, const std::string& key) {
        std::string pat = "\"" + key + "\"";
        size_t p = json.find(pat);
        if (p == std::string::npos) return std::string::npos;
        p += pat.size();
        auto skip_ws = [&]() {
            while (p < json.size() &&
                   (json[p]==' '||json[p]=='\t'||json[p]=='\n'||json[p]=='\r')) p++;
        };
        skip_ws();
        if (p >= json.size() || json[p] != ':') return std::string::npos;
        p++;
        skip_ws();
        return p;
    }

    static std::string json_string_value(const std::string& json, const std::string& key) {
        size_t pos = json_value_pos(json, key);
        if (pos == std::string::npos || pos >= json.size() || json[pos] != '"') return "";
        pos++;
        std::string result;
        while (pos < json.size() && json[pos] != '"') {
            if (json[pos] == '\\' && pos + 1 < json.size()) {
                pos++;
                switch (json[pos]) {
                    case 'n': result += '\n'; break;
                    case 'r': result += '\r'; break;
                    case 't': result += '\t'; break;
                    case '"': result += '"';  break;
                    case '\\': result += '\\'; break;
                    default:  result += json[pos];
                }
            } else {
                result += json[pos];
            }
            pos++;
        }
        return result;
    }

    static std::vector<std::string> json_string_array(const std::string& json, const std::string& key) {
        std::vector<std::string> result;
        size_t pos = json_value_pos(json, key);
        if (pos == std::string::npos || pos >= json.size() || json[pos] != '[') return result;
        pos++;
        auto end = json.find(']', pos);
        if (end == std::string::npos) return result;
        std::string arr = json.substr(pos, end - pos);
        size_t i = 0;
        while (i < arr.size()) {
            auto q1 = arr.find('"', i);
            if (q1 == std::string::npos) break;
            q1++;
            auto q2 = arr.find('"', q1);
            if (q2 == std::string::npos) break;
            std::string item = arr.substr(q1, q2 - q1);
            std::string unescaped;
            for (size_t k = 0; k < item.size(); ++k) {
                if (item[k] == '\\' && k + 1 < item.size()) {
                    k++;
                    switch (item[k]) {
                        case 'n': unescaped += '\n'; break;
                        case 'r': unescaped += '\r'; break;
                        case 't': unescaped += '\t'; break;
                        case '"': unescaped += '"';  break;
                        case '\\': unescaped += '\\'; break;
                        default:  unescaped += item[k];
                    }
                } else {
                    unescaped += item[k];
                }
            }
            if (!unescaped.empty()) result.push_back(unescaped);
            i = q2 + 1;
        }
        return result;
    }
};
