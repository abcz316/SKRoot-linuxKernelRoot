// ============================================================================
//  aah_app_utils.h — 应用列表工具
//  性能要点：只执行一次 "pm list packages" 拿到全部包名，绝不对每个包
//  单独执行 dumpsys / resolve-activity（那样 N 个应用会 fork N 次，卡死 WebUI）。
//  触发应用与"要隐藏的应用"都使用同一份全量列表（第三方+系统），保证用户
//  一定能选到目标；系统核心 App 标记 protected，前端在"要隐藏"列表里禁选。
// ============================================================================
#pragma once
#include <string>
#include <vector>
#include <set>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sstream>
#include <algorithm>
struct AppInfo {
    std::string pkg;
    std::string label;
    bool is_system = false;  // 系统应用（pm list packages -3 之外的）
    bool protected_app = false;  // 系统核心，不可隐藏（须与 shell AAH_PROTECT_PKGS 同步）
};
class AahAppUtils {
public:
    // 获取全部已安装应用（第三方+系统），单次命令流式解析
    static std::vector<AppInfo> get_installed_apps() {
        std::vector<AppInfo> result;
        result.reserve(256);
        std::set<std::string> seen;
        std::set<std::string> third_party;
        // 先取第三方名单，用于标记 is_system
        collect_pkg_set("pm list packages -3 2>/dev/null", third_party);
        // 全量应用（第三方+系统）
        collect_packages_from_cmd("pm list packages 2>/dev/null", result, seen, third_party);
        // 兜底：模块常驻进程未必具备执行 pm 的 zygote 环境，直接遍历常见安装目录
        collect_from_dir("/data/app", result, seen, third_party, true);
        collect_from_dir("/system/app", result, seen, third_party, false);
        collect_from_dir("/system/priv-app", result, seen, third_party, false);
        collect_from_dir("/product/app", result, seen, third_party, false);
        collect_from_dir("/product/priv-app", result, seen, third_party, false);
        collect_from_dir("/vendor/app", result, seen, third_party, false);
        // 按 label、pkg 排序
        std::sort(result.begin(), result.end(), [](const AppInfo& a, const AppInfo& b) {
            if (a.label != b.label) return a.label < b.label;
            return a.pkg < b.pkg;
        });
        return result;
    }
private:
    // 系统核心保护名单：必须与 shell AAH_PROTECT_PKGS 保持一致
    static bool is_protected_pkg(const std::string& pkg) {
        // 必须与 aah_native_daemon.cpp 的保护名单保持一致
        static const char* list[] = {
            "com.android.systemui",
            "com.android.settings",
            "com.android.phone",
            "com.android.dialer",
            "com.android.incallui",
            "com.google.android.dialer",
            "com.android.server.telecom",
            "com.miui.home",
            "com.android.launcher3",
            "com.google.android.gms",
            "com.android.providers.downloads",
        };
        for (const char* p : list) {
            if (pkg == p) return true;
        }
        return false;
    }
    // 只收集包名到 set（用于标记第三方）
    static void collect_pkg_set(const char* cmd, std::set<std::string>& out) {
        FILE* pipe = popen(cmd, "r");
        if (!pipe) return;
        char buf[512];
        std::string line;
        while (fgets(buf, sizeof(buf), pipe)) {
            line.assign(buf);
            while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
            if (line.compare(0, 8, "package:") == 0) out.insert(line.substr(8));
        }
        pclose(pipe);
    }
    static void collect_packages_from_cmd(const char* cmd,
                                          std::vector<AppInfo>& out,
                                          std::set<std::string>& seen,
                                          const std::set<std::string>& third_party) {
        FILE* pipe = popen(cmd, "r");
        if (!pipe) return;
        char buf[512];
        std::string line;
        while (fgets(buf, sizeof(buf), pipe)) {
            line.assign(buf);
            while (!line.empty() && line.back() != '\n' && !feof(pipe)) {
                if (!fgets(buf, sizeof(buf), pipe)) break;
                line += buf;
            }
            while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
            if (line.compare(0, 8, "package:") != 0) continue;
            add_pkg_once(line.substr(8), out, seen, third_party);
        }
        pclose(pipe);
    }
    static std::string last_segment(const std::string& pkg) {
        auto pos = pkg.rfind('.');
        if (pos != std::string::npos && pos + 1 < pkg.size()) return pkg.substr(pos + 1);
        return pkg;
    }
    static bool looks_like_package(const std::string& s) {
        if (s.empty() || s.size() > 255) return false;
        bool has_dot = false, seg_empty = true;
        for (char c : s) {
            if (c == '.') {
                if (seg_empty) return false;
                has_dot = true; seg_empty = true;
            } else if (std::isalnum(static_cast<unsigned char>(c)) || c == '_') {
                seg_empty = false;
            } else {
                return false;
            }
        }
        return has_dot && !seg_empty;
    }
    static std::string pkg_from_leaf(const std::string& leaf) {
        auto dash = leaf.find('-');
        std::string pkg = (dash == std::string::npos) ? leaf : leaf.substr(0, dash);
        return looks_like_package(pkg) ? pkg : std::string();
    }
    static void add_pkg_once(const std::string& pkg,
                             std::vector<AppInfo>& out, std::set<std::string>& seen,
                             const std::set<std::string>& third_party) {
        if (pkg.empty() || !seen.insert(pkg).second) return;
        AppInfo info;
        info.pkg = pkg;
        info.label = last_segment(pkg);
        info.is_system = (third_party.find(pkg) == third_party.end());
        info.protected_app = is_protected_pkg(pkg);
        out.push_back(std::move(info));
    }
    static void collect_from_dir(const std::string& dir,
                                 std::vector<AppInfo>& out,
                                 std::set<std::string>& seen,
                                 const std::set<std::string>& third_party,
                                 bool allow_descend) {
        DIR* d = opendir(dir.c_str());
        if (!d) return;
        struct dirent* e = nullptr;
        while ((e = readdir(d)) != nullptr) {
            std::string name = e->d_name;
            if (name == "." || name == "..") continue;
            std::string path = dir + "/" + name;
            struct stat st{};
            if (stat(path.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) continue;
            if (allow_descend && name.size() >= 2 && name[0] == '~' && name[1] == '~') {
                collect_from_dir(path, out, seen, third_party, false);
            } else {
                add_pkg_once(pkg_from_leaf(name), out, seen, third_party);
            }
        }
        closedir(d);
    }
};
