// ============================================================================
//  patch_compat_filldir.cpp — Hook compat_filldir（32 位兼容路径）
//  汇编主体与 patch_filldir64 对齐，严格沿用 SKRoot 官方实现
// ============================================================================
#include "patch_compat_filldir.h"
#include <vector>
using namespace asmjit;
using namespace asmjit::a64;
using namespace asmjit::a64::Predicate;

PatchCompatFilldir::PatchCompatFilldir(const PatchBase& patch_base,
                                       uint64_t compat_filldir)
    : PatchBase(patch_base), m_compat_filldir(compat_filldir) {}

PatchCompatFilldir::~PatchCompatFilldir() {}

KModErr PatchCompatFilldir::patch_compat_filldir(const std::set<std::string>& names,
                                                 const std::set<uint64_t>& ino_set) {
    GpX x1_name = x1;
    GpW w2_namelen = w2;
    GpX x4_ino = x4;

    std::vector<std::string> hide_names(names.begin(), names.end());
    std::vector<uint64_t> hide_inos(ino_set.begin(), ino_set.end());

    aarch64_asm_ctx asm_ctx = init_aarch64_asm();
    auto a = asm_ctx.assembler();
    Label L_allow_visible = a->newLabel();

    kernel_module::arm64_before_hook_start(a);

    emit_check_current_allow_visible_to_x10(a);
    a->cbnz(x10, L_allow_visible);

    for (size_t i = 0; i < hide_names.size(); ++i) {
        Label L_next = a->newLabel();
        const auto& dir_name = hide_names[i];
        aarch64_asm_mov_w(a, w11, dir_name.length());
        a->cmp(w2_namelen, w11);
        a->b(CondCode::kNE, L_next);

        aarch64_asm_set_x_cstr_ptr(a, x12, dir_name);
        {
            RegProtectGuard g1(a, x0);
            kernel_module::string_ops::kmemcmp(a, x1_name, x12, x11);
            a->mov(x11, x0);
        }
        a->cbnz(x11, L_next);

        a->mov(x0, xzr);  // 返回0=上层继续遍历；非0会截断目录列表
        kernel_module::arm64_before_hook_end(a, false);
        a->bind(L_next);
    }

    for (size_t i = 0; i < hide_inos.size(); ++i) {
        Label L_next = a->newLabel();
        aarch64_asm_mov_x(a, x11, hide_inos[i]);
        a->cmp(x4_ino, x11);
        a->b(CondCode::kNE, L_next);

        a->mov(x0, xzr);  // 返回0=上层继续遍历；非0会截断目录列表
        kernel_module::arm64_before_hook_end(a, false);
        a->bind(L_next);
    }

    a->bind(L_allow_visible);
    kernel_module::arm64_before_hook_end(a, true);
    return patch_kernel_before_hook(m_compat_filldir, a);
}
