#!/bin/bash
# ============================================================================
#  build.sh — 编译 module_app_auto_hider
#
#  使用方法：
#    1. 修改下方 NDK_PATH 为你的 NDK 路径
#    2. 确保 kernel_module_kit 目录在 ../kernel_module_kit（或修改 KIT_PATH）
#    3. 运行 ./build.sh
# ============================================================================

set -e

# ---- 配置区 ----
# NDK 路径（请修改为你的实际路径）
NDK_PATH="/path/to/your/android-ndk"
# kernel_module_kit SDK 路径（默认在上一级目录）
KIT_PATH="$(cd "$(dirname "$0")/../kernel_module_kit" && pwd)"

# ---- 检查 ----
if [ ! -d "$NDK_PATH" ]; then
    echo "[ERROR] NDK 路径不存在: $NDK_PATH"
    echo "        请修改 build.sh 中的 NDK_PATH 变量"
    exit 1
fi

if [ ! -d "$KIT_PATH" ]; then
    echo "[ERROR] kernel_module_kit 路径不存在: $KIT_PATH"
    echo "        请确保 SDK 在正确位置，或修改 KIT_PATH"
    exit 1
fi

if [ ! -f "$KIT_PATH/lib/libkernel_module_kit.a" ]; then
    echo "[ERROR] 未找到预编译库: $KIT_PATH/lib/libkernel_module_kit.a"
    echo "        请先编译 kernel_module_kit（运行其 build_lib.bat）"
    exit 1
fi

echo "[INFO] NDK_PATH = $NDK_PATH"
echo "[INFO] KIT_PATH = $KIT_PATH"
echo "[INFO] 开始编译..."

# ---- 编译 ----
cd "$(dirname "$0")"

export KIT_PATH="$KIT_PATH"

"$NDK_PATH/ndk-build" \
    NDK_PROJECT_PATH=. \
    APP_BUILD_SCRIPT=./Android.mk \
    NDK_APPLICATION_MK=./Application.mk \
    -j$(nproc)

# ---- 结果 ----
SO_PATH="./libs/arm64-v8a/module_app_auto_hider.so"
if [ -f "$SO_PATH" ]; then
    echo ""
    echo "[SUCCESS] 编译成功!"
    echo "          输出: $SO_PATH"
    echo ""
    echo "          模块大小: $(du -h "$SO_PATH" | cut -f1)"
else
    echo "[ERROR] 编译失败，未找到输出文件"
    exit 1
fi
