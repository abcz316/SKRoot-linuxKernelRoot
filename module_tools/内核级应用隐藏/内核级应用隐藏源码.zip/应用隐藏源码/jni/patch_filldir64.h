#pragma once
#include <iostream>
#include <set>
#include "patch_base.h"

// Hook 内核 filldir64（64 位 getdents 列目录路径），命中规则的目录项不返回给调用方
class PatchFilldir64 : public PatchBase {
public:
    PatchFilldir64(const PatchBase& patch_base, uint64_t filldir64);
    ~PatchFilldir64();

    KModErr patch_filldir64(const std::set<std::string>& names,
                            const std::set<uint64_t>& ino_set);
private:
    uint64_t m_filldir64 = 0;
};
