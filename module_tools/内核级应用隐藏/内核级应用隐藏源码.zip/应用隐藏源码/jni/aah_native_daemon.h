#pragma once
#include <string>
#include <vector>
#include <set>
#include <mutex>
#include "aah_paths.h"

// 原生守护进程：fork+setsid 独立常驻，不寄生在 SKRoot 加载模块的短命上下文里。
// 开机 L2 起后由 init 收养，独立存活；与 WebUI/加载进程通过 aah.pid、标记文件通信。
class AahNativeDaemon {
public:
    static AahNativeDaemon& instance();

    // 启动守护进程（幂等；已有活的守护进程则不重复 fork）
    void start(const std::string& module_dir);
    // 停止守护进程（kill 子进程）
    void stop();
    bool is_running() const { return running_; }

private:
    AahNativeDaemon() = default;
    ~AahNativeDaemon();

    void run();
    
    // 获取前台应用包名
    std::string get_foreground_app();
    // 获取所有用户 ID
    std::vector<std::string> get_users();
    // 读取规则：返回 {触发应用 -> [隐藏应用列表]}
    std::vector<std::pair<std::string, std::vector<std::string>>> load_rules();
    // 执行 shell 命令并返回输出
    std::string exec(const std::string& cmd);
    // 隐藏应用
    bool hide_app(const std::string& pkg, const std::vector<std::string>& users, bool force_stop);
    // 恢复应用
    bool restore_app(const std::string& pkg, const std::vector<std::string>& users);
    // 强停应用
    void force_stop_app(const std::string& pkg, const std::vector<std::string>& users);
    // 写日志
    void log(const std::string& msg);
    // 写状态文件
    void write_state(const std::set<std::string>& hidden);
    // 读状态文件
    std::set<std::string> read_state();
    
    bool running_ = false;
    bool stop_requested_ = false;
    pid_t child_pid_ = 0;
    std::string module_dir_;
    std::string data_dir_;   // start() 时取 aah_paths::root()（模块私有目录）
    std::set<std::string> current_hidden_;
    std::mutex mtx_;
};
