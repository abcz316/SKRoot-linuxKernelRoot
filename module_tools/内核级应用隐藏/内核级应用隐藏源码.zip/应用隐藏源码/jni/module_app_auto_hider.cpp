// ============================================================================
//  module_app_auto_hider — 应用自动隐藏 (SKRoot Pro 内核模块)
//
//  功能：检测指定目标进入前台时，自动隐藏（pm hide / suspend）配置的应用；
//        目标离开前台后恢复。支持后台保持、多用户、内存压力保护等。
//
//  架构：本 so 负责 WebUI REST API + 守护进程管理 + 配置/规则持久化；
//        核心隐藏逻辑由 common/aah_launch.sh 以后台守护进程方式运行。
// ============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <regex>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <signal.h>
#include <wait.h>
#include <mutex>
#include <filesystem>

#include "kernel_module_kit_umbrella.h"
#include "aah_paths.h"
#include "aah_native_daemon.h"
#include "aah_config_manager.h"
#include "aah_rule_manager.h"
#include "aah_app_utils.h"
#include "aah_kernel_hider.h"

namespace fs = std::filesystem;

// ---------------------------------------------------------------------------
// 全局常量（用宏，便于和字符串字面量拼接）
// ---------------------------------------------------------------------------
static constexpr const char* MODULE_TAG = "[app_auto_hider]";
// 与 SKROOT_MODULE_VERSION、shell 的 AAH_VERSION 保持一致，用于升级时替换旧守护进程
static constexpr const char* AAH_VERSION = "1.8.3";
// 运行期数据路径统一由 aah_paths 提供，配置根 = SKPro 模块私有目录（受隐藏保护）

// ---------------------------------------------------------------------------
// 内核级目录隐藏（L2）：全模块唯一实例，保证对 filldir64 只安装一份 hook；
// 启动时、规则增删时、WebUI 打开时重复调用 apply 都会先卸载旧 hook 再装新的，幂等。
// ---------------------------------------------------------------------------
static AahKernelHider g_kernel_hider;

// 汇总所有规则里"要隐藏的 App"包名（跨触发应用去重）——勾选的每一个都生效
static std::set<std::string> collect_all_hide_pkgs(AahRuleManager& rules) {
    std::set<std::string> pkgs;
    for (const auto& rule : rules.load_all()) {
        for (const auto& app : rule.hide_apps) pkgs.insert(app);
    }
    return pkgs;
}
// 规则 .conf 落在模块私有目录；覆盖升级时框架若先清空模块目录，文件规则会丢，
// 而框架磁盘存储(disk_storage)不随模块目录删除。故每次改规则都冗余一份全量 JSON，
// 启动时若 .conf 为空则从冗余重建，保证升级/重装后规则不丢。
static constexpr const char* KEY_RULES = "aah_rules_json";
static void persist_rules_to_disk(AahRuleManager& rules) {
    (void)kernel_module::write_string_disk_storage(KEY_RULES, rules.bundle().c_str());
}
static void restore_rules_from_disk(AahRuleManager& rules) {
    if (!rules.load_all().empty()) return;   // 目录里已有 .conf，以文件为准，不覆盖
    std::string json;
    if (is_ok(kernel_module::read_string_disk_storage(KEY_RULES, json)) && !json.empty()) {
        int n = rules.restore_bundle(json);
        if (n > 0) printf("%s restored %d rules from disk storage\n", MODULE_TAG, n);
    }
}

// 读取常驻守护 sh 的 PID，同步给内核隐藏层：让普通 App/目标反作弊枚举 /proc
// 进程名单时看不到本模块守护进程。set_self_pids 内部相同则不重装，可高频调用。
static void sync_kernel_self_pids() {
    std::set<uint32_t> pids;
    std::ifstream f(aah_paths::pid_file());
    int pid = 0;
    if (f && (f >> pid) && pid > 1) pids.insert(static_cast<uint32_t>(pid));
    g_kernel_hider.set_self_pids(pids);
}

// ---------------------------------------------------------------------------
// 工具：执行 shell 命令并获取输出
// ---------------------------------------------------------------------------
static std::string exec_cmd(const std::string& cmd) {
    std::string result;
    FILE* pipe = popen(cmd.c_str(), "r");
    if (!pipe) return result;
    char buf[512];
    while (fgets(buf, sizeof(buf), pipe)) {
        result += buf;
    }
    pclose(pipe);
    while (!result.empty() && (result.back() == '\n' || result.back() == '\r')) {
        result.pop_back();
    }
    return result;
}

// ---------------------------------------------------------------------------
// 工具：后台执行命令（不等待，用于卸载清理等耗时操作）
// ---------------------------------------------------------------------------
static void exec_cmd_background(const std::string& cmd) {
    std::string full = "(" + cmd + ") >/dev/null 2>&1 &";
    if (FILE* p = popen(full.c_str(), "r")) pclose(p);
}

// ---------------------------------------------------------------------------
// 工具：把旧版 /data/local/tmp/app_auto_hider 里的运行数据一次性迁移到模块私有目录
// （rules 规则、presets、状态、开关标志）。目标已存在的文件不覆盖，迁移完不删源。
// ---------------------------------------------------------------------------
static void migrate_legacy_data() {
    const std::string legacy = aah_paths::LEGACY_DIR;
    const std::string root   = aah_paths::root();
    if (root == legacy) return;                 // 仍在兜底位置则无需迁移
    if (!fs::exists(legacy)) return;            // 没有旧目录
    fs::create_directories(aah_paths::rules_dir());
    // cp -an：保留属性、不覆盖已存在文件；逐项拷贝，缺哪个补哪个
    std::string c;
    c += "S='" + legacy + "'; D='" + root + "'; ";
    c += "mkdir -p \"$D/rules\" 2>/dev/null; ";
    c += "[ -d \"$S/rules\" ] && cp -an \"$S/rules/.\" \"$D/rules/\" 2>/dev/null; ";
    c += "for f in presets.json aah.state .aah_disabled .aah_foreground_only ";
    c += ".aah_keep_background .aah_no_keep_background .aah_force_stop .aah_no_force_stop; do ";
    c += "[ -f \"$S/$f\" ] && [ ! -e \"$D/$f\" ] && cp -a \"$S/$f\" \"$D/$f\" 2>/dev/null; ";
    c += "done; true";
    exec_cmd(c);
}

// ---------------------------------------------------------------------------
// 工具：确保数据目录存在并设置权限/SELinux 上下文
//   - 模块私有目录(/data/adb 下，受框架隐藏保护)：只建目录，保持框架自身上下文，
//     不 chmod 0777、不 chcon（普通 App 在 DAC 层就进不了 /data/adb，无需放开权限）；
//   - 兜底的 /data/local/tmp：保留旧行为（0777 + shell_data_file，供 shell 读写）。
// ---------------------------------------------------------------------------
static void ensure_data_dirs() {
    migrate_legacy_data();
    fs::create_directories(aah_paths::rules_dir());
    if (aah_paths::in_local_tmp()) {
        chmod(aah_paths::root().c_str(), 0777);
        chmod(aah_paths::rules_dir().c_str(), 0777);
        exec_cmd("chcon -R u:object_r:shell_data_file:s0 '" +
                 aah_paths::root() + "' 2>/dev/null || true");
    } else {
        // 模块私有目录：root/框架可读写即可，权限收敛避免 0777 显眼
        chmod(aah_paths::root().c_str(), 0755);
        chmod(aah_paths::rules_dir().c_str(), 0755);
    }
}

// ---------------------------------------------------------------------------
// 工具：读取当前前台应用包名
// 注意：命令内部用 grep 只取关键行，避免把数 MB 的 dumpsys 全量读进内存。
// 包名提取正则与 shell 端 aah_extract_pkg 对齐：(word.)+word/
// ---------------------------------------------------------------------------
static std::string get_foreground_app() {
    static const std::regex kPkgRegex(R"(([a-zA-Z0-9_]+\.)+[a-zA-Z0-9_]+/)");

    // 1) activity：只取第一条 Resumed 行
    std::string line = exec_cmd(
        "dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity|ResumedActivity'");
    std::smatch m;
    if (std::regex_search(line, m, kPkgRegex)) {
        std::string s = m.str();
        s.pop_back(); // 去掉结尾 '/'
        return s;
    }

    // 2) window：mFocusedApp / mCurrentFocus / mFocusedWindow
    line = exec_cmd(
        "dumpsys window 2>/dev/null | grep -m1 -E 'mFocusedApp|mCurrentFocus|mFocusedWindow'");
    if (std::regex_search(line, m, kPkgRegex)) {
        std::string s = m.str();
        s.pop_back();
        return s;
    }
    return "";
}

// ---------------------------------------------------------------------------
// 工具：读取已隐藏应用列表（从 aah.state）
// ---------------------------------------------------------------------------
static std::vector<std::string> get_hidden_apps() {
    std::vector<std::string> result;
    std::ifstream f(aah_paths::state_file());
    if (!f.is_open()) return result;
    std::string line;
    while (std::getline(f, line)) {
        while (!line.empty() && (line.back() == '\r' || line.back() == '\n' ||
                                 line.back() == ' ' || line.back() == '\t')) {
            line.pop_back();
        }
        if (!line.empty()) result.push_back(line);
    }
    return result;
}

// ===========================================================================
// WebUI HTTP Handler — 实现所有 REST API
// ===========================================================================
class AppAutoHiderHandler : public kernel_module::WebUIHttpHandler {
public:
    void onPrepareCreate(const char* root_key, const char* module_private_dir,
                         uint32_t port) override {
        printf("%s WebUI prepare: root_key_len=%zu, dir=%s, port=%u\n",
               MODULE_TAG, strlen(root_key), module_private_dir, port);
        aah_paths::set_root(module_private_dir);   // 配置根 = 模块私有目录
        m_module_dir = module_private_dir;
        m_root_key = root_key;

        ensure_data_dirs();
        m_config.init(module_private_dir);
        m_config.apply_flags(module_private_dir);
        m_rules.init(aah_paths::rules_dir());
        restore_rules_from_disk(m_rules);   // 覆盖升级清空目录时从框架磁盘存储重建规则
        if (m_config.is_disabled()) {
            g_kernel_hider.remove_all();
        } else {
            g_kernel_hider.apply(collect_all_hide_pkgs(m_rules));
        }

        // WebUI 起来时确保正确版本的守护进程在运行（覆盖安装会替换旧版残留）
        if (!m_config.is_disabled()) {
            AahNativeDaemon::instance().start(module_private_dir);
            sync_kernel_self_pids();
        }
    }

    // ---- GET 请求 ----
    bool handleGet(CivetServer* server, struct mg_connection* conn,
                   const std::string& path, const std::string& query) override {
        if (path == "/api/status") {
            // 状态轮询顺带做内核隐藏 inode 漂移自检（内部 15s 节流，无漂移零操作），
            // 覆盖被隐藏 App 更新/重装后安装目录 inode 变化导致的文件层漏隐藏。
            if (!m_config.is_disabled()) {
                g_kernel_hider.refresh_if_drifted();
                sync_kernel_self_pids();
            }
            return send_json(conn, build_status_json());
        }
        if (path == "/api/config") {
            return send_json(conn, m_config.to_json());
        }
        if (path == "/api/rules") {
            return send_json(conn, m_rules.to_json());
        }
        if (path == "/api/games") {
            return send_json(conn, build_games_json());
        }
        if (path == "/api/apps") {
            return send_json(conn, build_apps_json());
        }
        if (path == "/api/log") {
            return send_log(conn);
        }
        return false; // 未匹配，交给静态文件处理
    }

    // ---- POST 请求 ----
    bool handlePost(CivetServer* server, struct mg_connection* conn,
                    const std::string& path, const std::string& body) override {
        // civetweb 每请求一线程：串行化所有写操作，避免并发写配置/规则文件、
        // 并发 start/stop 守护进程造成的中间态或双启动。
        std::lock_guard<std::mutex> post_lock(m_post_mutex);
        printf("%s POST %s body_len=%zu\n", MODULE_TAG, path.c_str(), body.size());

        if (path == "/api/config") {
            // 记录变更前状态：shell 守护进程只在启动时读取一次标记文件，
            // 因此 foreground_only/keep_background/disabled 任一变化都要
            // 重启守护进程才能让新配置真正生效（规则 .conf 则是每轮热读，不用重启）。
            bool was_disabled = m_config.is_disabled();
            bool was_fg_only  = m_config.is_foreground_only();
            bool was_keep_bg  = m_config.is_keep_background();
            bool was_force_stop = m_config.is_force_stop();
            m_config.from_json(body);
            m_config.apply_flags(m_module_dir);

            bool cfg_changed = (was_disabled != m_config.is_disabled()) ||
                               (was_fg_only  != m_config.is_foreground_only()) ||
                               (was_keep_bg  != m_config.is_keep_background()) ||
                               (was_force_stop != m_config.is_force_stop());

            // L2 内核目录隐藏随总开关联动：停用即撤销，启用则按当前勾选重装
            if (m_config.is_disabled()) {
                g_kernel_hider.remove_all();
            } else {
                g_kernel_hider.apply(collect_all_hide_pkgs(m_rules));
            }

            if (m_config.is_disabled()) {
                // 停用：停止守护（原生守护退出前会恢复所有应用）
                AahNativeDaemon::instance().stop();
            } else if (!AahNativeDaemon::instance().is_running()) {
                // 启用但守护进程没在跑（比如之前停用已退出）→ 启动
                AahNativeDaemon::instance().start(m_module_dir);
            } else if (cfg_changed) {
                // 原生守护每轮循环读取配置标记，无需重启
            }
            // 停用已由 remove_all 清掉自身 PID；启用/重启后同步新守护 PID 进内核隐藏
            if (!m_config.is_disabled()) sync_kernel_self_pids();
            return send_json(conn, "{\"ok\":true}");
        }
        if (path == "/api/rules") {
            // 规则文件由守护进程每轮循环自动重读，无需重启（重启反而会中断隐藏状态）
            if (m_rules.add_from_json(body)) {
                // 规则变化：同步重装内核目录隐藏（新增勾选的 App 立即纳入 L2）
                g_kernel_hider.apply(collect_all_hide_pkgs(m_rules));
                persist_rules_to_disk(m_rules);  // 冗余全量规则到框架磁盘存储，防升级丢失
                return send_json(conn, "{\"ok\":true}");
            }
            return send_json(conn, "{\"ok\":false,\"error\":\"invalid rule\"}");
        }
        if (path == "/api/rules/delete") {
            if (m_rules.delete_from_json(body)) {
                // 删除规则后按剩余勾选重装；若已清空，apply 内部会卸载内核 hook
                g_kernel_hider.apply(collect_all_hide_pkgs(m_rules));
                persist_rules_to_disk(m_rules);  // 同步冗余（删除后）到框架磁盘存储
                return send_json(conn, "{\"ok\":true}");
            }
            return send_json(conn, "{\"ok\":false,\"error\":\"delete failed\"}");
        }
        if (path == "/api/daemon") {
            return handle_daemon_action(conn, body);
        }
        if (path == "/api/restore_all") {
            // 一键救回：解除所有用户下被 pm hide/suspend（伪卸载/挂起）的应用
            std::string restored = restore_all_hidden();
            int n = 0;
            for (char c : restored) if (c == '\n') ++n;
            if (!restored.empty() && restored.back() != '\n') ++n;
            std::ostringstream rs;
            rs << "{\"ok\":true,\"restored\":" << n << "}";
            return send_json(conn, rs.str());
        }
        return false;
    }

private:
    std::string m_module_dir;
    std::string m_root_key;
    AahConfigManager m_config;
    AahRuleManager m_rules;
    // native daemon is singleton
    std::mutex m_post_mutex; // 串行化 POST 写操作

    // ---- 构建状态 JSON（running 统一用 is_running 身份校验）----
    std::string build_status_json() {
        bool running = AahNativeDaemon::instance().is_running();
        int pid = 0;
        if (running) {
            std::ifstream f(aah_paths::pid_file());
            f >> pid;
        }
        std::string fg = running ? get_foreground_app() : std::string();
        auto hidden = running ? get_hidden_apps() : std::vector<std::string>();

        std::ostringstream oss;
        oss << "{\"running\":" << (running ? "true" : "false")
            << ",\"pid\":" << (running ? pid : 0)
            << ",\"foreground\":\"" << json_escape(fg) << "\""
            << ",\"hidden\":[";
        for (size_t i = 0; i < hidden.size(); ++i) {
            if (i) oss << ",";
            oss << "\"" << json_escape(hidden[i]) << "\"";
        }
        oss << "]}";
        return oss.str();
    }

    // ---- 构建触发应用列表 JSON ----
    // 触发应用可以是手机内任意第三方应用（不一定是目标：用户可能想"打开 A 时隐藏 B"），
    // 因此直接返回全部第三方应用并带展示名，不再按目标关键词过滤。
    std::string build_games_json() {
        auto apps = AahAppUtils::get_installed_apps();
        std::ostringstream oss;
        oss << "{\"games\":[";
        for (size_t i = 0; i < apps.size(); ++i) {
            if (i) oss << ",";
            oss << "{\"pkg\":\"" << json_escape(apps[i].pkg)
                << "\",\"label\":\"" << json_escape(apps[i].label) << "\""
                << ",\"is_system\":" << (apps[i].is_system ? "true" : "false") << "}";
        }
        oss << "]}";
        return oss.str();
    }

    // ---- 构建应用列表 JSON ----
    std::string build_apps_json() {
        auto apps = AahAppUtils::get_installed_apps();
        std::ostringstream oss;
        oss << "{\"apps\":[";
        for (size_t i = 0; i < apps.size(); ++i) {
            if (i) oss << ",";
            oss << "{\"pkg\":\"" << json_escape(apps[i].pkg)
                << "\",\"label\":\"" << json_escape(apps[i].label) << "\""
                << ",\"is_system\":" << (apps[i].is_system ? "true" : "false")
                << ",\"protected\":" << (apps[i].protected_app ? "true" : "false") << "}";
        }
        oss << "]}";
        return oss.str();
    }

    // ---- 守护进程控制 ----
    bool handle_daemon_action(struct mg_connection* conn, const std::string& raw) {
        std::string action = raw;
        // 去掉引号和空白（前端发的是纯文本 start/stop/restart）
        while (!action.empty() && (action.back() == '"' || action.back() == ' ' ||
                                   action.back() == '\n' || action.back() == '\r')) {
            action.pop_back();
        }
        while (!action.empty() && (action.front() == '"' || action.front() == ' ')) {
            action.erase(action.begin());
        }

        bool ok = false;
        if (action == "start") {
            AahNativeDaemon::instance().start(m_module_dir); ok = true;
            if (ok) sync_kernel_self_pids();
        } else if (action == "stop") {
            AahNativeDaemon::instance().stop(); ok = true;
            g_kernel_hider.set_self_pids({});   // 守护已停，撤销自身进程隐藏
        } else if (action == "restart") {
            AahNativeDaemon::instance().stop(); AahNativeDaemon::instance().start(m_module_dir); ok = true;
            if (ok) sync_kernel_self_pids();
        }
        return send_json(conn, ok ? "{\"ok\":true}" : "{\"ok\":false}");
    }
    // 一键救回：对每个用户，找出"已安装(-u 能列出)但当前不可见"的包——即被
    // pm hide / suspend（伪卸载/挂起）或"对用户卸载"的包——逐个 unhide + unsuspend；
    // 并仅对当前用户补一次 install-existing 救回被对用户卸载的包（对已安装包是幂等
    // no-op，不会 enable 用户手动禁用的应用，也不碰分身用户）。POSIX 兼容、不依赖
    // 规则或 state 残留记录，因此即使规则已删、状态已清也能把卡住的应用救回。
    // stdout 每行输出一个被处理的包名，供前端计数。
    std::string restore_all_hidden() {
        const std::string d = aah_paths::root();
        std::string c;
        c += "D='" + d + "'; ";
        c += "US=$( { am get-current-user 2>/dev/null; cmd user list 2>/dev/null | sed -n 's/.*UserInfo{\\([0-9][0-9]*\\):.*/\\1/p'; echo 0; } | sed '/^[[:space:]]*$/d' | sort -u); ";
        // 当前用户：仅对它补 install-existing（救回被"对用户卸载"的包），分身用户不碰
        c += "CU=$(am get-current-user 2>/dev/null | tr -dc '0-9'); [ -z \"$CU\" ] && CU=0; ";
        c += "for U in $US; do ";
        c +=   "cmd package list packages -u --user $U 2>/dev/null > $D/.k.$U; ";
        c +=   "cmd package list packages --user $U 2>/dev/null > $D/.v.$U; ";
        c +=   "while IFS= read -r L; do P=${L#package:}; [ -n \"$P\" ] || continue; ";
        c +=     "if ! grep -Fqx \"package:$P\" $D/.v.$U; then ";
        c +=       "pm unhide --user $U \"$P\" >/dev/null 2>&1 || cmd package unhide --user $U \"$P\" >/dev/null 2>&1; ";
        c +=       "pm unsuspend --user $U \"$P\" >/dev/null 2>&1 || cmd package unsuspend --user $U \"$P\" >/dev/null 2>&1; ";
        // 仅当前用户补 install-existing：对 hidden/suspended 包是幂等 no-op，
        // 只把被"对用户卸载(pm uninstall --user)"的包装回；分身用户不执行以免建分身。
        c +=       "[ \"$U\" = \"$CU\" ] && cmd package install-existing --user $U \"$P\" >/dev/null 2>&1; ";
        c +=       "echo \"$P\"; ";
        c +=     "fi; ";
        c +=   "done < $D/.k.$U; ";
        c +=   "rm -f $D/.k.$U $D/.v.$U; ";
        c += "done";
        return exec_cmd(c);
    }

    // ---- 发送日志（只取最后 500 行，避免超大响应）----
    bool send_log(struct mg_connection* conn) {
        std::string content = exec_cmd("tail -n 500 '" + aah_paths::log_file() + "' 2>/dev/null");
        kernel_module::webui::send_text(conn, 200, content);
        return true;
    }

    bool send_json(struct mg_connection* conn, const std::string& json) {
        kernel_module::webui::send_text(conn, 200, json);
        return true;
    }

    // ---- JSON 字符串转义 ----
    static std::string json_escape(const std::string& s) {
        std::string out;
        out.reserve(s.size() + 8);
        for (char c : s) {
            switch (c) {
                case '"':  out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\n': out += "\\n";  break;
                case '\r': out += "\\r";  break;
                case '\t': out += "\\t";  break;
                default:
                    if (static_cast<unsigned char>(c) < 0x20) {
                        char buf[8];
                        snprintf(buf, sizeof(buf), "\\u%04x", c);
                        out += buf;
                    } else {
                        out += c;
                    }
            }
        }
        return out;
    }
};

// ===========================================================================
// SKRoot 模块入口函数（Android 早期阶段执行，必须快速返回）
// ===========================================================================
int skroot_module_main(const char* root_key, const char* module_private_dir) {
    printf("%s starting... module_dir=%s\n", MODULE_TAG, module_private_dir);
    aah_paths::set_root(module_private_dir);   // 最早设置配置根 = 模块私有目录

    ensure_data_dirs();

    // 初始化配置并写出标记文件
    AahConfigManager config;
    config.init(module_private_dir);
    config.apply_flags(module_private_dir);

    // 启动守护进程（非阻塞；脚本自身有循环容错，会等系统服务就绪后开始工作）
    if (!config.is_disabled()) {
        // 开机时先清掉上次关机残留的 aah.pid：start() 只按"PID 是否存活"判断 daemon
        // 是否在跑，重启后旧 PID 可能被 init/其他进程复用，kill(pid,0)==0 为真，
        // 导致 daemon 误判已运行而根本没启动——这就是"重启后必须点进模块才生效"。
        unlink((std::string(module_private_dir) + "/aah.pid").c_str());
        AahNativeDaemon::instance().start(module_private_dir);
        printf("%s native daemon started\n", MODULE_TAG);
        // L2 内核目录隐藏尽早安装：inode 直接遍历 /data/app 获得（不依赖 PMS/pm），
        // 只要 /data 已挂载即可取到；onPrepareCreate 时再 apply 一次，覆盖开机后
        // 才完成安装/更新的应用。
        AahRuleManager early_rules;
        early_rules.init(aah_paths::rules_dir());
        restore_rules_from_disk(early_rules);  // 覆盖升级清空目录时从框架磁盘存储重建
        g_kernel_hider.apply(collect_all_hide_pkgs(early_rules));
        sync_kernel_self_pids();  // 守护已就绪，隐藏其 /proc 进程条目
    }

    printf("%s init done\n", MODULE_TAG);
    return 0;
}

// ===========================================================================
// 安装回调：创建数据目录、初始化默认配置（返回空串表示允许安装）
// ===========================================================================
std::string module_on_install(const char* root_key, const char* module_private_dir) {
    printf("%s on_install\n", MODULE_TAG);
    aah_paths::set_root(module_private_dir);
    ensure_data_dirs();
    return "";
}

// ===========================================================================
// 卸载回调：停止守护进程、后台恢复所有应用
// ===========================================================================
void module_on_uninstall(const char* root_key, const char* module_private_dir) {
    printf("%s on_uninstall\n", MODULE_TAG);
    aah_paths::set_root(module_private_dir);

    AahNativeDaemon::instance().stop();
    // 必须显式卸载内核 filldir hook：框架不会自动追踪/释放模块安装的 inline hook，
    // 若 so 被释放后 hook 仍指向已回收内存，内核执行 filldir64 时会 panic。
    g_kernel_hider.remove_all();

    // uninstall.sh 内含多用户 pm 恢复，耗时不确定，放到后台执行避免阻塞卸载流程
    std::string script = std::string(module_private_dir) + "/uninstall.sh";
    if (fs::exists(script)) {
        exec_cmd_background("sh '" + script + "' 2>/dev/null");
    }
}

// ===========================================================================
// SKRoot 模块名片（必填元数据）
// ===========================================================================
SKROOT_MODULE_NAME("应用自动隐藏")
SKROOT_MODULE_VERSION("1.8.3")
SKROOT_MODULE_DESC("【应用自动隐藏】检测触发应用进入前台时自动隐藏指定应用，离开后恢复。三重隐藏：pm hide应用层 + 内核filldir64目录层 + am force-stop进程层，对抗内核层枚举扫描；并在内核/proc层隐藏模块自身守护进程。支持后台保持、仅前台模式、多用户、一键救回。作者：榆爱")
SKROOT_MODULE_AUTHOR("榆爱")
SKROOT_MODULE_ID32("cd08ae9eef7bb885c06f80ef3aea1d5c")

// 可选能力
SKROOT_MODULE_WEB_UI(AppAutoHiderHandler)
SKROOT_MODULE_ON_INSTALL(module_on_install)
SKROOT_MODULE_ON_UNINSTALL(module_on_uninstall)
