// ============================================================================
//  patch_base.cpp — 内核 hook 基座实现（改造自 SKRoot 官方示例）
// ============================================================================
#include "patch_base.h"
using namespace asmjit;
using namespace asmjit::a64;
using namespace asmjit::a64::Predicate;

PatchBase::PatchBase(uint32_t task_struct_offset_cred, uint32_t cred_euid_offset)
    : m_task_struct_offset_cred(task_struct_offset_cred),
      m_cred_euid_offset(cred_euid_offset) {}

PatchBase::PatchBase(const PatchBase& other)
    : m_task_struct_offset_cred(other.m_task_struct_offset_cred),
      m_cred_euid_offset(other.m_cred_euid_offset) {}

PatchBase::~PatchBase() {}

// 判定当前调用进程是否"放行可见"，结果写入 x10：
//   读取 current->cred->euid：
//     euid <  10000 → 系统/root 进程（root/system/shell/媒体等），放行 x10=1
//     euid >= 10000 → 普通第三方应用（含多用户、isolated），不放行 x10=0，
//                     交由后续 name/inode 比较决定是否摘掉该目录项
void PatchBase::emit_check_current_allow_visible_to_x10(Assembler* a) {
    Label label_end = a->newLabel();

    a->mov(x10, Imm(0));                                   // 默认不放行
    kernel_module::export_symbol::get_current(a, x11);    // x11 = current
    a->ldr(x12, ptr(x11, m_task_struct_offset_cred));     // x12 = current->cred
    a->ldr(w12, ptr(x12, m_cred_euid_offset));            // w12 = cred->euid
    aarch64_asm_mov_w(a, w13, MY_FIRST_APP_UID);
    a->cmp(w12, w13);
    a->b(CondCode::kHS, label_end);                       // euid>=10000(无符号) → 保持 0
    a->mov(x10, Imm(1));                                  // euid<10000 系统进程 → 放行
    a->bind(label_end);
}

KModErr PatchBase::patch_kernel_before_hook(uint64_t kaddr, const Assembler* a) {
    std::vector<uint8_t> bytes = aarch64_asm_to_bytes(a);
    RETURN_IF_ERROR(kernel_module::install_kernel_function_before_hook(
        kaddr, bytes, &m_hook_handle));
    return KModErr::OK;
}
