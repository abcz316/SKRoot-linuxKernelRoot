// ============================================================================
//  aah_paths.h — 运行时配置路径中心（全模块唯一）
//
//  所有运行期数据（rules 规则、aah.pid/state/log/version、.aah_* 开关标志）
//  统一放在 SKPro 框架传入的 module_private_dir —— 即"模块私有目录"。
//  SDK 头文件明确说明：module_private_dir 受框架隐藏保护，需要隐藏的文件建议
//  放在此目录；它位于 /data/adb 下（root 0700，普通 App 在 DAC 层就无法进入，
//  叠加框架隐藏保护），比旧的 /data/local/tmp（0777，仅靠 SELinux 单挡）更隐蔽，
//  且卸载模块时随模块目录整体删除，不残留。
//
//  兜底：若入口在极端早期尚未 set_root，则退回旧路径 /data/local/tmp/
//  app_auto_hider，保证任何时序下都有可用目录。
//
//  线程安全：set_root 仅在模块入口/ WebUI 创建时写入（早于守护线程读路径），
//  之后全程只读；inline 函数内的 static 单例在整个 .so 内唯一。
// ============================================================================
#pragma once
#include <string>

namespace aah_paths {

// 唯一可写的根目录单例（默认旧路径兜底）
inline std::string& root_ref() {
    static std::string s_root = "/data/local/tmp/app_auto_hider";
    return s_root;
}

// 模块各入口最早调用：以 SKPro 传入的模块私有目录作为配置根
inline void set_root(const std::string& dir) {
    if (!dir.empty()) root_ref() = dir;
}
inline void set_root(const char* dir) {
    if (dir != nullptr && dir[0] != '\0') root_ref() = dir;
}

// 配置根目录
inline std::string root()             { return root_ref(); }
// 规则目录
inline std::string rules_dir()        { return root_ref() + "/rules"; }
// 守护进程 PID
inline std::string pid_file()         { return root_ref() + "/aah.pid"; }
// 隐藏状态
inline std::string state_file()       { return root_ref() + "/aah.state"; }
// 运行日志
inline std::string log_file()         { return root_ref() + "/aah.log"; }
// 守护版本
inline std::string version_file()     { return root_ref() + "/aah.version"; }
// 锁文件
inline std::string lock_pid_file()    { return root_ref() + "/aah.lock/pid"; }
// 开关标志文件（.aah_disabled / .aah_foreground_only ...）
inline std::string flag_file(const std::string& name) {
    return root_ref() + "/" + name;
}

// 当前是否仍落在旧的 /data/local/tmp 兜底位置
inline bool in_local_tmp() {
    return root_ref().compare(0, 16, "/data/local/tmp") == 0;
}

// 旧版本配置目录（用于一次性迁移）
static constexpr const char* LEGACY_DIR = "/data/local/tmp/app_auto_hider";

} // namespace aah_paths
