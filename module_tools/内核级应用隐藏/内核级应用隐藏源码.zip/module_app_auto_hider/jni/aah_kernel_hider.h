// ============================================================================
//  aah_kernel_hider.h — 内核级目录隐藏（L2）
//
//  作用：对"所有规则里勾选要隐藏的 App"在内核 filldir64 / compat_filldir
//        （getdents 列目录）层面摘除其目录项，使任何普通 App（游戏/检测方，
//        euid>=10000）枚举 /data/data、/data/app、/sdcard/Android/data 时
//        都看不到这些 App 的目录；系统/root 进程（euid<10000）正常可见，
//        被隐藏 App 自身按"已知路径"访问数据也不受影响（不走列目录）。
//
//  与第一层 pm hide 的关系：
//    - pm hide：让 PackageManager 查询表现为"未安装"（应用查询层）；
//    - 本类：让文件系统"扫盘枚举"找不到目录（内核文件层），常驻生效。
//
//  健壮性：/data/app 安装目录带随机后缀，按 inode 精确摘除；但 App 更新/重装
//        会换目录、换 inode，旧快照会漏。因此额外提供 refresh_if_drifted()，
//        以极低开销重扫对比，仅在检测到 inode 漂移时才重装 hook（平时零操作）。
//
//  容错：任何一步（符号查找/偏移/hook 安装）失败都只记日志、返回 false，
//        绝不抛异常、不影响 WebUI 与第一层 pm hide。
// ============================================================================
#pragma once
#include <string>
#include <set>
#include <vector>
#include <mutex>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <sys/stat.h>
#include <dirent.h>
#include "kernel_module_kit_umbrella.h"
#include "patch_filldir64.h"
#include "patch_compat_filldir.h"
#ifndef AAH_KH_TAG
#define AAH_KH_TAG "[aah_kernel_hide]"
#endif
// 模块自身"守护进程"隐藏：把常驻守护 sh 的 PID 十进制名（/proc/<pid> 的目录项名）
// 加入按名隐藏名单。普通 App / 游戏反作弊（euid>=10000）枚举 /proc 进程名单时，
// 看不到守护进程那一行；root 与系统进程（euid<10000）放行仍可正常可见。
// 说明：按用户要求不再隐藏 /data/local/tmp 数据目录（该目录本就被 SELinux 隔离，
// 普通 App 无法访问）；只隐藏自身进程。PID 会随守护重启变化，由 set_self_pids()
// 触发幂等重装 hook（与规则增删、inode 漂移同一条成熟路径）。
// 单个 /proc 顶层条目名就是 PID 的十进制字符串，长度极短、纯数字，正常文件目录
// 几乎不可能同名，故无需额外判断"当前是否在列 /proc"，误摘概率可忽略。
// 漂移自检最小间隔（秒）：前端状态轮询会顺带触发，限制重扫 /data/app 的频率。
#define AAH_REFRESH_MIN_INTERVAL 15
class AahKernelHider {
public:
    // 用最新的目标包名集合重新应用：先卸载旧 hook，再按新集合安装。
    // 返回是否至少成功安装一条内核 hook。
    bool apply(const std::set<std::string>& pkgs) {
        std::lock_guard<std::mutex> lk(m_mtx);
        return apply_locked(pkgs);
    }
    // 低成本漂移自检：被隐藏 App 更新/重装会使 /data/app 目录 inode 改变，
    // 若仍用安装时的旧 inode 快照，新目录就可能被枚举到。这里重扫对比，
    // 仅在真正漂移时重装 hook；无规则/已停用/未到检查间隔时立即返回（零操作）。
    void refresh_if_drifted() {
        std::lock_guard<std::mutex> lk(m_mtx);
        if (m_applied_pkgs.empty()) return;  // 没有生效中的规则（或已停用），不自启
        time_t now = time(nullptr);
        if (m_last_scan_ts != 0 && now - m_last_scan_ts < AAH_REFRESH_MIN_INTERVAL) return;
        m_last_scan_ts = now;
        std::set<std::string> probe;
        for (const auto& p : m_applied_pkgs) if (!p.empty()) probe.insert(p);
        std::set<uint64_t> cur_inos;
        scan_apk_dirs_for_inodes(probe, cur_inos);
        if (cur_inos == m_applied_inos) return;  // 安装目录未变化，无需重装
        printf("%s apk inode drifted (app updated/reinstalled?), re-apply\n", AAH_KH_TAG);
        apply_locked(m_applied_pkgs);
    }
    // 卸载全部内核 hook，恢复原始列目录行为（模块卸载/停用/清空规则时调用）。
    void remove_all() {
        std::lock_guard<std::mutex> lk(m_mtx);
        remove_locked();
        m_applied_pkgs.clear();
        m_applied_inos.clear();
        m_self_pid_names.clear();
        m_last_scan_ts = 0;
    }
    // 更新要隐藏的"模块自身进程 PID"（守护 sh 等）。转成 /proc 条目名（十进制串），
    // 与最近一次规则集合合并后幂等重装 hook；集合没变立即返回，避免频繁重装。
    void set_self_pids(const std::set<uint32_t>& pids) {
        std::lock_guard<std::mutex> lk(m_mtx);
        std::set<std::string> names;
        for (uint32_t p : pids) if (p > 0) names.insert(std::to_string(p));
        if (names == m_self_pid_names) return;
        m_self_pid_names = names;
        apply_locked(m_applied_pkgs);
    }
private:
    std::mutex m_mtx;
    kernel_module::HookHandle m_h_filldir64 = nullptr;
    kernel_module::HookHandle m_h_compat = nullptr;
    std::set<std::string>   m_applied_pkgs;   // 最近一次成功应用的目标包集合
    std::set<uint64_t>      m_applied_inos;   // 最近一次实际 hook 的 /data/app inode
    std::set<std::string>   m_self_pid_names; // 要隐藏的自身进程 PID 十进制名(/proc)
    time_t                  m_last_scan_ts = 0;
    // 调用时已持有 m_mtx。
    bool apply_locked(const std::set<std::string>& pkgs) {
        remove_locked();  // 规则变化 / inode 刷新：先卸掉旧的，保证幂等
        std::set<std::string> hide_names;                 // 按名（数据包名目录 + 自身 /proc PID 名）
        std::set<uint64_t> hide_inos;                     // 按 inode（/data/app 随机后缀目录）
        for (const auto& pkg : pkgs) {
            if (!pkg.empty()) hide_names.insert(pkg);
        }
        // 自身守护进程 PID 名：普通 App 枚举 /proc 时摘除其进程条目
        for (const auto& self_name : m_self_pid_names) hide_names.insert(self_name);
        // APK 安装目录 inode：只按规则包名扫 /data/app（PID 纯数字串不参与目录匹配）
        scan_apk_dirs_for_inodes(pkgs, hide_inos);
        if (hide_names.empty() && hide_inos.empty()) {
            printf("%s nothing to hide\n", AAH_KH_TAG);
            m_applied_pkgs.clear();
            m_applied_inos.clear();
            return false;
        }
        // task_struct->cred 与 cred->euid 偏移（内核版本相关，由 SDK 动态获取）
        uint32_t cred_off = 0, euid_off = 0;
        if (kernel_module::get_task_struct_cred_offset(cred_off) != KModErr::OK ||
            kernel_module::get_cred_euid_offset(euid_off) != KModErr::OK) {
            printf("%s get cred/euid offset failed, kernel-hide skipped\n", AAH_KH_TAG);
            return false;
        }
        PatchBase base(cred_off, euid_off);
        bool any = false;
        // 64 位列目录路径
        kernel_module::SymbolHit hit64;
        if (kernel_module::kallsyms_lookup_name(
                "filldir64", hit64, kernel_module::SymbolMatchMode::Prefix) == KModErr::OK &&
            hit64.addr != 0) {
            PatchFilldir64 patcher(base, hit64.addr);
            if (patcher.patch_filldir64(hide_names, hide_inos) == KModErr::OK) {
                m_h_filldir64 = patcher.take_handle();
                any = true;
                printf("%s filldir64 hooked (%zu names, %zu inodes)\n",
                       AAH_KH_TAG, hide_names.size(), hide_inos.size());
            } else {
                printf("%s filldir64 patch failed\n", AAH_KH_TAG);
            }
        } else {
            printf("%s symbol filldir64 not found\n", AAH_KH_TAG);
        }
        // 32 位兼容列目录路径（没有 32 位进程的内核可缺，失败不影响 64 位主路径）
        kernel_module::SymbolHit hitCompat;
        if (kernel_module::kallsyms_lookup_name(
                "compat_filldir", hitCompat, kernel_module::SymbolMatchMode::Prefix) == KModErr::OK &&
            hitCompat.addr != 0) {
            PatchCompatFilldir patcher(base, hitCompat.addr);
            if (patcher.patch_compat_filldir(hide_names, hide_inos) == KModErr::OK) {
                m_h_compat = patcher.take_handle();
                any = true;
                printf("%s compat_filldir hooked\n", AAH_KH_TAG);
            } else {
                printf("%s compat_filldir patch failed\n", AAH_KH_TAG);
            }
        }
        if (any) {
            // 记录本次成功应用的状态，供 refresh_if_drifted 做漂移对比
            m_applied_pkgs = pkgs;
            m_applied_inos = hide_inos;
            m_last_scan_ts = time(nullptr);
        }
        return any;
    }
    void remove_locked() {
        if (m_h_filldir64) {
            kernel_module::uninstall_kernel_hook(m_h_filldir64);
            m_h_filldir64 = nullptr;
        }
        if (m_h_compat) {
            kernel_module::uninstall_kernel_hook(m_h_compat);
            m_h_compat = nullptr;
        }
    }
    // 判断叶子目录名是否对应某个目标包：等于包名，或形如 "<包名>-<hash>"。
    // 用 "pkg-" 精确边界，避免 com.foo 误匹配 com.foo.bar。
    static bool leaf_matches_pkg(const std::string& leaf,
                                 const std::set<std::string>& pkgs) {
        for (const auto& pkg : pkgs) {
            if (pkg.empty()) continue;
            if (leaf == pkg) return true;
            if (leaf.size() > pkg.size() &&
                leaf.compare(0, pkg.size(), pkg) == 0 &&
                leaf[pkg.size()] == '-') return true;
        }
        return false;
    }
    static void try_add_dir_inode(const std::string& path, std::set<uint64_t>& inos) {
        struct stat st{};
        if (stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
            inos.insert(static_cast<uint64_t>(st.st_ino));
        }
    }
    // 直接遍历 /data/app 定位目标包的 APK 安装目录并收集 inode（主路径，不依赖 pm）。
    // 兼容两种布局：
    //   新式 /data/app/~~<rand>/<pkg>-<hash>/base.apk   （两级，~~随机父目录）
    //   旧式 /data/app/<pkg>[-<n>]/base.apk             （一级）
    static void scan_apk_dirs_for_inodes(const std::set<std::string>& pkgs,
                                         std::set<uint64_t>& inos) {
        scan_apk_root("/data/app", pkgs, inos);
    }
    static void scan_apk_root(const std::string& root,
                              const std::set<std::string>& pkgs,
                              std::set<uint64_t>& inos) {
        DIR* d = opendir(root.c_str());
        if (!d) {
            printf("%s opendir %s failed, fallback to pm only\n", AAH_KH_TAG, root.c_str());
            return;
        }
        struct dirent* e = nullptr;
        while ((e = readdir(d)) != nullptr) {
            std::string name = e->d_name;
            if (name == "." || name == "..") continue;
            std::string p1 = root + "/" + name;
            // ~~ 开头视为随机父目录，再下钻一层；否则当作一级布局直接匹配
            bool random_parent = (name.size() >= 2 && name[0] == '~' && name[1] == '~');
            if (random_parent) {
                DIR* d2 = opendir(p1.c_str());
                if (!d2) continue;
                struct dirent* e2 = nullptr;
                while ((e2 = readdir(d2)) != nullptr) {
                    std::string n2 = e2->d_name;
                    if (n2 == "." || n2 == "..") continue;
                    if (leaf_matches_pkg(n2, pkgs)) {
                        try_add_dir_inode(p1 + "/" + n2, inos);
                    }
                }
                closedir(d2);
            } else if (leaf_matches_pkg(name, pkgs)) {
                try_add_dir_inode(p1, inos);
            }
        }
        closedir(d);
    }
};
