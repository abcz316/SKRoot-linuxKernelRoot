#pragma once
#include <string>
#include <vector>
#include <set>
#include <mutex>
#include "aah_paths.h"

// 原生守护线程：替代 sh 守护脚本，零常驻用户态进程
// 运行在 so 的 pthread 中，共享 SKRoot 框架进程 PID，/proc 无独立条目
class AahNativeDaemon {
public:
    static AahNativeDaemon& instance();
    
    // 启动守护线程（幂等）
    void start(const std::string& module_dir);
    // 停止守护线程
    void stop();
    bool is_running() const { return running_; }
    
private:
    AahNativeDaemon() = default;
    ~AahNativeDaemon();
    
    static void* thread_main(void* arg);
    void run();
    
    // 获取前台应用包名
    std::string get_foreground_app();
    // 获取所有用户 ID
    std::vector<std::string> get_users();
    // 读取规则：返回 {触发应用 -> [隐藏应用列表]}
    std::vector<std::pair<std::string, std::vector<std::string>>> load_rules();
    // 执行 shell 命令并返回输出
    std::string exec(const std::string& cmd);
    // 隐藏应用
    bool hide_app(const std::string& pkg, const std::vector<std::string>& users, bool force_stop);
    // 恢复应用
    bool restore_app(const std::string& pkg, const std::vector<std::string>& users);
    // 强停应用
    void force_stop_app(const std::string& pkg, const std::vector<std::string>& users);
    // 写日志
    void log(const std::string& msg);
    // 写状态文件
    void write_state(const std::set<std::string>& hidden);
    // 读状态文件
    std::set<std::string> read_state();
    
    bool running_ = false;
    bool stop_requested_ = false;
    pthread_t thread_ = 0;
    std::string module_dir_;
    std::string data_dir_;   // start() 时取 aah_paths::root()（模块私有目录）
    std::set<std::string> current_hidden_;
    std::mutex mtx_;
};
