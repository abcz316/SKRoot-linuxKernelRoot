LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := module_app_auto_hider
LOCAL_SRC_FILES := module_app_auto_hider.cpp patch_base.cpp patch_filldir64.cpp patch_compat_filldir.cpp aah_native_daemon.cpp
KERNEL_MODULE_KIT := $(KIT_PATH)
LOCAL_C_INCLUDES += $(LOCAL_PATH) $(KERNEL_MODULE_KIT)/include $(KERNEL_MODULE_KIT)/include/third_party
LOCAL_CPPFLAGS += -std=c++20 -fPIC -fvisibility=hidden -fno-stack-protector -ffunction-sections -fdata-sections -O2 -flto=thin
LOCAL_LDFLAGS += $(KERNEL_MODULE_KIT)/lib/libkernel_module_kit_static.a -Wl,-O2 -Wl,--gc-sections -Wl,-s -flto=thin
LOCAL_LDLIBS :=
include $(BUILD_SHARED_LIBRARY)
