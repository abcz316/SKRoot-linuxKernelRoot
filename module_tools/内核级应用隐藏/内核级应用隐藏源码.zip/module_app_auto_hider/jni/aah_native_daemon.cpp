#include "aah_native_daemon.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <algorithm>
#include <fstream>
#include <sstream>

#define AAH_VERSION "1.7"

static bool flag_exists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

struct AahRunConfig {
    bool foreground_only = false;
    bool keep_background = true;
    bool force_stop = true;
};

static AahRunConfig load_config(const std::string& data_dir) {
    AahRunConfig cfg;
    cfg.foreground_only = flag_exists(data_dir + "/.aah_foreground_only");
    cfg.keep_background = !flag_exists(data_dir + "/.aah_no_keep_background");
    if (flag_exists(data_dir + "/.aah_keep_background")) cfg.keep_background = true;
    cfg.force_stop = flag_exists(data_dir + "/.aah_force_stop");
    if (flag_exists(data_dir + "/.aah_no_force_stop")) cfg.force_stop = false;
    return cfg;
}

AahNativeDaemon& AahNativeDaemon::instance() {
    static AahNativeDaemon inst;
    return inst;
}

AahNativeDaemon::~AahNativeDaemon() {
    stop();
}

void AahNativeDaemon::start(const std::string& module_dir) {
    std::lock_guard<std::mutex> lk(mtx_);
    if (running_) return;
    module_dir_ = module_dir;
    aah_paths::set_root(module_dir);      // 确保配置根 = 模块私有目录
    data_dir_ = aah_paths::root();
    (void)mkdir(aah_paths::root().c_str(), 0755);
    (void)mkdir(aah_paths::rules_dir().c_str(), 0755);
    stop_requested_ = false;
    running_ = true;
    // 立即写 PID 文件：getpid() 主线程/子线程相同，确保 start() 返回后
    // sync_kernel_self_pids() 立即可读到 PID，避免首轮轮询漏隐藏自身进程
    {
        std::ofstream f(data_dir_ + "/aah.pid", std::ios::trunc);
        if (f.is_open()) f << getpid() << "\n";
    }
    pthread_create(&thread_, nullptr, thread_main, this);
}

void AahNativeDaemon::stop() {
    {
        std::lock_guard<std::mutex> lk(mtx_);
        if (!running_) return;
        stop_requested_ = true;
    }
    pthread_join(thread_, nullptr);
    running_ = false;
}

void* AahNativeDaemon::thread_main(void* arg) {
    AahNativeDaemon* self = static_cast<AahNativeDaemon*>(arg);
    self->run();
    return nullptr;
}

std::string AahNativeDaemon::exec(const std::string& cmd) {
    std::string result;
    std::string wrapped = "timeout 10 " + cmd;
    FILE* pipe = popen(wrapped.c_str(), "r");
    if (!pipe) return result;
    char buf[512];
    while (fgets(buf, sizeof(buf), pipe)) {
        result += buf;
    }
    pclose(pipe);
    while (!result.empty() && (result.back() == '\n' || result.back() == '\r')) {
        result.pop_back();
    }
    return result;
}

void AahNativeDaemon::log(const std::string& msg) {
    time_t now = time(nullptr);
    struct tm* tm = localtime(&now);
    char ts[32];
    snprintf(ts, sizeof(ts), "%02d:%02d:%02d", tm->tm_hour, tm->tm_min, tm->tm_sec);
    std::string line = "[" + std::string(ts) + "] " + msg + "\n";
    
    std::string logpath = data_dir_ + "/aah.log";
    FILE* f = fopen(logpath.c_str(), "a");
    if (f) {
        fputs(line.c_str(), f);
        fclose(f);
    }
    // 日志截断：每写 50 条检查一次，超 900 行保留最后 200 行
    static int write_count = 0;
    if (++write_count >= 50) {
        write_count = 0;
        std::ifstream in(logpath);
        if (in) {
            std::vector<std::string> lines;
            std::string l;
            while (std::getline(in, l)) lines.push_back(l);
            in.close();
            if (lines.size() > 900) {
                std::ofstream out(logpath, std::ios::trunc);
                for (size_t i = lines.size() - 200; i < lines.size(); i++) {
                    out << lines[i] << "\n";
                }
            }
        }
    }
}

std::vector<std::string> AahNativeDaemon::get_users() {
    std::vector<std::string> users;
    std::string out = exec("pm list users 2>/dev/null | sed -n 's/.*UserInfo{\\([0-9][0-9]*\\).*/\\1/p'");
    if (out.empty()) {
        users.push_back("0");
        return users;
    }
    std::istringstream iss(out);
    std::string u;
    while (iss >> u) {
        if (!u.empty()) users.push_back(u);
    }
    if (users.empty()) users.push_back("0");
    return users;
}

std::string AahNativeDaemon::get_foreground_app() {
    // 优先用 dumpsys activity 的 ResumedActivity，用 grep 直接提取 u0 后面的包名
    // 兼容两种格式：
    //   mResumedActivity: ActivityRecord{u0 a.b.c/.Activity t123}
    //   topResumedActivity=ActivityRecord{u0 a.b.c/.Activity t123}
    std::string out = exec("dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity' | sed -n 's/.*u0 \\([^ /]*\\).*/\\1/p'");
    if (!out.empty()) return out;
    // 兜底：dumpsys window
    out = exec("dumpsys window 2>/dev/null | grep -m1 mCurrentFocus | sed -n 's/.*u0 \\([^ /]*\\).*/\\1/p'");
    if (!out.empty()) return out;
    return "";
}

// 严格包名校验（与 aah_rule_manager.h 对齐），杜绝损坏规则文件里的非法条目
static bool is_valid_pkg_name(const std::string& pkg) {
    if (pkg.empty() || pkg.size() > 255) return false;
    bool has_dot = false, seg_empty = true;
    for (char ch : pkg) {
        if (ch == '.') {
            if (seg_empty) return false;
            has_dot = true; seg_empty = true;
        } else if (std::isalnum(static_cast<unsigned char>(ch)) || ch == '_') {
            seg_empty = false;
        } else {
            return false;
        }
    }
    return has_dot && !seg_empty;
}

std::vector<std::pair<std::string, std::vector<std::string>>> AahNativeDaemon::load_rules() {
    std::vector<std::pair<std::string, std::vector<std::string>>> rules;
    std::string rules_dir = data_dir_ + "/rules";
    DIR* dir = opendir(rules_dir.c_str());
    if (!dir) return rules;
    struct dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        std::string fname = ent->d_name;
        if (fname.size() < 5 || fname.substr(fname.size() - 5) != ".conf") continue;
        std::string game = fname.substr(0, fname.size() - 5);
        if (!is_valid_pkg_name(game)) continue;  // 非法文件名跳过
        std::vector<std::string> apps;
        std::ifstream f(rules_dir + "/" + fname);
        std::string line;
        while (std::getline(f, line)) {
            // 去回车、去注释、去空行
            while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
            if (line.empty() || line[0] == '#') continue;
            if (is_valid_pkg_name(line)) apps.push_back(line);  // 非法包名跳过
        }
        if (!apps.empty()) {
            rules.push_back({game, apps});
        }
    }
    closedir(dir);
    return rules;
}

static bool is_protected_pkg(const std::string& pkg) {
    // 必须与 aah_app_utils.h 的保护名单保持一致
    static const char* protected_pkgs[] = {
        "com.android.systemui", "com.android.phone", "com.android.settings",
        "com.android.dialer", "com.android.incallui", "com.google.android.dialer",
        "com.android.server.telecom", "com.miui.home", "com.android.launcher3",
        "com.google.android.gms", "com.android.providers.downloads", nullptr
    };
    for (int i = 0; protected_pkgs[i]; i++) {
        if (pkg == protected_pkgs[i]) return true;
    }
    return false;
}

bool AahNativeDaemon::hide_app(const std::string& pkg, const std::vector<std::string>& users, bool force_stop) {
    if (is_protected_pkg(pkg)) {
        log("hide-skip protected pkg=" + pkg);
        return false;
    }
    bool ok = false;
    for (const auto& u : users) {
        std::string r = exec("pm hide --user " + u + " " + pkg + " 2>&1");
        if (r.find("true") != std::string::npos) {
            ok = true;
        } else {
            // 回退 suspend
            exec("pm suspend --user " + u + " " + pkg + " >/dev/null 2>&1");
        }
    }
    if (ok) {
        // 隐藏后立即冻结进程（受 force_stop 配置控制）
        if (force_stop) {
            for (const auto& u : users) {
                exec("am force-stop --user " + u + " " + pkg + " >/dev/null 2>&1");
            }
        }
    }
    return ok;
}

bool AahNativeDaemon::restore_app(const std::string& pkg, const std::vector<std::string>& users) {
    bool ok = false;
    for (const auto& u : users) {
        exec("pm unsuspend --user " + u + " " + pkg + " >/dev/null 2>&1");
        std::string r = exec("pm unhide --user " + u + " " + pkg + " 2>&1");
        if (r.find("false") != std::string::npos) ok = true;
        exec("pm enable --user " + u + " " + pkg + " >/dev/null 2>&1");
        if (u == "0") exec("cmd package install-existing --user " + u + " " + pkg + " >/dev/null 2>&1");
    }
    return ok;
}

void AahNativeDaemon::force_stop_app(const std::string& pkg, const std::vector<std::string>& users) {
    for (const auto& u : users) {
        exec("am force-stop --user " + u + " " + pkg + " >/dev/null 2>&1");
    }
}

void AahNativeDaemon::write_state(const std::set<std::string>& hidden) {
    std::string path = data_dir_ + "/aah.state";
    if (hidden.empty()) {
        unlink(path.c_str());
        return;
    }
    std::ofstream f(path, std::ios::trunc);
    for (const auto& p : hidden) f << p << "\n";
}

std::set<std::string> AahNativeDaemon::read_state() {
    std::set<std::string> result;
    std::ifstream f(data_dir_ + "/aah.state");
    std::string line;
    while (std::getline(f, line)) {
        while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
        if (!line.empty()) result.insert(line);
    }
    return result;
}

void AahNativeDaemon::run() {
    // 写 PID 文件（用于内核隐藏自身）
    {
        std::ofstream f(data_dir_ + "/aah.pid", std::ios::trunc);
        f << getpid() << "\n";
    }
    log("native daemon started version=" AAH_VERSION);
    
    // 等待系统服务就绪：开机早期 PMS/ActivityManagerService 可能尚未启动，
    // pm/dumpsys/am 命令会失败。最多等 30 秒，就绪后立即继续。
    for (int i = 0; i < 30; i++) {
        if (stop_requested_) return;
        std::string probe = exec("pm list packages 2>/dev/null | head -1");
        if (!probe.empty()) break;
        usleep(1000000); // 1 秒
    }
    
    // 启动时孤儿恢复：state 里有但规则里没有的包，恢复
    {
        auto rules = load_rules();
        std::set<std::string> managed;
        for (auto& r : rules) for (auto& a : r.second) managed.insert(a);
        auto orphan = read_state();
        for (auto& p : orphan) {
            if (managed.find(p) == managed.end()) {
                auto users = get_users();
                restore_app(p, users);
                log("orphan-restore: " + p);
            }
        }
    }
    
    std::string last_fg;
    while (!stop_requested_) {
        // 停用检查：读到 disabled 标记则恢复所有应用并退出
        if (flag_exists(data_dir_ + "/.aah_disabled")) {
            log("disabled flag detected, restoring all and exiting");
            auto users = get_users();
            for (const auto& pkg : current_hidden_) {
                restore_app(pkg, users);
            }
            current_hidden_.clear();
            write_state(current_hidden_);
            break;
        }
        auto users = get_users();
        auto rules = load_rules();
        AahRunConfig cfg = load_config(data_dir_);
        std::string fg = get_foreground_app();
        
        // 计算需要隐藏的包
        std::set<std::string> should_hide;
        for (auto& r : rules) {
            const std::string& game = r.first;
            bool active = false;
            // 前台是触发应用
            if (fg == game) active = true;
            // 后台保持：仅在 keep_background=true 且 foreground_only=false 时检查进程
            if (!active && cfg.keep_background && !cfg.foreground_only) {
                std::string running = exec("pidof " + game + " 2>/dev/null");
                if (!running.empty()) active = true;
            }
            if (active) {
                for (auto& a : r.second) {
                    if (a != game) should_hide.insert(a); // 触发应用自身不隐藏
                }
            }
        }
        
        // 执行隐藏
        for (const auto& pkg : should_hide) {
            if (current_hidden_.find(pkg) == current_hidden_.end()) {
                log("hide-begin pkg=" + pkg + " users=" + [&](){
                    std::string s; for (auto& u : users) s += u + " "; return s;
                }());
                if (hide_app(pkg, users, cfg.force_stop)) {
                    current_hidden_.insert(pkg);
                    log("hide-done pkg=" + pkg);
                } else {
                    log("hide-fail pkg=" + pkg);
                }
            } else {
                // 已隐藏，持续强停（防止被重新拉起，受 force_stop 配置控制）
                if (cfg.force_stop) {
                    force_stop_app(pkg, users);
                }
            }
        }
        
        // 执行恢复
        std::set<std::string> to_restore;
        for (const auto& pkg : current_hidden_) {
            if (should_hide.find(pkg) == should_hide.end()) {
                to_restore.insert(pkg);
            }
        }
        for (const auto& pkg : to_restore) {
            if (restore_app(pkg, users)) {
                current_hidden_.erase(pkg);
                log("restore pkg=" + pkg);
            } else {
                log("restore-fail pkg=" + pkg + " (will retry next round)");
            }
        }
        
        // 更新状态文件
        write_state(current_hidden_);
        
        // 前台变化日志
        if (fg != last_fg) {
            if (!fg.empty()) log("fg: " + (last_fg.empty() ? "?" : last_fg) + " -> " + fg);
            last_fg = fg;
        }
        
        // 空闲日志（每 60 秒）
        static time_t last_idle_log = 0;
        time_t now = time(nullptr);
        if (should_hide.empty() && now - last_idle_log >= 60) {
            log("idle fg=" + (fg.empty() ? "?" : fg) + " rules=" + std::to_string(rules.size()));
            last_idle_log = now;
        }
        
        // 轮询间隔：默认 1 秒（隐藏延迟 1s 内用户几乎感知不到）；
        // 已有应用处于隐藏状态时降频到 2 秒（此时前台变化不影响隐藏集合，省电）。
        usleep(current_hidden_.empty() ? 1000000 : 2000000);
    }
    
    // 退出前恢复所有
    auto users = get_users();
    for (const auto& pkg : current_hidden_) {
        restore_app(pkg, users);
    }
    current_hidden_.clear();
    write_state(current_hidden_);
    unlink((data_dir_ + "/aah.pid").c_str());
    log("native daemon stopped");
}
