# 应用自动隐藏 (module_app_auto_hider)

SKRoot Pro 内核模块 — 目标应用进入前台时自动隐藏指定应用，离开后恢复。

## 功能特性

- **目标场景自动隐藏**：检测指定目标应用进入前台时，自动 `pm hide` / `pm suspend` 配置的应用
- **智能恢复**：目标离开前台、进程退出、或从最近任务划掉后自动恢复
- **后台保持**：目标切后台后可选择保持隐藏状态（默认开启）
- **仅前台模式**：目标在前台时隐藏，切后台立即恢复（可选）
- **多用户支持**：自动检测并支持 Android 多用户/工作资料
- **内存压力保护**：低内存时自动恢复所有应用并暂停，避免 OOM
- **小窗/分屏识别**：目标在小窗/分屏模式下也能触发隐藏（可选）
- **保护应用白名单**：系统关键与常用应用不会被误隐藏
- **WebUI 管理界面**：可视化配置规则、运行模式、查看状态
- **内核级隐匿**：基于 SKRoot 内核模块框架，无挂载、SELinux 零触碰

## 目录结构

```
module_app_auto_hider/
├── jni/                          # C++ 源码
│   ├── module_app_auto_hider.cpp # 主模块（入口 + WebUI REST API）
│   ├── aah_daemon_manager.h      # 守护进程管理
│   ├── aah_config_manager.h      # 配置管理
│   ├── aah_rule_manager.h        # 规则管理
│   ├── aah_app_utils.h           # 应用列表工具
│   ├── Android.mk                # NDK 编译配置
│   ├── Application.mk            # NDK 应用配置
│   └── build.sh                  # 编译脚本
├── webroot/                      # WebUI 前端
│   ├── index.html
│   ├── main.js
│   └── style.css
├── common/                       # Shell 脚本
│   ├── aah_launch.sh             # 守护进程（核心隐藏逻辑）
│   └── aah_paths.sh              # 路径配置与迁移
└── uninstall.sh                  # 卸载脚本
```

## 编译方法

### 前置要求
- Android NDK（r21+）
- SKRoot `kernel_module_kit` SDK（预编译静态库 + 头文件）

### 编译步骤
1. 将 `kernel_module_kit` 放在本模块的上一级目录
2. 修改 `jni/build.sh` 中的 `NDK_PATH` 为你的 NDK 路径
3. 运行编译：
   ```bash
   cd jni
   chmod +x build.sh
   ./build.sh
   ```
4. 编译产物：`jni/libs/arm64-v8a/module_app_auto_hider.so`

## 打包安装

将以下文件打包为 ZIP：
- `module_app_auto_hider.so`（重命名为模块主 so）
- `webroot/` 目录
- `common/` 目录
- `uninstall.sh`

通过 SKRoot App 安装 ZIP 包即可。

## REST API 说明

WebUI 通过以下 REST API 与模块通信：

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/status` | 获取守护进程状态、PID、前台应用、已隐藏列表 |
| GET | `/api/config` | 获取运行配置 |
| POST | `/api/config` | 保存配置 `{disabled, foreground_only, keep_background}` |
| GET | `/api/rules` | 获取所有隐藏规则 |
| POST | `/api/rules` | 添加/更新规则 `{game, apps[]}` |
| POST | `/api/rules/delete` | 删除规则 `{game}` |
| GET | `/api/games` | 获取已安装应用列表（作为触发目标） |
| GET | `/api/apps` | 获取已安装应用列表 |
| POST | `/api/daemon` | 守护进程控制 `start`/`stop`/`restart` |
| GET | `/api/log` | 获取守护进程日志 |

## 隐藏规则格式

规则以 `.conf` 文件存储在模块私有目录的 `rules/` 下：
- 文件名 = 目标包名（如 `com.example.target.conf`）
- 文件内容 = 要隐藏的应用包名列表（每行一个）

示例：
```
# com.example.target.conf
com.example.hidden1
com.example.hidden2
com.example.hidden3
```

## 配置标记文件

守护进程通过模块目录下的标记文件控制行为：

| 文件 | 作用 |
|------|------|
| `.aah_disabled` | 完全停用自动隐藏 |
| `.aah_foreground_only` | 仅前台模式（切后台立即恢复） |
| `.aah_keep_background` | 后台保持模式（默认开启） |
| `.aah_force_stop` | 彻底强停被隐藏应用（默认开启） |

## 数据目录

运行期数据存放在 SKPro 模块私有目录下（root 0700，普通应用不可见）：

- 规则目录：`rules/`（每个目标包名一个 `.conf`）
- 状态文件：`aah.state`（当前已隐藏的应用列表）
- PID 文件：`aah.pid`
- 日志文件：`aah.log`
- 配置/规则同时在 SDK 磁盘存储（disk storage）有冗余备份

## 版本

20260516-bg-hold-v34
