#!/system/bin/sh

# 配置根 = SKPro 模块私有目录 $MODPATH（受框架隐藏保护，位于 /data/adb，
# 普通 App 在 DAC 层就无法进入）；仅当 MODPATH 缺失时兜底到旧路径。
AAH_OLD_DATA_DIR=/data/local/tmp/app_auto_hider
MODPATH=${MODPATH:-/data/adb/skroot/modules/app_auto_hider}
AAH_DATA_DIR=${AAH_DATA_DIR:-$MODPATH}
AAH_RULES_DIR=${AAH_RULES_DIR:-$AAH_DATA_DIR/rules}
AAH_PRESETS_FILE=${AAH_PRESETS_FILE:-$AAH_DATA_DIR/presets.json}
AAH_FREE_LEASE=${AAH_FREE_LEASE:-$AAH_DATA_DIR/free_online_ok}
# 旧版本数据在 /data/local/tmp，用于一次性迁移到模块私有目录
AAH_LEGACY_RULES_DIR=$AAH_OLD_DATA_DIR/rules
AAH_LEGACY_PRESETS_FILE=$AAH_OLD_DATA_DIR/presets.json

# 配置根是否落在兜底的 /data/local/tmp（只有这里才需要放开权限/打 shell 标签）
aah_in_local_tmp() {
    case "$AAH_DATA_DIR" in /data/local/tmp*) return 0 ;; *) return 1 ;; esac
}

aah_paths_prepare() {
    mkdir -p "$AAH_DATA_DIR" "$AAH_RULES_DIR" 2>/dev/null || true
    if aah_in_local_tmp; then
        # 兜底位置：shell 用户需可读写，放开权限并标 shell_data_file
        chmod 0777 "$AAH_DATA_DIR" "$AAH_RULES_DIR" 2>/dev/null || true
        if command -v chown >/dev/null 2>&1; then
            chown shell:shell "$AAH_DATA_DIR" "$AAH_RULES_DIR" 2>/dev/null || true
        fi
        if [ -x /system/bin/toybox ]; then
            /system/bin/toybox chcon -R u:object_r:shell_data_file:s0 "$AAH_DATA_DIR" 2>/dev/null || true
        else
            chcon -R u:object_r:shell_data_file:s0 "$AAH_DATA_DIR" 2>/dev/null || true
        fi
    fi
    # 模块私有目录(/data/adb)：保持框架自身上下文与 root 属主，不 chmod 0777、不 chcon
}

aah_paths_migrate_legacy() {
    aah_paths_prepare
    # 从旧 /data/local/tmp 位置迁移规则/预设到模块私有目录（不覆盖已存在文件）
    if [ -d "$AAH_LEGACY_RULES_DIR" ]; then
        for _aah_old_rule in "$AAH_LEGACY_RULES_DIR"/*.conf; do
            [ -f "$_aah_old_rule" ] || continue
            _aah_new_rule="$AAH_RULES_DIR/$(basename "$_aah_old_rule")"
            [ -f "$_aah_new_rule" ] || cp -p "$_aah_old_rule" "$_aah_new_rule" 2>/dev/null || true
        done
    fi
    if [ -f "$AAH_LEGACY_PRESETS_FILE" ] && [ ! -f "$AAH_PRESETS_FILE" ]; then
        cp -p "$AAH_LEGACY_PRESETS_FILE" "$AAH_PRESETS_FILE" 2>/dev/null || true
    fi
    if aah_in_local_tmp; then
        chmod 0666 "$AAH_RULES_DIR"/*.conf "$AAH_PRESETS_FILE" 2>/dev/null || true
    fi
    unset _aah_old_rule _aah_new_rule
}

aah_restore_managed_apps() {
    MODPATH=${MODPATH:-/data/adb/skroot/modules/app_auto_hider}
    AAH_DATA_DIR=${AAH_DATA_DIR:-$MODPATH}
    AAH_RULES_DIR=${AAH_RULES_DIR:-$AAH_DATA_DIR/rules}
    _aah_users=$(
        {
            am get-current-user 2>/dev/null
            cmd user list 2>/dev/null | sed -n 's/.*UserInfo{\([0-9][0-9]*\):.*/\1/p'
            echo 0
        } | sed '/^[[:space:]]*$/d' | sort -nu | tr '\n' ' '
    )
    [ -n "$_aah_users" ] || _aah_users=0
    _aah_pkgs=$(
        {
            cat "$AAH_DATA_DIR/aah.state" 2>/dev/null
            # 当前配置目录 + 旧 /data/local/tmp 目录双读，卸载救回不遗漏
            for _aah_rule in "$AAH_RULES_DIR"/*.conf "$AAH_OLD_DATA_DIR/rules"/*.conf; do
                [ -f "$_aah_rule" ] && sed -e 's/\r$//' -e '/^[[:space:]]*#/d' -e '/^[[:space:]]*$/d' "$_aah_rule" 2>/dev/null
            done
        } | sort -u | grep -v '^$'
    )
    for _aah_pkg in $_aah_pkgs; do
        for _aah_user in $_aah_users; do
            pm unhide --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || cmd package unhide --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            pm unsuspend --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || cmd package unsuspend --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            pm enable --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            _aah_cu=$(am get-current-user 2>/dev/null | tr -dc '0-9'); [ -z "$_aah_cu" ] && _aah_cu=0
            [ "$_aah_user" = "$_aah_cu" ] && cmd package install-existing --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
        done
    done
    [ -n "$_aah_pkgs" ] && echo "[$(date '+%H:%M:%S.%3N' 2>/dev/null)] restore-managed pkgs=$(printf '%s' "$_aah_pkgs" | tr '\n' ',')" >> "$AAH_DATA_DIR/aah.log" 2>/dev/null
    rm -f "$AAH_DATA_DIR/aah.state" "$AAH_DATA_DIR/aah.games" "$AAH_DATA_DIR"/aah.bgsince.* 2>/dev/null || true
    unset _aah_users _aah_pkgs _aah_rule _aah_pkg _aah_user _aah_cu
}
