#!/system/bin/sh
# AAH daemon 独立启动器 (由 heartbeat.sh 在重新授权后触发)
# 不走 service.sh 避免重复启动 heartbeat/watch/tricky 等

# MODPATH 由 so 启动时通过环境变量传入；若为空则从 /proc/self/maps 推导
if [ -z "$MODPATH" ]; then
  MODPATH=$(grep -o '/[^ ]*module_app_auto_hider\.so' /proc/self/maps 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
fi
MODPATH=${MODPATH:-/data/adb/skroot/modules/app_auto_hider}
PATH=$MODPATH/common/bin:/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:$PATH
. "$MODPATH/common/aah_paths.sh" 2>/dev/null || true

AAH_RULES_DIR=${AAH_RULES_DIR:-$MODPATH/rules}
AAH_LOG="$AAH_DATA_DIR/aah.log"
AAH_LOG_MAX=900
AAH_STATE="$AAH_DATA_DIR/aah.state"
AAH_GAMES_STATE="$AAH_DATA_DIR/aah.games"
AAH_GAME_LAUNCH_DIR="$AAH_DATA_DIR/game_launch"
AAH_LOCKDIR="$AAH_DATA_DIR/aah.lock"
AAH_VERSION="1.7"
AAH_VERSION_FILE="$AAH_DATA_DIR/aah.version"
mkdir -p "$AAH_RULES_DIR" 2>/dev/null
mkdir -p "$AAH_GAME_LAUNCH_DIR" 2>/dev/null
command -v aah_paths_migrate_legacy >/dev/null 2>&1 && aah_paths_migrate_legacy >/dev/null 2>&1 || true
# 标记文件读取：配置根已统一到模块私有目录($MODPATH == $AAH_DATA_DIR，受框架隐藏保护)；
# 保留两处判断为同点幂等，兼容历史写法。
aah_flag() { [ -f "$MODPATH/$1" ] || [ -f "$AAH_DATA_DIR/$1" ]; }
# 默认后台保持：游戏进程/任务还在时继续冻结，避免回桌面后被管控 app 立刻恢复。
# 手动创建 .aah_foreground_only 可恢复“仅前台冻结”；创建 .aah_disabled 可完全停用辅助冻结。
aah_flag .aah_disabled && AAH_DISABLED=1 || AAH_DISABLED=0
# v34 默认开启后台保持：游戏挂后台不恢复冻结、不释放启动会话。
AAH_KEEP_BACKGROUND=1
aah_flag .aah_foreground_only && AAH_KEEP_BACKGROUND=0
aah_flag .aah_keep_background && AAH_KEEP_BACKGROUND=1
# 小窗/分屏可见识别 v190+ 默认开启: 你把游戏拖进小窗/分屏肯定是在玩,理应冻结生效.
# 之前默认关闭因担心某些 ROM 的 dumpsys window 残留后台窗口误判,但 v190 已有
# pidof 兜底保护(进程死了立刻清状态), 误冻结风险可控.
# 如果你的 ROM 真的会误判, 创建空文件 .aah_disable_visible_window 即可关闭.
AAH_VISIBLE_WINDOW=1
[ -f "$MODPATH/.aah_disable_visible_window" ] && AAH_VISIBLE_WINDOW=0
[ -f "$MODPATH/.aah_visible_window" ] && AAH_VISIBLE_WINDOW=1
# 方案A(默认开): 触发应用(游戏/检测方)活跃期间, 对勾选的风险App执行 am force-stop,
# 让其进程从内核进程表彻底消失——对游戏内核反作弊没有"进程在跑却被藏"的枚举破绽。
# 仅在该App确有进程在跑、且距上次强停超过冷却时才动作, 避免反复拉起空耗CPU。
# 创建 .aah_no_force_stop 可关闭; 创建 .aah_force_stop 可显式开启。
AAH_FORCE_STOP=1
aah_flag .aah_no_force_stop && AAH_FORCE_STOP=0
aah_flag .aah_force_stop && AAH_FORCE_STOP=1
AAH_KILL_COOLDOWN=4
AAH_BG_MAX_SECONDS=0
if [ -s "$MODPATH/.aah_bg_max_seconds" ]; then
    _aah_bg_max=$(cat "$MODPATH/.aah_bg_max_seconds" 2>/dev/null | tr -dc '0-9' | head -c 6)
    [ -n "$_aah_bg_max" ] && AAH_BG_MAX_SECONDS="$_aah_bg_max"
fi

# Concurrency guard: 如果 .aah.pid 里的 AAH 进程还活着, 直接退出, 防止 service.sh 启动 + heartbeat 重启同时拉起两个 daemon 抢状态.
aah_pid_alive() {
    _p="$1"
    [ -n "$_p" ] || return 1
    kill -0 "$_p" 2>/dev/null || return 1
    # 进程名伪装后 cmdline 只剩中性 "sh"，身份改认 environ 令牌(仅 root 可读，普通App不可见)
    _env=$(tr '\0' '\n' < "/proc/$_p/environ" 2>/dev/null)
    case "$_env" in
        *AAH_DAEMON=1*) unset _p _env; return 0 ;;
    esac
    # 兼容旧版(以脚本路径启动、cmdline 含 aah_launch.sh)
    _cmd=$(tr '\0' ' ' < "/proc/$_p/cmdline" 2>/dev/null)
    case "$_cmd" in
        *aah_launch.sh*) unset _p _env _cmd; return 0 ;;
    esac
    unset _p _env _cmd
    return 1
}

if ! mkdir "$AAH_LOCKDIR" 2>/dev/null; then
    _lock_pid=$(cat "$AAH_LOCKDIR/pid" 2>/dev/null | tr -d '\r\n ')
    if [ -z "$_lock_pid" ]; then
        sleep 1
        _lock_pid=$(cat "$AAH_LOCKDIR/pid" 2>/dev/null | tr -d '\r\n ')
    fi
    if aah_pid_alive "$_lock_pid"; then
        exit 0
    fi
    rm -rf "$AAH_LOCKDIR" 2>/dev/null
    mkdir "$AAH_LOCKDIR" 2>/dev/null || exit 0
fi
echo $$ > "$AAH_LOCKDIR/pid" 2>/dev/null

AAH_RELEASE_ON_EXIT=0
aah_restore_managed_fast() {
    _aah_users=$(
        {
            am get-current-user 2>/dev/null
            cmd user list 2>/dev/null | sed -n 's/.*UserInfo{\([0-9][0-9]*\):.*/\1/p'
            echo 0
        } | sed '/^[[:space:]]*$/d' | sort -nu | tr '\n' ' '
    )
    [ -n "$_aah_users" ] || _aah_users=0
    _aah_pkgs=$(
        {
            cat "$AAH_STATE" 2>/dev/null
            printf '%s\n' "$AAH_LAST_STATE" 2>/dev/null
            for _aah_rule in "$AAH_RULES_DIR"/*.conf "$MODPATH/rules"/*.conf; do
                [ -f "$_aah_rule" ] && sed -e 's/\r$//' -e '/^[[:space:]]*#/d' -e '/^[[:space:]]*$/d' "$_aah_rule" 2>/dev/null
            done
        } | sort -u | grep -v '^$'
    )
    for _aah_pkg in $_aah_pkgs; do
        for _aah_user in $_aah_users; do
            pm unhide --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || cmd package unhide --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            pm unsuspend --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || cmd package unsuspend --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            pm enable --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
            _aah_cu=$(am get-current-user 2>/dev/null | tr -dc '0-9'); [ -z "$_aah_cu" ] && _aah_cu=0
            [ "$_aah_user" = "$_aah_cu" ] && cmd package install-existing --user "$_aah_user" "$_aah_pkg" >/dev/null 2>&1 || true
        done
    done
    [ -n "$_aah_pkgs" ] && echo "[$(date '+%H:%M:%S.%3N' 2>/dev/null)] exit-restore pkgs=$(printf '%s' "$_aah_pkgs" | tr '\n' ',')" >> "$AAH_LOG" 2>/dev/null
    rm -f "$AAH_STATE" "$AAH_GAMES_STATE" "$AAH_DATA_DIR"/aah.bgsince.* 2>/dev/null || true
    unset _aah_users _aah_pkgs _aah_rule _aah_pkg _aah_user
}
aah_cleanup_exit() {
    [ "$AAH_RELEASE_ON_EXIT" = 1 ] && aah_restore_managed_fast
    _own_pid=$(cat "$AAH_DATA_DIR/aah.pid" "$MODPATH/.aah.pid" 2>/dev/null | head -n1 | tr -d '\r\n ')
    [ "$_own_pid" = "$$" ] && rm -f "$AAH_DATA_DIR/aah.pid" "$MODPATH/.aah.pid" 2>/dev/null
    rm -rf "$AAH_LOCKDIR" 2>/dev/null
}
trap 'aah_cleanup_exit' EXIT
trap 'AAH_RELEASE_ON_EXIT=1; exit 0' INT TERM

if [ -f "$AAH_DATA_DIR/aah.pid" ] || [ -f "$MODPATH/.aah.pid" ]; then
    _existing=$(cat "$AAH_DATA_DIR/aah.pid" "$MODPATH/.aah.pid" 2>/dev/null | head -n1 | tr -d '\r\n ')
    if [ "$_existing" != "$$" ] && aah_pid_alive "$_existing"; then
        # 已有 daemon 活着 → 不再启动新的
        exit 0
    fi
fi

# 写 PID 供 heartbeat.sh 检测存活
echo $$ > "$AAH_DATA_DIR/aah.pid" 2>/dev/null
echo $$ > "$MODPATH/.aah.pid" 2>/dev/null || true
echo "$AAH_VERSION" > "$AAH_VERSION_FILE" 2>/dev/null
echo "$AAH_VERSION" > "$MODPATH/.aah.version" 2>/dev/null || true

if [ "$AAH_DISABLED" = 1 ]; then
    # 兼容模式: 立刻恢复本模块管理过的包, 然后退出，不再轮询 dumpsys/pm。
    AAH_USERS=$(
        {
            am get-current-user 2>/dev/null
            cmd user list 2>/dev/null | sed -n 's/.*UserInfo{\([0-9][0-9]*\):.*/\1/p'
            echo 0
        } | sed '/^[[:space:]]*$/d' | sort -nu | tr '\n' ' '
    )
    [ -n "$AAH_USERS" ] || AAH_USERS=0
    AAH_DISABLED_PKGS=$(
        {
            cat "$AAH_STATE" 2>/dev/null
            for _r in "$AAH_RULES_DIR"/*.conf "$MODPATH/rules"/*.conf; do
                [ -f "$_r" ] && sed -e 's/\r$//' -e '/^[[:space:]]*#/d' -e '/^[[:space:]]*$/d' "$_r" 2>/dev/null
            done
        } | sort -u | grep -v '^$'
    )
    for _p in $AAH_DISABLED_PKGS; do
        for _u in $AAH_USERS; do
            pm unsuspend --user "$_u" "$_p" >/dev/null 2>&1 || cmd package unsuspend --user "$_u" "$_p" >/dev/null 2>&1 || true
            pm unhide --user "$_u" "$_p" >/dev/null 2>&1 || cmd package unhide --user "$_u" "$_p" >/dev/null 2>&1 || true
            pm enable --user "$_u" "$_p" >/dev/null 2>&1 || cmd package set-enabled-setting --user "$_u" "$_p" enabled >/dev/null 2>&1 || true
            _dis_cu=$(am get-current-user 2>/dev/null | tr -dc '0-9'); [ -z "$_dis_cu" ] && _dis_cu=0
            [ "$_u" = "$_dis_cu" ] && cmd package install-existing --user "$_u" "$_p" >/dev/null 2>&1 || true
        done
    done
    rm -f "$AAH_STATE" "$AAH_GAMES_STATE" "$AAH_DATA_DIR"/aah.bgsince.* 2>/dev/null || true
    echo "[$(date '+%H:%M:%S.%3N' 2>/dev/null)] disabled: restored managed apps and exited" >> "$AAH_LOG" 2>/dev/null
    exit 0
fi

AAH_LOG_TICK=0
AAH_CACHE_TS=0
AAH_CACHE_TTL=120
# 纯轮询 (事件驱动方案在部分 ROM 上 mksh read -t fifo 有诡异 hang 问题撤销).
# v28 anti-hang: 关键 pm/dumpsys 命令加超时, 减少卡死风险；并继续压低轮询。
# - SLEEP_ACTIVE (0.3s): hide/restore 状态机进行中, 快速响应切换.
# - SLEEP_STABLE (1s): 已冻结 + fg 稳定, 仍保持 1s 内可检测退出并恢复.
# - SLEEP_IDLE (0.3s): 闲置等触发应用启动, 最坏 0.3s 发现进程(配合进程启动预热更早藏好).
# - SLEEP_LOCKED (15s): 未授权时无意义查 fg.
# - SLEEP_SCREEN_OFF (30s): 锁屏时极低频轮询.
# 响应提速: 进程启动预热 + 0.3s 轮询，触发应用进程一起来就藏目标(早于其界面首次扫描)；
# 退出/切后台到恢复 ~1-1.5s。
AAH_SLEEP_ACTIVE=0.3
AAH_SLEEP_STABLE=1
AAH_SLEEP_IDLE=0.3
AAH_SLEEP_LOCKED=15
AAH_SLEEP_SCREEN_OFF=30
AAH_SLEEP_PRESSURE=20
AAH_GAME_STABLE_SECONDS=0
if [ -s "$MODPATH/.aah_game_stable_seconds" ]; then
    _aah_stable=$(cat "$MODPATH/.aah_game_stable_seconds" 2>/dev/null | tr -dc '0-9' | head -c 3)
    [ -n "$_aah_stable" ] && AAH_GAME_STABLE_SECONDS="$_aah_stable"
fi
AAH_KILL_TS=""
AAH_LAST_STATE=""
AAH_LAST_FG=""
AAH_LAST_GAME_FG=""
AAH_GAME_FG_SINCE=0
AAH_LAST_LAUNCH_GAME=""
AAH_LAUNCHED_GAMES="|"
AAH_PKG_KNOWN=""
AAH_PKG_VISIBLE=""
AAH_WAS_AUTHORIZED=0
AAH_USERS=""
AAH_LAST_DIAG_TS=0
AAH_IDLE_LOG_INTERVAL=60
AAH_GAME_BG_SINCE=""
AAH_FORCE_RESTORE_ONCE=0
AAH_RESTORE_UNTIL=0
AAH_RESTORE_PKGS=""
AAH_RESTORE_NEXT_TS=0
AAH_HIDE_RETRY_INTERVAL=30
AAH_HIDE_RETRY_NEXT_TS=0
AAH_SCREEN_CACHE_TS=0
AAH_SCREEN_CACHE_TTL=30
AAH_SCREEN_INTERACTIVE=1
AAH_LAST_FORCE_REFRESH_TS=0
AAH_FORCE_REFRESH_MIN_INTERVAL=15
AAH_LAST_RECENTS_TS=0
AAH_RECENTS_MIN_INTERVAL=10
AAH_WINDOW_DUMP=""
AAH_WINDOW_DUMP_READY=0
AAH_ACTIVITY_DUMP=""
AAH_ACTIVITY_DUMP_READY=0
AAH_TASK_DUMP=""
AAH_TASK_DUMP_READY=0
AAH_RECENTS_DUMP=""
AAH_RECENTS_DUMP_READY=0
AAH_PRESSURE_CHECK_TS=0
AAH_PRESSURE_CHECK_TTL=60
AAH_PRESSURE_PAUSE_UNTIL=0
AAH_PRESSURE_ACTIVE=0
AAH_LOW_MEM_KB=524288
AAH_LOW_SWAP_KB=262144
AAH_CMD_TIMEOUT=4
if [ -s "$MODPATH/.aah_cmd_timeout" ]; then
    _aah_cmd_timeout=$(cat "$MODPATH/.aah_cmd_timeout" 2>/dev/null | tr -dc '0-9' | head -c 2)
    [ -n "$_aah_cmd_timeout" ] && AAH_CMD_TIMEOUT="$_aah_cmd_timeout"
fi
AAH_PROTECT_PKGS="
com.android.systemui
com.android.settings
com.android.phone
com.android.dialer
com.android.incallui
com.google.android.dialer
com.android.server.telecom
"

# 取当前 epoch 秒：优先 mksh/bash 内建 EPOCHSECONDS（0 fork，省 CPU），老环境回退 date
aah_now() {
    if [ -n "$EPOCHSECONDS" ]; then
        printf '%s' "$EPOCHSECONDS"
    else
        date +%s
    fi
}

aah_log() {
    [ -n "$1" ] || return 0
    ts=$(date '+%H:%M:%S.%3N' 2>/dev/null)
    echo "[$ts] $*" >> "$AAH_LOG"
    AAH_LOG_TICK=$((AAH_LOG_TICK + 1))
    if [ "$AAH_LOG_TICK" -ge 120 ]; then
        AAH_LOG_TICK=0
        if [ -f "$AAH_LOG" ]; then
            lc=$(wc -l < "$AAH_LOG" 2>/dev/null)
            if [ "${lc:-0}" -gt "$AAH_LOG_MAX" ] 2>/dev/null; then
                tail -n 200 "$AAH_LOG" > "$AAH_LOG.tmp" 2>/dev/null && mv -f "$AAH_LOG.tmp" "$AAH_LOG"
            fi
        fi
    fi
}

aah_cmd_try() {
    _label="$1"
    shift
    if command -v timeout >/dev/null 2>&1; then
        _out=$(timeout "$AAH_CMD_TIMEOUT" "$@" 2>&1)
    else
        _out=$("$@" 2>&1)
    fi
    _rc=$?
    _out=$(printf '%s' "$_out" | tr '\r\n' ' ' | cut -c1-180)
    aah_log "cmd[$_label] rc=$_rc out=${_out:-<empty>}"
    return "$_rc"
}

aah_quick_out() {
    if command -v timeout >/dev/null 2>&1; then
        timeout "$AAH_CMD_TIMEOUT" "$@" 2>/dev/null
    else
        "$@" 2>/dev/null
    fi
}

# 内存/CPU 优化：dumpsys 全量输出常达数百 KB~数 MB。这里在抓取管道里就只保留
# 下游会用到的行，并尽量让 grep 提前关闭管道，使 dumpsys 收到 SIGPIPE 尽早退出。
#   - 前台行 aah_capture_activity：grep -m1 命中第一条 Resumed 即停（它在 dump 很
#     靠前），dumpsys 不必序列化后面海量 Task/Hist 记录，这是每轮最重命令的主要省点；
#   - 任务行 aah_capture_task_dump：仅后台保持判断"游戏任务是否还在"时惰性取一次。
#   - window：保留 Window#块头与可见性/焦点字段，供前台兜底与小窗分块判断。
aah_capture_activity() {
    aah_quick_out dumpsys activity activities \
        | grep -m1 -E 'topResumedActivity|mResumedActivity|ResumedActivity'
}
aah_capture_task_dump() {
    aah_quick_out dumpsys activity activities \
        | grep -E 'packageName=|cmp='
}
aah_capture_window() {
    _cw=$(aah_quick_out dumpsys window \
        | grep -E '^[[:space:]]*Window #[0-9]+|mHasSurface|isVisible|mPolicyVisibility|mFocusedApp|mCurrentFocus|mFocusedWindow')
    [ -n "$_cw" ] || _cw=$(aah_quick_out dumpsys window displays \
        | grep -E '^[[:space:]]*Window #[0-9]+|mHasSurface|isVisible|mPolicyVisibility|mFocusedApp|mCurrentFocus|mFocusedWindow')
    printf '%s' "$_cw"
    unset _cw
}

aah_get_list() {
    sed -e 's/\r$//' -e '/^[[:space:]]*#/d' -e '/^[[:space:]]*$/d' "$1" 2>/dev/null
}

aah_authorized() {
    return 0
}

aah_extract_pkg() {
    # grep -oE 可能输出多个匹配(甚至同一行多个)；用 POSIX 参数展开取第一个、去尾斜杠，
    # 全程仅 1 个 grep 进程（替代 grep|head|sed 三个进程）。
    _ep=$(printf '%s\n' "$1" | grep -oE '([a-zA-Z0-9_]+\.)+[a-zA-Z0-9_]+/')
    _ep=${_ep%%'
'*}
    printf '%s' "${_ep%/}"
    unset _ep
}

aah_foreground() {
    local _fg _line
    # 1) AAH_ACTIVITY_DUMP 经 -m1 早停已只是"第一条 Resumed 行"，直接提取，无需再 grep
    if [ "$AAH_ACTIVITY_DUMP_READY" != 1 ]; then
        AAH_ACTIVITY_DUMP=$(aah_capture_activity)
        AAH_ACTIVITY_DUMP_READY=1
    fi
    _fg=$(aah_extract_pkg "$AAH_ACTIVITY_DUMP")
    # 2) window mFocusedApp / mCurrentFocus / mFocusedWindow (共用一次 dumpsys window 缓存)
    if [ -z "$_fg" ]; then
        if [ "$AAH_WINDOW_DUMP_READY" != 1 ]; then
            AAH_WINDOW_DUMP=$(aah_capture_window)
            AAH_WINDOW_DUMP_READY=1
        fi
        _line=$(printf '%s\n' "$AAH_WINDOW_DUMP" | grep -m1 mFocusedApp)
        _fg=$(aah_extract_pkg "$_line")
        [ -z "$_fg" ] && { _line=$(printf '%s\n' "$AAH_WINDOW_DUMP" | grep -m1 mCurrentFocus); _fg=$(aah_extract_pkg "$_line"); }
        [ -z "$_fg" ] && { _line=$(printf '%s\n' "$AAH_WINDOW_DUMP" | grep -m1 mFocusedWindow); _fg=$(aah_extract_pkg "$_line"); }
    fi
    printf '%s' "$_fg"
}

aah_pkg_visible_window() {
    # 用于检测"游戏在分屏/小窗/画中画但焦点在别处"的情况.
    # 关键: 后台进程的 window 条目 (paused activity) 也会出现在 dumpsys window 里,
    # 仅看到 Window{...pkg...} 不能算"可见", 否则会把后台 app 误判为前台,
    # 导致错误触发冻结状态机 + 错误跳过 hide.
    # 严格判: 必须找到 pkg 块内同时出现 mHasSurface=true 且 (isVisible=true 或
    # mPolicyVisibility=true). 块边界用下一个 'Window #' 头识别.
    _vpkg="$1"
    [ -n "$_vpkg" ] || return 1
    if [ "$AAH_WINDOW_DUMP_READY" != 1 ]; then
        AAH_WINDOW_DUMP=$(aah_capture_window)
        AAH_WINDOW_DUMP_READY=1
    fi
    [ -n "$AAH_WINDOW_DUMP" ] || { unset _vpkg; return 1; }
    printf '%s\n' "$AAH_WINDOW_DUMP" | awk -v p="$_vpkg" '
        # 进入新 Window 块 (Window #N Window{addr u0 pkg/Activity}): 重置块状态
        /^ *Window #[0-9]+/ {
            if (in_block && has_surface && (is_visible || policy_visible)) { found=1; exit }
            in_block = (index($0, p) > 0) ? 1 : 0
            has_surface = 0
            is_visible = 0
            policy_visible = 0
            next
        }
        in_block && /mHasSurface=true/ { has_surface = 1 }
        in_block && /isVisible=true/   { is_visible = 1 }
        in_block && /mPolicyVisibility=true/ { policy_visible = 1 }
        in_block && /mHasSurface=false|isVisible=false|mPolicyVisibility=false/ {
            # 显式 false 字段不立即退出 (后续可能有其他字段覆盖), 但保持各自标志状态.
            # 实际上一个块里同字段不会冲突, 这里只保证不会被 false 行误升 ok.
        }
        END {
            if (in_block && has_surface && (is_visible || policy_visible)) found=1
            exit found ? 0 : 1
        }
    '
    _vrc=$?
    unset _vpkg
    return "$_vrc"
}

aah_screen_interactive() {
    _now_screen=$(aah_now)
    [ -n "$_now_screen" ] || _now_screen=0
    _elapsed_screen=$(( _now_screen - AAH_SCREEN_CACHE_TS ))
    if [ "$AAH_SCREEN_CACHE_TS" -gt 0 ] 2>/dev/null && [ "$_elapsed_screen" -lt "$AAH_SCREEN_CACHE_TTL" ] 2>/dev/null; then
        [ "$AAH_SCREEN_INTERACTIVE" = 1 ]
        return $?
    fi
    _power_dump=$(aah_quick_out dumpsys power)
    if [ -z "$_power_dump" ]; then
        AAH_SCREEN_INTERACTIVE=1
    else
        case "$_power_dump" in
            *"mInteractive=true"*|*"mWakefulness=Awake"*|*"mWakefulness=Dreaming"*|*"Display Power: state=ON"*|*"state=ON"*)
                AAH_SCREEN_INTERACTIVE=1
                ;;
            *)
                AAH_SCREEN_INTERACTIVE=0
                ;;
        esac
    fi
    AAH_SCREEN_CACHE_TS=$_now_screen
    unset _now_screen _elapsed_screen _power_dump
    [ "$AAH_SCREEN_INTERACTIVE" = 1 ]
}

aah_pressure_active() {
    _now_pressure=$(aah_now)
    [ -n "$_now_pressure" ] || _now_pressure=0
    if [ "$AAH_PRESSURE_PAUSE_UNTIL" -gt "$_now_pressure" ] 2>/dev/null; then
        return 0
    fi
    _elapsed_pressure=$(( _now_pressure - AAH_PRESSURE_CHECK_TS ))
    if [ "$AAH_PRESSURE_CHECK_TS" -gt 0 ] 2>/dev/null && [ "$_elapsed_pressure" -lt "$AAH_PRESSURE_CHECK_TTL" ] 2>/dev/null; then
        [ "$AAH_PRESSURE_ACTIVE" = 1 ]
        return $?
    fi
    AAH_PRESSURE_CHECK_TS=$_now_pressure
    AAH_PRESSURE_ACTIVE=0
    _mem_avail=$(awk '/^MemAvailable:/ {print $2; exit}' /proc/meminfo 2>/dev/null)
    _swap_total=$(awk '/^SwapTotal:/ {print $2; exit}' /proc/meminfo 2>/dev/null)
    _swap_free=$(awk '/^SwapFree:/ {print $2; exit}' /proc/meminfo 2>/dev/null)
    [ -n "$_mem_avail" ] || { unset _now_pressure _elapsed_pressure _mem_avail _swap_total _swap_free; return 1; }
    [ -n "$_swap_total" ] || _swap_total=0
    [ -n "$_swap_free" ] || _swap_free=0
    if [ "$_mem_avail" -lt "$AAH_LOW_MEM_KB" ] 2>/dev/null && { [ "$_swap_total" -le 0 ] 2>/dev/null || [ "$_swap_free" -lt "$AAH_LOW_SWAP_KB" ] 2>/dev/null; }; then
        AAH_PRESSURE_ACTIVE=1
        AAH_PRESSURE_PAUSE_UNTIL=$((_now_pressure + 60))
        aah_log "pressure-pause mem_avail=${_mem_avail}k swap_free=${_swap_free}k swap_total=${_swap_total}k"
        unset _now_pressure _elapsed_pressure _mem_avail _swap_total _swap_free
        return 0
    fi
    unset _now_pressure _elapsed_pressure _mem_avail _swap_total _swap_free
    return 1
}

aah_users() {
    {
        aah_quick_out am get-current-user
        aah_quick_out cmd user list | sed -n 's/.*UserInfo{\([0-9][0-9]*\):.*/\1/p'
        echo 0
    } | sed '/^[[:space:]]*$/d' | sort -nu
}

aah_refresh_users() {
    _u=$(aah_users | tr '\n' ' ' | sed 's/[[:space:]]*$//')
    [ -n "$_u" ] || _u="0"
    if [ "$_u" != "$AAH_USERS" ]; then
        AAH_USERS="$_u"
        aah_log "users: $AAH_USERS"
    fi
}

aah_refresh_cache() {
    now_ts=$(aah_now)
    [ -n "$now_ts" ] || now_ts=0
    elapsed=$((now_ts - AAH_CACHE_TS))
    if [ "$1" = "force" ] || [ -z "$AAH_PKG_KNOWN" ] || [ "$elapsed" -ge "$AAH_CACHE_TTL" ]; then
        aah_refresh_users
        AAH_PKG_KNOWN=""
        AAH_PKG_VISIBLE=""
        for _u in $AAH_USERS; do
            AAH_PKG_KNOWN="$AAH_PKG_KNOWN
$(aah_quick_out cmd package list packages -u --user "$_u")"
            AAH_PKG_VISIBLE="$AAH_PKG_VISIBLE
$(aah_quick_out cmd package list packages --user "$_u")"
        done
        AAH_CACHE_TS=$now_ts
    fi
}

aah_known() {
    [ -n "$1" ] || return 1
    # 等价 grep -Fqx 整行精确匹配，但用 case 换行边界在 shell 内完成、0 fork（省每轮每包进程）
    case "
$AAH_PKG_KNOWN
" in
        *"
package:$1
"*) return 0 ;;
    esac
    return 1
}
aah_visible() {
    [ -n "$1" ] || return 1
    case "
$AAH_PKG_VISIBLE
" in
        *"
package:$1
"*) return 0 ;;
    esac
    return 1
}
aah_current_visible() {
    for _u in $AAH_USERS; do
        aah_quick_out cmd package list packages --user "$_u" | grep -Fqx "package:$1" && return 0
    done
    return 1
}

aah_state_has_pkg() {
    [ -n "$1" ] || return 1
    case "
$AAH_LAST_STATE
" in
        *"
$1
"*) return 0 ;;
    esac
    return 1
}

aah_restore_active() {
    _now_restore=$(aah_now)
    [ -n "$_now_restore" ] || _now_restore=0
    [ -n "$AAH_RESTORE_PKGS" ] && [ "$AAH_RESTORE_UNTIL" -gt "$_now_restore" ] 2>/dev/null
}

aah_restore_queue_add() {
    _pkgs="$1"
    [ -n "$_pkgs" ] || return 0
    _now_restore=$(aah_now)
    [ -n "$_now_restore" ] || _now_restore=0
    AAH_RESTORE_UNTIL=$((_now_restore + 180))
    AAH_RESTORE_NEXT_TS=$((_now_restore))  # 提速: 当轮即可恢复, 不再多等 1s
    AAH_RESTORE_PKGS=$(
        {
            printf '%s\n' "$AAH_RESTORE_PKGS"
            printf '%s\n' "$_pkgs"
        } | sed '/^[[:space:]]*$/d' | sort -u
    )
    aah_log "restore-queue until=$AAH_RESTORE_UNTIL pkgs=$(printf '%s' "$AAH_RESTORE_PKGS" | tr '\n' ',')"
}

aah_restore_user_pkg() {
    _u="$1"
    _p="$2"
    _mode="$3"
    [ -n "$_u" ] && [ -n "$_p" ] || return 1
    _ok=1
    if aah_cmd_try "pm-unsuspend:u=$_u:$1" pm unsuspend --user "$_u" "$_p"; then
        _ok=0
    elif aah_cmd_try "cmd-unsuspend:u=$_u:$1" cmd package unsuspend --user "$_u" "$_p"; then
        _ok=0
    fi
    if aah_cmd_try "pm-unhide:u=$_u:$1" pm unhide --user "$_u" "$_p"; then
        _ok=0
    elif aah_cmd_try "cmd-unhide:u=$_u:$1" cmd package unhide --user "$_u" "$_p"; then
        _ok=0
    fi
    if [ "$_mode" = "force" ]; then
        if aah_cmd_try "pm-enable:u=$_u:$1" pm enable --user "$_u" "$_p"; then
            _ok=0
        elif aah_cmd_try "cmd-enable:u=$_u:$1" cmd package set-enabled-setting --user "$_u" "$_p" enabled; then
            _ok=0
        fi
        # install-existing 对"已对该用户正常安装"的包是幂等 no-op（不改 hidden/
        # suspend/disabled），只有该包被"对用户卸载(pm uninstall --user)"时才真正装回，
        # 这正是"图标恢复后又消失/救不回"的兜底。因此不再要求前面命令全失败才执行，
        # force 恢复时对当前用户总是补一次。仍严格限定当前用户，避免在分身/系统克隆
        # 用户凭空创建系统应用分身(v295 教训)。
        _current_user=$(am get-current-user 2>/dev/null | tr -dc '0-9' | head -c 3)
        [ -z "$_current_user" ] && _current_user=0
        if [ "$_u" = "$_current_user" ]; then
            aah_cmd_try "install-existing:u=$_u:$1" cmd package install-existing --user "$_u" "$_p" && _ok=0
        fi
        unset _current_user
    fi
    unset _mode
    return "$_ok"
}

aah_pkg_running() {
    # Bug history: pgrep -x 只匹配 comm (15 字符截断), Android 包名超 15 字符时永远 false.
    # 修复: 1) pidof 优先 (查 /proc/*/cmdline 全名); 2) pgrep -f 兜底 (匹配完整 cmdline).
    # v24: 移除 /proc 全扫描兜底 — pidof + pgrep -f 已覆盖 99.9% 场景,
    # 全扫描在游戏场景下 fork 1000+ 次 tr 是发热主因之一.
    [ -n "$1" ] || return 1
    pidof "$1" >/dev/null 2>&1 && return 0
    pgrep -f "(^|/)$1(:|$)" >/dev/null 2>&1 && return 0
    return 1
}

aah_game_task_present() {
    # 区分"切到后台但还在最近任务"和"用户已经划掉后台"。
    # 部分 ROM 划掉后进程会短暂残留, 不能只靠 pidof 判断。
    _gp="$1"
    [ -n "$_gp" ] || return 1
    # 任务/历史行惰性抓取（含 packageName=/cmp=），与"前台行 -m1 早停"分开，避免每轮全量
    if [ "$AAH_TASK_DUMP_READY" != 1 ]; then
        AAH_TASK_DUMP=$(aah_capture_task_dump)
        AAH_TASK_DUMP_READY=1
    fi
    if printf '%s\n' "$AAH_TASK_DUMP" | grep -Fq "packageName=$_gp"; then
        unset _gp
        return 0
    fi
    if printf '%s\n' "$AAH_TASK_DUMP" | grep -Fq "cmp=$_gp/"; then
        unset _gp
        return 0
    fi
    if [ "$AAH_RECENTS_DUMP_READY" != 1 ]; then
        _now_recents=$(aah_now)
        [ -n "$_now_recents" ] || _now_recents=0
        if [ "$AAH_LAST_RECENTS_TS" -gt 0 ] 2>/dev/null && [ $((_now_recents - AAH_LAST_RECENTS_TS)) -lt "$AAH_RECENTS_MIN_INTERVAL" ] 2>/dev/null; then
            # 距上次 recents dump 不足 10s, 跳过 (假设 task 仍在)
            unset _gp _now_recents
            return 0
        fi
        AAH_RECENTS_DUMP=$(aah_quick_out dumpsys activity recents)
        AAH_RECENTS_DUMP_READY=1
        AAH_LAST_RECENTS_TS=$_now_recents
        unset _now_recents
    fi
    if printf '%s\n' "$AAH_RECENTS_DUMP" | grep -Fq "mActivityComponent=$_gp/"; then
        unset _gp
        return 0
    fi
    if printf '%s\n' "$AAH_RECENTS_DUMP" | grep -Fq "=$_gp/"; then
        unset _gp
        return 0
    fi
    unset _gp
    return 1
}

aah_protected_pkg() {
    [ -n "$1" ] || return 1
    case "
$AAH_PROTECT_PKGS
" in
        *"
$1
"*) return 0 ;;
    esac
    return 1
}

aah_clear_game_bg_since() {
    _g="$1"
    [ -n "$_g" ] || return 0
    rm -f "$AAH_DATA_DIR/aah.bgsince.${_g}" 2>/dev/null
}

aah_bg_since_get() {
    _g="$1"
    [ -n "$_g" ] || return 0
    [ -f "$AAH_DATA_DIR/aah.bgsince.${_g}" ] && cat "$AAH_DATA_DIR/aah.bgsince.${_g}" 2>/dev/null
}

aah_bg_since_set() {
    _g="$1"
    _ts="$2"
    [ -n "$_g" ] && [ -n "$_ts" ] || return 0
    printf '%s' "$_ts" > "$AAH_DATA_DIR/aah.bgsince.${_g}" 2>/dev/null
}

aah_seen_add() {
    _g="$1"
    [ -n "$_g" ] || return 0
    # 直接追加到盘文件 (绕过内存变量异常清空), 同时同步 内存变量
    case "$AAH_SEEN_GAMES" in
        *"|$_g|"*) ;;
        *) AAH_SEEN_GAMES="$AAH_SEEN_GAMES|$_g|" ;;
    esac
    # 用追加+去重模式直接写盘, 不靠内存
    {
        cat "$AAH_GAMES_STATE" 2>/dev/null
        printf '%s\n' "$_g"
    } | sed '/^[[:space:]]*$/d' | sort -u > "$AAH_GAMES_STATE.tmp" 2>/dev/null \
        && mv -f "$AAH_GAMES_STATE.tmp" "$AAH_GAMES_STATE" 2>/dev/null
}

aah_seen_del() {
    _g="$1"
    [ -n "$_g" ] || return 0
    AAH_SEEN_GAMES=$(
        printf '%s\n' "$AAH_SEEN_GAMES" \
            | tr '|' '\n' \
            | sed '/^[[:space:]]*$/d' \
            | grep -Fvx "$_g" 2>/dev/null \
            | sed 's/^/|/;s/$/|/' \
            | tr -d '\n'
    )
    # 同步从盘文件删除
    if [ -s "$AAH_GAMES_STATE" ]; then
        grep -Fvx "$_g" "$AAH_GAMES_STATE" 2>/dev/null > "$AAH_GAMES_STATE.tmp" || true
        mv -f "$AAH_GAMES_STATE.tmp" "$AAH_GAMES_STATE" 2>/dev/null || true
    fi
    aah_clear_game_bg_since "$_g"
}

aah_persist_seen_games() {
    # 已废弃: aah_seen_add/del 直接写盘. 此函数保留为 noop 以兼容老调用.
    return 0
}

aah_load_seen_games() {
    [ -s "$AAH_GAMES_STATE" ] || return 0
    while IFS= read -r _g; do
        [ -n "$_g" ] || continue
        aah_seen_add "$_g"
    done < "$AAH_GAMES_STATE"
}

aah_fg_is_safe_release() {
    case "$1" in
        ''|com.android.launcher*|com.miui.home|com.huawei.android.launcher|com.oppo.launcher|com.bbk.launcher2|com.vivo.launcher|com.sec.android.app.launcher|com.meizu.flyme.launcher|cn.nubia.launcher|com.android.settings|com.miui.securitycenter|com.coloros.safecenter|com.iqoo.secure|com.vivo.permissionmanager|com.android.systemui)
            return 0
            ;;
    esac
    return 1
}

aah_game_fg_stable() {
    _game_fg="$1"
    [ -n "$_game_fg" ] || return 1
    _now_game_fg=$(aah_now)
    [ -n "$_now_game_fg" ] || _now_game_fg=0
    if [ "$AAH_LAST_GAME_FG" != "$_game_fg" ]; then
        AAH_LAST_GAME_FG="$_game_fg"
        AAH_GAME_FG_SINCE="$_now_game_fg"
        aah_log "game foreground warmup: $_game_fg ${AAH_GAME_STABLE_SECONDS}s"
        # v189 加速: 同一轮里就把 STABLE 期等完(默认 1s),再查一次前台仍是
        # 同一个游戏就当稳定. 之前要等下一轮循环(SLEEP_IDLE 3s)才能再判,
        # 所以从 fg-切换到 trigger 至少 3s + 1s + 3s = 7s,改后 1s 内即可.
        if [ "$AAH_GAME_STABLE_SECONDS" -gt 0 ] 2>/dev/null; then
            sleep "$AAH_GAME_STABLE_SECONDS" 2>/dev/null || sleep 1
            # 重查前清缓存,否则 aah_foreground 直接复用同一轮的旧值,refg 永远等于
            # 主循环开头那次查询的结果(那时游戏还没就绪) → 加速分支永远 return 1
            # → 启动脚本被漏掉,要等下一轮普通节奏 3s+ 才触发.
            AAH_ACTIVITY_DUMP=""
            AAH_ACTIVITY_DUMP_READY=0
            AAH_TASK_DUMP=""
            AAH_TASK_DUMP_READY=0
            _refg=$(aah_foreground 2>/dev/null)
            if [ "$_refg" = "$_game_fg" ]; then
                AAH_GAME_FG_SINCE=$(aah_now)
                [ -n "$AAH_GAME_FG_SINCE" ] || AAH_GAME_FG_SINCE=0
                AAH_GAME_FG_SINCE=$((AAH_GAME_FG_SINCE - AAH_GAME_STABLE_SECONDS - 1))
                aah_log "game foreground stabilized fast: $_game_fg"
                unset _game_fg _now_game_fg _refg
                return 0
            fi
            aah_log "game foreground recheck failed: want=$_game_fg got=${_refg:-?}"
            unset _refg
        fi
        unset _game_fg _now_game_fg
        return 1
    fi
    _game_fg_elapsed=$((_now_game_fg - AAH_GAME_FG_SINCE))
    if [ "$AAH_GAME_STABLE_SECONDS" -gt 0 ] 2>/dev/null && [ "$_game_fg_elapsed" -lt "$AAH_GAME_STABLE_SECONDS" ] 2>/dev/null; then
        unset _game_fg _now_game_fg _game_fg_elapsed
        return 1
    fi
    unset _game_fg _now_game_fg _game_fg_elapsed
    return 0
}

aah_game_launch_file() {
    printf '%s/%s.cmd' "$AAH_GAME_LAUNCH_DIR" "$1"
}

aah_game_launch_seq_file() {
    printf '%s/%s.seq' "$AAH_GAME_LAUNCH_DIR" "$1"
}

aah_game_launch_mark_file() {
    printf '%s/.%s.launched' "$AAH_GAME_LAUNCH_DIR" "$1"
}

aah_launch_session_remove() {
    _ls_pkg="$1"
    [ -n "$_ls_pkg" ] || return 0
    _ls_new="|"
    for _ls_item in $(printf '%s' "$AAH_LAUNCHED_GAMES" | tr '|' ' '); do
        [ "$_ls_item" = "$_ls_pkg" ] && continue
        _ls_new="${_ls_new}${_ls_item}|"
    done
    AAH_LAUNCHED_GAMES="$_ls_new"
    rm -f "$(aah_game_launch_mark_file "$_ls_pkg")" 2>/dev/null || true
    unset _ls_pkg _ls_new _ls_item
}

aah_launch_sessions_prune() {
    _ls_new="|"
    for _ls_item in $(printf '%s' "$AAH_LAUNCHED_GAMES" | tr '|' ' '); do
        [ -n "$_ls_item" ] || continue
        if aah_pkg_running "$_ls_item"; then
            _ls_new="${_ls_new}${_ls_item}|"
        else
            rm -f "$(aah_game_launch_mark_file "$_ls_item")" 2>/dev/null || true
        fi
    done
    AAH_LAUNCHED_GAMES="$_ls_new"
    unset _ls_new _ls_item
}

aah_fire_game_launch() {
    _gl_game="$1"
    [ -n "$_gl_game" ] || return 0
    # 本模块不随包提供 game_launch_once.sh（"进游戏执行自定义脚本"扩展未启用）。
    # runner 缺失时整体静默短路：功能本就不会生效，这样可避免每局游戏刷一条
    # cmd_file_missing 日志（挤占日志额度）并省掉 pidof/mark 等无谓检查；
    # 将来若补回 runner，此扩展会自动恢复工作。
    [ -s "$MODPATH/common/game_launch_once.sh" ] || return 0
    # 自动触发只认"同一游戏进程仍存活"这个会话。不能用 pidof 返回的第一个 pid
    # 做 token: 一局结束/回大厅时多进程顺序会抖, 会把同一游戏误判成新会话。
    _gl_pid=$(pidof "$_gl_game" 2>/dev/null | awk '{print $1}')
    [ -n "$_gl_pid" ] || _gl_pid="0"
    _gl_mark=$(aah_game_launch_mark_file "$_gl_game")
    if [ -f "$_gl_mark" ]; then
        if aah_pkg_running "$_gl_game"; then
            aah_log "game-launch skip pkg=$_gl_game pid=$_gl_pid (marked live session)"
            case "$AAH_LAUNCHED_GAMES" in
                *"|$_gl_game|"*) ;;
                *) AAH_LAUNCHED_GAMES="${AAH_LAUNCHED_GAMES}${_gl_game}|" ;;
            esac
            unset _gl_game _gl_pid _gl_mark
            return 0
        fi
        rm -f "$_gl_mark" 2>/dev/null || true
    fi
    case "$AAH_LAUNCHED_GAMES" in
        *"|$_gl_game|"*)
            if aah_pkg_running "$_gl_game"; then
                aah_log "game-launch skip pkg=$_gl_game pid=$_gl_pid (already launched in live session)"
                unset _gl_game _gl_pid _gl_mark
                return 0
            fi
            ;;
    esac
    if [ "$AAH_LAST_LAUNCH_GAME" = "$_gl_game" ] && aah_pkg_running "$_gl_game"; then
        aah_log "game-launch skip pkg=$_gl_game pid=$_gl_pid (same live session)"
        unset _gl_game _gl_pid _gl_mark
        return 0
    fi
    _gl_file=$(aah_game_launch_file "$_gl_game")
    _gl_seq=$(aah_game_launch_seq_file "$_gl_game")
    if [ ! -s "$_gl_file" ]; then
        aah_log "game-launch skip pkg=$_gl_game cmd_file_missing=$_gl_file"
        unset _gl_game _gl_pid _gl_mark _gl_file _gl_seq
        return 0
    fi
    aah_log "game-launch trigger: $_gl_game pid=$_gl_pid"
    export MRRR_GAME_LAUNCH_IMGUI=1
    export MRRR_GAME_LAUNCH_AUTO=1
    export MRRR_GAME_LAUNCH_REPLACE=0
    sh "$MODPATH/common/game_launch_once.sh" "$_gl_game" "$_gl_file" "$_gl_seq" "$AAH_LOG" >/dev/null 2>&1 || true
    AAH_LAST_LAUNCH_GAME="$_gl_game"
    mkdir -p "$AAH_GAME_LAUNCH_DIR" 2>/dev/null || true
    printf '%s %s\n' "$(aah_now)" "$_gl_pid" > "$_gl_mark" 2>/dev/null || true
    case "$AAH_LAUNCHED_GAMES" in
        *"|$_gl_game|"*) ;;
        *) AAH_LAUNCHED_GAMES="${AAH_LAUNCHED_GAMES}${_gl_game}|" ;;
    esac
    unset _gl_game _gl_pid _gl_mark _gl_file _gl_seq
}

# —— 方案A：强停风险 App 进程。冷却时间戳用内存字符串 "pkg=epoch " 记录(纯 POSIX)。——
aah_kill_ts_get() {
    _ktg_pkg="$1"; _ktg_ret=0
    for _ktg_i in $AAH_KILL_TS; do
        case "$_ktg_i" in
            "$_ktg_pkg"=*) _ktg_ret=${_ktg_i#*=} ;;
        esac
    done
    printf '%s' "$_ktg_ret"
    unset _ktg_pkg _ktg_ret _ktg_i
}
aah_kill_ts_set() {
    _kts_pkg="$1"; _kts_ts="$2"; _kts_new=""
    for _kts_i in $AAH_KILL_TS; do
        case "$_kts_i" in
            "$_kts_pkg"=*) ;;
            *) _kts_new="$_kts_new $_kts_i" ;;
        esac
    done
    AAH_KILL_TS="$_kts_new $_kts_pkg=$_kts_ts"
    unset _kts_pkg _kts_ts _kts_new _kts_i
}
# 让风险 App 进程彻底消失：进程没在跑就不动(省 am binder 开销)；冷却窗口内不动；
# 保护白名单不动。对每个用户 force-stop，am 异常时回退 am kill。
aah_force_stop() {
    [ "$AAH_FORCE_STOP" = 1 ] || return 0
    _fs_pkg="$1"
    [ -n "$_fs_pkg" ] || return 0
    aah_protected_pkg "$_fs_pkg" && { unset _fs_pkg; return 0; }
    _fs_now=$(aah_now); [ -n "$_fs_now" ] || _fs_now=0
    _fs_last=$(aah_kill_ts_get "$_fs_pkg"); [ -z "$_fs_last" ] && _fs_last=0
    # 冷却窗口内直接返回(连 pidof 都不 fork)，把稳态开销压到每包每冷却周期最多一次
    if [ $((_fs_now - _fs_last)) -lt "$AAH_KILL_COOLDOWN" ] 2>/dev/null; then
        unset _fs_pkg _fs_now _fs_last
        return 0
    fi
    # 进程没在跑就不动(省 am binder 开销与无谓强停)
    aah_pkg_running "$_fs_pkg" || { unset _fs_pkg _fs_now _fs_last; return 0; }
    aah_kill_ts_set "$_fs_pkg" "$_fs_now"
    for _fs_u in $AAH_USERS; do
        if command -v timeout >/dev/null 2>&1; then
            timeout "$AAH_CMD_TIMEOUT" am force-stop --user "$_fs_u" "$_fs_pkg" >/dev/null 2>&1 \
                || timeout "$AAH_CMD_TIMEOUT" am kill --user "$_fs_u" "$_fs_pkg" >/dev/null 2>&1
        else
            am force-stop --user "$_fs_u" "$_fs_pkg" >/dev/null 2>&1 \
                || am kill --user "$_fs_u" "$_fs_pkg" >/dev/null 2>&1
        fi
    done
    aah_log "force-stop risk-app pkg=$_fs_pkg users=$AAH_USERS"
    unset _fs_pkg _fs_now _fs_last _fs_u
}
aah_hide() {
    [ -n "$1" ] || return 0
    if aah_protected_pkg "$1"; then
        aah_log "hide-skip protected pkg=$1"
        return 0
    fi
    aah_visible "$1" || return 0
    if ! aah_authorized; then
        aah_log "hide-skip unauthorized pkg=$1"
        return 0
    fi
    if ! aah_known "$1"; then
        aah_log "hide-skip unknown pkg=$1 users=$AAH_USERS"
        return 0
    fi
    # 如果目标 app 当前有可见窗口 (分屏/小窗/画中画), 跳过冻结防止卡死。
    # 默认关闭，避免部分 ROM 的后台残留窗口导致误判。
    if [ "$AAH_VISIBLE_WINDOW" = 1 ] && aah_pkg_visible_window "$1"; then
        aah_log "hide-skip visible-window pkg=$1"
        return 0
    fi
    aah_log "hide-begin pkg=$1 users=$AAH_USERS"
    _ok=0
    _mode=""
    for _u in $AAH_USERS; do
        if aah_cmd_try "pm-hide:u=$_u:$1" pm hide --user "$_u" "$1"; then
            _ok=1
            _mode="${_mode}hide,"
        elif aah_cmd_try "cmd-hide:u=$_u:$1" cmd package hide --user "$_u" "$1"; then
            _ok=1
            _mode="${_mode}cmd-hide,"
        elif aah_cmd_try "pm-suspend:u=$_u:$1" pm suspend --user "$_u" "$1"; then
            _ok=1
            _mode="${_mode}suspend,"
        elif aah_cmd_try "cmd-suspend:u=$_u:$1" cmd package suspend --user "$_u" "$1"; then
            _ok=1
            _mode="${_mode}cmd-suspend,"
        fi
    done
    if [ "$_ok" = 1 ]; then
        aah_log "hide-done pkg=$1 users=$AAH_USERS mode=$_mode"
        # 隐藏后立即冻结进程，确保隐藏后无进程残留
        for _u in $AAH_USERS; do
            am force-stop --user "$_u" "$1" >/dev/null 2>&1 || am kill --user "$_u" "$1" >/dev/null 2>&1 || true
        done
    else
        aah_log "hide-fail pkg=$1 users=$AAH_USERS"
    fi
}

aah_unhide() {
    [ -n "$1" ] || return 0
    _force_restore="$2"
    # 不 gate 在 aah_known: 某些 ROM (ColorOS/OneUI) 的 -u flag 不返回 pm hide 状态的包,
    # 会让 aah_known 错判 false 导致冻结永远恢复不了. 直接基于 visible 列表:
    # - 已可见且不是本轮冻结状态 → 不用动
    # - 不可见 → 尝试 pm unhide (对不存在的包 pm 自己会 no-op, 没副作用)
    # 部分 ROM 有时 pm hide 失败后回退到 suspend, 包仍出现在 list packages,
    # 所以只用 visible 判断会跳过 unsuspend, 造成兜底触发后仍未恢复.
    _state_restore=0
    aah_state_has_pkg "$1" && _state_restore=1
    if [ "$_force_restore" != "force" ] && [ "$_state_restore" != 1 ] && aah_visible "$1"; then
        return 0
    fi
    _restore_mode=""
    if [ "$_force_restore" = "force" ] || [ "$_state_restore" = 1 ]; then
        _restore_mode="force"
    fi
    _ok=0
    for _u in $AAH_USERS; do
        if aah_restore_user_pkg "$_u" "$1" "$_restore_mode"; then
            _ok=1
        fi
    done
    [ "$_ok" = 1 ] && aah_log "restore(u=$AAH_USERS mode=${_restore_mode:-normal}): $1" || aah_log "restore-fail(u=$AAH_USERS mode=${_restore_mode:-normal}): $1"
    AAH_PKG_VISIBLE="$AAH_PKG_VISIBLE
package:$1"
    unset _force_restore _state_restore _restore_mode
}

aah_release_all() {
    aah_refresh_users
    PKGS=$(
        {
            for rule in "$AAH_RULES_DIR"/*.conf; do
                [ -f "$rule" ] || continue
                aah_get_list "$rule"
            done
            for rule in "$MODPATH/rules"/*.conf; do
                [ -f "$rule" ] || continue
                aah_get_list "$rule"
            done
            cat "$AAH_STATE" 2>/dev/null
            printf '%s\n' "$AAH_LAST_STATE"
        } | sort -u | grep -v '^$'
    )
    if [ -n "$PKGS" ]; then
        aah_log "locked: restore managed apps"
        for pkg in $PKGS; do
            for _u in $AAH_USERS; do
                aah_restore_user_pkg "$_u" "$pkg" force >/dev/null 2>&1 || true
            done
        done
    fi
    rm -f "$AAH_STATE" 2>/dev/null
    rm -f "$AAH_GAMES_STATE" 2>/dev/null
    AAH_LAST_STATE=""
    AAH_LAST_FG=""
    AAH_PKG_KNOWN=""
    AAH_PKG_VISIBLE=""
    AAH_SEEN_GAMES=""
    AAH_GAME_BG_SINCE=""
    AAH_LAST_LAUNCH_GAME=""
    AAH_RESTORE_PKGS=""
    AAH_RESTORE_UNTIL=0
    AAH_RESTORE_NEXT_TS=0
}

AAH_SEEN_GAMES=""
aah_load_seen_games
[ -s "$AAH_STATE" ] && AAH_LAST_STATE=$(sed -e 's/\r$//' -e '/^[[:space:]]*$/d' "$AAH_STATE" 2>/dev/null)
aah_log "aah daemon restarted via aah_launch.sh version=$AAH_VERSION"

# v295 修复: 启动时只对"历史 aah.state 里记录过的 pkg"做 orphan-unhide, 不再扫全量.
# 旧逻辑: comm -23 (所有隐藏 pkg - 可见 pkg) → 在多用户/分身 ROM 上, 某个 user 的
# cmd list packages 失败会让差集误包含系统 app → 随后 install-existing 把系统 app
# 分身装到分身用户, 用户看到"一堆系统应用分身".
# 新逻辑: 只处理我们自己的 aah.state 记录 (即本模块曾 hide 过但已不在 rule 里的).
_aah_managed_now=""
for _r in "$AAH_RULES_DIR"/*.conf; do
    [ -f "$_r" ] || continue
    _aah_managed_now="$_aah_managed_now
$(aah_get_list "$_r")"
done
aah_refresh_users
if [ -s "$AAH_STATE" ]; then
    while IFS= read -r _hpkg; do
        _hpkg=$(printf '%s' "$_hpkg" | sed 's/\r$//;s/^[[:space:]]*//;s/[[:space:]]*$//')
        [ -n "$_hpkg" ] || continue
        case "
$_aah_managed_now
" in
            *"
$_hpkg
"*) ;;
            *)
                # 不在任何规则里的旧 hide 残留 → 恢复
                # force 模式里面的 install-existing 不再使用 (修复分身 bug), 只走 unhide/unsuspend.
                _orphan_cu=$(am get-current-user 2>/dev/null | tr -dc '0-9'); [ -z "$_orphan_cu" ] && _orphan_cu=0
                for _u in $AAH_USERS; do
                    [ -n "$_u" ] || continue
                    pm unhide --user "$_u" "$_hpkg" >/dev/null 2>&1 || \
                        cmd package unhide --user "$_u" "$_hpkg" >/dev/null 2>&1 || true
                    pm unsuspend --user "$_u" "$_hpkg" >/dev/null 2>&1 || \
                        cmd package unsuspend --user "$_u" "$_hpkg" >/dev/null 2>&1 || true
                    # 仅当前用户补 install-existing：救回被"对用户卸载"的包，分身用户不执行避免建分身
                    [ "$_u" = "$_orphan_cu" ] && cmd package install-existing --user "$_u" "$_hpkg" >/dev/null 2>&1 || true
                done
                unset _orphan_cu
                aah_log "orphan-unhide-safe: $_hpkg"
                ;;
        esac
    done < "$AAH_STATE"
fi
unset _aah_managed_now _r _hpkg

while [ -d "$MODPATH" ]; do
    [ -d "$AAH_RULES_DIR" ] || { sleep 1; continue; }

    if ! aah_authorized; then
        if [ "$AAH_WAS_AUTHORIZED" = 1 ] || [ -s "$AAH_STATE" ] || [ -n "$AAH_LAST_STATE" ]; then
            aah_release_all
            aah_log "locked: no license"
        fi
        AAH_WAS_AUTHORIZED=0
        sleep "$AAH_SLEEP_LOCKED"
        continue
    fi

    if [ "$AAH_WAS_AUTHORIZED" != 1 ]; then
        AAH_WAS_AUTHORIZED=1
        AAH_LAST_FG=""
        aah_log "unlocked: license present"
    fi

    if aah_pressure_active; then
        if [ -s "$AAH_STATE" ] || [ -n "$AAH_LAST_STATE" ]; then
            aah_log "pressure: restore managed apps and pause"
            aah_release_all
        fi
        sleep "$AAH_SLEEP_PRESSURE"
        continue
    fi

    # v24: 锁屏省电 — 屏幕关闭时拉长轮询到 30s.
    # 用 aah_screen_interactive() 判断, 它有 30s 缓存避免频繁调 dumpsys power.
    # 如果锁屏期间游戏还在后台保持, 超时逻辑照常走 (bg_since 基于 epoch 不受 sleep 影响).
    if ! aah_screen_interactive; then
        sleep "$AAH_SLEEP_SCREEN_OFF"
        continue
    fi

    # 每轮重置 dump 缓存, 所有函数共享同一 tick 的 dump 结果
    AAH_WINDOW_DUMP=""
    AAH_WINDOW_DUMP_READY=0
    AAH_ACTIVITY_DUMP=""
    AAH_ACTIVITY_DUMP_READY=0
    AAH_TASK_DUMP=""
    AAH_TASK_DUMP_READY=0
    AAH_RECENTS_DUMP=""
    AAH_RECENTS_DUMP_READY=0
    FG=$(aah_foreground)
    aah_launch_sessions_prune

    SHOULD_HIDE=""
    ALL_MANAGED=""
    HIT_GAMES=""
    for rule in "$AAH_RULES_DIR"/*.conf; do
        [ -f "$rule" ] || continue
        game_pkg=$(basename "$rule" .conf)
        # 兜底：绝不隐藏触发应用自身（后端保存时已拦截，这里再防历史规则文件），
        # 否则游戏一进前台就被自己的规则 pm hide，立刻退回桌面。
        APPS=$(aah_get_list "$rule" | grep -Fvx "$game_pkg")
        [ -z "$APPS" ] && continue
        ALL_MANAGED="$ALL_MANAGED
$APPS"
        # 稳定版默认前台冻结 + 后台短保持:
        # 1) 游戏前台 → 冻结
        # 2) 可选: .aah_visible_window 开启后, 游戏小窗/分屏可见 → 继续冻结
        # 3) 用户显式开启后台保持时，游戏后台且进程仍在 → 短时间继续冻结
        # 4) 离开游戏、后台超时、或进程退出 → 恢复
        _game_active=0
        # 【进程启动预热 · 修复检测软件首次扫描漏藏】
        # 触发应用(游戏/检测软件，如 Maple)冷启动时，进程出现早于界面 Resumed；而检测类
        # 应用往往在进入界面的最初瞬间就查询系统"已安装列表"(PMS)。若等前台稳定后再
        # pm hide 会慢半拍，表现为"第一次/刚伪卸载恢复时能扫到，之后才扫不到"。这里在
        # "进程已起、界面尚未前台"时就提前隐藏目标，抢在检测软件首次扫描之前完成。
        # 仅默认后台保持模式生效；用户显式选择"仅前台冻结"(.aah_foreground_only)时不预热。
        if [ "$FG" != "$game_pkg" ] && [ "$AAH_KEEP_BACKGROUND" = 1 ] && aah_pkg_running "$game_pkg"; then
            case "$AAH_SEEN_GAMES" in
                *"|$game_pkg|"*) ;;
                *) aah_log "preheat on process-start: $game_pkg fg=${FG:-?}" ;;
            esac
            aah_seen_add "$game_pkg"
            aah_clear_game_bg_since "$game_pkg"
            _game_active=1
        fi
        if [ "$_game_active" != 1 ] && [ "$FG" = "$game_pkg" ]; then
            if aah_game_fg_stable "$game_pkg"; then
                aah_fire_game_launch "$game_pkg"
                aah_seen_add "$game_pkg"
                aah_clear_game_bg_since "$game_pkg"
                _game_active=1
            else
                aah_clear_game_bg_since "$game_pkg"
            fi
        elif [ "$_game_active" != 1 ] && [ "$AAH_VISIBLE_WINDOW" = 1 ] && aah_pkg_visible_window "$game_pkg"; then
            case "$AAH_SEEN_GAMES" in
                *"|$game_pkg|"*) ;;
                *) aah_log "game visible-window: $game_pkg fg=${FG:-?}" ;;
            esac
            # v194: 小窗/分屏命中也触发一次启动脚本(只在第一次见到时,后续靠 SEEN 去重)
            case "$AAH_SEEN_GAMES" in
                *"|$game_pkg|"*) ;;
                *) aah_fire_game_launch "$game_pkg" ;;
            esac
            aah_seen_add "$game_pkg"
            aah_clear_game_bg_since "$game_pkg"
            _game_active=1
        elif [ "$_game_active" != 1 ] && [ "$AAH_KEEP_BACKGROUND" = 1 ]; then
            # 内存变量 SEEN 不可靠, 直接查盘文件 (aah.games 每行一个 game pkg)
            if [ -s "$AAH_GAMES_STATE" ] && grep -Fxq "$game_pkg" "$AAH_GAMES_STATE" 2>/dev/null; then
                _aah_seen_match=1
            else
                case "$AAH_SEEN_GAMES" in
                    *"|$game_pkg|"*) _aah_seen_match=1 ;;
                    *) _aah_seen_match=0 ;;
                esac
            fi
            if [ "$_aah_seen_match" = 1 ]; then
                if ! aah_game_task_present "$game_pkg"; then
                    aah_seen_del "$game_pkg"
                    aah_log "game task gone: $game_pkg fg=${FG:-?}"
                elif ! aah_pkg_running "$game_pkg"; then
                    aah_seen_del "$game_pkg"
                    aah_log "game process gone: $game_pkg fg=${FG:-?}"
                else
                    # 后台保持开启时，只要游戏任务/进程还活着，就继续冻结。
                    # 这样回桌面或临时切应用不会恢复目标 app，也不会释放启动会话。
                    _now_bg=$(aah_now)
                    [ -n "$_now_bg" ] || _now_bg=0
                    _bg_since=$(aah_bg_since_get "$game_pkg")
                    if [ -f "$MODPATH/.aah_release_on_launcher" ] && aah_fg_is_safe_release "$FG"; then
                        # opt-in 老行为: 桌面/系统 app 立即解冻
                        aah_seen_del "$game_pkg"
                        aah_log "game release(launcher,opt-in): $game_pkg fg=${FG:-?}"
                    else
                        if [ -z "$_bg_since" ]; then
                            _bg_since=$_now_bg
                            aah_bg_since_set "$game_pkg" "$_bg_since"
                            aah_log "game background hold: $game_pkg fg=${FG:-?}"
                        fi
                        _bg_elapsed=$(( _now_bg - _bg_since ))
                        if [ "$AAH_BG_MAX_SECONDS" -gt 0 ] 2>/dev/null && [ "$_bg_elapsed" -ge "$AAH_BG_MAX_SECONDS" ] 2>/dev/null; then
                            aah_seen_del "$game_pkg"
                            aah_log "game background timeout ${_bg_elapsed}s: $game_pkg"
                        else
                            _game_active=1
                        fi
                    fi
                fi
            fi
        elif [ "$_game_active" != 1 ]; then
            case "$AAH_SEEN_GAMES" in
                *"|$game_pkg|"*)
                    aah_seen_del "$game_pkg"
                    aah_log "game left foreground: $game_pkg fg=${FG:-?}"
                    ;;
            esac
        fi
        if [ "$_game_active" = 1 ]; then
            SHOULD_HIDE="$SHOULD_HIDE
$APPS"
            HIT_GAMES="$HIT_GAMES $game_pkg"
        fi
    done
    SHOULD_HIDE=$(printf '%s\n' "$SHOULD_HIDE" | sort -u | grep -v '^$')
    ALL_MANAGED=$(printf '%s\n' "$ALL_MANAGED" | sort -u | grep -v '^$')

    if [ -z "$SHOULD_HIDE" ] && [ -n "$AAH_LAST_STATE" ]; then
        aah_restore_queue_add "$AAH_LAST_STATE"
    fi

    fg_changed=0
    if [ "$FG" != "$AAH_LAST_FG" ]; then
        aah_log "fg: ${AAH_LAST_FG:-?} -> ${FG:-?}"
        AAH_LAST_FG="$FG"
        fg_changed=1
        # 只有游戏进程真正消失才释放自动启动会话。单局结束、回大厅、窗口焦点
        # 抖动都不应该再次触发脚本。
        if [ -n "$AAH_LAST_LAUNCH_GAME" ]; then
            _last_pkg="$AAH_LAST_LAUNCH_GAME"
            if ! aah_pkg_running "$_last_pkg"; then
                aah_log "launch session reset: $_last_pkg process gone"
                AAH_LAST_LAUNCH_GAME=""
                aah_launch_session_remove "$_last_pkg"
            fi
            unset _last_pkg
        fi
        if [ -z "$FG" ] || [ "$FG" != "$AAH_LAST_GAME_FG" ]; then
            AAH_LAST_GAME_FG=""
            AAH_GAME_FG_SINCE=0
        fi
    fi
    if [ "$fg_changed" = 1 ] && [ -n "$SHOULD_HIDE" ]; then
        aah_log "rule-hit fg=${FG:-?} games=$(echo "$HIT_GAMES" | sed 's/^ *//') apps=$(printf '%s' "$SHOULD_HIDE" | tr '\n' ',')"
    fi
    if [ -z "$SHOULD_HIDE" ]; then
        _now_diag=$(aah_now)
        if [ -z "$_now_diag" ] || [ "$(( _now_diag - AAH_LAST_DIAG_TS ))" -ge "$AAH_IDLE_LOG_INTERVAL" ] 2>/dev/null; then
            aah_log "idle fg=${FG:-?} seen=${AAH_SEEN_GAMES:-<none>} rules=$(ls "$AAH_RULES_DIR"/*.conf 2>/dev/null | wc -l | tr -d ' ') users=$AAH_USERS"
            AAH_LAST_DIAG_TS=${_now_diag:-0}
        fi
    fi

    _now_hide=$(aah_now)
    [ -n "$_now_hide" ] || _now_hide=0
    _last_state_norm=$(printf '%s\n' "$AAH_LAST_STATE" | sort -u | grep -v '^$')
    hide_check=0
    if [ -n "$SHOULD_HIDE" ]; then
        if [ "$fg_changed" = 1 ] || [ "$SHOULD_HIDE" != "$_last_state_norm" ] || [ "$_now_hide" -ge "$AAH_HIDE_RETRY_NEXT_TS" ] 2>/dev/null; then
            hide_check=1
        fi
    fi

    if [ "$hide_check" = 1 ] && aah_authorized; then
        # v24: rate-limit force refresh — 至少间隔 15s 才真正 force
        _now_fr=$(aah_now)
        [ -n "$_now_fr" ] || _now_fr=0
        if [ $((_now_fr - AAH_LAST_FORCE_REFRESH_TS)) -ge "$AAH_FORCE_REFRESH_MIN_INTERVAL" ] 2>/dev/null; then
            aah_refresh_cache force
            AAH_LAST_FORCE_REFRESH_TS=$_now_fr
        else
            aah_refresh_cache
        fi
        for pkg in $SHOULD_HIDE; do
            aah_authorized && aah_hide "$pkg"
        done
        AAH_HIDE_RETRY_NEXT_TS=$((_now_hide + AAH_HIDE_RETRY_INTERVAL))
        if [ $((_now_fr - AAH_LAST_FORCE_REFRESH_TS)) -ge "$AAH_FORCE_REFRESH_MIN_INTERVAL" ] 2>/dev/null; then
            aah_refresh_cache force
            AAH_LAST_FORCE_REFRESH_TS=$(aah_now)
            [ -n "$AAH_LAST_FORCE_REFRESH_TS" ] || AAH_LAST_FORCE_REFRESH_TS=$_now_fr
        fi
        unset _now_fr
    else
        aah_refresh_cache
    fi

    # 方案A：触发应用活跃期间，持续把勾选的风险 App 进程强停干净(独立于上面 pm hide
    # 的 30s 限频，按 ACTIVE 0.3s 粒度检查；函数内部"仅在运行+冷却"限流，不会空耗)。
    if [ -n "$SHOULD_HIDE" ] && [ "$AAH_FORCE_STOP" = 1 ]; then
        for pkg in $SHOULD_HIDE; do
            aah_force_stop "$pkg"
        done
    fi

    # 恢复扫描集合 = 当前规则管理的 App(ALL_MANAGED) ∪ 上一轮实际被本模块隐藏的
    # App(AAH_LAST_STATE，此时仍是旧值，本轮 new_state 在后面才算)。并入后者是为了
    # 兜底：运行中删除整条规则、或编辑规则移除某 App 时，它已不在 ALL_MANAGED，
    # 但若上一轮正被隐藏就必须恢复，否则会永久卡在 pm hide（伪卸载回不来）。
    _restore_scan=$(
        {
            printf '%s\n' "$ALL_MANAGED"
            printf '%s\n' "$AAH_LAST_STATE"
        } | sed '/^[[:space:]]*$/d' | sort -u
    )
    for pkg in $_restore_scan; do
        case "
$SHOULD_HIDE
" in
            *"
$pkg
"*) ;;
            *)
                # 已在强制恢复队列的包交给 restore_queue 块统一 force 恢复，避免同一轮重复执行
                case "
$AAH_RESTORE_PKGS
" in
                    *"
$pkg
"*) ;;
                    *) aah_unhide "$pkg" ;;
                esac
                ;;
        esac
    done
    unset _restore_scan
    _now_restore=$(aah_now)
    [ -n "$_now_restore" ] || _now_restore=0
    if aah_restore_active && [ "$_now_restore" -ge "$AAH_RESTORE_NEXT_TS" ] 2>/dev/null; then
        for pkg in $AAH_RESTORE_PKGS; do
            case "
$SHOULD_HIDE
" in
                *"
$pkg
"*) ;;
                *) aah_unhide "$pkg" force ;;
            esac
        done
        AAH_RESTORE_PKGS=""
        AAH_RESTORE_UNTIL=0
        AAH_RESTORE_NEXT_TS=0
    else
        if ! aah_restore_active; then
            AAH_RESTORE_PKGS=""
            AAH_RESTORE_UNTIL=0
            AAH_RESTORE_NEXT_TS=0
        fi
    fi
    AAH_LOOP_SLEEP=""
    if [ -n "$SHOULD_HIDE" ] && [ "$hide_check" = 0 ] && [ "$SHOULD_HIDE" = "$_last_state_norm" ]; then
        # 稳定冻结状态: fg 切换才需要快醒, 拉长轮询.
        AAH_LOOP_SLEEP="$AAH_SLEEP_STABLE"
    fi
    unset _now_restore _now_hide _last_state_norm hide_check
    if [ "$AAH_FORCE_RESTORE_ONCE" = 1 ]; then
        AAH_FORCE_RESTORE_ONCE=0
        aah_log "startup restore sweep done active=$( [ -n "$SHOULD_HIDE" ] && echo 1 || echo 0 )"
    fi

    new_state=""
    for pkg in $SHOULD_HIDE; do
        aah_known "$pkg" && new_state="$new_state$pkg
"
    done
    if [ "$new_state" != "$AAH_LAST_STATE" ]; then
        if [ -n "$new_state" ]; then
            printf '%s' "$new_state" > "$AAH_STATE" 2>/dev/null
            chmod 0644 "$AAH_STATE" 2>/dev/null
        else
            rm -f "$AAH_STATE" 2>/dev/null
        fi
        AAH_LAST_STATE="$new_state"
    fi
    aah_persist_seen_games

    if [ -n "$AAH_LOOP_SLEEP" ]; then
        sleep "$AAH_LOOP_SLEEP"
    elif [ -n "$SHOULD_HIDE" ] || [ -n "$AAH_LAST_STATE" ]; then
        sleep "$AAH_SLEEP_ACTIVE"
    else
        sleep "$AAH_SLEEP_IDLE"
    fi
    unset AAH_LOOP_SLEEP
done
