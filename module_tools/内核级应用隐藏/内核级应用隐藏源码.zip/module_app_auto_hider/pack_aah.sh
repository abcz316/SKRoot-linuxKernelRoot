#!/bin/bash
# module_app_auto_hider 打包（严格 SKRoot 模块结构）：
#   根: libmodule_app_auto_hider.so (0600)
#   common/aah_launch.sh, aah_paths.sh (0755, 守护脚本，C++ 从 module_private_dir/common 加载)
#   uninstall.sh (0755)
#   webroot/index.html main.js style.css (WebUI 静态页)
# 暂存用本地盘 /tmp，规避网络盘 zip 截断；最终 zip 落持久 dist。
set -u
W=/sandboxdata/workspace/file
MOD="$W/module_app_auto_hider"
VER=1.7
AUTH=榆爱
STAGE=/tmp/aah_pack
OUT="$MOD/dist/应用自动隐藏-内核级-v${VER}-${AUTH}.zip"

SO="$MOD/dist/libmodule_app_auto_hider.so"
[ -f "$SO" ] || { echo "NO_SO_BUILD_FIRST"; exit 2; }
[ "$(stat -c %s "$SO")" -gt 100000 ] || { echo "SO_TOO_SMALL"; exit 3; }

rm -rf "$STAGE"; mkdir -p "$STAGE/common" "$STAGE/webroot"
# so 置根 0600
cp -f "$SO" "$STAGE/libmodule_app_auto_hider.so"; chmod 0600 "$STAGE/libmodule_app_auto_hider.so"
# 原生守护已内置 so，无需 sh 守护脚本
# 卸载脚本
cp -f "$MOD/uninstall.sh" "$STAGE/uninstall.sh"; chmod 0755 "$STAGE/uninstall.sh"
# WebUI
cp -f "$MOD/webroot/index.html" "$MOD/webroot/main.js" "$MOD/webroot/style.css" "$STAGE/webroot/"
chmod 0644 "$STAGE/webroot/"*

# 版本在 so 内置，无需核对

rm -f "$OUT"
( cd "$STAGE" && zip -X -r -q "$OUT" ./libmodule_app_auto_hider.so ./uninstall.sh ./webroot )
RC=$?
[ $RC -ne 0 ] && { echo "ZIP_FAILED rc=$RC"; exit 5; }

echo "=== 打包完成：$OUT ==="
ls -la "$OUT"
echo "=== zip 成员与权限回读 ==="
unzip -l "$OUT"
echo "=== 关键自检 ==="
echo "so size in zip : $(unzip -p "$OUT" ./libmodule_app_auto_hider.so | wc -c) bytes"
echo "native daemon  : built-in so (pthread, no sh process)"
echo "force_stop 前端: $(unzip -p "$OUT" ./webroot/index.html | grep -c cfgForceStop )"
echo "PACK_DONE"
