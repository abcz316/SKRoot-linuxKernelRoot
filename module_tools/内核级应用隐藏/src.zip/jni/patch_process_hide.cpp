#include "patch_process_hide.h"
using namespace asmjit;
using namespace asmjit::a64;
using namespace asmjit::a64::Predicate;

/*
 * 内核级进程隐藏
 *
 * hook 两个函数：
 * 1. proc_pid_instantiate - 遍历 /proc 时创建 PID 目录项，hook 后跳过指定 PID
 * 2. proc_pid_lookup - 按 PID 查找 /proc/PID 目录，hook 后返回不存在
 *
 * proc_pid_lookup 用 dentry->d_name.name（标准 qstr 布局）
 * qstr 布局（64位现代内核）：offset 0=hash(4)+len(4), offset 8=name(指针)
 */

PatchProcessHide::PatchProcessHide(const PatchBase& patch_base,
                                   uint64_t proc_pid_instantiate,
                                   uint64_t proc_pid_lookup,
                                   uint32_t dentry_d_name_offset)
    : PatchBase(patch_base),
      m_proc_pid_instantiate(proc_pid_instantiate),
      m_proc_pid_lookup(proc_pid_lookup),
      m_dentry_d_name_offset(dentry_d_name_offset) {}

PatchProcessHide::~PatchProcessHide() {}

/*
 * static int proc_pid_instantiate(struct dir_context *ctx, int tid, struct task_struct *task)
 * x0 = ctx, x1 = tid, x2 = task
 * 返回 1 表示继续遍历，返回 0 表示停止（缓冲区满）
 * 我们要隐藏的 PID 直接返回 1，不输出目录项
 */
KModErr PatchProcessHide::patch_proc_pid_instantiate(const std::vector<int>& pids) {
    if (pids.empty() || m_proc_pid_instantiate == 0) return KModErr::ERR_MODULE_PARAM;

    aarch64_asm_ctx asm_ctx = init_aarch64_asm();
    auto a = asm_ctx.assembler();
    Label L_skip = a->newLabel();   // 命中隐藏 PID，返回 1
    Label L_orig = a->newLabel();   // 未命中，调用原函数

    kernel_module::arm64_before_hook_start(a);

    // x1 是 tid（int，32位），用 w1 比较
    for (size_t i = 0; i < pids.size() && i < 8; ++i) {
        aarch64_asm_mov_x(a, x9, static_cast<uint64_t>(pids[i]));
        a->cmp(w1, w9);
        a->b(CondCode::kEQ, L_skip);
    }
    a->b(L_orig);

    // 命中：返回 1（继续遍历，不输出此目录项）
    a->bind(L_skip);
    aarch64_asm_mov_x(a, x0, 1);
    kernel_module::arm64_before_hook_end(a, false);

    // 未命中：调用原函数
    a->bind(L_orig);
    kernel_module::arm64_before_hook_end(a, true);

    return patch_kernel_before_hook(m_proc_pid_instantiate, a);
}

/*
 * static struct dentry *proc_pid_lookup(struct inode *dir, struct dentry *dentry, unsigned int flags)
 * x0 = dir, x1 = dentry, x2 = flags
 *
 * 用 dentry->d_name.name（标准 qstr 布局，name 在 offset 8）
 */
KModErr PatchProcessHide::patch_proc_pid_lookup(const std::vector<int>& pids) {
    if (pids.empty() || m_proc_pid_lookup == 0) return KModErr::ERR_MODULE_PARAM;

    aarch64_asm_ctx asm_ctx = init_aarch64_asm();
    auto a = asm_ctx.assembler();
    Label L_skip = a->newLabel();   // 命中隐藏 PID，返回 NULL
    Label L_orig = a->newLabel();   // 未命中，调用原函数

    kernel_module::arm64_before_hook_start(a);

    // x1 = dentry
    // dentry->d_name 是内嵌的 qstr，地址 = dentry + d_name_offset
    // qstr.name 在 offset 8
    a->add(x9, x1, static_cast<uint64_t>(m_dentry_d_name_offset));  // x9 = &dentry->d_name
    a->ldr(x10, ptr(x9, 8));                                         // x10 = d_name.name

    // 逐个比较 PID 字符串
    for (size_t i = 0; i < pids.size() && i < 8; ++i) {
        std::string pid_str = std::to_string(pids[i]);
        aarch64_asm_set_x_cstr_ptr(a, x11, pid_str);
        {
            RegProtectGuard g1(a, x0);
            kernel_module::string_ops::kstrcmp(a, x10, x11);
            a->mov(x12, x0);
        }
        a->cbz(x12, L_skip);  // 字符串相等，命中
    }
    a->b(L_orig);

    // 命中：返回 NULL（ENOENT）
    a->bind(L_skip);
    aarch64_asm_mov_x(a, x0, 0);
    kernel_module::arm64_before_hook_end(a, false);

    // 未命中：调用原函数
    a->bind(L_orig);
    kernel_module::arm64_before_hook_end(a, true);

    return patch_kernel_before_hook(m_proc_pid_lookup, a);
}

KModErr PatchProcessHide::install(const std::vector<int>& hidden_pids) {
    KModErr err = KModErr::OK;
    if (m_proc_pid_instantiate) {
        err = patch_proc_pid_instantiate(hidden_pids);
    }
    // proc_pid_lookup 在 6.12 内核上 hook 会导致 kernel panic，暂时禁用
    // 只 hook instantiate 已足够覆盖所有遍历 /proc 的场景（ps/top/反作弊扫进程）
    // if (m_proc_pid_lookup) {
    //     err = patch_proc_pid_lookup(hidden_pids);
    // }
    return err;
}
