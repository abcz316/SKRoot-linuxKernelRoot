#pragma once
#include "patch_base.h"
#include <vector>
#include <cstdint>

class PatchProcessHide : public PatchBase {
public:
    PatchProcessHide(const PatchBase& patch_base,
                     uint64_t proc_pid_instantiate,
                     uint64_t proc_pid_lookup,
                     uint32_t dentry_d_name_offset);
    ~PatchProcessHide();

    // 安装进程隐藏 hook，hidden_pids 是要隐藏的 PID 列表
    KModErr install(const std::vector<int>& hidden_pids);

private:
    uint64_t m_proc_pid_instantiate;
    uint64_t m_proc_pid_lookup;
    uint32_t m_dentry_d_name_offset;

    KModErr patch_proc_pid_instantiate(const std::vector<int>& pids);
    KModErr patch_proc_pid_lookup(const std::vector<int>& pids);
};
