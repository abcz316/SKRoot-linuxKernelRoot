#pragma once

#include <unistd.h>
#include <sys/stat.h>
#include <cstdio>
#include <fstream>
#include <map>
#include <mutex>
#include <sstream>
#include <string>

#include "cJSON.h"
#include "app_label_helper_data.generated.h"
#include "kernel_module_kit_umbrella.h"

namespace app_label_helper {
inline std::string base64_decode_utf8(const std::string& input) {
    static const int8_t tbl[256] = {
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63, 52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,-1,
        -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14, 15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,
        -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40, 41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1
    };
    std::string out;
    out.reserve(input.size() * 3 / 4);
    uint32_t val = 0; int valb = -8;
    for (unsigned char c : input) {
        if (c == '=') break;
        int8_t d = tbl[c];
        if (d < 0) continue;
        val = (val << 6) | d;
        valb += 6;
        if (valb >= 0) { out.push_back(char((val >> valb) & 0xFF)); valb -= 8; }
    }
    return out;
}

// 清理无效UTF-8字节：系统应用label可能来自框架资源，编码不一致时会产生
// 无效UTF-8序列，导致浏览器解析JSON时显示乱码。逐字节验证，无效序列替换为'?'。
inline std::string sanitize_utf8(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    size_t i = 0;
    while (i < s.size()) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        if (c < 0x80) { out += s[i]; i++; }
        else if ((c & 0xE0) == 0xC0) {
            if (i+1 < s.size() && (static_cast<unsigned char>(s[i+1]) & 0xC0) == 0x80) {
                out += s[i]; out += s[i+1]; i += 2;
            } else { out += '?'; i++; }
        }
        else if ((c & 0xF0) == 0xE0) {
            if (i+2 < s.size() &&
                (static_cast<unsigned char>(s[i+1]) & 0xC0) == 0x80 &&
                (static_cast<unsigned char>(s[i+2]) & 0xC0) == 0x80) {
                out += s[i]; out += s[i+1]; out += s[i+2]; i += 3;
            } else { out += '?'; i++; }
        }
        else if ((c & 0xF8) == 0xF0) {
            if (i+3 < s.size() &&
                (static_cast<unsigned char>(s[i+1]) & 0xC0) == 0x80 &&
                (static_cast<unsigned char>(s[i+2]) & 0xC0) == 0x80 &&
                (static_cast<unsigned char>(s[i+3]) & 0xC0) == 0x80) {
                out += s[i]; out += s[i+1]; out += s[i+2]; out += s[i+3]; i += 4;
            } else { out += '?'; i++; }
        }
        else { out += '?'; i++; }
    }
    return out;
}

inline bool parse_json(const std::string & json, std::map<std::string, std::string> & result) {
    if (json.empty()) return false;
    size_t begin = json.find('[');
    size_t end = json.rfind(']');
    if (begin == std::string::npos || end == std::string::npos || end <= begin) return false;

    std::string json_array = json.substr(begin, end - begin + 1);
    cJSON * root = cJSON_Parse(json_array.c_str());
    if (!root) return false;
    if (!cJSON_IsArray(root)) {
        cJSON_Delete(root);
        return false;
    }

    int size = cJSON_GetArraySize(root);
    for (int i = 0; i < size; i++) {
        cJSON * item = cJSON_GetArrayItem(root, i);
        if (!item) continue;
        cJSON * j_package_name = cJSON_GetObjectItem(item, "packageName");
        cJSON * j_label_base64 = cJSON_GetObjectItem(item, "labelBase64");
        if (!j_package_name || !j_package_name->valuestring) continue;
        std::string b64 = (j_label_base64 && j_label_base64->valuestring) ? j_label_base64->valuestring : "";
        result[j_package_name->valuestring] = b64.empty() ? "" : sanitize_utf8(base64_decode_utf8(b64));
    }
    cJSON_Delete(root);
    return true;
}

inline std::map<std::string, std::string> get_all_app_display_names(const char* root_key, const char* work_dir, const void* dex_data, size_t dex_size) {
    static std::map<std::string, std::string> s_cache;
    static std::mutex s_mutex;
    // 本模块有 /api/games 和 /api/apps 两个端点并行调用（Promise.all），
    // 必须加锁防止两个线程同时写DEX文件导致竞态。内核拦截模块只有一个端点，无需锁。
    std::lock_guard<std::mutex> lock(s_mutex);
    if (!s_cache.empty()) return s_cache;

    if (!root_key || !work_dir || !dex_data || dex_size == 0) return {};

    std::string app_label_helper_path = work_dir;
    app_label_helper_path += "/app_label_helper.dex";

    remove(app_label_helper_path.c_str());
    std::ofstream file(app_label_helper_path, std::ios::binary | std::ios::out);
    if (!file.is_open()) return {};

    file.write(reinterpret_cast<const char*>(dex_data), dex_size);
    bool write_ok = file.good();
    file.close();
    if (!write_ok) return {};

    if (chmod(app_label_helper_path.c_str(), 0644)) return {};

    std::stringstream cmd;
    cmd << "CLASSPATH=" << app_label_helper_path << " app_process /system/bin AppLabelsHelper";

    std::string json;
    KModErr err = skroot_env::run_root_cmd(root_key, cmd.str().c_str(), json);
    remove(app_label_helper_path.c_str());
    if (is_failed(err)) return {};

    std::map<std::string, std::string> result;
    parse_json(json, result);

    bool all_ok = result.size() > 5;
    for (const auto & kv : result) {
        if (kv.first.empty() || kv.second.empty()) {
            all_ok = false;
            break;
        }
    }
    if (all_ok) s_cache = result;
    return result;
}

} // namespace app_label_helper
