#include "aah_native_daemon.h"
#include "patch_process_hide.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <algorithm>
#include <fstream>
#include <sstream>

#define AAH_VERSION "1.8.5"

// 崩溃日志路径（在 start() 里设为模块私有目录，信号 handler 里只读）
static std::string g_crash_log_path;
static std::string g_cgroup_log_path;

// SIGTERM/SIGINT 优雅退出：设置 stop_requested_，主循环检测后恢复所有应用并退出。
// stop() 发 SIGTERM 后等 2 秒，若未退出再 SIGKILL 兜底。
static std::atomic_bool* g_stop_flag = nullptr;
static void aah_graceful_stop(int /*sig*/) {
    if (g_stop_flag) g_stop_flag->store(true);
}

// 崩溃信号处理：段错误/abort/bus error/非法指令时写日志后 _exit，
// 让外层 while 循环自动重启。SIGKILL 无法捕获（OOM killer），只能靠外层轮询。
static void aah_crash_handler(int sig) {
    const char* name = "unknown";
    switch (sig) {
        case SIGSEGV: name = "SIGSEGV"; break;
        case SIGABRT: name = "SIGABRT"; break;
        case SIGBUS:  name = "SIGBUS";  break;
        case SIGILL:  name = "SIGILL";  break;
        case SIGFPE:  name = "SIGFPE";  break;
        default: break;
    }
    int fd = open(g_crash_log_path.c_str(), O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd >= 0) {
        char buf[128];
        int n = snprintf(buf, sizeof(buf), "[crash] signal=%d %s pid=%d\n", sig, name, getpid());
        if (n > 0) write(fd, buf, n);
        close(fd);
    }
    _exit(128 + sig);
}

// 把当前进程从父进程的 cgroup 移到 init cgroup，避免父进程退出时 cgroup 销毁
// 把 daemon 一起 SIGKILL。Android cgroup v2 会跟踪创建者进程，必须显式迁移。
static void escape_cgroup() {
    const char* cg_paths[] = {
        "/sys/fs/cgroup/init/cgroup.procs",
        "/sys/fs/cgroup/cgroup.procs",
        nullptr
    };
    char buf[32];
    int blen = snprintf(buf, sizeof(buf), "%d", getpid());
    bool ok = false;
    for (int i = 0; cg_paths[i]; i++) {
        int fd = open(cg_paths[i], O_WRONLY);
        if (fd >= 0) {
            ssize_t w = write(fd, buf, blen);
            close(fd);
            if (w == blen) { ok = true; break; }
        }
    }
    int lfd = open(g_cgroup_log_path.c_str(), O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (lfd >= 0) {
        char lb[160];
        int n = snprintf(lb, sizeof(lb), "[%ld] cgroup-escape=%s pid=%d\n",
                         (long)time(nullptr), ok ? "ok" : "FAILED", getpid());
        if (n > 0) write(lfd, lb, n);
        close(lfd);
    }
}

static bool flag_exists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

struct AahRunConfig {
    bool foreground_only = false;
    bool keep_background = true;
    bool force_stop = true;
};

static AahRunConfig load_config(const std::string& data_dir) {
    AahRunConfig cfg;
    cfg.foreground_only = flag_exists(data_dir + "/.aah_foreground_only");
    cfg.keep_background = !flag_exists(data_dir + "/.aah_no_keep_background");
    if (flag_exists(data_dir + "/.aah_keep_background")) cfg.keep_background = true;
    cfg.force_stop = flag_exists(data_dir + "/.aah_force_stop");
    if (flag_exists(data_dir + "/.aah_no_force_stop")) cfg.force_stop = false;
    return cfg;
}

AahNativeDaemon& AahNativeDaemon::instance() {
    static AahNativeDaemon inst;
    return inst;
}

AahNativeDaemon::~AahNativeDaemon() {
    stop();
}

void AahNativeDaemon::start(const std::string& module_dir) {
    std::lock_guard<std::mutex> lk(mtx_);
    if (running_) return;
    module_dir_ = module_dir;
    aah_paths::set_root(module_dir);      // 确保配置根 = 模块私有目录
    data_dir_ = aah_paths::root();
    (void)mkdir(aah_paths::root().c_str(), 0755);
    (void)mkdir(aah_paths::rules_dir().c_str(), 0755);

    std::string pidfile = data_dir_ + "/aah.pid";

    // 设置诊断日志路径到模块私有目录（fork 前设置，子进程继承）
    g_crash_log_path = data_dir_ + "/aah_crash.log";
    g_cgroup_log_path = data_dir_ + "/aah_cgroup.log";

    // 跨进程幂等：开机加载进程和 WebUI 进程是不同进程，各自的 running_ 不共享。
    // 读 pidfile，里面的 daemon 还活着就不重复 fork。
    {
        std::ifstream pf(pidfile);
        if (pf) {
            long oldpid = 0;
            pf >> oldpid;
            if (oldpid > 1 && kill((pid_t)oldpid, 0) == 0) {
                running_ = true;
                return;
            }
        }
    }

    stop_requested_ = false;

    // 按 SKPro 官方模式（fork_delayed_task）：
    // 单 fork，不 double-fork，不 setsid，不 cgroup 迁移。
    // 子进程先 sleep(5) 等 SKPro 加载进程完成 cleanup，再跑 daemon 循环。
    signal(SIGPIPE, SIG_IGN);
    signal(SIGXFSZ, SIG_IGN);
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid > 0) {
        running_ = true;
        return;
    }

    // ===== 子进程 =====
    // 先 sleep 5 秒，等 SKPro 模块加载进程完成 cleanup
    sleep(5);

    // 迁移到 init cgroup：父进程退出时 cgroup v2 会销毁并 SIGKILL 同 cgroup 的子进程，
    // 必须显式迁移否则 daemon 存活不到主循环。
    escape_cgroup();

    // 进程伪装：fork 后 comm/cmdline 继承自 SKPro 加载进程，包含模块路径和 .so 名，
    // 游戏枚举 /proc 或直接读 /proc/<pid>/cmdline 就能识别。改为普通系统进程名并清空 cmdline。
    prctl(PR_SET_NAME, "logd", 0, 0, 0);
    {
        int fd = open("/proc/self/cmdline", O_WRONLY);
        if (fd >= 0) {
            char zero[4096]; memset(zero, 0, sizeof(zero));
            write(fd, zero, sizeof(zero));
            close(fd);
        }
    }

    // 内核级进程隐藏：hook /proc 遍历，让 daemon 进程完全消失
    {
        uint32_t cred_off = 0, euid_off = 0;
        if (kernel_module::get_task_struct_cred_offset(cred_off) == KModErr::OK &&
            kernel_module::get_cred_euid_offset(euid_off) == KModErr::OK) {
            uint64_t proc_pid_instantiate = 0;
            kernel_module::kallsyms_lookup_name("proc_pid_instantiate", proc_pid_instantiate);
            if (proc_pid_instantiate) {
                uint32_t d_name_offset = 0;
                kernel_module::get_dentry_d_name_offset(d_name_offset);
                PatchBase patch_base(cred_off, euid_off);
                PatchProcessHide patch(patch_base, proc_pid_instantiate, 0, d_name_offset);
                std::vector<int> pids = {getpid()};
                if (is_ok(patch.install(pids))) {
                    log("kernel process-hide installed pid=" + std::to_string(getpid()));
                }
            }
        }
    }

    // 注册崩溃信号处理
    g_stop_flag = &stop_requested_;
    signal(SIGTERM, aah_graceful_stop);
    signal(SIGINT,  aah_graceful_stop);
    signal(SIGHUP,  aah_graceful_stop);
    signal(SIGSEGV, aah_crash_handler);
    signal(SIGABRT, aah_crash_handler);
    signal(SIGBUS,  aah_crash_handler);
    signal(SIGILL,  aah_crash_handler);
    signal(SIGFPE,  aah_crash_handler);

    // 写 pidfile
    {
        std::ofstream f(pidfile, std::ios::trunc);
        if (f.is_open()) f << getpid() << "\n";
    }
    chmod(pidfile.c_str(), 0644);

    // 自动重启：run() 退出后 3 秒重新进入
    int restarts = 0;
    while (!stop_requested_) {
        run();
        if (stop_requested_) break;
        if (access((data_dir_ + "/.aah_disabled").c_str(), F_OK) == 0) {
            log("disabled flag, not auto-restarting");
            break;
        }
        restarts++;
        if (restarts > 20) {
            log("too many restarts(" + std::to_string(restarts) + "), giving up");
            break;
        }
        log("daemon exited, restarting in 3s (try " + std::to_string(restarts) + ")");
        sleep(3);
    }
    _exit(0);
}

void AahNativeDaemon::stop() {
    std::string dir;
    {
        std::lock_guard<std::mutex> lk(mtx_);
        dir = data_dir_.empty() ? aah_paths::root() : data_dir_;
        running_ = false;
    }
    // 从 pid 文件找守护进程，先发 SIGTERM 再兜底 SIGKILL
    std::ifstream pf(dir + "/aah.pid");
    long pid = 0;
    if (pf) pf >> pid;
    if (pid > 1) {
        kill((pid_t)pid, SIGTERM);
        for (int i = 0; i < 20 && kill((pid_t)pid, 0) == 0; i++) {
            usleep(100000);
        }
        kill((pid_t)pid, SIGKILL);
        waitpid((pid_t)pid, nullptr, WNOHANG);
    }
    unlink((dir + "/aah.pid").c_str());
}

std::string AahNativeDaemon::exec(const std::string& cmd) {
    std::string result;
    std::string wrapped = "timeout 10 " + cmd;
    FILE* pipe = popen(wrapped.c_str(), "r");
    if (!pipe) return result;
    char buf[512];
    while (fgets(buf, sizeof(buf), pipe)) {
        result += buf;
    }
    pclose(pipe);
    while (!result.empty() && (result.back() == '\n' || result.back() == '\r')) {
        result.pop_back();
    }
    return result;
}

void AahNativeDaemon::log(const std::string& msg) {
    time_t now = time(nullptr);
    struct tm* tm = localtime(&now);
    char ts[32];
    snprintf(ts, sizeof(ts), "%02d:%02d:%02d", tm->tm_hour, tm->tm_min, tm->tm_sec);
    std::string line = "[" + std::string(ts) + "] " + msg + "\n";
    
    std::string logpath = data_dir_ + "/aah.log";
    FILE* f = fopen(logpath.c_str(), "a");
    if (f) {
        fputs(line.c_str(), f);
        fclose(f);
        // 模块私有目录本身 0700 root，普通 App 进不来；这里放宽到 0644 是为了
        // 让 SKPro 框架 App 进程能直接读取展示日志（否则框架 open aah.log 会 Permission denied）。
        chmod(logpath.c_str(), 0644);
    }
    // 日志截断：每写 50 条检查一次，超 900 行保留最后 200 行
    static int write_count = 0;
    if (++write_count >= 50) {
        write_count = 0;
        std::ifstream in(logpath);
        if (in) {
            std::vector<std::string> lines;
            std::string l;
            while (std::getline(in, l)) lines.push_back(l);
            in.close();
            if (lines.size() > 900) {
                std::ofstream out(logpath, std::ios::trunc);
                for (size_t i = lines.size() - 200; i < lines.size(); i++) {
                    out << lines[i] << "\n";
                }
            }
        }
    }
}

std::vector<std::string> AahNativeDaemon::get_users() {
    std::vector<std::string> users;
    std::string out = exec("pm list users 2>/dev/null | sed -n 's/.*UserInfo{\\([0-9][0-9]*\\).*/\\1/p'");
    if (out.empty()) {
        users.push_back("0");
        return users;
    }
    std::istringstream iss(out);
    std::string u;
    while (iss >> u) {
        if (!u.empty()) users.push_back(u);
    }
    if (users.empty()) users.push_back("0");
    return users;
}

std::string AahNativeDaemon::get_foreground_app() {
    // 优先用 dumpsys activity 的 ResumedActivity，用 grep 直接提取包名
    // 兼容任意 user（u0 主用户、u10/u120 双开/分身）：
    //   mResumedActivity: ActivityRecord{u10 com.pkg/.Activity t123}
    //   topResumedActivity=ActivityRecord{u0 com.pkg/.Activity t123}
    std::string out = exec("dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity' | sed -n 's/.*u[0-9]* \\([^ /]*\\).*/\\1/p'");
    if (!out.empty()) return out;
    // 兜底：dumpsys window
    out = exec("dumpsys window 2>/dev/null | grep -m1 mCurrentFocus | sed -n 's/.*u[0-9]* \\([^ /]*\\).*/\\1/p'");
    if (!out.empty()) return out;
    return "";
}

// 严格包名校验（与 aah_rule_manager.h 对齐），杜绝损坏规则文件里的非法条目
static bool is_valid_pkg_name(const std::string& pkg) {
    if (pkg.empty() || pkg.size() > 255) return false;
    bool has_dot = false, seg_empty = true;
    for (char ch : pkg) {
        if (ch == '.') {
            if (seg_empty) return false;
            has_dot = true; seg_empty = true;
        } else if (std::isalnum(static_cast<unsigned char>(ch)) || ch == '_') {
            seg_empty = false;
        } else {
            return false;
        }
    }
    return has_dot && !seg_empty;
}

std::vector<std::pair<std::string, std::vector<std::string>>> AahNativeDaemon::load_rules() {
    std::vector<std::pair<std::string, std::vector<std::string>>> rules;
    std::string rules_dir = data_dir_ + "/rules";
    DIR* dir = opendir(rules_dir.c_str());
    if (!dir) return rules;
    struct dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        std::string fname = ent->d_name;
        if (fname.size() < 5 || fname.substr(fname.size() - 5) != ".conf") continue;
        std::string game = fname.substr(0, fname.size() - 5);
        if (!is_valid_pkg_name(game)) continue;  // 非法文件名跳过
        std::vector<std::string> apps;
        std::ifstream f(rules_dir + "/" + fname);
        std::string line;
        while (std::getline(f, line)) {
            // 去回车、去注释、去空行
            while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
            if (line.empty() || line[0] == '#') continue;
            if (is_valid_pkg_name(line)) apps.push_back(line);  // 非法包名跳过
        }
        if (!apps.empty()) {
            rules.push_back({game, apps});
        }
    }
    closedir(dir);
    return rules;
}

static bool is_protected_pkg(const std::string& pkg) {
    // 必须与 aah_app_utils.h 的保护名单保持一致
    static const char* protected_pkgs[] = {
        "com.android.systemui", "com.android.phone", "com.android.settings",
        "com.android.dialer", "com.android.incallui", "com.google.android.dialer",
        "com.android.server.telecom", "com.miui.home", "com.android.launcher3",
        "com.google.android.gms", "com.android.providers.downloads", nullptr
    };
    for (int i = 0; protected_pkgs[i]; i++) {
        if (pkg == protected_pkgs[i]) return true;
    }
    return false;
}

bool AahNativeDaemon::hide_app(const std::string& pkg, const std::vector<std::string>& users, bool force_stop) {
    if (is_protected_pkg(pkg)) {
        log("hide-skip protected pkg=" + pkg);
        return false;
    }
    bool ok = false;
    for (const auto& u : users) {
        std::string r = exec("pm hide --user " + u + " " + pkg + " 2>&1");
        if (r.find("true") != std::string::npos) {
            ok = true;
        } else {
            // 回退 suspend
            exec("pm suspend --user " + u + " " + pkg + " >/dev/null 2>&1");
        }
    }
    if (ok) {
        // 隐藏后立即冻结进程（受 force_stop 配置控制）
        if (force_stop) {
            for (const auto& u : users) {
                exec("am force-stop --user " + u + " " + pkg + " >/dev/null 2>&1");
            }
        }
    }
    return ok;
}

bool AahNativeDaemon::restore_app(const std::string& pkg, const std::vector<std::string>& users) {
    bool ok = false;
    for (const auto& u : users) {
        exec("pm unsuspend --user " + u + " " + pkg + " >/dev/null 2>&1");
        std::string r = exec("pm unhide --user " + u + " " + pkg + " 2>&1");
        if (r.find("false") != std::string::npos) ok = true;
        exec("pm enable --user " + u + " " + pkg + " >/dev/null 2>&1");
        if (u == "0") exec("cmd package install-existing --user " + u + " " + pkg + " >/dev/null 2>&1");
    }
    return ok;
}

void AahNativeDaemon::force_stop_app(const std::string& pkg, const std::vector<std::string>& users) {
    for (const auto& u : users) {
        exec("am force-stop --user " + u + " " + pkg + " >/dev/null 2>&1");
    }
    // 双重保险：am force-stop 可能杀不干净有前台服务的应用，
    // 额外用 pidof + kill -9 兜底，确保被隐藏应用进程存活时间 < 500ms
    std::string pids = exec("pidof " + pkg + " 2>/dev/null");
    if (!pids.empty()) {
        exec("kill -9 " + pids + " >/dev/null 2>&1");
    }
}

void AahNativeDaemon::write_state(const std::set<std::string>& hidden) {
    std::string path = data_dir_ + "/aah.state";
    if (hidden.empty()) {
        unlink(path.c_str());
        return;
    }
    std::ofstream f(path, std::ios::trunc);
    for (const auto& p : hidden) f << p << "\n";
}

std::set<std::string> AahNativeDaemon::read_state() {
    std::set<std::string> result;
    std::ifstream f(data_dir_ + "/aah.state");
    std::string line;
    while (std::getline(f, line)) {
        while (!line.empty() && (line.back() == '\r' || line.back() == '\n')) line.pop_back();
        if (!line.empty()) result.insert(line);
    }
    return result;
}

void AahNativeDaemon::run() {
    // 开机早期 SKPro 加载进程的 PATH 可能不完整（缺 /system/bin），
    // 导致 popen("pm/dumpsys/am") 全部失败、daemon 空转。这里强制设置完整 PATH，
    // 不依赖父进程环境。
    setenv("PATH", "/system/bin:/system/xbin:/sbin:/vendor/bin", 1);
    // 写 PID 文件（用于内核隐藏自身）
    {
        std::ofstream f(data_dir_ + "/aah.pid", std::ios::trunc);
        f << getpid() << "\n";
    }
    chmod((data_dir_ + "/aah.pid").c_str(), 0644);
    log("native daemon started version=" AAH_VERSION);

    // 不等 PMS，直接进主循环。PMS 没就绪时 get_foreground_app() 返回空，
    // 主循环自动跳过；PMS 就绪后第一次查到前台时打 pms-ready 日志。
    bool pms_logged = false;
    time_t start_t = time(nullptr);

    // 启动时孤儿恢复：state 里有但规则里没有的包，恢复
    {
        auto rules = load_rules();
        std::set<std::string> managed;
        for (auto& r : rules) for (auto& a : r.second) managed.insert(a);
        auto orphan = read_state();
        for (auto& p : orphan) {
            if (managed.find(p) == managed.end()) {
                auto users = get_users();
                restore_app(p, users);
                log("orphan-restore: " + p);
            }
        }
    }

    std::string last_fg;
    while (!stop_requested_) {
        // 停用检查：读到 disabled 标记则恢复所有应用并退出
        if (flag_exists(data_dir_ + "/.aah_disabled")) {
            log("disabled flag detected, restoring all and exiting");
            auto users = get_users();
            for (const auto& pkg : current_hidden_) {
                restore_app(pkg, users);
            }
            current_hidden_.clear();
            write_state(current_hidden_);
            break;
        }
        auto users = get_users();
        auto rules = load_rules();
        AahRunConfig cfg = load_config(data_dir_);
        std::string fg = get_foreground_app();

        // PMS 就绪检测：第一次成功查到前台应用时打日志
        if (!pms_logged && !fg.empty()) {
            long waited = (long)(time(nullptr) - start_t);
            log("pms-ready after " + std::to_string(waited) + "s");
            pms_logged = true;
        }
        // PMS 没就绪（fg 为空）：这轮什么都不做，1 秒后重试
        if (fg.empty()) {
            sleep(1);
            continue;
        }
        
        // 计算需要隐藏的包
        std::set<std::string> should_hide;
        for (auto& r : rules) {
            const std::string& game = r.first;
            bool active = false;
            // 前台是触发应用
            if (fg == game) active = true;
            // 后台保持：仅在 keep_background=true 且 foreground_only=false 时检查进程
            if (!active && cfg.keep_background && !cfg.foreground_only) {
                std::string running = exec("pidof " + game + " 2>/dev/null");
                if (!running.empty()) active = true;
            }
            if (active) {
                for (auto& a : r.second) {
                    if (a != game) should_hide.insert(a); // 触发应用自身不隐藏
                }
            }
        }
        
        // 执行隐藏
        for (const auto& pkg : should_hide) {
            if (current_hidden_.find(pkg) == current_hidden_.end()) {
                log("hide-begin pkg=" + pkg + " users=" + [&](){
                    std::string s; for (auto& u : users) s += u + " "; return s;
                }());
                if (hide_app(pkg, users, cfg.force_stop)) {
                    current_hidden_.insert(pkg);
                    log("hide-done pkg=" + pkg);
                } else {
                    log("hide-fail pkg=" + pkg);
                }
            } else {
                // 已隐藏，持续强停（防止被重新拉起，受 force_stop 配置控制）
                if (cfg.force_stop) {
                    force_stop_app(pkg, users);
                }
            }
        }
        
        // 执行恢复
        std::set<std::string> to_restore;
        for (const auto& pkg : current_hidden_) {
            if (should_hide.find(pkg) == should_hide.end()) {
                to_restore.insert(pkg);
            }
        }
        for (const auto& pkg : to_restore) {
            if (restore_app(pkg, users)) {
                current_hidden_.erase(pkg);
                log("restore pkg=" + pkg);
            } else {
                log("restore-fail pkg=" + pkg + " (will retry next round)");
            }
        }
        
        // 更新状态文件
        write_state(current_hidden_);
        
        // 前台变化日志
        if (fg != last_fg) {
            if (!fg.empty()) log("fg: " + (last_fg.empty() ? "?" : last_fg) + " -> " + fg);
            last_fg = fg;
        }
        
        // 空闲日志（每 60 秒）
        static time_t last_idle_log = 0;
        time_t now = time(nullptr);
        if (should_hide.empty() && now - last_idle_log >= 60) {
            log("idle fg=" + (fg.empty() ? "?" : fg) + " rules=" + std::to_string(rules.size()));
            last_idle_log = now;
        }
        
        // 轮询间隔：默认 1 秒（隐藏延迟 1s 内用户几乎感知不到）；
        // 已有应用处于隐藏状态时降频到 500ms（更频繁地 force-stop + kill -9，
        // 确保被隐藏应用进程存活时间 < 500ms，游戏扫 /proc 几乎不可能抓到）。
        usleep(current_hidden_.empty() ? 1000000 : 500000);
    }
    
    // 退出前恢复所有
    auto users = get_users();
    for (const auto& pkg : current_hidden_) {
        restore_app(pkg, users);
    }
    current_hidden_.clear();
    write_state(current_hidden_);
    unlink((data_dir_ + "/aah.pid").c_str());
    log("native daemon stopped");
}
