LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := autorun
LOCAL_SRC_FILES := autorun.cpp
KERNEL_MODULE_KIT := $(LOCAL_PATH)/../../kernel_module_kit
LOCAL_C_INCLUDES += $(KERNEL_MODULE_KIT)/include
LOCAL_LDFLAGS += $(KERNEL_MODULE_KIT)/lib/libkernel_module_kit_static.a
LOCAL_CPPFLAGS := -std=c++20
include $(BUILD_SHARED_LIBRARY)