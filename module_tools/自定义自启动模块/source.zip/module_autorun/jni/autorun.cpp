#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <limits.h>
#include <fcntl.h>
#include "kernel_module_kit_umbrella.h"

SKROOT_MODULE_NAME("自定义自启动模块")
SKROOT_MODULE_VERSION("1.0.3")
SKROOT_MODULE_DESC("自动执行/data/adb/.zqd下所有文件")
SKROOT_MODULE_AUTHOR("蜃")
SKROOT_MODULE_ID32("d3f7a9c2e5b8f1a4d6c9e0b3f2a7c5e8")

int skroot_module_main(const char* root_key, const char* private_dir) {
    const char *target_dir = "/data/adb/.zqd";
    const char *launcher_name = "launcher";
    char target_path[PATH_MAX];
    char src_path[PATH_MAX];

    mkdir(target_dir, 0755);
    snprintf(target_path, sizeof(target_path), "%s/%s", target_dir, launcher_name);

    if (access(target_path, X_OK) != 0) {
        snprintf(src_path, sizeof(src_path), "%s/%s", private_dir, launcher_name);
        if (access(src_path, F_OK) == 0) {
            char cmd[PATH_MAX + 64];
            snprintf(cmd, sizeof(cmd), "cp %s %s && chmod +x %s", src_path, target_path, target_path);
            system(cmd);
        } else {
            return 0;
        }
    }

    if (access(target_path, X_OK) != 0) {
        return 0;
    }

    pid_t pid = fork();
    if (pid == 0) {
        // 关键：延迟 30 秒，等待系统完全初始化
        sleep(30);
        // 再次尝试检查系统是否就绪（可选）
        execl(target_path, target_path, (char *)NULL);
        _exit(1);
    }

    return 0;
}