#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <limits.h>
#include "kernel_module_kit_umbrella.h"

SKROOT_MODULE_NAME("自定义自启动模块")
SKROOT_MODULE_VERSION("1.0.2")
SKROOT_MODULE_DESC("启动/data/adb/.zqd目录下的所有.sh脚本")
SKROOT_MODULE_AUTHOR("蜃")
SKROOT_MODULE_ID32("d3f7a9c2e5b8f1a4d6c9e0b3f2a7c5e8")

int skroot_module_main(const char* root_key, const char* private_dir) {
    const char *dir_path = "/data/adb/.zqd";
    DIR *dir;
    struct dirent *entry;
    char full_path[PATH_MAX];
    struct stat st;

    dir = opendir(dir_path);
    if (dir == NULL) {
        mkdir(dir_path, 0755);
        return 0;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;

        char *dot = strrchr(entry->d_name, '.');
        if (dot == NULL || strcmp(dot, ".sh") != 0) continue;

        int len = snprintf(full_path, sizeof(full_path), "%s/%s", dir_path, entry->d_name);
        if (len < 0 || (size_t)len >= sizeof(full_path)) {
            continue;
        }

        if (stat(full_path, &st) != 0) continue;
        if (!S_ISREG(st.st_mode)) continue;
        if (st.st_size == 0) continue;

        pid_t pid = fork();
        if (pid == 0) {
            setenv("PATH", "/sbin:/system/sbin:/system/bin:/system/xbin", 1);
            setenv("ANDROID_ROOT", "/system", 1);
            setenv("LD_LIBRARY_PATH", "/system/lib:/system/lib64", 1);
            execl("/system/bin/sh", "sh", full_path, (char *)NULL);
            execl(full_path, full_path, (char *)NULL);
            _exit(1);
        }
    }

    closedir(dir);
    return 0;
}