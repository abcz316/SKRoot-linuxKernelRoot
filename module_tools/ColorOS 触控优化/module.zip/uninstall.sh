#!/system/bin/sh
# 卸载清理
if [ -n "$SKROOT_MODULE_DIR" ]; then
    MODDIR="$SKROOT_MODULE_DIR"
else
    MODDIR="$(cd "$(dirname "$0")" && pwd)"
fi
case "$MODDIR" in
    */) ;;
    *) MODDIR="$MODDIR/" ;;
esac

PID_FILE="${MODDIR}log/touch_opt.pid"

# 停止守护进程
if [ -f "$PID_FILE" ]; then
    pid=$(cat "$PID_FILE" 2>/dev/null)
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null
    fi
    rm -f "$PID_FILE"
fi

# 删除配置与日志（全部在模块私有目录，不碰外部路径）
rm -f ${MODDIR}common/games.conf
rm -f ${MODDIR}log/touch_opt.log*
rm -f ${MODDIR}log/touch_opt.pid
exit 0
