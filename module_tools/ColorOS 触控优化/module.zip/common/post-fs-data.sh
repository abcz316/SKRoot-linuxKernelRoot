#!/system/bin/sh
# 本脚本位于 common/，由 service.sh 手动调用
# 不使用/data/adb路径，全部在模块私有目录
true