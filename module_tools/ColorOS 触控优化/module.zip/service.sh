#!/system/bin/sh
# ColorOS触控优化 SKRootPro版

# 获取模块目录
if [ -n "$SKROOT_MODULE_DIR" ]; then
    MODDIR="$SKROOT_MODULE_DIR"
elif [ -n "$MODDIR" ]; then
    :
else
    MODDIR="$(cd "$(dirname "$0")" && pwd)"
fi

# 确保路径以/结尾
case "$MODDIR" in
    */) ;;
    *) MODDIR="$MODDIR/" ;;
esac

CONF_DIR="${MODDIR}common"
LOG_DIR="${MODDIR}log"
PID_FILE="$LOG_DIR/touch_opt.pid"
LOG_FILE="$LOG_DIR/touch_opt.log"

mkdir -p "$LOG_DIR" "$CONF_DIR"

# ---------- 日志（分级） ----------
log_i() { echo "$(date) [INFO] $1" >> "$LOG_FILE"; }
log_w() { echo "$(date) [WARN] $1" >> "$LOG_FILE"; }
log_e() { echo "$(date) [ERROR] $1" >> "$LOG_FILE"; }

log_i "=== ColorOS触控优化 SKP版启动 ==="
log_i "模块目录: $MODDIR"

# 等待系统完全启动
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done
sleep 10

# 执行 post-fs-data.sh
if [ -f "$MODDIR/common/post-fs-data.sh" ]; then
    sh "$MODDIR/common/post-fs-data.sh"
fi

# 检查二进制是否存在且可执行
if [ ! -x "$MODDIR/common/touch_opt" ]; then
    log_e "未找到可执行的 touch_opt 二进制，模块不启动"
    exit 0
fi
chmod 755 "$MODDIR/common/touch_opt"

# 初始化配置文件（如果不存在，放在模块私有目录，不暴露到外部）
CONF_FILE="${CONF_DIR}/games.conf"
if [ ! -f "$CONF_FILE" ]; then
    cat > "$CONF_FILE" << 'EOF'
# 触控优化配置
# 全局配置
config 游戏采样率=420, 日用采样率=240, touch_node=182, stop_horae=1

# 游戏列表（每行一个包名，自行添加）
EOF
    log_i "已生成默认配置文件 $CONF_FILE"
fi

# ---------- 启动守护进程 ----------
start_daemon() {
    nohup "$MODDIR/common/touch_opt" >/dev/null 2>&1 &
    log_i "守护进程已启动 (PID $!)"
}

# 清理旧 PID 文件
rm -f "$PID_FILE"

# ---------- 自愈守护 ----------
start_daemon
while true; do
    sleep 30    # 每30秒检查一次，加快保活频率
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            continue
        fi
    fi
    log_w "检测到守护进程退出，自动重启"
    start_daemon
done
