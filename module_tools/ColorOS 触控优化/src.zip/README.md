# ColorOS 触控优化 SKRootPro版

## 模块介绍
基于Go守护进程的ColorOS触控采样率动态调度引擎。
前台游戏自动360Hz，日常自动恢复省电，内置保活对抗与守护自愈。

## 编译方法
1. 安装Android NDK r26d
2. cd jni
3. ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk NDK_APPLICATION_MK=Application.mk
4. 编译生成的so文件在libs/arm64-v8a/

## 模块结构
- coloros_touch.cpp - 模块主源码
- kernel_module_kit - SKRootPro SDK
- jni/ - 编译配置
- module_pkg/ - 模块打包文件

## 作者
1021
