#include "kernel_module_kit_umbrella.h"
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <sys/wait.h>

// 读取文件内容
std::string read_file(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return "";
    std::stringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

// 写入文件
bool write_file(const std::string& path, const std::string& content) {
    std::ofstream file(path);
    if (!file.is_open()) return false;
    file << content;
    return true;
}

// SKRoot模块入口函数
int skroot_module_main(const char* root_key, const char* module_private_dir) {
    printf("[ColorOSTouch] 模块启动, dir=%s\n", module_private_dir);
    
    // 启动守护进程
    std::string daemon_path = std::string(module_private_dir) + "/common/touch_opt";
    std::string log_path = std::string(module_private_dir) + "/log/touch_opt.log";
    
    pid_t pid = fork();
    if (pid == 0) {
        // 子进程
        freopen(log_path.c_str(), "a", stdout);
        freopen(log_path.c_str(), "a", stderr);
        execl(daemon_path.c_str(), "touch_opt", NULL);
        _exit(1);
    }
    
    printf("[ColorOSTouch] 守护进程已启动, PID=%d\n", pid);
    return 0;
}

// WebUI HTTP服务器回调函数
class ColorTouchWebHandler : public kernel_module::WebUIHttpHandler {
public:
    std::string module_dir;
    
    void onPrepareCreate(const char* root_key, const char* module_private_dir, uint32_t port) override {
        module_dir = module_private_dir;
        printf("[ColorOSTouch] WebUI启动, port=%d, dir=%s\n", port, module_private_dir);
    }

    bool handleGet(CivetServer* server, struct mg_connection* conn, const std::string& path, const std::string& query) override {
        printf("GET: %s\n", path.c_str());
        
        if (path == "/getLog") {
            std::string log_path = module_dir + "/log/touch_opt.log";
            std::string log = read_file(log_path);
            kernel_module::webui::send_text(conn, 200, log);
            return true;
        }
        else if (path == "/getStatus") {
            std::string log_path = module_dir + "/log/touch_opt.log";
            std::string log = read_file(log_path);
            std::string status = log.empty() ? "pending" : "completed";
            kernel_module::webui::send_text(conn, 200, "{\"status\":\"" + status + "\"}");
            return true;
        }
        else if (path == "/getPackages") {
            std::string conf = read_file("/data/games.conf");
            kernel_module::webui::send_text(conn, 200, conf);
            return true;
        }
        
        return false;
    }

    bool handlePost(CivetServer* server, struct mg_connection* conn, const std::string& path, const std::string& body) override {
        printf("POST: %s, body=%s\n", path.c_str(), body.c_str());
        
        if (path == "/setPackages") {
            write_file("/data/games.conf", body);
            kernel_module::webui::send_text(conn, 200, "OK");
            return true;
        }
        else if (path == "/restart") {
            // 重启守护进程
            system("pkill touch_opt");
            std::string daemon_path = module_dir + "/common/touch_opt";
            std::string cmd = "nohup " + daemon_path + " >/dev/null 2>&1 &";
            system(cmd.c_str());
            kernel_module::webui::send_text(conn, 200, "OK");
            return true;
        }
        
        return false;
    }
};

// SKRoot 模块名片
SKROOT_MODULE_NAME("ColorOS 触控优化")
SKROOT_MODULE_VERSION("1.0.0")
SKROOT_MODULE_DESC("ColorOS触控采样率动态调度引擎")
SKROOT_MODULE_AUTHOR("1021")
SKROOT_MODULE_ID32("a1b2c3d4e5f67890abcdef1234567890")
SKROOT_MODULE_WEB_UI(ColorTouchWebHandler)
